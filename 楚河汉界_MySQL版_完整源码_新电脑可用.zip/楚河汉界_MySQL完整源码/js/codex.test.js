import game, { createBoard } from './gameData.js';
import { SPELLS } from './config.js';

export async function runCodexTests() {
  let passed = 0;
  const check = (ok, msg) => { if (!ok) throw Error(msg); passed++; };
  const descriptor = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
  const data = {};
  const storage = { getItem: key => data[key] ?? null, setItem: (key, value) => { data[key] = value; } };
  try {
    Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: storage });
    const m = await import('./codex.js?test=' + Date.now());
    const b = createBoard('me'), opp = createBoard('opp');
    const groups = m.codexSpellGroups();
    check(groups.length === 6 && groups.every(g => g.spells.length === 6), '三十六计六类每类六计');
    check(groups.flatMap(g => g.spells).every((s,i) => s.id === SPELLS[i].id), '按三十六计原顺序');
    check(!m.isCodexUnlocked('pieces','ma') && !m.isCodexUnlocked('spells','yiyidailao'), '新账号未解锁');
    check(!m.recordCodex('pieces','ma',opp), 'AI不解锁玩家图鉴');
    b._simulationContext = {}; check(!m.recordCodex('pieces','ma',b), '模拟不解锁'); delete b._simulationContext;
    check(m.recordCodex('pieces','ma',b) && m.isCodexUnlocked('pieces','ma'), '玩家实际使用解锁');
    check(!m.recordCodex('pieces','ma',b), '重复使用不重复写入');
    check(m.recordCodex('spells','yiyidailao',b) && m.isCodexUnlocked('spells','yiyidailao'), '法术解锁');
    check(!m.recordCodex('spells','invalid',b), '未知条目不入存档');
    const restored = await import('./codex.js?restore=' + Date.now());
    check(restored.isCodexUnlocked('pieces','ma') && restored.isCodexUnlocked('spells','yiyidailao'), '重新加载保留进度');
    b.pieces = [{type:'shi'}]; b.shopSlots[0]={source:'fromBoard',piece:{type:'ju'}};
    b.shopSlots[1]={source:'native',type:'piece',piece:{type:'xiang'}};
    m.recordOwnedPieces(b);
    check(m.isCodexUnlocked('pieces','shi') && m.isCodexUnlocked('pieces','ju') && !m.isCodexUnlocked('pieces','xiang'), '场上和已合成商店棋子解锁、未买不解锁');
    storage.setItem = () => { throw Error('blocked'); };
    check(m.recordCodex('pieces','pao',b) && m.isCodexUnlocked('pieces','pao'), '存储失败保留会话解锁');
    check(game.cur !== b, '不改变棋盘上下文');
    return {passed};
  } finally { if (descriptor) Object.defineProperty(globalThis,'localStorage',descriptor); else delete globalThis.localStorage; }
}
