/** 每方棋盘独立计算上限；帅单独存放在 board.king，不占棋子名额。 */
export const MAX_BOARD_PIECES = 10;
export const BOARD_CAPACITY_REASON = `场上棋子已达上限（${MAX_BOARD_PIECES}枚）`;

export function hasBoardCapacity(board) {
  return board.pieces.length < MAX_BOARD_PIECES;
}
