/** 只使用显式快照的有限出怪计划；不读取 game、正式调度、商店或随机。
 * 时间以私有调度 tick 的结束为准；事件在该 tick 战斗更新前出生。
 * 调用者须确认双方帅已到位且时钟正在运行；否则传 schedulerReady:false。
 */
import { spawnIntervalForWave } from './config.js';
import { enemySpecForSpawn } from './boss.js';

const MAX_HORIZON = 30;
const MAX_STEPS = 7200;

export function buildSpawnPlan(sharedWaves, options = {}) {
  const { horizon = 10, step = 1 / 30, WAVES, ENEMY, schedulerReady = true } = options;
  if (!sharedWaves || !WAVES || !ENEMY) throw new TypeError('explicit sharedWaves, WAVES and ENEMY required');
  if (!Number.isFinite(horizon) || !Number.isFinite(step) || step <= 0) {
    throw new TypeError('finite horizon and positive step required');
  }
  const finite = (value, name) => {
    if (!Number.isFinite(value)) throw new TypeError(`${name} must be finite`);
  };
  for (const key of ['wave', 'waveToSpawn', 'spawnedInWave', 'countInWave']) {
    if (!Number.isSafeInteger(sharedWaves[key]) || sharedWaves[key] < (key.startsWith('wave') ? 1 : 0)) {
      throw new TypeError(`invalid sharedWaves.${key}`);
    }
  }
  finite(sharedWaves.timer, 'timer');
  for (const key of ['firstWaveCount', 'countGrowPerWave', 'spawnInterval', 'waveInterval', 'startDelay']) {
    finite(WAVES[key], `WAVES.${key}`);
    if (WAVES[key] < 0) throw new TypeError(`negative WAVES.${key}`);
  }
  for (const key of ['baseHp', 'baseSpeed', 'hpGrowPerWave', 'speedGrowPerWave']) finite(ENEMY[key], `ENEMY.${key}`);
  if (ENEMY.hpDoubleAfterWave != null) {
    finite(ENEMY.hpDoubleAfterWave, 'ENEMY.hpDoubleAfterWave');
    finite(ENEMY.hpDoubleFactor, 'ENEMY.hpDoubleFactor');
  }
  const duration = Math.max(0, Math.min(MAX_HORIZON, horizon));
  const dt = Math.max(1 / 240, Math.min(1 / 30, step));
  // 只复制调度字段；不复制/推断双方棋盘或未来清空。
  const w = {
    wave: sharedWaves.wave, waveToSpawn: sharedWaves.waveToSpawn, timer: sharedWaves.timer,
    spawnedInWave: sharedWaves.spawnedInWave, countInWave: sharedWaves.countInWave,
    betweenWaves: !!sharedWaves.betweenWaves, countdown: !!sharedWaves.countdown,
  };
  const events = [];
  let elapsed = 0;
  let uncertainBoundary = null;
  const boundary = reason => Object.freeze({ at: elapsed, wave: w.wave, nextWave: w.waveToSpawn, reason });
  if (!schedulerReady) uncertainBoundary = boundary('scheduler-not-ready');
  else if (w.spawnedInWave >= w.countInWave && (!w.betweenWaves || !w.countdown)) {
    uncertainBoundary = boundary('awaiting-any-board-clear');
  }
  for (let ticks = 0; !uncertainBoundary && elapsed < duration - 1e-9 && ticks < MAX_STEPS; ticks++) {
    // 已出完而未锁存 countdown：任一盘何时清空未知。即使本地是空盘也不代替双方调度。
    if (w.spawnedInWave >= w.countInWave && (!w.betweenWaves || !w.countdown)) {
      uncertainBoundary = boundary('awaiting-any-board-clear');
      break;
    }
    const tick = Math.min(dt, duration - elapsed);
    elapsed += tick;
    if (w.spawnedInWave < w.countInWave) {
      w.timer -= tick;
      if (w.timer <= 0) {
        const spec = enemySpecForSpawn(w.wave, w.spawnedInWave, ENEMY);
        const { hp, speed } = spec;
        if (!(hp > 0) || speed < 0 || !Number.isFinite(hp) || !Number.isFinite(speed)) {
          throw new TypeError('invalid generated enemy stats');
        }
        events.push(Object.freeze({ at: elapsed, wave: w.wave, ...spec }));
        w.spawnedInWave++;
        w.timer = spawnIntervalForWave(w.wave); // 与正式调度相同，不保留余量。
        if (w.spawnedInWave >= w.countInWave) uncertainBoundary = boundary('awaiting-any-board-clear');
      }
    } else {
      // 只有快照中已经锁存的 countdown 可以跨越边界。
      w.timer -= tick;
      if (w.timer <= 0) {
        w.wave = w.waveToSpawn++;
        w.countInWave = WAVES.firstWaveCount + (w.wave - 1) * WAVES.countGrowPerWave;
        w.spawnedInWave = 0;
        w.timer = 0;
        w.betweenWaves = false;
        w.countdown = false;
        // 正式规则只开波，本 tick 不出第一只；下一 tick 才生成。
      }
    }
  }
  return Object.freeze({ events: Object.freeze(events), uncertainBoundary, horizon: duration, step: dt,
    truncated: horizon > MAX_HORIZON });
}

export default buildSpawnPlan;
