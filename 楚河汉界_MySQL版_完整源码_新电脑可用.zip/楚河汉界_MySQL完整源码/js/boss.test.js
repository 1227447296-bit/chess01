/** 无DOM Boss回归：显式runBossFixtures()，不启动浏览器、不读取原版。 */
import game, { createBoard, withBoard } from './gameData.js';
import { WAVES, ENEMY, RES, enemyStatsForWave, spawnIntervalForWave } from './config.js';
import { BOSS, enemySpecForSpawn, activeBossAnnouncement } from './boss.js';
import { sharedWaves, updateSharedWaves, registerWaveEnemy, update, updateCombat,
  jumpToWave, startGame } from './wave.js';
import { buildSpawnPlan } from './aiSpawnPlan.js';
import { simulateCombat } from './aiSimulation.js';

export function runBossFixtures() {
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(`Boss: ${name}`); };
  const near = (a, b) => Math.abs(a - b) < 1e-7;
  const saved = { cur: game.cur, phase: game.phase, scheduler: { ...sharedWaves } };
  const board = side => createBoard(side, {
    cols: 300, rows: 2, ground: [], grass: [], road: [],
    path: Array.from({ length: 300 }, (_, c) => ({ c, r: 0 })),
    enemySpawn: { c: 0, r: 0 }, kingPoint: { c: 299, r: 0 },
  });
  const fields = ['hp', 'speed', 'isBoss', 'bossWave', 'spawnIndex', 'displayName', 'spriteKey', 'spriteScale'];
  const match = (a, b) => fields.every(key => a[key] === b[key]);
  try {
    game.phase = 'playing';
    check('只复用实际已配置敌人素材', RES.images[BOSS.spriteKey] === 'piece/green_character.png');
    check('第三次王提前到20波且25波不再出王', enemySpecForSpawn(20, 0).isBoss && !enemySpecForSpawn(25, 0).isBoss);
    let previousHp = 0;
    for (const wave of [8, 15, 20]) {
      const count = WAVES.firstWaveCount + (wave - 1) * WAVES.countGrowPerWave;
      const state = { wave, waveToSpawn: wave + 1, timer: 0, spawnedInWave: 0,
        countInWave: count, betweenWaves: false, countdown: false };
      const plan = buildSpawnPlan(state, { WAVES, ENEMY, horizon: 30 });
      const me = board('me'), opp = board('opp'); me.spawned = 999;
      Object.assign(sharedWaves, state);
      for (let i = 0; i < count; i++) updateSharedWaves(i ? spawnIntervalForWave(wave) : 0, [me, opp]);
      const boss = me.enemies[0], ordinary = enemyStatsForWave(wave);
      check(`${wave}波双方同数且仅首位一个王`, me.enemies.length === count && opp.enemies.length === count &&
        [me, opp].every(b => b.enemies.filter(e => e.isBoss).length === 1 && b.enemies[0].isBoss));
      check(`${wave}波Boss显著高血且减速`, boss.hp === ordinary.hp * BOSS.waves[wave].hpMultiplier &&
        boss.maxHp === boss.hp && boss.speed < ordinary.speed && boss.hp > previousHp);
      previousHp = boss.hp;
      check(`${wave}波保留敌人kind且独立出生标志`, boss.kind === 'enemy' && boss.spawnWave === wave &&
        boss.bossWave === wave && boss.spawnIndex === 0 && me.spawned === 999 + count);
      check(`${wave}波显示王与寇并扩大Boss`, boss.displayName === '王' && boss.spriteScale > 1 &&
        me.enemies.slice(1).every(e => e.displayName === '寇' && e.spriteScale === 1 && !e.isBoss && e.hp === ordinary.hp));
      check(`${wave}波计划窗口内数量与真实规格一致`, plan.events.length > 0 && plan.events.length <= count && plan.events.every(event => match(event, enemySpecForSpawn(wave, event.spawnIndex))));
      check(`${wave}波双方出怪规格一致`, me.enemies.every((e, i) => match(e, opp.enemies[i])));
      check(`${wave}波Boss不增加波次账本预期`, me.waveClearState[wave].expected === count && me.waveClearState[wave].spawned === count);
      const sim = simulateCombat(board('opp'), { horizon: 30, spawnPlan: plan.events });
      check(`${wave}波推演保留完整Boss字段`, sim.generatedCount === plan.events.length && sim.board.enemies.every((e, i) => match(e, me.enemies[i])));
      check(`${wave}波推演HP预算包含Boss`, near(sim.generatedHp, plan.events.reduce((sum, e) => sum + e.hp, 0)));
      const notice = activeBossAnnouncement(me);
      check(`${wave}波真出生才出现短时提示`, notice?.text === '王从天降' && notice.wave === wave && near(notice.until - notice.startedAt, 2.4));
      registerWaveEnemy(me, boss, wave);
      check(`${wave}波重复登记不重放提示`, me.bossAnnouncement === notice);
      game.phase = 'paused'; withBoard(me, () => update(10));
      check(`${wave}波暂停不消耗提示`, activeBossAnnouncement(me) === notice);
      game.phase = 'playing'; withBoard(me, () => update(2.5));
      check(`${wave}波提示到时清理`, me.bossAnnouncement === null && activeBossAnnouncement(me) === null);
      const partial = buildSpawnPlan({ ...state, spawnedInWave: 1 }, { WAVES, ENEMY, horizon: 30 });
      check(`${wave}波中途计划不会重复生王`, partial.events.length === Math.min(count - 1, plan.events.length) && partial.events.every(e => !e.isBoss));
    }
    for (const wave of [1, 5, 7, 9, 12, 14, 16, 24, 26]) {
      const spec = enemySpecForSpawn(wave, 0), ordinary = enemyStatsForWave(wave);
      check(`${wave}非Boss波保持普通规格`, !spec.isBoss && spec.hp === ordinary.hp && spec.speed === ordinary.speed);
    }
    const rewardBoards = [board('me'), board('opp')];
    for (const [index, b] of rewardBoards.entries()) {
      const spec = enemySpecForSpawn(8, index);
      const e = { id: `reward-${index}`, kind: 'enemy', c: 0, r: 0, fx: 0, fy: 0,
        ...spec, hp: 1, maxHp: 1, speed: 0, progress: 0, done: false, dying: false, deathT: 0 };
      b.enemies = [e]; registerWaveEnemy(b, e, 8);
      b.pieces = [{ id: 'bing', kind: 'piece', type: 'bing', color: 'red', c: 0, r: 1,
        level: 0, exp: 0, stage: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [] }];
      withBoard(b, () => updateCombat(0));
    }
    check('Boss击杀无额外金币或经验', rewardBoards.every(b => b.kills === 1) &&
      rewardBoards[0].gold === rewardBoards[1].gold && rewardBoards[0].pieces[0].exp === rewardBoards[1].pieces[0].exp);
    const leak = board('me'); leak.enemies = [{ ...rewardBoards[0].enemies[0], id: 'leak',
      hp: 1, dying: false, progress: 298.999, speed: 1, _waveRegistered: false, _waveOutcome: null, _waveRemoved: false }];
    registerWaveEnemy(leak, leak.enemies[0], 8);
    const lives = leak.lives, gold = leak.gold;
    withBoard(leak, () => update(0.1));
    check('Boss漏怪只扣一点血且不加金币', leak.lives === lives - 1 && leak.gold === gold && leak.enemies.length === 0);
    const reset = rewardBoards[0];
    jumpToWave(8, [reset]); check('跳波清除旧提示', reset.bossAnnouncement === null);
    updateSharedWaves(0, [reset]); check('跳入Boss波仍正确出生王', reset.enemies[0].isBoss);
    withBoard(reset, startGame); check('重开清除Boss和提示', reset.bossAnnouncement === null && reset.enemies.length === 0);
    check('恢复当前棋盘引用', game.cur === saved.cur);
    return { ok: true, count: checks.length, checks };
  } finally {
    game.cur = saved.cur; game.phase = saved.phase; Object.assign(sharedWaves, saved.scheduler);
  }
}
export default runBossFixtures;
