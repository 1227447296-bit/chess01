/** 独立教学关：真实 board1 地图与正式 actions；不参与段位结算。 */
import game, { createBoard } from './gameData.js';
import { RANK_SAVE_KEY, enemyStatsForWave, GOLD_ON_KILL } from './config.js';
import { loadMap } from './mapLoader.js';

export const TUTORIAL_KEY = 'cnchess.experimental.tutorial.v1';
export const TUTORIAL_ACTION_REASON = '请按提示要求操作';
export const TUTORIAL_CELLS = Object.freeze({
  first: { c: 1, r: 1 }, shovel: { c: 2, r: 4 },
  black: { c: 1, r: 5 }, bond: { c: 2, r: 5 },
});
// board1 的右下三行草地：不覆盖道路、帅、棋子或任一教学目标。
export const TUTORIAL_PANEL_RECT = Object.freeze({ c: 1, r: 6, cols: 3, rows: 3 });
export const TUTORIAL_DEFENSE_STEP = 6;
let sessionChoice = null;
export function shouldOfferTutorial(storage) {
  if (sessionChoice) return false;
  try {
    storage ??= globalThis.localStorage;
    if (['skipped', 'completed'].includes(storage.getItem(TUTORIAL_KEY))) return false;
    for (const key of [RANK_SAVE_KEY, RANK_SAVE_KEY + '.backup']) {
      try {
        const s = JSON.parse(storage.getItem(key));
        if (s && Number.isInteger(s.tier) && Number.isInteger(s.sub)) return false;
      } catch { /* 损坏主存档仍检查备份 */ }
    }
  } catch { /* 存储不可用也可进行教程 */ }
  return true;
}
export function rememberTutorial(choice, storage) {
  sessionChoice = choice;
  try { (storage ?? globalThis.localStorage).setItem(TUTORIAL_KEY, choice); return true; } catch { return false; }
}
export const tutorialActive = () => !!game.boards.me?.tutorial;
const nativeBing = () => ({ source: 'native', type: 'piece', kind: 'bing', color: 'red', level: 0, stage: 0, price: 6 });
export async function createTutorialBoards() {
  // 使用现有异步解析/缓存，绝不复制或改写 TMX 地形。cleared 由 createBoard 独立创建。
  const map = await loadMap(1);
  const me = createBoard('me', map), opp = createBoard('opp', map);
  const end = map.kingPoint;
  for (const b of [me, opp]) b.king = { id: `tutorial-${b.side}-king`, kind: 'king', type: 'king', color: 'red',
    ...end, fx: end.c, fy: end.r, progress: map.path.length - 1, arrived: true };
  me.gold = 36; me.totalRefreshCount = 0;
  me.tutorial = { step: -1, spawned: 0, spawnTimer: 0, targetId: null };
  me.shopSlots = Array(5).fill(null);
  me.pieces.push({ id: 'tutorial-black-bing', kind: 'piece', type: 'bing', color: 'black',
    ...TUTORIAL_CELLS.black, level: 10, exp: 0, stage: 0, mergeCount: 0, atkBonus: 0,
    flags: {}, cdLeft: 0, bonds: [] });
  return { me, opp };
}
export const TUTORIAL_STEPS = [
  { title: '放置棋子', text: '你有36金币。将商店红兵拖到闪亮空地（第2列第2行）。红黑都是你的友军；道路不能放棋子。', cell: TUTORIAL_CELLS.first, slot: 0 },
  { title: '融合棋子', text: '将新红兵拖到闪亮红兵上。相同种类、颜色可融合：阶数相加再+1，等级相加再+3；兵融合到3阶会随机进化。', cell: TUTORIAL_CELLS.first, slot: 0 },
  { title: '使用铲子', text: '将铲子拖到闪亮草地（第3列第5行），花1金币开垦。只能铲指定格；道路不能铲，每局最多用10把。', cell: TUTORIAL_CELLS.shovel, slot: 0 },
  { title: '补充防线', text: '将红兵拖到刚开垦的闪亮空地（第3列第5行）。棋子攻击范围遵循象棋规则，点击棋子可查看详情。', cell: TUTORIAL_CELLS.shovel, slot: 0 },
  { title: '激活羁绊', text: '已预放黑卒Lv.10。将商店红兵（已Lv.10）拖到它右侧的闪亮空地（第3列第6行）。红兵黑卒横竖相邻，两者都达10级，激活”二鬼拍门”，每10秒+1金币。', cell: TUTORIAL_CELLS.bond, slot: 0 },
  { title: '使用法术', text: '将“以逸待劳”拖到闪亮的融合兵上，花6金币获得10秒伤害+25%。法术有不同目标与价格，每种本局库存1次。', cell: TUTORIAL_CELLS.first, slot: 0 },
  { title: '防守与胜负', text: `点击“开始防守”观察3名敌人。每击杀1敌+${GOLD_ON_KILL.default}金币，用于购买和刷新；漏1敌扣1心，生命归零失败。正式局对手先归零则获胜；同轮归零按漏怪、击杀判定。教学清完3敌即完成，不计段位。` },
];
export function tutorialInstruction(board = game.boards.me) {
  if (board.tutorial?.step === -1) return { title: '1 / 8 · 刷新商店',
    text: '点击下方“刷新（免费）”获得卡牌。每局首次刷新免费，后续花金币且价格逐次增加；顺手牵羊可优惠下次刷新。教程提供指定卡牌，请按闪亮目标操作。' };
  const info = TUTORIAL_STEPS[board.tutorial?.step];
  return info ? { ...info, title: `${board.tutorial.step + 2} / 8 · ${info.title}` } : null;
}

/** 教程限制只作用于标记的教学盘，正式盘与AI不受影响。 */
export function tutorialActionAllowed(kind, args) {
  const t = game.cur.tutorial;
  if (!t || game.cur !== game.boards.me) return true;
  if (t.finished || t.failed || t.defending) return false;
  const [slot, c, r] = args;
  if (t.step === -1) return kind === 'refresh' && game.cur.totalRefreshCount === 0;
  if ([0, 3, 4].includes(t.step)) return kind === 'buyAndPlace' && slot === 0 &&
    c === TUTORIAL_STEPS[t.step].cell.c && r === TUTORIAL_STEPS[t.step].cell.r;
  if (t.step === 1) return kind === 'shopToPiece' && slot === 0 && args[1]?.id === t.targetId;
  if (t.step === 2) return kind === 'useShovel' && slot === 0 && c === TUTORIAL_CELLS.shovel.c && r === TUTORIAL_CELLS.shovel.r;
  if (t.step === 5) return kind === 'useSpell' && slot === 0 && args[1]?.id === t.targetId;
  return false;
}
export function advanceTutorial(board = game.boards.me) {
  const t = board.tutorial;
  if (!t || t.step >= TUTORIAL_DEFENSE_STEP) return false;
  if (t.step === -1) {
    if (!board.totalRefreshCount) return false;
    t.step = 0;
    board.shopSlots = [nativeBing(), null, null, null, null];
    return true;
  }
  const first = board.pieces.find(p => p.c === TUTORIAL_CELLS.first.c && p.r === TUTORIAL_CELLS.first.r);
  const ready = [!!first, first?.stage === 1, board.map.cleared.has('2,4'),
    board.pieces.some(p => p.c === 2 && p.r === 4),
    board.bonds.some(b => b.key === 'bing_bing' && (b.aId === 'tutorial-black-bing' || b.bId === 'tutorial-black-bing')),
    board.spellUsed.yiyidailao === 1][t.step];
  if (!ready) return false;
  if (t.step === 0) t.targetId = first.id;
  t.step++;
  board.shopSlots = Array(5).fill(null);
  if ([1, 3].includes(t.step)) board.shopSlots[0] = nativeBing();
  if (t.step === 4) board.shopSlots[0] = { ...nativeBing(), level: 10 };
  if (t.step === 2) board.shopSlots[0] = { source: 'native', type: 'shovel' };
  if (t.step === 5) board.shopSlots[0] = { source: 'native', type: 'spell', id: 'yiyidailao', price: 6 };
  return true;
}
export function startTutorialDefense(board = game.boards.me) {
  if (board.tutorial?.step !== TUTORIAL_DEFENSE_STEP || board.tutorial.defending) return false;
  board.tutorial.defending = true;
  board.tutorial.spawnTimer = 0;
  return true;
}
export function nextTutorialEnemy(board, dt) {
  const t = board.tutorial;
  if (!t?.defending || t.spawned >= 3) return null;
  t.spawnTimer -= dt;
  if (t.spawnTimer > 0) return null;
  t.spawnTimer = 3; t.spawned++;
  const spawn = board.map.enemySpawn;
  // 首敌承受教学法术增伤，稍厚一些；后续敌人也能走到中段供玩家观察。
  const hp = t.spawned === 1 ? 96 : 72;
  return { id: `tutorial-enemy-${t.spawned}`, kind: 'enemy', ...spawn, fx: spawn.c, fy: spawn.r, progress: 0,
    hp, maxHp: hp, speed: enemyStatsForWave(1).speed, done: false, dying: false, deathT: 0, stunLeft: 0, stunImmuneLeft: 0,
    displayName: '寇', spriteKey: 'green_character', spriteScale: 1 };
}
