/**
 * cheats.js —— 测试码（测试用）
 * 在开始页 / 暂停菜单的输入框里输入，回车执行。命令不区分大小写，输入 help 查看全部。
 *
 * 局内命令作用于我方棋盘（游戏未开始时会提示「需在对局中使用」）。
 */
import { PIECE_STATS, SPELLS, SPELL_BY_ID, RANKS, AI_PROFILES } from './config.js';
import game, { addGold, isPlaceablePlot, uid, currentRefreshCost } from './gameData.js';
import * as rank from './rank.js';
import { setForcedTier, setAIPaused, aiInfo } from './ai.js';
import { doMerge } from './synthesis.js';
import { afterBoardChange, placePiece } from './actions.js';
import * as shop from './shop.js';

/** main 注入的回调：结束对局、刷新界面、调速、自动下棋、显示对手商店 */
let hooks = {
  finish: () => {}, refreshUI: () => {}, setSpeed: () => {},
  toggleAuto: () => false, toggleSeeShop: () => false, inGame: () => false,
  jumpWave: () => {},
};
export function setCheatHooks(h) { hooks = { ...hooks, ...h }; }

const TYPE_ALIAS = {
  bing: 'bing', 兵: 'bing', shi: 'shi', 士: 'shi', xiang: 'xiang', 象: 'xiang',
  ma: 'ma', 马: 'ma', ju: 'ju', 车: 'ju', che: 'ju', pao: 'pao', 炮: 'pao',
};
const COLOR_ALIAS = { red: 'red', 红: 'red', r: 'red', black: 'black', 黑: 'black', b: 'black' };

const HELP = [
  'gold 999 —— 我方金币 +999',
  'lv 50 —— 选中棋子设为 50 级（未选中则我方全部）',
  'stage 1 —— 选中棋子阶数 +1（满足则进化）',
  'give ju red —— 空地生成棋子（bing/shi/xiang/ma/ju/pao, red/black）',
  'spell heyi —— 商店空位放入法术（不填则随机）',
  'shovel —— 商店空位放入铲子',
  'refresh —— 免费刷新商店',
  'wave 15 —— 双方跳到第 15 波',
  'god —— 我方不掉红心（开关）',
  'heart 3 —— 我方红心设为 3',
  'win / lose / draw —— 立即结束并结算',
  'speed 2 —— 游戏速度 1~5 倍',
  'ai stop / ai go —— 暂停 / 恢复对手 AI',
  'ai 6 —— 强制对手 AI 档位 0~7（ai auto 恢复自动）',
  'auto / auto 3 —— 我方也由 AI 下棋（开关；可指定档位 0~7，默认 4）',
  'seeshop —— 显示对手商店（开关）',
  'rank 黄金 3 2 —— 设置段位（大段 小段 星）',
  'star +5 / star -2 —— 加 / 减星（按规则升降）',
  'resetrank —— 清空段位存档',
];

const needGame = () => (hooks.inGame() ? null : '需在对局中使用');
const firstEmptySlot = () => game.shopSlots.findIndex(c => !c);

/** 当前选中的我方棋子（详情面板正在看的那枚） */
function selectedMine() {
  return game.boards.me.pieces.find(p => p.id === game.selectedPieceId) || null;
}

/**
 * 执行一条测试码。
 * @returns {{ok:boolean, msg:string}}
 */
export function runCheat(input) {
  const raw = String(input || '').trim();
  if (!raw) return { ok: false, msg: '请输入测试码' };
  const [cmdRaw, ...args] = raw.split(/\s+/);
  const cmd = cmdRaw.toLowerCase();
  const n = (i, d = 0) => (args[i] != null && !isNaN(Number(args[i])) ? Number(args[i]) : d);
  let err;

  switch (cmd) {
    case 'help': case '帮助':
      return { ok: true, msg: HELP.join('\n') };

    /* ---------------- 段位（任何时候可用） ---------------- */
    case 'rank': {
      const ok = rank.setRank(isNaN(Number(args[0])) ? args[0] : Number(args[0]), n(1, 1), n(2, 1));
      hooks.refreshUI();
      return ok ? { ok, msg: `段位已设为 ${rank.label()} ${rank.starText()}` }
                : { ok, msg: `未知大段，可选：${RANKS.map(r => r.name).join(' / ')}` };
    }
    case 'star': {
      const events = rank.adjustStars(n(0, 1));
      hooks.refreshUI();
      return { ok: true, msg: `当前 ${rank.label()} ${rank.starText()}${events.length ? '\n' + events.join('\n') : ''}` };
    }
    case 'resetrank':
      rank.resetRank(); hooks.refreshUI();
      return { ok: true, msg: '段位存档已清空' };

    case 'ai': {
      const a = (args[0] || '').toLowerCase();
      if (a === 'stop') { setAIPaused(true); return { ok: true, msg: '对手 AI 已暂停' }; }
      if (a === 'go')   { setAIPaused(false); return { ok: true, msg: '对手 AI 已恢复' }; }
      if (a === 'auto') { setForcedTier(null); return { ok: true, msg: '对手 AI 档位恢复自动' }; }
      if (!isNaN(Number(a)) && a !== '') {
        setForcedTier(Number(a));
        return { ok: true, msg: `对手 AI 强制为第 ${aiInfo().forced} 档（0~${AI_PROFILES.length - 1}）` };
      }
      const info = aiInfo();
      return { ok: true, msg: `AI 档位 ${info.rating.toFixed(2)}${info.paused ? '（已暂停）' : ''}` };
    }
    case 'speed': {
      const s = Math.max(1, Math.min(5, n(0, 1)));
      hooks.setSpeed(s);
      return { ok: true, msg: `游戏速度 ×${s}` };
    }
  }

  /* ---------------- 以下需在对局中 ---------------- */
  if ((err = needGame())) return { ok: false, msg: err };

  switch (cmd) {
    case 'gold':
      addGold(n(0, 999));
      hooks.refreshUI();
      return { ok: true, msg: `金币 +${n(0, 999)}` };

    case 'lv': case 'level': {
      const lv = Math.max(0, n(0, 50));
      const sel = selectedMine();
      const list = sel ? [sel] : game.pieces;
      list.forEach(p => { p.level = lv; p.exp = 0; });
      afterBoardChange(); hooks.refreshUI();
      return { ok: true, msg: `${sel ? '选中棋子' : `我方 ${list.length} 枚棋子`}设为 ${lv} 级` };
    }

    case 'stage': {
      const sel = selectedMine();
      if (!sel) return { ok: false, msg: '请先点击选中一枚我方棋子' };
      const cap = 3;
      sel.stage = Math.min(cap, (sel.stage || 0) + Math.max(1, n(0, 1)));
      // 作弊码仅用于压测，真实融合自动进化；不再把2阶当作进化门槛。
      if (sel.stage >= 3 && ['bing', 'shi', 'xiang'].includes(sel.type)) {
        const pool = sel.type === 'bing' ? ['shi', 'xiang'] : ['ju', 'ma', 'pao'];
        sel.type = pool[Math.floor(Math.random() * pool.length)];
        sel.color = Math.random() < 0.5 ? 'red' : 'black';
        sel.stage = 0;
      }
      afterBoardChange(); hooks.refreshUI();
      return { ok: true, msg: '阶数已提升' };
    }

    case 'give': {
      const type = TYPE_ALIAS[(args[0] || 'bing').toLowerCase()];
      if (!type) return { ok: false, msg: '种类可选：bing shi xiang ma ju pao' };
      const color = COLOR_ALIAS[(args[1] || 'red').toLowerCase()] || 'red';
      const { cols, rows } = game.map;
      for (let r = rows - 1; r >= 0; r--) for (let c = 0; c < cols; c++) {
        if (!isPlaceablePlot(c, r)) continue;
        placePiece({
          id: uid('p'), kind: 'piece', type, color, c, r,
          level: Math.max(0, n(2, 0)), exp: 0, stage: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [],
        }, c, r);
        afterBoardChange(); hooks.refreshUI();
        return { ok: true, msg: `已生成 ${color === 'red' ? '红' : '黑'}${PIECE_STATS[type].name}` };
      }
      return { ok: false, msg: '没有空地（可先用 shovel 挖地）' };
    }

    case 'spell': {
      const slot = firstEmptySlot();
      if (slot < 0) return { ok: false, msg: '商店没有空位' };
      const spec = args[0] ? SPELL_BY_ID[args[0]] || SPELLS.find(s => s.name === args[0])
                           : SPELLS[Math.floor(Math.random() * SPELLS.length)];
      if (!spec) return { ok: false, msg: `未知法术，可选：${SPELLS.map(s => `${s.id}(${s.name})`).join(' ')}` };
      game.shopSlots[slot] = { source: 'native', type: 'spell', id: spec.id, price: spec.price, name: spec.name, tier: spec.tier, kind: spec.kind };
      hooks.refreshUI();
      return { ok: true, msg: `商店放入法术：${spec.name}` };
    }

    case 'shovel': {
      const slot = firstEmptySlot();
      if (slot < 0) return { ok: false, msg: '商店没有空位' };
      game.shopSlots[slot] = { source: 'native', type: 'shovel' };
      hooks.refreshUI();
      return { ok: true, msg: '商店放入铲子' };
    }

    case 'refresh': {
      // 免费刷新：先补上本次费用再走正常刷新（刷新次数 / 涨价照常计算）
      const cost = currentRefreshCost();
      game.gold += cost;
      const res = shop.refreshShop();
      if (!res.ok) game.gold -= cost;
      hooks.refreshUI();
      return { ok: res.ok, msg: res.ok ? '已免费刷新' : '刷新失败' };
    }

    case 'wave': {
      const w = Math.max(1, n(0, 1));
      hooks.jumpWave(w);
      hooks.refreshUI();
      return { ok: true, msg: `双方跳到第 ${w} 波` };
    }

    case 'god':
      game.boards.me.god = !game.boards.me.god;
      return { ok: true, msg: `无敌：${game.boards.me.god ? '开' : '关'}` };

    case 'heart': case 'hp':
      game.boards.me.lives = Math.max(1, n(0, 3));
      hooks.refreshUI();
      return { ok: true, msg: `我方红心设为 ${game.boards.me.lives}` };

    case 'win': case 'lose': case 'draw':
      hooks.finish(cmd);
      return { ok: true, msg: `已结算：${{ win: '胜利', lose: '失败', draw: '平局' }[cmd]}` };

    case 'auto': {
      const tier = args[0] != null && !isNaN(Number(args[0])) ? Math.max(0, Math.min(AI_PROFILES.length - 1, Number(args[0]))) : null;
      const v = hooks.toggleAuto(tier);
      return { ok: true, msg: v == null ? '我方自动下棋：关' : `我方自动下棋：开（AI 第 ${v} 档）` };
    }

    case 'seeshop':
      return { ok: true, msg: `显示对手商店：${hooks.toggleSeeShop() ? '开' : '关'}` };

    default:
      return { ok: false, msg: `未知测试码「${cmdRaw}」，输入 help 查看全部` };
  }
}

export default { runCheat, setCheatHooks };
