/** 只在已评估的等价方案中打破固定顺序；不消耗任何随机流。 */
const EPSILON = 1e-7;

export function actionKey(a, pieceKeys = null) {
  return JSON.stringify([a.kind, a.slot, pieceKeys?.get(a.pieceId) ?? a.pieceId,
    pieceKeys?.get(a.targetId) ?? a.targetId, pieceKeys?.get(a.secondaryTargetId) ?? a.secondaryTargetId,
    a.c, a.r, a.spellId, a.color, a.evolutionType,
    a.followup ? actionKey(a.followup, pieceKeys) : null]);
}

export function variationKey(seed, key) {
  let hash = (seed ^ 2166136261) >>> 0;
  for (let i = 0; i < key.length; i++) {
    hash ^= key.charCodeAt(i);
    hash = Math.imul(hash, 16777619) >>> 0;
  }
  hash ^= hash >>> 16;
  hash = Math.imul(hash, 0x7feb352d);
  hash ^= hash >>> 15;
  return hash >>> 0;
}

/** 粗选集合完全保留原规则；多样性不能在完整评估前挤掉原有候选。 */
export function placementShortlist(items, count) {
  return [...items].sort((a, b) => b.weight - a.weight).slice(0, Math.max(0, count));
}

/** 首次见到的棋子按局面位置登记，之后保持身份，不依赖全局UID或数组存储顺序。 */
export function registerPieceKeys(pieces, keys = new Map()) {
  const fresh = pieces.filter(piece => !keys.has(piece.id));
  fresh.sort((a, b) => a.r - b.r || a.c - b.c || a.type.localeCompare(b.type) || a.color.localeCompare(b.color));
  for (const piece of fresh) keys.set(piece.id, keys.size);
  return keys;
}

function staticFloor(a) {
  return Math.min(...(a.branches || []).map(branch => branch.value));
}

function combatNoWorse(a, reference) {
  return !!a && !!reference && a.leaks <= reference.leaks &&
    a.value + EPSILON >= reference.value && a.worstValue + EPSILON >= reference.worstValue;
}

export function equivalentAction(a, reference, needsCombat = false) {
  if (!['buy', 'move', 'dig'].includes(a?.kind)) return false;
  if (a.kind === 'buy' && (a.slot !== reference?.slot || a.color !== reference?.color || a.evolutionType !== reference?.evolutionType)) return false;
  if (a.kind === 'move' && a.pieceId !== reference?.pieceId) return false;
  if (!a?.branches?.length || !reference?.branches?.length ||
      a.branches.some(branch => !Number.isFinite(branch.value)) ||
      reference.branches.some(branch => !Number.isFinite(branch.value))) return false;
  if (!a || !reference || a.kind !== reference.kind || a.committed || a.saved ||
      !Number.isFinite(a.cost) || !Number.isFinite(reference.cost) ||
      a.cost > reference.cost || !Number.isFinite(a.gain) || !Number.isFinite(a.score) ||
      a.gain + EPSILON < reference.gain || a.score + EPSILON < reference.score ||
      staticFloor(a) + EPSILON < staticFloor(reference)) return false;
  if (a.kind === 'dig' && (a.followup?.kind !== reference.followup?.kind ||
      !a.followup || a.followup.cost > reference.followup.cost ||
      a.followup.slot !== reference.followup.slot || a.followup.pieceId !== reference.followup.pieceId)) return false;
  if (needsCombat && (!a.tested || !reference.tested || !combatNoWorse(a.combat, reference.combat))) return false;
  if (needsCombat && a.kind === 'dig' && (!a.followupCombat?.followupApplied ||
      !reference.followupCombat?.followupApplied || !combatNoWorse(a.followupCombat, reference.followupCombat))) return false;
  return true;
}

/** 仅允许左右镜像且整条有序道路逐点不动的落点；短期同分不代表长期等价。 */
export function symmetricPlacement(board, a, reference) {
  const map = board?.map;
  if (!map || !Number.isInteger(map.cols) || !Number.isInteger(map.rows) ||
      !map.path?.length || a.c !== map.cols - 1 - reference.c || a.r !== reference.r) return false;
  // 双车错的纵向冲刺固定向右拐，不具备左右镜像等价性；潜在上场的车也排除。
  if (board.pieces.some(p => p.type === 'ju') ||
      board.shopSlots?.some(card => card?.kind === 'ju' || (card?.piece || card?._piece)?.type === 'ju')) return false;
  const fixed = p => p && p.c === map.cols - 1 - p.c;
  if (!map.path.every(fixed) || (map.kingPoint && !fixed(map.kingPoint)) ||
      (map.enemySpawn && !fixed(map.enemySpawn)) || (board.king && !fixed(board.king)) ||
      !board.pieces.every(fixed) || !board.enemies.every(fixed)) return false;
  for (let r = 0; r < map.rows; r++) for (let c = 0; c < map.cols; c++) {
    const mirrored = map.cols - 1 - c;
    for (const layer of ['ground', 'grass', 'road']) {
      if (!!map[layer]?.[r]?.[c] !== !!map[layer]?.[r]?.[mirrored]) return false;
    }
    if (!!map.cleared?.has(`${c},${r}`) !== !!map.cleared?.has(`${mirrored},${r}`)) return false;
  }
  return true;
}

export function chooseEquivalent(reference, candidates, { seed, enabled = true, urgent = false, needsCombat = false, pieceKeys = null, board = null } = {}) {
  if (!enabled || urgent || !reference || !['buy', 'move', 'dig'].includes(reference.kind) ||
      reference.committed || reference.saved || reference.gain <= 1) {
    return { action: reference, eligible: 1 };
  }
  const unique = new Map([[actionKey(reference), reference]]);
  for (const a of candidates) if (equivalentAction(a, reference, needsCombat) &&
      symmetricPlacement(board, a, reference)) unique.set(actionKey(a), a);
  const choices = [...unique.values()].sort((a, b) =>
    variationKey(seed, actionKey(a, pieceKeys)) - variationKey(seed, actionKey(b, pieceKeys)));
  return { action: choices[0], eligible: choices.length };
}
