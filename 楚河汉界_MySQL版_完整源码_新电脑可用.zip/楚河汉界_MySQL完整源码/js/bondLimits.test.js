/** 羁绊无通用数量限制、断开清理与模拟隔离；不写存档。 */
import game, { createBoard, withBoard } from './gameData.js';
import { rescanBonds } from './bond.js';
import { clonePosition } from './aiEvaluation.js';
import { update } from './wave.js';

export function runBondLimitFixtures() {
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const map = { cols: 9, rows: 9, path: [{ c: 8, r: 0 }, { c: 8, r: 1 }],
    ground: Array.from({ length: 9 }, () => Array(9).fill(true)),
    grass: Array.from({ length: 9 }, () => Array(9).fill(false)),
    road: Array.from({ length: 9 }, () => Array(9).fill(false)) };
  const piece = (id, type, c, r, color = 'red') => ({ id, kind: 'piece', type, c, r,
    level: 10, color, exp: 0, stage: 0, atkBonus: 0, flags: {}, cdLeft: 999, bonds: [], activeBonds: [] });
  const scan = b => withBoard(b, rescanBonds);
  const has = (b, a, c) => b.bonds.some(x => [x.aId, x.bId].includes(a) && [x.aId, x.bId].includes(c));
  const original = game.cur;
  try {
    const board = createBoard('me', map);
    for (let i = 0; i < 3; i++) {
      board.pieces.push(piece(`a${i}`, 'bing', 0, i * 3), piece(`b${i}`, 'bing', 1, i * 3, 'black'));
      scan(board);
      check(`同名第${i + 1}组全部生效`, board.bonds.length === i + 1);
    }
    const oldest = board.bonds.find(x => x.aId === 'a0' || x.bId === 'a0').id;
    board.bondGoldTimers[oldest] = 9;
    scan(board);
    check('新增组合不清除旧组合名称', board.pieces[0].activeBonds.includes('二鬼拍门'));
    check('有效组合保留金币计时', board.bondGoldTimers[oldest] === 9);
    const reward = clonePosition(board); reward._simulationContext = {}; reward.bondGoldTimers = {};
    const gold = reward.gold;
    withBoard(reward, () => update(10));
    check('三组真实金币收益', reward.gold === gold + 3);
    const order = [...board.bondOrder], sequence = board.bondSequence;
    for (let i = 0; i < 8; i++) scan(board);
    check('周期重扫稳定', sequence === board.bondSequence && JSON.stringify(order) === JSON.stringify([...board.bondOrder]));
    board.pieces.reverse(); scan(board);
    check('数组顺序不改变有效配对', board.bonds.length === 3 && has(board, 'a0', 'b0'));
    board.pieces.find(p => p.id === 'b0').c = 3; scan(board);
    check('断开只移除对应羁绊', board.bonds.length === 2 && !has(board, 'a0', 'b0'));
    check('断开清除金币计时', !(oldest in board.bondGoldTimers));
    check('断开清除棋子名称', board.pieces.find(p => p.id === 'a0').activeBonds.length === 0);
    board.pieces.find(p => p.id === 'b0').c = 1; scan(board);
    check('重连恢复全部三组', board.bonds.length === 3 && board.bondSequence > sequence);

    const mixed = createBoard('me', map);
    mixed.pieces = [piece('center', 'bing', 3, 3), piece('left', 'bing', 2, 3, 'black'),
      piece('top', 'bing', 3, 2, 'black'), piece('bottom', 'bing', 3, 4, 'black'), piece('right', 'bing', 4, 3, 'black')];
    scan(mixed);
    check('单棋可参与四组且同名可四组', mixed.pieces[0].bonds.length === 4 && mixed.bonds.filter(b => b.key === 'bing_bing').length === 4);
    check('多组同时保留', has(mixed, 'center', 'right') && has(mixed, 'center', 'left'));
    const snapshot = JSON.stringify([...mixed.bondOrder]);
    const copy = clonePosition(mixed); copy.pieces.find(p => p.id === 'right').c = 7; scan(copy);
    check('模拟独立移除配对', !has(copy, 'center', 'right') && has(mixed, 'center', 'right'));
    check('模拟不污染达成记录', snapshot === JSON.stringify([...mixed.bondOrder]));
    const opp = createBoard('opp', map);
    opp.pieces = board.pieces.map(p => ({ ...structuredClone(p), id: `opp-${p.id}` })); scan(opp);
    check('双方均可激活三组', board.bonds.length === 3 && opp.bonds.length === 3);
    check('双方记录独立', board.bondOrder !== opp.bondOrder);
    const fresh = createBoard('opp', map);
    check('新局记录清空', fresh.bondSequence === 0 && fresh.bondOrder.size === 0);
    check('上下文恢复', game.cur === original);
    return { passed: checks.length, checks };
  } finally { game.cur = original; }
}
