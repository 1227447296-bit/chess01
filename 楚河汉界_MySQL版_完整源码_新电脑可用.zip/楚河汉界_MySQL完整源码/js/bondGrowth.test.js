/** 现行两类羁绊的无DOM回归：二鬼拍门、士象全（限定一组）。保留 runBondGrowthFixtures 接口；不启动服务器、不读写存档。 */
import game, { createBoard, withBoard } from './gameData.js';
import { LEVEL, WAVES, BOND_CONFIG, experienceRequired } from './config.js';
import { bondKeysBetween, rescanBonds, activeBondNames, onBoardChanged } from './bond.js';
import { pieceDamage } from './attackRule.js';
import { registerWaveEnemy, update } from './wave.js';
import { simulateCombat, createCombatSimulation, cloneBoard } from './aiSimulation.js';

export function runBondGrowthFixtures() {
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const near = (a, b) => Math.abs(a - b) < 1e-7;
  const map = { cols: 10, rows: 10, path: [{ c: 8, r: 0 }, { c: 8, r: 1 }],
    enemySpawn: { c: 8, r: 0 }, kingPoint: { c: 8, r: 1 }, cleared: new Set(),
    ground: Array.from({ length: 10 }, () => Array(10).fill(true)),
    road: Array.from({ length: 10 }, () => Array(10).fill(false)), grass: [] };
  const piece = (id, type, c, r, level = 0, color = 'red', stage = 0) => ({
    id, kind: 'piece', type, c, r, color, level, exp: 0, stage,
    atkBonus: 0, flags: {}, cdLeft: 999, bonds: [], activeBonds: [],
  });
  const board = () => {
    const b = createBoard('me', map);
    b._simulationContext = { random: () => 1 };
    return b;
  };
  const enemy = (id, c = 8, r = 0, extra = {}) => ({ id, kind: 'enemy', c, r, fx: c, fy: r,
    hp: 100000, maxHp: 100000, speed: 0, progress: 0, done: false, dying: false,
    deathT: 0, stunLeft: 0, stunImmuneLeft: 0, ...extra });
  const scan = b => withBoard(b, rescanBonds);
  const tick = (b, dt = 0) => withBoard(b, () => update(dt));
  const damage = (b, p) => withBoard(b, () => pieceDamage(p));
  const exp = p => {
    let total = p.exp;
    for (let l = 0; l < p.level; l++) total += experienceRequired(l);
    return total;
  };
  const baseWaveExp = wave => LEVEL.waveExpBase + LEVEL.waveExpPerWave * wave;
  function addWave(b, wave = 1, last = {}) {
    const count = WAVES.firstWaveCount + (wave - 1) * WAVES.countGrowPerWave;
    for (let i = 0; i < count; i++) {
      const e = enemy(`w${wave}-${i}`, 8, 0, i === count - 1 ? last : { done: true });
      registerWaveEnemy(b, e, wave); b.enemies.push(e);
    }
  }
  const previous = game.cur, phase = game.phase;
  try {
    game.phase = 'playing';
    check('接口保持兼容', onBoardChanged === rescanBonds);
    check('只保留二鬼拍门与士象全', Object.keys(BOND_CONFIG).join() === 'bing_bing,shi_xiang');
    for (const [typeA, typeB, key, level, same] of [
      ['bing', 'bing', 'bing_bing', 10, false], ['shi', 'xiang', 'shi_xiang', 15, true],
    ]) {
      const b = board(), a = piece('a', typeA, 1, 1), c = piece('b', typeB, 2, 1, 0, same ? 'red' : 'black');
      b.pieces = [a, c];
      withBoard(b, () => {
        a.level = c.level = level - 1;
        check(`${key}/两者均未达标不生效`, !bondKeysBetween(a, c).includes(key));
        a.level = level;
        check(`${key}/仅一枚达标不生效`, !bondKeysBetween(a, c).includes(key));
        c.level = level;
        check(`${key}/两者都达标生效且顺序无关`, bondKeysBetween(a, c).includes(key) && bondKeysBetween(c, a).includes(key));
        c.color = same ? 'black' : 'red';
        check(`${key}/错误颜色无效`, !bondKeysBetween(a, c).includes(key));
        c.color = same ? 'red' : 'black';
        c.c = 2; c.r = 2;
        check(`${key}斜向不生效`, !bondKeysBetween(a, c).includes(key));
        c.c = 3; c.r = 1;
        check(`${key}隔一格不生效`, !bondKeysBetween(a, c).includes(key));
        c.c = a.c; c.r = a.r;
        check(`${key}重叠及自身不生效`, !bondKeysBetween(a, c).length && !bondKeysBetween(a, a).length);
      });
    }
    const removed = board();
    removed.pieces = [piece('m', 'ma', 1, 1, 999), piece('p', 'pao', 2, 1, 999, 'black'),
      piece('b', 'bing', 4, 4, 999), piece('s', 'shi', 5, 4, 999)];
    scan(removed);
    check('马炮、兵士等已删除羁绊不再触发', removed.bonds.length === 0);

    const guards = board();
    guards.pieces = [piece('s1', 'shi', 0, 0, 15), piece('x1', 'xiang', 1, 0, 15),
      piece('s2', 'shi', 0, 3, 15), piece('x2', 'xiang', 1, 3, 15),
      piece('bs', 'shi', 5, 0, 15, 'black'), piece('bx', 'xiang', 6, 0, 15, 'black'),
      piece('red', 'ma', 4, 8), piece('black', 'ma', 8, 8, 0, 'black')];
    scan(guards);
    const guardBonds = () => guards.bonds.filter(b => b.key === 'shi_xiang');
    check('士象全限定：一方只激活一组', guardBonds().length === 1);
    check('士象全对己方全部棋子+10%，不分颜色', guards.pieces.every(p => p.bondMods.teamAtkRate === 0.10));
    const plain = piece('plain', 'ma', 4, 8);
    check('士象全真实攻击+10%', near(damage(guards, guards.pieces[6]), damage(guards, plain) * 1.1));
    const first = guardBonds()[0].id;
    for (let i = 0; i < 4; i++) scan(guards);
    check('重复扫描保持同一组生效', guardBonds().length === 1 && guardBonds()[0].id === first);
    const guardExp = guards.pieces.map(exp);
    addWave(guards, 1, { done: true }); tick(guards);
    check('士象全不加清波经验', guards.pieces.every((p, i) => exp(p) - guardExp[i] === baseWaveExp(1)));
    const holder = guards.pieces.find(p => p.activeBonds.includes('士象全') && p.type === 'xiang');
    holder.c = 9; holder.r = 9; scan(guards);
    check('生效组断开后由其他组接替', guardBonds().length === 1 && guardBonds()[0].id !== first);
    check('接替后仍全场+10%', guards.pieces.every(p => p.bondMods.teamAtkRate === 0.10));
    guards.pieces = guards.pieces.filter(p => p.type !== 'xiang'); scan(guards);
    check('全部断开加成即时清零', guardBonds().length === 0 && guards.pieces.every(p => p.bondMods.teamAtkRate === 0));
    check('断开清除名称', guards.pieces.every(p => activeBondNames(p).length === 0));

    const gold = board();
    gold.pieces = [piece('red', 'bing', 3, 3, 10), piece('left', 'bing', 2, 3, 10, 'black'),
      piece('top', 'bing', 3, 2, 10, 'black'), piece('bottom', 'bing', 3, 4, 10, 'black'),
      piece('right', 'bing', 4, 3, 10, 'black')];
    scan(gold); const startGold = gold.gold;
    check('二鬼单兵四组无公共上限', gold.bonds.length === 4 && gold.pieces[0].bonds.length === 4);
    tick(gold, 9.75); check('二鬼10秒前无收益', gold.gold === startGold);
    scan(gold); tick(gold, 0.25); check('二鬼每组10秒各+1金', gold.gold === startGold + 4);
    tick(gold, 25); check('二鬼大dt逐组结算并保留余数', gold.gold === startGold + 12 && Object.values(gold.bondGoldTimers).every(t => near(t, 5)));
    const firstId = gold.bonds.find(b => b.aId === 'left' || b.bId === 'left').id;
    gold.pieces[1].c = 0; scan(gold);
    check('二鬼断开只清该组计时', !(firstId in gold.bondGoldTimers) && Object.keys(gold.bondGoldTimers).length === 3);
    gold.pieces[1].c = 2; scan(gold); tick(gold, 5);
    check('二鬼重连从零计时且其余组连续', gold.gold === startGold + 15 && near(gold.bondGoldTimers[firstId], 5));
    gold.pieces[0].level = 9; scan(gold);
    check('二鬼等级不足全部断开并清零', gold.bonds.length === 0 && Object.keys(gold.bondGoldTimers).length === 0);

    const isolated = board();
    isolated.pieces = [piece('s', 'shi', 0, 0, 15), piece('x', 'xiang', 1, 0, 15), piece('remote', 'ma', 9, 9)];
    scan(isolated); addWave(isolated, 1, { hp: 0, dying: true }); tick(isolated);
    check('死亡闪烁未离场不提前结算清波', !isolated.waveClearState[1].settled && isolated.pieces[2].level === 0);
    const before = JSON.stringify(isolated), sync = simulateCombat(isolated, { horizon: 2 });
    check('模拟兑现清波基础经验', exp(sync.board.pieces[2]) === baseWaveExp(1));
    check('模拟不修改源棋子、账本、计时', JSON.stringify(isolated) === before);
    const sliced = createCombatSimulation(isolated, { horizon: 2 });
    while (!sliced.done) sliced.advance(1);
    check('同步分帧模拟清波一致', JSON.stringify(sync.board) === JSON.stringify(sliced.result.board));
    const copy = cloneBoard(isolated); copy.pieces[1].c = 4; scan(copy);
    check('模拟断开不污染源有效羁绊', isolated.bonds.length === 1 && copy.bonds.length === 0 && isolated.bondOrder !== copy.bondOrder);
    check('棋盘上下文恢复', game.cur === previous);
    return { passed: checks.length, checks };
  } finally { game.cur = previous; game.phase = phase; }
}

/** 最新规格测试入口；旧调用者仍可调用 runBondGrowthFixtures。 */
export const runBondRulesFixtures = runBondGrowthFixtures;

// Node直接运行：node --experimental-default-type=module "E:\\cn chess experimental\\js\\bondGrowth.test.js"
if (typeof process !== 'undefined' && process.argv[1]?.replace(/\\/g, '/').endsWith('/bondGrowth.test.js')) {
  const { runBondLimitFixtures } = await import('./bondLimits.test.js');
  const { runJuReturnFixtures } = await import('./juReturn.test.js');
  const results = [runBondRulesFixtures(), runBondLimitFixtures(), runJuReturnFixtures()];
  console.log(JSON.stringify({ passed: results.reduce((sum, result) => sum + result.passed, 0), suites: results.map(result => result.passed) }));
}
