/** 同风格加载页：显示真实资源完成进度，不使用定时假进度。 */
export function showLoading(title = '正在准备棋局') {
  document.getElementById('loading-screen').classList.remove('hidden');
  document.getElementById('loading-screen').setAttribute('aria-busy', 'true');
  document.getElementById('loading-title').textContent = title;
  document.getElementById('loading-retry').classList.add('hidden');
  document.getElementById('loading-screen').classList.remove('has-error');
  updateLoading(0, '准备加载');
}

export function updateLoading(percent, label, detail = '') {
  const value = Math.max(0, Math.min(100, Math.round(percent)));
  const meter = document.getElementById('loading-meter');
  meter.style.width = `${value}%`;
  document.getElementById('loading-progress').setAttribute('aria-valuenow', value);
  document.getElementById('loading-percent').textContent = `${value}%`;
  document.getElementById('loading-status').textContent = label;
  document.getElementById('loading-detail').textContent = detail;
}

export function hideLoading() {
  document.getElementById('loading-screen').setAttribute('aria-busy', 'false');
  document.getElementById('loading-screen').classList.add('hidden');
}

export function loadingError(error, retry, buttonText = '重试加载') {
  document.getElementById('loading-screen').classList.remove('hidden');
  document.getElementById('loading-screen').classList.add('has-error');
  document.getElementById('loading-status').textContent = '加载暂未完成';
  document.getElementById('loading-detail').textContent = error.message || String(error);
  const button = document.getElementById('loading-retry');
  button.textContent = buttonText;
  button.classList.remove('hidden');
  button.onclick = retry;
}
