/**
 * ai.js —— 人类节奏的对手：每次只做一个动作，强度来自评估而非手速。
 * 只看己方可见局面，沿用玩家 actions；推演只使用副本和候选集合机会节点。
 */
import { AI_PROFILES, AI_ADAPT, AI_RELIEF, AI_NOVICE, AI_PLAY, SHOP, SPELL_BY_ID, RANKS, WAVES, ENEMY } from './config.js';
import game, { withBoard, isPlaceablePlot, isDiggable, currentRefreshCost } from './gameData.js';
import * as shop from './shop.js';
import { canAbsorb, canEvolve } from './synthesis.js';
import { computeAttackCells } from './rangePreview.js';
import { spellStockLeft } from './spell.js';
import * as act from './actions.js';
import { clonePosition, previewCard, scorePosition, evaluateActionSteps, riskAdjusted, knownEvolutionChoices, spellActions, spellOpportunityScore } from './aiEvaluation.js';
import { criticalStats } from './attackRule.js';
import { createCombatSimulation } from './aiSimulation.js';
import { sharedWaves } from './wave.js';
import { MAX_BOARD_PIECES as BOARD_PIECE_LIMIT } from './boardLimits.js';
import { effectiveLives } from './tacticalEffects.js';
import { buildSpawnPlan } from './aiSpawnPlan.js';
import { actionKey, variationKey, placementShortlist, registerPieceKeys, equivalentAction, chooseEquivalent } from './aiVariety.js';

const ai = { forced: null, paused: false, rating: 0, progress: 0, adjustment: 0,
  testSeed: null, testSlices: null, variationSeed: null, variety: true, relief: null,
  rankTier: 7, noviceMode: null };
// 只在本次浏览器会话内观察结果，不新增玩家存档字段，也不预定任何一局胜负。
const calibration = { wins: null, losses: null, tier: null, outcomes: [] };
let sessions = new WeakMap();

function observeResults(rankState, tier) {
  const wins = rankState.wins || 0, losses = rankState.losses || 0;
  if (calibration.wins != null) {
    const dw = wins - calibration.wins, dl = losses - calibration.losses;
    if (dw + dl === 1 && dw >= 0 && dl >= 0 && calibration.tier === tier) {
      calibration.outcomes.push(dw ? 1 : 0);
      if (calibration.outcomes.length > 20) calibration.outcomes.shift();
    } else if (dw + dl !== 0 || calibration.tier !== tier) calibration.outcomes = [];
  }
  calibration.wins = wins; calibration.losses = losses; calibration.tier = tier;
  if (calibration.outcomes.length < 8) return 0;
  const rate = calibration.outcomes.reduce((sum, n) => sum + n, 0) / calibration.outcomes.length;
  return Math.max(-0.15, Math.min(0.15, (rate - AI_PLAY.playerWinTargets[tier]) * 0.5));
}

/** 星级只平滑增加有限的规划预算；不强制胜负，不无限提高强度。 */
export function setupAI(rankState, options = {}) {
  ai.testSeed = Number.isInteger(options.seed) ? options.seed >>> 0 : null;
  ai.variationSeed = Number.isInteger(options.variationSeed) ? options.variationSeed >>> 0 : null;
  ai.variety = options.variety !== false;
  // 仅开发对照显式启用；正式开局不传该项，仍按墙钟软预算分帧。
  ai.testSlices = Number.isInteger(options.evaluationSlices) && options.evaluationSlices >= 1 &&
    options.evaluationSlices <= 64 ? options.evaluationSlices : null;
  const tier = Math.max(0, Math.min(AI_PROFILES.length - 1, rankState.tier || 0));
  ai.rankTier = tier;
  // 开发对照可固定档位；正式开局由盘内独立种子抽一次。
  ai.noviceMode = ['normal', 'novice'].includes(options.lowRankMode) ? options.lowRankMode : null;
  const subs = RANKS[tier]?.subs || 1;
  const progress = Math.min(1, ((rankState.sub || 0) + Math.min(3, rankState.stars || 0) / 4) / Math.min(subs, 12));
  const streak = Math.max(-AI_ADAPT.streakCap, Math.min(AI_ADAPT.streakCap,
    (rankState.streak || 0) * AI_ADAPT.streakStep));
  ai.progress = progress;
  ai.adjustment = observeResults(rankState, tier);
  ai.rating = Math.max(0, Math.min(AI_PROFILES.length - 1,
    tier + (AI_ADAPT.tierBias[tier] || 0) + progress * 0.3 + streak + ai.adjustment));
  ai.relief = (AI_RELIEF.enabled || options.reliefTest === true) &&
    tier >= AI_RELIEF.minTier && (rankState.streak || 0) <= -AI_RELIEF.lossStreak
    ? { active: true, seed: variationKey(ai.testSeed ?? Date.now(), 'relief'),
        maxMistakes: AI_RELIEF.maxMistakes }
    : null;
  ai.paused = false;
  // 论文对照实验开关，只由开发对照 benchmark 显式传入；正式开局不传，行为完全不变。
  //   strategy: 'full'（默认）| 'random'（随机合法动作基线）
  //   noSimulation: true 关闭短期战斗推演，只按静态评估选择（贪心基线 / 消融）
  //   risk: 覆盖战斗推演的风险系数 λ；horizon: 覆盖推演时长（秒）
  ai.experiment = options.experiment || null;
  sessions = new WeakMap();
}

export function setForcedTier(n) { ai.forced = n == null ? null : Math.max(0, Math.min(AI_PROFILES.length - 1, n)); }
export function setAIPaused(v) { ai.paused = v; }
export function aiInfo(board = game.boards.opp) {
  const s = sessions.get(board);
  return { rating: ai.forced ?? ai.rating, paused: ai.paused, forced: ai.forced,
    adjustment: ai.adjustment, observedGames: calibration.outcomes.length,
    lastAction: s?.lastAction || null, rescue: s?.rescue || null,
    decisions: s?.decisions || 0, cancelled: s?.cancelled || 0,
    peakPlanSeconds: s?.peakPlanSeconds || 0, evaluationMs: s?.evaluationMs || 0,
    forecastCount: s?.forecastCount || 0, battleChecks: s?.battleChecks || 0,
    plan: s?.plan ? { ...s.plan.action } : null,
    plansCompleted: s?.plansCompleted || 0, plansCancelled: s?.plansCancelled || 0,
    varietyChoices: s?.varietyChoices || 0, varietyEligible: s?.varietyEligible || 0,
    lowRankMode: s?.noviceActive ? 'novice' : 'normal',
    noviceActions: s?.noviceActions || 0,
    reliefActivated: !!s?.relief?.active, reliefActions: s?.relief?.actions || 0,
    reliefBudgetExhausted: !!s?.relief?.completed, reliefLost: !!s?.relief?.active && !!board?.dead,
    reliefCancelled: !!s?.relief?.cancelled };
}

function session(board) {
  if (!sessions.has(board)) {
    const seed = new Uint32Array(1);
    if (ai.testSeed != null) seed[0] = ai.testSeed;
    else if (globalThis.crypto?.getRandomValues) crypto.getRandomValues(seed);
    else seed[0] = Date.now() >>> 0;
    sessions.set(board, { seed: seed[0] || 1, time: 0, moved: new Map(),
      variationSeed: ai.variationSeed ?? variationKey(seed[0] || 1, 'layout'), variety: ai.variety, pieceKeys: new Map(),
      novice: board.side === 'opp' && ai.rankTier <= 1 && (ai.noviceMode === 'novice' ||
        (ai.noviceMode == null && variationKey(seed[0] || 1, 'novice-match') / 4294967296 < AI_NOVICE.chance)),
      noviceActive: false, noviceActions: 0,
      relief: ai.relief && board.side === 'opp' ? { ...ai.relief, actions: 0, lastAt: -Infinity, completed: false, cancelled: false } : null,
      rescue: null, lastAction: null, decisions: 0, cancelled: 0, peakPlanSeconds: 0, evaluationMs: 0 });
  }
  return sessions.get(board);
}

/** 决策随机与商店/融合随机分开；增加搜索候选不会改变正式抽卡。 */
function random(s) {
  let x = s.seed;
  x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
  s.seed = x >>> 0;
  return s.seed / 4294967296;
}

function profile(t) {
  const lo = Math.floor(t), hi = Math.min(AI_PROFILES.length - 1, lo + 1), k = t - lo;
  const out = {};
  for (const key of Object.keys(AI_PROFILES[lo])) out[key] = AI_PROFILES[lo][key] * (1 - k) + AI_PROFILES[hi][key] * k;
  return out;
}

/** 一次一个动作；不按帧补执行、不以高段位加速、不因比分突然放水。 */
export function aiTick(dt, rivalLives, tierOverride = null) {
  if (game.phase !== 'playing' || game.dead || (tierOverride == null && ai.paused)) return;
  const s = session(game.cur);
  const novice = s.novice && tierOverride == null && ai.forced == null;
  if (s.job && novice !== s.noviceActive) { s.job.return(); s.job = null; }
  s.noviceActive = novice;
  s.time += dt;
  if (game.cur.aiTimer == null) game.cur.aiTimer = AI_PLAY.openingDelay;
  game.cur.aiTimer -= dt;
  if (game.cur.aiTimer > 0 && !s.job) return;
  const tier = tierOverride == null ? (ai.forced ?? ai.rating) : tierOverride;
  const p = profile(tier);
  p.progress = tierOverride == null && ai.forced == null ? ai.progress : 0;
  const start = performance.now();
  if (s.job && positionKey(game.cur) !== s.jobKey) {
    s.job.return();
    s.job = null;
    s.cancelled++;
    s.decisions++;
    game.cur.aiTimer = 0;
    s.evaluationMs = performance.now() - start;
    return;
  }
  if (!s.job) {
    // 动作签名用稳定盘内身份，不让全局UID或数组重排改变本局风格。
    registerPieceKeys(game.pieces, s.pieceKeys);
    s.planningStarted = s.time;
    s.jobKey = positionKey(game.cur);
    s.job = novice ? noviceStep(p, tier, s) : step(p, tier, s);
  }
  let result, slices = 0;
  do {
    result = s.job.next();
    slices++;
  } while (!result.done && (ai.testSlices == null
    ? performance.now() - start < AI_PLAY.evaluationBudgetMs : slices < ai.testSlices));
  if (result.done) {
    s.job = null;
    // 取消的是后台思考，不是一次实际操作；下一帧重新观察，不额外空等一秒。
    game.cur.aiTimer = result.value === 'stale' ? 0
      : AI_PLAY.actionMin + random(s) * (AI_PLAY.actionMax - AI_PLAY.actionMin);
    s.decisions++;
    s.peakPlanSeconds = Math.max(s.peakPlanSeconds, s.time - s.planningStarted);
  }
  s.evaluationMs = performance.now() - start;
}

function freePlots() {
  const cells = [];
  for (let r = 0; r < game.map.rows; r++) for (let c = 0; c < game.map.cols; c++) {
    if (isPlaceablePlot(c, r)) cells.push({ c, r });
  }
  return cells;
}

const price = card => shop.cardPrice(card) || 0;
const movable = p => !p.charge && !p.stomp;
const sameCell = (a, b) => a.c === b.c && a.r === b.r;

/** 铲地只预约下一手；卡牌身份、落点和移动冷却都按当前真实局面复核。 */
function plannedFollowup(s) {
  const plan = s.plan;
  if (!plan) return null;
  const a = plan.action, piece = game.pieces.find(p => p.id === a.pieceId);
  const valid = s.time <= plan.expires && isPlaceablePlot(a.c, a.r) &&
    (a.kind === 'buy'
      ? game.pieces.length < BOARD_PIECE_LIMIT && game.shopSlots[a.slot] === plan.card && shop.isPieceCard(plan.card) && game.gold >= price(plan.card)
      : piece && movable(piece) && sameCell(piece, plan.origin) &&
        s.time - (s.moved.get(piece.id) ?? -Infinity) >= AI_PLAY.moveCooldown);
  if (!valid) {
    s.plan = null;
    s.plansCancelled = (s.plansCancelled || 0) + 1;
    return null;
  }
  return { ...a, cost: a.kind === 'buy' ? price(plan.card) : 0, committed: true };
}

/** 粗选只缩减候选；最终在完整假想局面重算全盘阻挡和羁绊。 */
function bestCells(piece, cells, count, s, smart) {
  if (!smart) return [...cells].sort((a, b) => a.r - b.r).filter(() => random(s) < 0.8).slice(0, count);
  const board = clonePosition(game.cur);
  board.pieces = board.pieces.filter(p => p.id !== piece.id);
  return withBoard(board, () => {
    const weighted = cells.map(cell => {
    const hits = computeAttackCells(piece.type, piece.color, cell.c, cell.r, piece.flags, piece.level, piece.activeBonds);
    let weight = hits.length;
    for (const e of board.enemies) {
      if (e.hp <= 0) continue;
      const progress = Math.floor(e.progress || 0);
      for (let i = progress; i < Math.min(board.map.path.length, progress + 7); i++) {
        const next = board.map.path[i];
        if (hits.some(h => h.c === next.c && h.r === next.r)) weight += 7 / (1 + i - progress);
      }
    }
    return { ...cell, weight };
    });
    return placementShortlist(weighted, count);
  });
}

function* candidates(p, tier, s) {
  const out = [], plots = freePlots(), board = game.cur;
  const count = tier >= 5 ? 4 : tier >= 2 ? 3 : 2;
  const smart = random(s) < p.placeSmart;
  // 调防候选先生成；即便评估预算不足也不能只评买棋而忽略救场。
  for (const piece of board.pieces) {
    if (!movable(piece) || s.time - (s.moved.get(piece.id) ?? -Infinity) < AI_PLAY.moveCooldown) continue;
    const cells = bestCells(piece, plots, count, s, true);
    if (s.rescue?.pieceId === piece.id && plots.some(c => sameCell(c, s.rescue.origin))) cells.push(s.rescue.origin);
    for (const cell of cells) out.push({ kind: 'move', pieceId: piece.id, c: cell.c, r: cell.r, cost: 0 });
    yield;
  }
  // 进化与融合是两手；已固化的候选才可直接选择，不在候选生成时重抽。
  for (const piece of board.pieces) {
    if (!movable(piece) || !canEvolve(piece)) continue;
    const choices = knownEvolutionChoices(piece);
    if (!choices.length) out.push({ kind: 'prepareEvolution', targetId: piece.id, cost: 0 });
    for (const evolutionType of choices) out.push({ kind: 'evolve', pieceId: piece.id, evolutionType, cost: 0 });
  }
  for (let slot = 0; slot < board.shopSlots.length; slot++) {
    const card = board.shopSlots[slot];
    if (!card || board.gold < price(card)) continue;
    if (shop.isPieceCard(card)) {
      const piece = previewCard(card, slot);
      if (!piece) continue;
      for (const cell of board.pieces.length < BOARD_PIECE_LIMIT ? bestCells(piece, plots, count, s, smart) : []) {
        out.push({ kind: 'buy', slot, c: cell.c, r: cell.r, cost: price(card) });
      }
      for (const target of board.pieces) {
        if (movable(target) && canAbsorb(target, piece).ok) out.push({ kind: 'shopMerge', slot, targetId: target.id, cost: price(card) });
      }
    } else if (card.type === 'spell' && spellStockLeft(card.id) > 0 && random(s) < p.spellUse) {
      out.push(...spellActions(board, slot));
    }
    yield;
  }
  for (const piece of board.pieces) {
    for (const target of board.pieces) {
      if (piece === target || !movable(piece) || !movable(target)) continue;
      if (canAbsorb(target, piece).ok) out.push({ kind: 'merge', pieceId: piece.id, targetId: target.id, cost: 0 });
    }
    yield;
  }
  // 高段也要在有空格时比较换位：随机进化后的合适位置可能被友军占着。
  if (tier >= 3 && (!plots.length || tier >= 4)) {
    for (let i = 0; i < board.pieces.length; i++) for (let j = i + 1; j < board.pieces.length; j++) {
      const a = board.pieces[i], b = board.pieces[j];
      if (movable(a) && movable(b) && !canAbsorb(b, a).ok && !['full', 'overflow'].includes(canAbsorb(b, a).reason) &&
          s.time - (s.moved.get(a.id) ?? -Infinity) >= AI_PLAY.moveCooldown &&
          s.time - (s.moved.get(b.id) ?? -Infinity) >= AI_PLAY.moveCooldown) {
        out.push({ kind: 'swap', pieceId: a.id, targetId: b.id, cost: 0 });
      }
    }
  }
  // 先按类型与融合阶段轮转，不能让数组前面的兵吃掉全部融合预算。
  const merges = out.filter(a => a.kind === 'merge' || a.kind === 'shopMerge');
  const buckets = new Map();
  for (const action of merges) {
    const target = board.pieces.find(piece => piece.id === action.targetId);
    const key = `${target.type}:${target.stage || 0}`;
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(action);
  }
  const ordered = [];
  const lists = [...buckets.values()];
  for (let n = 0; lists.some(list => n < list.length); n++) {
    for (const list of lists) if (list[n]) ordered.push(list[n]);
  }
  return [...out.filter(a => !merges.includes(a)), ...ordered];
}

function danger(board) {
  const end = board.map.path.length - 1;
  return board.enemies.some(e => e.hp > 0 && end - e.progress < Math.max(4, (e.speed || 0.65) * 10));
}

/** 连败调节只从完整推演过的合法候选中挑有限的自然次优动作。 */
function reliefAction(considered, selected, s, source, urgent) {
  const relief = s.relief;
  if (!relief?.active || relief.completed || urgent || !selected ||
      s.time < AI_RELIEF.startSec || source.lives <= 1 || selected.committed || selected.saved || s.plan ||
      relief.actions >= relief.maxMistakes || s.time - relief.lastAt < AI_RELIEF.minInterval || s.rescue) return null;
  const candidates = considered.filter(a => a !== selected && a.tested && !a.committed && !a.saved &&
    !['dig', 'merge'].includes(a.kind) && Number.isFinite(a.gain) &&
    a.gain > Math.max(1, selected.gain * 0.45) && a.gain < selected.gain - 1e-7 &&
    a.reliefRisk && a.reliefRisk.leaks <= 1 && a.reliefRisk.valueLoss <= AI_PLAY.leakPenalty);
  if (!candidates.length) return null;
  const risky = candidates.filter(a => a.reliefRisk.leaks > 0 || a.reliefRisk.valueLoss > 1);
  const pool = (risky.length ? risky : candidates).sort((a, b) =>
    (b.reliefRisk.leaks - a.reliefRisk.leaks) ||
    (b.reliefRisk.valueLoss - a.reliefRisk.valueLoss) ||
    (a.gain - b.gain));
  const width = Math.min(2, pool.length);
  return pool[variationKey(relief.seed, `${relief.actions}:${actionKey(pool[0], s.pieceKeys)}`) % width];
}

/** 现存敌人和确定待生成事件共用快照；不能因空场提前结束或只挑有利暴击。 */
function* combatValue(board, seeds, horizon = AI_PLAY.horizon, spawnPlan = [], followup = null) {
  let value = 0, leaks = 0, worstValue = Infinity, followupApplied = true;
  for (const seed of seeds) {
    let applied = !followup;
    const delayed = followup ? { actionDelay: AI_PLAY.actionMax,
      mutateAfterDelay: copy => {
        // 只在私有副本按正常动作落子；冲锋/践踏使预约失效时，不强行搬动。
        const piece = copy.pieces.find(p => p.id === followup.pieceId);
        const result = withBoard(copy, () => followup.kind === 'buy'
          ? act.buyAndPlace(followup.slot, followup.c, followup.r)
          : piece && movable(piece) ? act.moveTo(piece, followup.c, followup.r) : null);
        applied = !!result?.ok;
      } } : {};
    const simulation = createCombatSimulation(board, { horizon, step: AI_PLAY.simStep, seed, spawnPlan, ...delayed });
    while (!simulation.done) {
      simulation.advance({ maxSteps: 8, timeBudgetMs: ai.testSlices == null ? Math.max(0.1,
        Math.min(AI_PLAY.evaluationBudgetMs, AI_PLAY.simulationBudgetMs)) : Infinity });
      yield;
    }
    const result = simulation.result;
    // 临时心先挡漏怪，不能只看永久心差；死亡和到期后的0永久心必须显式惩罚。
    const lostHearts = Math.max(0, effectiveLives(board) - effectiveLives(result.board));
    const score = -(result.leaks + Math.max(0, lostHearts - result.leaks) * 0.1) * AI_PLAY.leakPenalty +
      result.kills * 8 - result.remainingHp * 0.06 + result.goldGain * 0.45 -
      (result.dead || result.board.lives <= 0 ? AI_PLAY.leakPenalty * 20 : 0);
    value += score;
    worstValue = Math.min(worstValue, score);
    leaks = Math.max(leaks, lostHearts);
    followupApplied = followupApplied && applied;
  }
  return { value: value / seeds.length, leaks, worstValue, followupApplied };
}

function positionKey(board) {
  return JSON.stringify([board.gold, board.wave, board.lives,
    board.temporaryLives, (board.gameTime || 0) >= (board.displacementCooldownUntil || 0),
    board.pieces.map(p => [p.id, p.type, p.color, p.c, p.r, p.level, p.stage,
      p.atkBonus, p.exp, p.critRateBonus, p.critDamageBonus, p.specialEnhancements,
      (p.tacticalBuffs || []).filter(b => b.until > (board.gameTime || 0)),
      p.evolutionChoicesType, p.evolutionChoices, p.flags, !!p.charge, !!p.stomp]),
    (board.gameTime || 0) >= (board.huanbingCooldownUntil || 0),
    board.enemies.some(e => e.hp > 0 && !e.done && !e.dying && !e.dead),
    board.flags, board.spellUsed, board.shopSlots, [...board.map.cleared], !!board.king?.arrived,
    // 不放每帧递减的 timer，避免永远取消；实际出怪/开波/倒计时状态改变则重新观察。
    sharedWaves.wave, sharedWaves.spawnedInWave, sharedWaves.betweenWaves, sharedWaves.countdown]);
}

/** 新手只看大致射程，不做临场调防或整盘长期规划。 */
function noviceCell(piece, cells, s) {
  const weighted = cells.map(cell => ({ ...cell,
    hits: computeAttackCells(piece.type, piece.color, cell.c, cell.r, piece.flags, piece.level, []).length,
  })).filter(cell => cell.hits > 0);
  if (!weighted.length) return null;
  weighted.sort((a, b) => b.hits - a.hits);
  const pool = random(s) < AI_NOVICE.smartPlacement ? weighted.slice(0, 2) : weighted;
  return pool[Math.floor(random(s) * pool.length)];
}

/** 独立的新手档；正常档不经过这里，也不消耗此档的随机数。 */
function* noviceStep(p, tier, s) {
  const play = action => {
    const ok = perform(action, s);
    if (ok) s.noviceActions++;
    return ok;
  };
  if (game.totalRefreshCount === 0) return play({ kind: 'refresh' });
  const live = game.cur, key = positionKey(live);
  const followup = plannedFollowup(s);
  if (followup) return play(followup);
  const source = clonePosition(live);
  // 新手容易满足于少量守兵，不会像正常档一样主动铺满防线。
  const plots = freePlots(), room = source.pieces.length < Math.min(BOARD_PIECE_LIMIT, AI_NOVICE.developmentPieces);
  const cards = source.shopSlots.map((card, slot) => ({ card, slot }))
    .filter(x => x.card && source.gold >= price(x.card));
  const shuffled = cards.map(x => ({ ...x, order: random(s) })).sort((a, b) => a.order - b.order);
  const merge = random(s) < AI_NOVICE.mergeChance;
  const base = scorePosition(clonePosition(source));
  // 仍检查完整随机进化分支，不能只挑好颜色/类型；只是新手不善于积极养成。
  // 新手仍有合法主动进化能力，但沿用原本低频养成倾向与正常动作间隔。
  if (merge) {
    for (const target of source.pieces.filter(piece => movable(piece) && canEvolve(piece))) {
      const choices = knownEvolutionChoices(target);
      const action = choices.length ? { kind: 'evolve', pieceId: target.id,
        evolutionType: choices[Math.floor(random(s) * choices.length)], cost: 0 }
        : { kind: 'prepareEvolution', targetId: target.id, cost: 0 };
      const evaluated = yield* evaluateActionSteps(source, action);
      if (positionKey(live) !== key) return 'stale';
      if (evaluated.score > base.score + 1) return play(action);
    }
    const options = [];
    for (const { card, slot } of shuffled) {
      if (!shop.isPieceCard(card)) continue;
      const material = previewCard(card, slot);
      for (const target of source.pieces) {
        if (!movable(target) || !canAbsorb(target, material).ok) continue;
        const evaluated = yield* evaluateActionSteps(source,
          { kind: 'shopMerge', slot, targetId: target.id, cost: price(card) });
        if (evaluated.score > base.score + 1) options.push(evaluated);
      }
    }
    if (positionKey(live) !== key) return 'stale';
    if (options.length) return play(options[Math.floor(random(s) * options.length)]);
  }
  for (const { card, slot } of shuffled) {
    if (room && shop.isPieceCard(card)) {
      const piece = previewCard(card, slot);
      const cell = withBoard(source, () => noviceCell(piece, plots, s));
      if (cell) return play({ kind: 'buy', slot, c: cell.c, r: cell.r, cost: price(card) });
    } else if (card.type === 'spell' && spellStockLeft(card.id) > 0 && random(s) < p.spellUse) {
      const options = spellActions(source, slot);
      if (!options.length) continue;
      const a = options[Math.floor(random(s) * Math.min(3, options.length))];
      const evaluated = yield* evaluateActionSteps(source, a);
      if (positionKey(live) !== key) return 'stale';
      if (!evaluated.unsafe && evaluated.branches.length && evaluated.score > base.score + 1) return play(a);
    }
    yield;
    if (positionKey(live) !== key) return 'stale';
  }
  // 只为眼前买得起的棋子扩一格，不搬动已有防线或反复撤兵救场。
  const shovel = cards.find(x => x.card.type === 'shovel');
  if (room && shovel && source.shovelUsed < SHOP.shovelMaxUsed) {
    const purchase = shuffled.find(x => shop.isPieceCard(x.card) &&
      source.gold >= SHOP.price.shovel + price(x.card));
    if (purchase) {
      const cells = [];
      for (let r = 0; r < source.map.rows; r++) for (let c = 0; c < source.map.cols; c++) {
        if (isDiggable(c, r)) cells.push({ c, r });
      }
      const cell = withBoard(source, () => noviceCell(previewCard(purchase.card, purchase.slot), cells, s));
      if (cell) return play({ kind: 'dig', slot: shovel.slot, c: cell.c, r: cell.r,
        followup: { kind: 'buy', slot: purchase.slot, c: cell.c, r: cell.r, cost: price(purchase.card) } });
    }
  }
  const refreshed = tryRefresh(p, s);
  if (refreshed) s.noviceActions++;
  return refreshed;
}

function* step(p, tier, s) {
  if (game.totalRefreshCount === 0) return perform({ kind: 'refresh' }, s);
  // 净赚金币不应排在买兵后面；这是确定收益，不需要消耗模拟预算。
  const income = game.shopSlots.findIndex(card => card?.type === 'spell' &&
    SPELL_BY_ID[card.id]?.effect.type === 'gainGold' && game.gold >= price(card) &&
    SPELL_BY_ID[card.id].effect.value > price(card) && spellStockLeft(card.id) > 0);
  if (income >= 0) return perform({ kind: 'spell', slot: income }, s);

  const live = game.cur, key = positionKey(live);
  const experiment = ai.experiment;
  const commitment = plannedFollowup(s);
  const source = clonePosition(live), base = scorePosition(clonePosition(source));
  const horizon = experiment?.horizon ?? AI_PLAY.horizon + p.progress * 2;
  const forecast = buildSpawnPlan({ ...sharedWaves }, { horizon, step: AI_PLAY.simStep, WAVES, ENEMY,
    schedulerReady: !!source.king?.arrived &&
      Object.values(game.boards).every(board => !board?.king || board.king.arrived) });
  s.forecastCount = forecast.events.length;
  const urgent = danger(source);
  const search = candidates(p, tier, s);
  let generated;
  do {
    // 每次恢复时才切到快照，绝不跨 yield 持有 game.cur。
    generated = withBoard(source, () => search.next());
    if (!generated.done) yield;
  } while (!generated.done);
  const pool = generated.value, ranked = [];
  // 随机基线：从同一批合法候选中均匀抽取，不做任何评估。
  if (experiment?.strategy === 'random') {
    if (positionKey(live) !== key) { s.cancelled++; return 'stale'; }
    if (!pool.length) return tryRefresh(p, s);
    return perform(pool[Math.floor(random(s) * pool.length)], s);
  }
  let planned;
  if (commitment) {
    planned = yield* evaluateActionSteps(source, commitment, tier >= 4);
    planned.gain = planned.score - base.score - (planned.kind === 'move' ? AI_PLAY.movePenalty : 0);
    ranked.push(planned);
  }
  const limit = tier >= 5 ? AI_PLAY.maxCandidates + Math.floor(p.progress * 8) : Math.round(24 + tier * 8);
  // 按动作类别交错评估，避免大量移动或融合挤掉买棋/法术；计划不重复占用预算。
  const groups = ['buy', 'shopMerge', 'evolve', 'spell', 'prepareEvolution', 'move', 'merge', 'swap'].map(kind => pool.filter(a =>
    a.kind === kind && !(commitment && a.kind === commitment.kind && sameCell(a, commitment) &&
      a.slot === commitment.slot && a.pieceId === commitment.pieceId)));
  for (let n = 0; ranked.length < limit; n++) {
    let any = false;
    for (const group of groups) {
      const a = group[n];
      if (!a || ranked.length >= limit) continue;
      any = true;
      const evaluated = yield* evaluateActionSteps(source, a, tier >= 4);
      if (!evaluated.branches.length || evaluated.unsafe) continue;
      evaluated.gain = evaluated.score - base.score;
      // 移位需要真实增益，不能为微小静态分差不停挪动。
      if (['move', 'swap'].includes(a.kind)) evaluated.gain -= AI_PLAY.movePenalty;
      if (!urgent && s.rescue && s.rescue.pieceId === a.pieceId && sameCell(a, s.rescue.origin)) evaluated.gain += 5;
      ranked.push(evaluated);
      yield;
    }
    if (!any) break;
  }
  // 开地也是一步经济规划，不能永远被小幅换位挤到最后而停止扩建。
  if (tier >= 4) {
    const digging = tryDig(p, tier, s, base);
    let dig;
    do {
      dig = withBoard(source, () => digging.next());
      if (!dig.done) yield;
    } while (!dig.done);
    for (const option of dig.value) {
      const evaluated = yield* evaluateActionSteps(source, option);
      evaluated.gain = option.gain;
      ranked.push(evaluated);
    }
  }
  ranked.sort((a, b) => b.gain - a.gain);

  // 临时调防候选即使静态评分低，也必须进入近期战斗比较。
  // 成熟防线允许小额投资，但必须有当前已知、买得起的补位牌，且逐分支验证防守。
  const investmentLimit = Math.min(20, base.output * 0.04);
  const canDevelop = tier >= 4 && !urgent && source.pieces.length >= 8 &&
    source.shopSlots.some(card => card && shop.isPieceCard(card) && source.gold >= price(card));
  const development = canDevelop ? ranked.find(a => a.kind === 'merge' && a.gain > -investmentLimit &&
    ['bing', 'shi', 'xiang'].includes(source.pieces.find(piece => piece.id === a.targetId)?.type)) : null;
  const simulations = ranked.slice(0, tier >= 5 ? 3 : 2);
  // 时限增伤、直接伤害、强控和蓄势都要经过真实战斗，不能只理解卡面。
  const tacticalSpell = ranked.find(a => a.kind === 'spell' && !a.unsafe && a.branches.length &&
    SPELL_BY_ID[a.spellId]?.role !== 'growth');
  if (tacticalSpell && !simulations.includes(tacticalSpell)) simulations.push(tacticalSpell);
  if (planned && !simulations.includes(planned)) simulations.push(planned);
  if (development && !simulations.includes(development)) simulations.push(development);
  if (tier >= 4) {
    const development = ranked.find(a => ['merge', 'shopMerge'].includes(a.kind) && a.gain > 1);
    if (development && !simulations.includes(development)) simulations.push(development);
  }
  if (s.variety && !urgent && !planned && ranked[0]) {
    const extra = ranked.find(a => !simulations.includes(a) && equivalentAction(a, ranked[0]));
    if (extra) simulations.push(extra);
  }
  if (urgent) {
    const moves = ranked.filter(a => a.kind === 'move');
    for (const move of moves.slice(0, 3)) if (!simulations.includes(move)) simulations.push(move);
    if (s.rescue) {
      const back = moves.find(a => a.pieceId === s.rescue.pieceId && sameCell(a, s.rescue.origin));
      if (back && !simulations.includes(back)) simulations.push(back);
    }
  }
  const active = source.enemies.some(e => !e.done && !e.dying && e.hp > 0) || forecast.events.length > 0;
  const needsCombat = active && !experiment?.noSimulation && (tier >= 2 || urgent || !!planned);
  if (needsCombat) {
    const hasCrit = source.pieces.some(piece => criticalStats(piece).rate > 0) ||
      simulations.some(a => a.branches.some(b => b.board.pieces.some(piece => criticalStats(piece).rate > 0)));
    const seeds = tier >= 5 && (hasCrit || s.relief?.active) ? [173, 941] : [173];
    const before = yield* combatValue(source, seeds, horizon, forecast.events);
    for (const a of simulations) {
      // 同色羁绊与全场经验使颜色/候选状态不再战斗等价；每个机会节点独立推演。
      const typeResults = new Map();
      const values = [];
      for (const branch of a.branches) {
        const result = yield* combatValue(branch.board, seeds, horizon, forecast.events);
        typeResults.set(typeResults.size, result);
        values.push({ probability: branch.probability, value: result.value });
      }
      const after = riskAdjusted(values, experiment?.risk ?? (urgent ? 0.75 : 0.5));
      a.combat = { value: after, leaks: Math.max(...[...typeResults.values()].map(result => result.leaks)),
        worstValue: Math.min(...[...typeResults.values()].map(result => result.worstValue)) };
      a.reliefRisk = { leaks: a.combat.leaks - before.leaks,
        valueLoss: Math.max(0, before.value - a.combat.value) };
      if (a.kind === 'dig' && s.variety && !urgent && !planned &&
          simulations.filter(option => option.kind === 'dig').length > 1) {
        a.followupCombat = yield* combatValue(a.branches[0].board, seeds, horizon, forecast.events, a.followup);
      }
      if (a.kind === 'spell') {
        // 筛选近似已由真实战斗覆盖，避免伤害/控制/增伤重复记分。
        const settled = a.branches.map(branch => ({ probability: branch.probability,
          value: branch.staticValue + spellOpportunityScore(source, branch.board, a) +
            Math.max(0, branch.board.kills - source.kills) * 8 }));
        a.gain += riskAdjusted(settled) - a.score;
      }
      a.gain += after - before.value;
      a.tested = true;
      s.battleChecks = (s.battleChecks || 0) + 1;
      a.saved = after - before.value >= AI_PLAY.leakPenalty * 0.5;
      a.safeDevelopment = a === development && before.leaks === 0 &&
        [...typeResults.values()].every(result => result.leaks === 0 && result.value >= before.value - 1);
      a.safePlan = a === planned &&
        [...typeResults.values()].every(result => result.leaks <= before.leaks && result.value >= before.value - 1);
    }
    ranked.sort((a, b) => b.gain - a.gain);
  }

  // 不能在推演否定前三名后，又退回未经推演的第四名冒险。
  const considered = (needsCombat ? ranked.filter(a => a.tested) : ranked)
    .filter(a => !a.committed || !active || a.safePlan);
  let selected = considered.find(a => a.gain > 1);
  if (!active && development && !forecast.uncertainBoundary) development.safeDevelopment = true;
  if (!selected || (['move', 'swap'].includes(selected.kind) && !selected.saved)) {
    selected = considered.find(a => a.safeDevelopment && a.gain > -investmentLimit) || selected;
  }
  // 兑现扩建目的，不让微小换位分差抢走下一手；真正能少漏血的救场仍可打断。
  if (planned && (!active || planned.safePlan) && planned.gain > 1 && !selected?.saved) selected = planned;
  let reliefSelected = false;
  const relieved = needsCombat ? reliefAction(considered, selected, s, source, urgent) : null;
  if (relieved) {
    selected = relieved;
    reliefSelected = true;
  }
  // 低段失误只在合理候选里选次优，不允许乱刷最后金币。
  let mistaken = false;
  if (!reliefSelected && selected && random(s) < p.mistake) {
    mistaken = true;
    const alternatives = considered.filter(a => a.gain > Math.max(1, selected.gain * 0.45)).slice(0, 3);
    selected = alternatives[Math.floor(random(s) * alternatives.length)] || selected;
  }
  const reference = selected;
  const variety = chooseEquivalent(reference, considered, { seed: s.variationSeed,
    enabled: s.variety && !planned && !mistaken && !reliefSelected, urgent, needsCombat, pieceKeys: s.pieceKeys, board: source });
  selected = variety.action;
  if (positionKey(live) !== key) { s.cancelled++; return 'stale'; }
  if (planned && s.plan && ((active && !planned.safePlan) || planned.gain <= 1)) {
    s.plan = null;
    s.plansCancelled = (s.plansCancelled || 0) + 1;
  }
  if (selected?.committed && !plannedFollowup(s)) return 'stale';
  if (selected) {
    if (selected.kind === 'move' && selected.saved && !s.rescue) {
      const piece = source.pieces.find(p => p.id === selected.pieceId);
      s.rescue = { pieceId: piece.id, origin: { c: piece.c, r: piece.r }, started: s.time };
    }
    const success = perform(selected, s);
    if (success) {
      s.varietyEligible = variety.eligible;
      if (selected !== reference) s.varietyChoices = (s.varietyChoices || 0) + 1;
      if (reliefSelected && s.relief) {
        s.relief.actions++;
        s.relief.lastAt = s.time;
        if (s.relief.actions >= s.relief.maxMistakes) s.relief.completed = true;
      }
    }
    return success;
  }
  // 兜底不启用随机扩建：未推演的替代方案不能从这里绕过门禁。
  const digging = tryDig(p, tier, { ...s, variety: false }, base);
  let dig;
  do {
    dig = withBoard(source, () => digging.next());
    if (!dig.done) yield;
  } while (!dig.done);
  if (positionKey(live) !== key) { s.cancelled++; return 'stale'; }
  if (dig.value.length) return perform(dig.value[0], s);
  return tryRefresh(p, s);
}

/** 为实际能买/搬的棋子开地，且预留下一步成本；铲子本身不是战力。 */
function* tryDig(p, tier, s, baseline) {
  const slot = game.shopSlots.findIndex(c => c?.type === 'shovel');
  if (slot < 0 || game.gold < SHOP.price.shovel || game.shovelUsed >= SHOP.shovelMaxUsed) return [];
  const available = game.shopSlots.map((card, i) => ({ card, i }))
    .filter(x => game.pieces.length < BOARD_PIECE_LIMIT && shop.isPieceCard(x.card) && game.gold >= SHOP.price.shovel + price(x.card));
  const samples = available.map(x => ({ piece: previewCard(x.card, x.i), cost: price(x.card), slot: x.i }));
  samples.push(...game.pieces.filter(piece => movable(piece) &&
    s.time - (s.moved.get(piece.id) ?? -Infinity) >= AI_PLAY.moveCooldown).map(piece => ({ piece, cost: 0 })));
  if (!samples.length) return [];
  const cells = [];
  for (let r = 0; r < game.map.rows; r++) for (let c = 0; c < game.map.cols; c++) {
    if (isDiggable(c, r)) cells.push({ c, r });
  }
  let best = null;
  const alternatives = [];
  for (const sample of samples.slice(0, tier >= 4 ? 8 : 4)) {
    const shortlist = bestCells(sample.piece, cells, 3, s, true);
    for (const cell of shortlist) {
      const board = clonePosition(game.cur);
      board.map.cleared.add(`${cell.c},${cell.r}`);
      const existing = board.pieces.find(x => x.id === sample.piece.id);
      if (existing) { existing.c = cell.c; existing.r = cell.r; }
      else board.pieces.push({ ...sample.piece, c: cell.c, r: cell.r });
      board.gold -= SHOP.price.shovel + sample.cost;
      const gain = scorePosition(board).score - baseline.score - 2;
      if (gain > 1) {
        const followup = existing
          ? { kind: 'move', pieceId: sample.piece.id, ...cell, cost: 0 }
          : { kind: 'buy', slot: sample.slot, ...cell, cost: sample.cost };
        const option = { kind: 'dig', slot, ...cell, gain, cost: SHOP.price.shovel, followup };
        alternatives.push(option);
        if (gain > (best?.gain || 1)) best = option;
      }
      yield;
    }
  }
  if (!best) return [];
  if (!s.variety || danger(game.cur) || s.plan) return [best];
  return [best, ...alternatives.filter(a => a !== best && a.gain >= best.gain - 1e-7 &&
      a.followup.kind === best.followup.kind && a.followup.slot === best.followup.slot &&
      a.followup.pieceId === best.followup.pieceId)
    .sort((a, b) => variationKey(s.variationSeed, actionKey(a, s.pieceKeys)) -
      variationKey(s.variationSeed, actionKey(b, s.pieceKeys)))].slice(0, 2);
}

/** 未知刷新不预读结果；按后续购买预算搜索，并保护已拥有的棋子。 */
function tryRefresh(p, s) {
  const cost = currentRefreshCost();
  if (s.plan || game.shopSlots.some(c => c?.source === 'fromBoard')) return false;
  const plots = freePlots();
  const hasShovel = game.shopSlots.some(c => c?.type === 'shovel');
  const canDig = game.shovelUsed < SHOP.shovelMaxUsed;
  const followup = !plots.length && !hasShovel && canDig ? SHOP.price.shovel + SHOP.price.piece : SHOP.price.piece;
  const reserve = Math.max(followup, Math.min(p.reserve, 10));
  if (game.gold - cost < reserve) return false;
  if (random(s) > p.refreshEagerness) return false;
  return perform({ kind: 'refresh' }, s);
}

function perform(a, s) {
  const piece = game.pieces.find(p => p.id === a.pieceId);
  const target = game.pieces.find(p => p.id === a.targetId);
  let result;
  switch (a.kind) {
    case 'refresh': result = act.refresh(); break;
    case 'buy': result = act.buyAndPlace(a.slot, a.c, a.r); break;
    case 'shopMerge': result = act.shopToPiece(a.slot, target); break;
    case 'merge': result = act.boardToPiece(piece, target); break;
    case 'swap': result = act.boardToPiece(piece, target); break;
    case 'move': result = act.moveTo(piece, a.c, a.r); break;
    case 'dig': result = act.useShovel(a.slot, a.c, a.r); break;
    case 'evolve': result = piece && movable(piece) ? act.evolvePiece(piece, a.evolutionType) : null; break;
    case 'prepareEvolution': {
      if (!target || !movable(target) || knownEvolutionChoices(target, Number.isInteger(a.slot)).length) break;
      // 请求真实界面同样使用的选择入口；不消费卡/金币，并等待下一次正常动作确认。
      result = Number.isInteger(a.slot) ? act.useSpell(a.slot, target, null, {}) : act.evolvePiece(target);
      if (result?.requiresSelection === 'evolutionType' && knownEvolutionChoices(target, Number.isInteger(a.slot)).length) result = { ok: true };
      break;
    }
    case 'spell': result = act.useSpell(a.slot, target || null,
      Number.isInteger(a.c) && Number.isInteger(a.r) ? { c: a.c, r: a.r } : null,
      { color: a.color, secondaryTargetId: a.secondaryTargetId }); break;
  }
  if (!result?.ok) return false;
  if (a.committed) {
    s.plan = null;
    s.plansCompleted = (s.plansCompleted || 0) + 1;
  }
  if (a.kind === 'dig' && a.followup) {
    const followupPiece = game.pieces.find(p => p.id === a.followup.pieceId);
    s.plan = { action: { ...a.followup }, expires: s.time + 8,
      card: a.followup.kind === 'buy' ? game.shopSlots[a.followup.slot] : null,
      origin: followupPiece ? { c: followupPiece.c, r: followupPiece.r } : null };
  }
  if (['move', 'swap'].includes(a.kind)) {
    s.moved.set(a.pieceId, s.time);
    if (a.targetId) s.moved.set(a.targetId, s.time);
  }
  if (s.rescue) {
    const rescued = game.pieces.find(p => p.id === s.rescue.pieceId);
    if (!rescued || sameCell(rescued, s.rescue.origin)) s.rescue = null;
  }
  s.lastAction = { kind: a.kind, time: s.time, pieceId: a.pieceId, targetId: a.targetId,
    spellId: a.spellId, evolutionType: a.evolutionType, color: a.color, c: a.c, r: a.r };
  return true;
}

export default { setupAI, aiTick, setForcedTier, setAIPaused, aiInfo };
