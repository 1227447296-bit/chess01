import game, { createBoard, withBoard, isPlaceablePlot } from './gameData.js';
import { rescanBonds } from './bond.js';
import { computeAttackCells } from './rangePreview.js';
import { update, updateSharedWaves, resetSharedWaves, sharedWaves } from './wave.js';

/** Optimistic capped roster stress test, not a claim about normal player/AI match duration. */
export function runExperimentalPressureBenchmark(map = null) {
  const source = game.boards.me;
  const sharedMap = map || source.map;
  const previous = { cur: game.cur, phase: game.phase, scheduler: { ...sharedWaves } };
  function makeBoard(side) {
    const board = createBoard(side, sharedMap);
    board._simulationContext = { random: () => 0.5 };
    board.king = { kind: 'king', type: 'king', ...board.map.kingPoint, arrived: true };
    for (let r = 0; r < board.map.rows; r++) for (let c = 0; c < board.map.cols; c++) {
      if (board.map.grass[r]?.[c]) board.map.cleared.add(`${c},${r}`);
    }
    withBoard(board, () => {
      const types = ['ju', 'ju', 'pao', 'pao', 'ma', 'ma', 'xiang', 'xiang', 'shi', 'bing'];
      for (let i = 0; i < types.length; i++) {
        const type = types[i], color = i % 2 ? 'black' : 'red';
        let best = null;
        for (let r = 0; r < board.map.rows; r++) for (let c = 0; c < board.map.cols; c++) {
          if (!isPlaceablePlot(c, r)) continue;
          const cells = computeAttackCells(type, color, c, r, {}, 60);
          const score = cells.length;
          if (!best || score > best.score) best = { c, r, score };
        }
        if (!best) break;
        board.pieces.push({ id: `${side}-pressure-${i}`, kind: 'piece', type, color,
          c: best.c, r: best.r, level: 60, exp: 0, stage: 3, atkBonus: 20,
          flags: { critRateBonus: 0.10, critDamageBonus: 0.25 }, cdLeft: 0, activeBonds: [] });
      }
      rescanBonds();
    });
    return board;
  }
  try {
    const me = makeBoard('me'), opp = makeBoard('opp');
    game.phase = 'playing';
    resetSharedWaves();
    let seconds = 0;
    const dt = 0.05;
    while (seconds < 1800 && !me.dead && !opp.dead) {
      updateSharedWaves(dt, [me, opp]);
      withBoard(me, () => update(dt));
      withBoard(opp, () => update(dt));
      seconds += dt;
    }
    return { scenario: 'fixed optimistic capped roster; no AI economy or emergency spells',
      map: `${me.map.cols}x${me.map.rows}`, pieces: me.pieces.length,
      ended: me.dead || opp.dead, wave: me.wave, seconds: Math.round(seconds),
      kills: me.kills, lives: me.lives, sourceUnchanged: source === game.boards.me };
  } finally {
    game.cur = previous.cur;
    game.phase = previous.phase;
    Object.assign(sharedWaves, previous.scheduler);
  }
}
