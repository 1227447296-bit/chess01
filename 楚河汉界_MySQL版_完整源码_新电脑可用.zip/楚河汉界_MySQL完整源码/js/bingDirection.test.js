/** 显式开发回归入口；不依赖画布方向状态，不改正式棋盘。 */
import game, { createBoard, withBoard } from './gameData.js';
import { bingAttackOffsets, canBingAttack, canPieceAttack } from './attackRule.js';
import { boardToView, viewToBoard, vectorToView, isSidewaysMap, viewSize } from './boardView.js';
import { computeAttackCells, computeAttackPreview } from './rangePreview.js';
import { simulateCombat } from './aiSimulation.js';

const snapshot = value => JSON.stringify(value, (key, item) =>
  item instanceof Set ? [...item] : item instanceof Map ? [...item] : item);
const keys = cells => cells.map(({ c, r }) => `${c},${r}`).sort().join('|');
const screenDirections = [[0, -1], [-1, 0], [1, 0], [0, 1]];

export function runBingDirectionFixtures() {
  const checks = [];
  const check = (name, ok) => {
    checks.push({ name, ok: !!ok });
    if (!ok) throw new Error(`bing direction: ${name}`);
  };
  const originalCur = game.cur, originalPhase = game.phase;
  const originalBoards = snapshot(game.boards);
  for (const [cols, rows] of [[4, 10], [5, 8]]) {
    for (const side of ['me', 'opp']) for (const color of ['red', 'black']) for (const level of [9, 10]) {
      const b = createBoard(side, {
        cols, rows,
        ground: Array.from({ length: rows }, () => Array(cols).fill(1)),
        grass: Array.from({ length: rows }, () => Array(cols).fill(0)),
        road: Array.from({ length: rows }, () => Array(cols).fill(1)),
        path: [], enemySpawn: null, kingPoint: null, raw: null,
      });
      const p = {
        id: 'bing-direction-piece', kind: 'piece', type: 'bing', color,
        c: 1, r: 3, level, exp: 0, stage: 0, atkBonus: 0,
        flags: {}, cdLeft: 0, bonds: [], activeBonds: [],
      };
      b.pieces.push(p);
      const label = `${cols}x${rows}/${side}/${color}/lv${level}`;
      const sideways = isSidewaysMap(b.map), flip = side === 'opp';
      const center = boardToView(p.c, p.r, b.map, sideways, flip);
      // Expected directions are screen-space constants, not derived from the rule helper.
      // 兵不再在10级获得后方攻击，所有等级都只打前、左、右。
      const permitted = (dx, dy) => dy === 0 || dy === (flip ? 1 : -1);
      const expected = screenDirections.filter(([dx, dy]) => permitted(dx, dy))
        .map(([dx, dy]) => viewToBoard(center.c + dx, center.r + dy, b.map, sideways, flip));
      const before = snapshot(b);
      withBoard(b, () => {
        for (const [dx, dy] of screenDirections) {
          const target = viewToBoard(center.c + dx, center.r + dy, b.map, sideways, flip);
          check(`${label} screen ${dx},${dy}`, canBingAttack(p, target) === permitted(dx, dy) &&
            canPieceAttack(p, target) === permitted(dx, dy));
        }
        for (const [dc, dr] of [[0, 0], [1, 1], [-1, -1], [2, 0], [0, -2]]) {
          check(`${label} excludes ${dc},${dr}`, !canPieceAttack(p, { c: p.c + dc, r: p.r + dr }));
        }
        const offsets = bingAttackOffsets(p);
        check(`${label} shared offsets`, keys(offsets.map(([dc, dr]) => ({ c: p.c + dc, r: p.r + dr }))) === keys(expected));
        // main.rangeSectionHtml uses this same helper and one display-vector transform.
        const diagram = offsets.map(([dc, dr]) => {
          const v = vectorToView(dc, dr, sideways, flip);
          return { c: v.x, r: v.y };
        });
        check(`${label} detail vectors`, keys(diagram) === keys(screenDirections
          .filter(([dx, dy]) => permitted(dx, dy)).map(([c, r]) => ({ c, r }))));
        check(`${label} preview equals true attack`, keys(computeAttackCells('bing', color, p.c, p.r, {}, level)) === keys(expected));
        const preview = computeAttackPreview('bing', color, p.c, p.r, {}, level);
        check(`${label} preview has no blocked cells`, keys(preview.hits) === keys(expected) && preview.blocked.length === 0);
      });
      check(`${label} preview source isolation`, snapshot(b) === before && game.cur === originalCur);

      // Omit a legal attack cell from road: true legality remains, preview must omit it.
      const excluded = expected[0];
      b.map.road[excluded.r][excluded.c] = 0;
      const roadBefore = snapshot(b);
      withBoard(b, () => {
        check(`${label} preview only road`, canPieceAttack(p, excluded) &&
          keys(computeAttackCells('bing', color, p.c, p.r, {}, level)) === keys(expected.slice(1)));
      });
      check(`${label} road-filter source isolation`, snapshot(b) === roadBefore);
      b.map.road[excluded.r][excluded.c] = 1;

      // Each screen corner checks clipping independently of the logical orientation.
      const size = viewSize(b.map);
      for (const [vc, vr] of [[0, 0], [size.cols - 1, 0], [0, size.rows - 1], [size.cols - 1, size.rows - 1]]) {
        const cell = viewToBoard(vc, vr, b.map, sideways, flip);
        const expectedEdge = screenDirections.filter(([dx, dy]) => permitted(dx, dy) &&
          vc + dx >= 0 && vc + dx < size.cols && vr + dy >= 0 && vr + dy < size.rows)
          .map(([dx, dy]) => viewToBoard(vc + dx, vr + dy, b.map, sideways, flip));
        withBoard(b, () => check(`${label} corner ${vc},${vr}`,
          keys(computeAttackCells('bing', color, cell.c, cell.r, {}, level)) === keys(expectedEdge)));
      }

      // AI simulation calls real wave.update on a private clone. Stationary enemies
      // avoid movement/target ambiguity; nonlethal HP avoids experience/reward effects.
      for (const [dx, dy] of screenDirections) {
        const target = viewToBoard(center.c + dx, center.r + dy, b.map, sideways, flip);
        b.map.path = [target, { c: target.c, r: target.r }];
        b.enemies = [{
          id: 'bing-direction-enemy', ...target, fx: target.c, fy: target.r,
          hp: 10000, maxHp: 10000, speed: 0, progress: 0,
          done: false, dying: false, deathT: 0, stunLeft: 0, stunImmuneLeft: 0,
        }];
        const combatBefore = snapshot(b);
        const result = simulateCombat(b, { horizon: 1 / 30, seed: 17 });
        check(`${label} simulation ${dx},${dy}`, (result.board.enemies[0].hp < 10000) === permitted(dx, dy));
        check(`${label} simulation preserves source/context ${dx},${dy}`,
          snapshot(b) === combatBefore && game.cur === originalCur && game.phase === originalPhase && result.board.side === side);
      }
    }
  }
  check('formal boards unchanged', snapshot(game.boards) === originalBoards);
  check('global context unchanged', game.cur === originalCur && game.phase === originalPhase);
  return { passed: checks.length, checks };
}
