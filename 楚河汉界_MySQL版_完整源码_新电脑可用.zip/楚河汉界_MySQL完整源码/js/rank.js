/**
 * rank.js —— 段位系统（只存段位进度到 localStorage）
 *
 * 状态 { tier, sub, stars, protectLeft, wins, losses, streak }
 *   tier ：大段索引（RANKS 下标，0 = 塑料）
 *   sub  ：小段（1 起）
 *   stars：当前小段星数 0~3（至高最后不封顶）
 *   protectLeft：当前大段剩余「掉大段保护」次数（升入该大段时补满）
 *   streak：连胜为正、连败为负（供 AI 动态难度）
 *
 * 规则：
 *   赢 +1 星：满 3 星后再 +1 → 下一小段 1 星；最后一个小段满星后再 +1 → 下一大段 1 段 1 星；
 *            至高为最高段，到顶后星数继续累加。
 *   输 -1 星：0 星时再输 → 上一小段 2 星；若要跨回上一大段，先消耗保护（留在原段 0 星）；
 *            塑料 1 段 0 星不再掉。
 *   平局：不变。
 */
import { RANKS, STARS_PER_SUB, RANK_SAVE_KEY } from './config.js';

const fresh = () => ({
  tier: 0, sub: 1, stars: 1,
  protectLeft: RANKS[0].protect,
  wins: 0, losses: 0, streak: 0,
});

export const storageStatus = { ok: true, recovered: false };
let state = load();

function normalize(s) {
  const value = { ...fresh(), ...s };
  value.tier = Math.min(Math.max(0, value.tier | 0), RANKS.length - 1);
  value.sub = Math.min(Math.max(1, value.sub | 0), RANKS[value.tier].subs);
  const top = value.tier === RANKS.length - 1 && value.sub === RANKS[value.tier].subs;
  value.stars = Math.min(top ? Number.MAX_SAFE_INTEGER : STARS_PER_SUB, Math.max(0, Number.isSafeInteger(value.stars) ? value.stars : 0));
  value.protectLeft = Math.min(RANKS[value.tier].protect, Math.max(0, value.protectLeft | 0));
  return value;
}

function load() {
  for (const key of [RANK_SAVE_KEY, RANK_SAVE_KEY + '.backup']) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) continue;
      const parsed = JSON.parse(raw);
      if (!parsed || !Number.isInteger(parsed.tier) || !Number.isInteger(parsed.sub)) continue;
      storageStatus.recovered = key.endsWith('.backup');
      storageStatus.ok = true;
      return normalize(parsed);
    } catch { storageStatus.ok = false; }
  }
  return fresh();
}

export function save() {
  try {
    const text = JSON.stringify(state);
    localStorage.setItem(RANK_SAVE_KEY, text);
    storageStatus.ok = true;
    try { localStorage.setItem(RANK_SAVE_KEY + '.backup', text); } catch { /* 主存档已成功写入 */ }
    return true;
  } catch {
    storageStatus.ok = false;
    return false;
  }
}

/** 可复制到另一设备或网站的段位备份，不包含对局状态。 */
export function exportRank() {
  return 'CNCHESS1:' + btoa(JSON.stringify(state));
}

export function importRank(code) {
  try {
    if (!String(code).trim().startsWith('CNCHESS1:')) throw new Error('format');
    const s = JSON.parse(atob(String(code).trim().slice(9)));
    const fields = ['tier', 'sub', 'stars', 'protectLeft', 'wins', 'losses', 'streak'];
    if (!s || fields.some(k => !Number.isSafeInteger(s[k]))) throw new Error('fields');
    if (s.tier < 0 || s.tier >= RANKS.length) throw new Error('tier');
    const r = RANKS[s.tier], top = s.tier === RANKS.length - 1 && s.sub === r.subs;
    if (s.sub < 1 || s.sub > r.subs || s.stars < 0 || (!top && s.stars > STARS_PER_SUB)
        || s.protectLeft < 0 || s.protectLeft > r.protect || s.wins < 0 || s.losses < 0) throw new Error('range');
    state = Object.fromEntries(fields.map(k => [k, s[k]]));
    const saved = save();
    return { ok: true, saved };
  } catch { return { ok: false, message: '存档码无效或不完整，请重新复制' }; }
}

export const getRank = () => ({ ...state });

const isTop = (s) => s.tier === RANKS.length - 1;
const isLastSub = (s) => s.sub >= RANKS[s.tier].subs;

/** 加 1 星，返回事件文本（升段提示）或空串 */
function addStar(s) {
  if (s.stars < STARS_PER_SUB || (isTop(s) && isLastSub(s))) { s.stars += 1; return ''; }
  if (!isLastSub(s)) { s.sub += 1; s.stars = 1; return `晋升 ${label(s)}`; }
  if (isTop(s)) { s.stars += 1; return ''; }
  s.tier += 1; s.sub = 1; s.stars = 1;
  s.protectLeft = RANKS[s.tier].protect;
  return `晋升大段：${RANKS[s.tier].name}！`;
}

/** 减 1 星，返回事件文本（掉段 / 保护提示）或空串 */
function loseStar(s) {
  if (s.stars > 0) { s.stars -= 1; return ''; }
  if (s.sub > 1) { s.sub -= 1; s.stars = STARS_PER_SUB - 1; return `降至 ${label(s)}`; }
  if (s.tier === 0) return '';                              // 塑料 1 段 0 星：不再掉
  if (s.protectLeft > 0) {
    s.protectLeft -= 1;
    return `触发掉段保护（剩余 ${s.protectLeft} 次）`;
  }
  s.tier -= 1;
  s.sub = RANKS[s.tier].subs;
  s.stars = STARS_PER_SUB - 1;
  // 掉回的大段保护次数不补满（只有升入时补满）
  return `掉回大段：${RANKS[s.tier].name}`;
}

/**
 * 结算一局。
 * @param {'win'|'lose'|'draw'} result
 * @returns {{before:object, after:object, events:string[]}}
 */
export function settle(result) {
  const before = { ...state };
  const events = [];
  if (result === 'win') {
    state.wins += 1;
    state.streak = state.streak > 0 ? state.streak + 1 : 1;
    const e = addStar(state); if (e) events.push(e);
  } else if (result === 'lose') {
    state.losses += 1;
    state.streak = state.streak < 0 ? state.streak - 1 : -1;
    const e = loseStar(state); if (e) events.push(e);
  }
  save();
  return { before, after: { ...state }, events };
}

/** 作弊：加 / 减 n 星（按正常升降规则逐颗结算） */
export function adjustStars(n) {
  const events = [];
  for (let i = 0; i < Math.abs(n); i++) {
    const e = n > 0 ? addStar(state) : loseStar(state);
    if (e) events.push(e);
  }
  save();
  return events;
}

/** 作弊：直接设置段位（大段可传名称或下标） */
export function setRank(tier, sub = 1, stars = 1) {
  let t = typeof tier === 'number' ? tier : RANKS.findIndex(r => r.name === tier);
  if (t < 0 || t >= RANKS.length) return false;
  state.tier = t;
  state.sub = Math.min(Math.max(1, sub | 0), RANKS[t].subs);
  state.stars = Math.max(0, stars | 0);
  state.protectLeft = RANKS[t].protect;
  save();
  return true;
}

export function resetRank() {
  state = fresh();
  save();
}

/** 「黄金 3 段」 */
export function label(s = state) {
  return `${RANKS[s.tier].name} ${s.sub} 段`;
}

/** 段位下方的星数显示：★×n */
export function starText(s = state) {
  return `★×${s.stars}`;
}

export default { getRank, settle, adjustStars, setRank, resetRank, label, starText, save };
