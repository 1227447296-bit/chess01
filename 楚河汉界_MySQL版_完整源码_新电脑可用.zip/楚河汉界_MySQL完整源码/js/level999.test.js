import game, { createBoard, withBoard } from './gameData.js';
import { LEVEL, MERGE, experienceRequired } from './config.js';
import { mergedLevel, applyAbsorb } from './synthesis.js';
import { grantExperience } from './wave.js';
import { shopMerge, shopToPiece, boardToPiece, useSpell } from './actions.js';
import { actionBranches } from './aiEvaluation.js';

export function runLevel999Fixtures() {
  let passed = 0;
  const check = (ok, label) => { if (!ok) throw Error(label); passed++; };
  let uid = 0;
  const piece = (type = 'ju', level = 12, stage = 0) => ({ id: `level-${++uid}`, kind: 'piece', type,
    color: 'red', c: 1, r: 1, level, stage, exp: 4, atkBonus: 0, flags: {}, bonds: [], cdLeft: 0 });
  const board = () => { const b = createBoard('opp'); b.gold = 100; b._simulationContext = { random: () => 0.25 };
    b.map = { cols: 3, rows: 3, path: [], ground: [], road: [], grass: [], cleared: new Set() }; return b; };
  check(LEVEL.hardCap === 999 && MERGE.levelCap === 999 && Object.values(LEVEL.naturalCap).every(x => x === 999), '全部等级上限999');
  for (const [a, b, expected] of [[0, 0, 3], [11, 7, 21], [60, 60, 123], [500, 495, 998], [500, 496, 999], [998, 999, 999]]) {
    check(mergedLevel({ level: a }, { level: b }) === expected, `${a}+${b}+3封顶999`);
    check(mergedLevel({ level: b }, { level: a }) === expected, '融合等级与方向无关');
  }
  for (const type of ['bing', 'shi', 'xiang', 'ju', 'ma', 'pao']) withBoard(board(), () => {
    const a = piece(type, 998); game.pieces = [a];
    grantExperience(a, experienceRequired(998));
    check(a.level === 999 && a.exp === 0, type + '自然经验可升999');
    grantExperience(a, 1000000);
    check(a.level === 999 && a.exp === 0, type + '自然经验不超999');
    const target = piece(type, 500, 2), material = piece(type, 450);
    check(applyAbsorb(target, material).ok && target.level === 953 && target.exp === 0, type + '融合进化保留相加等级');
  });
  withBoard(board(), () => {
    const a = piece('ju', 45), b = piece('ju', 60); game.pieces = [a, b];
    check(boardToPiece(b, a).ok && a.level === 108 && game.pieces.length === 1, '场上融合等级相加');
  });
  withBoard(board(), () => {
    const a = piece('ju', 45), b = piece('ju', 60); game.pieces = [a];
    game.shopSlots[0] = { source: 'fromBoard', piece: b };
    check(shopToPiece(0, a).ok && a.level === 108 && !game.shopSlots[0], '商店到场上融合等级相加');
  });
  withBoard(board(), () => {
    const a = piece('ju', 45), b = piece('ju', 60);
    game.shopSlots = [{ source: 'fromBoard', piece: a }, { source: 'fromBoard', piece: b }, null, null, null];
    check(shopMerge(1, 0).ok && a.level === 108 && !game.shopSlots[1], '商店内融合等级相加');
  });
  {
    const b = board(); const a = piece('bing', 500, 2), m = piece('bing', 450); b.pieces = [a, m];
    const before = JSON.stringify(b), branches = actionBranches(b, { kind: 'merge', targetId: a.id, pieceId: m.id });
    check(branches.length === 4 && branches.every(x => x.board.pieces[0].level === 953), 'AI全部进化分支使用相加等级');
    check(JSON.stringify(b) === before, 'AI融合预览不修改源');
  }
  withBoard(board(), () => {
    const a = piece('ju', 998); a.exp = 0; game.pieces = [a];
    game.shopSlots[0] = { type: 'spell', id: 'geanguanhuo', price: 8 };
    check(useSpell(0, a).ok && a.level === 998 && a.exp === 60, '经验法术在998级仍合法');
    a.exp = 0; grantExperience(a, experienceRequired(998));
    game.shopSlots[0] = { type: 'spell', id: 'hunshuimoyu', price: 6 };
    const gold = game.gold;
    check(!useSpell(0, a).ok && game.gold === gold && !game.spellUsed.hunshuimoyu, '999级经验法术拒绝且不消费');
  });
  return { passed };
}
