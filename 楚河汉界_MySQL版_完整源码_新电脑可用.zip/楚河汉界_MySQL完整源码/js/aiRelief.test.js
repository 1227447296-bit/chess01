/** 连败阈值与跨局隔离检查；不调用段位结算、不写存档。 */
import game, { createBoard, withBoard } from './gameData.js';
import { loadMap } from './mapLoader.js';
import { setupAI, aiTick, aiInfo } from './ai.js';
import { waitForBenchmarkReady } from './aiBenchmark.test.js';

export async function runAIReliefFixtures() {
  await waitForBenchmarkReady();
  if (game.phase !== 'start') throw Error('Start page required');
  const original = { cur: game.cur, phase: game.phase };
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  try {
    const map = await loadMap(1);
    game.phase = 'playing';
    const open = (streak, tier = 7, side = 'opp') => {
      setupAI({ tier, streak }, { seed: 17, evaluationSlices: 32, reliefTest: true });
      const board = createBoard(side, map);
      withBoard(board, () => aiTick(0, 3));
      return { board, info: aiInfo(board) };
    };
    check('首局不触发连败调节', !open(0).info.reliefActivated);
    check('一败不触发', !open(-1).info.reliefActivated);
    check('两败不触发', !open(-2).info.reliefActivated);
    const third = open(-3);
    check('第三败后下一局启用', third.info.reliefActivated);
    check('开局不立即执行失误', third.info.reliefActions === 0 && third.info.lastAction === null && third.board.gold === 25);
    check('开局启用不等于完成输局', !third.info.reliefBudgetExhausted && !third.info.reliefLost);
    check('更长连败仍可启用', open(-4).info.reliefActivated);
    check('胜利后下一局关闭', !open(1).info.reliefActivated);
    check('低段不接入高段调节', !open(-3, 0).info.reliefActivated);
    check('玩家自动下棋不继承对手调节', !open(-3, 7, 'me').info.reliefActivated);
    const next = open(-3);
    check('新局重新建立独立计数', next.info.reliefActions === 0 && !next.info.reliefBudgetExhausted && next.board !== third.board);
    check('初始化不改变生命或直接结算', next.board.lives === 3 && !next.board.dead && game.phase === 'playing');
    check('初始化恢复棋盘上下文', game.cur === original.cur);
    setupAI({ tier: 7, streak: -3 });
    const formal = createBoard('opp', map);
    withBoard(formal, () => aiTick(0, 3));
    check('未验收的让局调节不在正式开局自动启用', !aiInfo(formal).reliefActivated);
    return { passed: checks.length, checks };
  } finally {
    game.cur = original.cur;
    game.phase = original.phase;
    setupAI({ tier: 7 });
  }
}
