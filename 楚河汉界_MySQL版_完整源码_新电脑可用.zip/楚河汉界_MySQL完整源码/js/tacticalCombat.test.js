/** 浏览器控制台：await import('./js/tacticalCombat.test.js').then(m => m.runTacticalCombatFixtures()) */
import game, { createBoard, withBoard } from './gameData.js';
import { pieceDamage, criticalStats, canPaoAttack, canBingAttack, canShiAttack, canXiangAttack, canMaAttack, canJuAttack } from './attackRule.js';
import { update, updateCombat, spellDamage, stunEnemy } from './wave.js';
import { cloneBoard } from './aiSimulation.js';
import { effectiveLives, addTemporaryLives, damageKing, updateTacticalEffects, buffPiece,
  slowEnemy, amplifyEnemy, retreatEnemies, forceSpecial, forceCannonBurst, specialThreshold } from './tacticalEffects.js';

export function runTacticalCombatFixtures() {
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const near = (a,b) => Math.abs(a-b) < 1e-6;
  const piece = (type, c = 0, r = 2, extra = {}) => ({ id: type, kind: 'piece', type, c, r, color: 'red',
    level: 60, exp: 0, stage: 0, atkBonus: 0, flags: {}, activeBonds: [], bonds: [], cdLeft: 999, ...extra });
  const enemy = (id, c, r = 2, extra = {}) => ({ id, kind: 'enemy', c, r, fx: c, fy: r,
    progress: c, speed: 0, hp: 100000, maxHp: 100000, done: false, dying: false, deathT: 0,
    stunLeft: 0, stunImmuneLeft: 0, ...extra });
  const board = () => {
    const road = Array.from({ length: 7 }, () => Array(12).fill(1));
    const b = createBoard('me', { cols: 12, rows: 7, road, ground: road, grass: [],
      path: Array.from({ length: 12 }, (_, c) => ({ c, r: 2 })), enemySpawn: { c: 0, r: 2 }, kingPoint: { c: 11, r: 2 } });
    b._simulationContext = { random: () => 1 }; return b;
  };
  const tick = (b, dt) => withBoard(b, () => update(dt));
  const combat = (b, dt = 0) => withBoard(b, () => updateCombat(dt));
  const attack = (b,p) => { p.cdLeft = 0; combat(b); };
  const damage = (b,p) => withBoard(b, () => pieceDamage(p));
  const old = game.cur, oldPhase = game.phase;
  try {
    game.phase = 'playing';
    const rules = board();
    withBoard(rules, () => {
      const at = (type, level, c = 4, r = 3) => piece(type, c, r, { level });
      check('兵任何等级都不打身后', !canBingAttack(at('bing', 10), { c: 4, r: 4 }) && !canBingAttack(at('bing', 999), { c: 4, r: 4 }));
      check('士15级与14级均只攻击斜角', !canShiAttack(at('shi', 15), { c: 4, r: 2 }) && canShiAttack(at('shi', 15), { c: 5, r: 2 }) && !canShiAttack(at('shi', 14), { c: 4, r: 2 }));
      check('士不攻击自身格', !canShiAttack(at('shi', 15), { c: 4, r: 3 }));
      rules.pieces = [piece('bing', 5, 4)];
      check('象20级无视兵塞象眼且19级受阻', canXiangAttack(at('xiang', 20), { c: 6, r: 5 }) && !canXiangAttack(at('xiang', 19), { c: 6, r: 5 }));
      rules.pieces = [];
      check('车50级穿透', canJuAttack(at('ju', 50), { c: 6, r: 3 }));
      rules.pieces = [piece('leg', 5, 3)];
      check('马80级无马腿', canMaAttack(at('ma', 80), { c: 6, r: 4 }));
      check('炮普通仍恰好1枚炮架', canPaoAttack(at('pao', 25), { c: 7, r: 3 }));
      rules.pieces.push(piece('screen2', 6, 3));
      check('炮79级拒绝2架而80级允许2架', !canPaoAttack(at('pao', 79), { c: 7, r: 3 }) && canPaoAttack(at('pao', 80), { c: 7, r: 3 }));
    });
    for (const level of [19, 20, 34, 35]) {
      const guards = board(), guard = piece('shi', 4, 3, { level, cdLeft: 0 });
      guards.pieces = [guard];
      guards.enemies = [enemy('guard-main', 5, 2), enemy('guard-second', 5, 2), enemy('guard-third', 3, 2), enemy('guard-fourth', 3, 4)];
      const hit = damage(guards, guard); combat(guards);
      check(`士${level}级新多目标门槛`, guards.enemies.every((e, i) => near(100000 - e.hp, i < (level >= 20 ? 2 : 1) ? hit : 0)));
    }
    const hp = board(); hp.lives = 1;
    hp.lives--; addTemporaryLives(hp);
    check('苦肉1永久变0永久+2临时', hp.lives === 0 && effectiveLives(hp) === 2 && !hp.dead);
    damageKing(hp); check('漏怪先扣临时', hp.lives === 0 && effectiveLives(hp) === 1 && !hp.dead);
    tick(hp, 29.9); check('临时血30秒前存活', !hp.dead && effectiveLives(hp) === 1);
    tick(hp, 0.1); check('临时血到期永久0立即dead', hp.dead && effectiveLives(hp) === 0);
    const permanent = board(); permanent.lives = 2; addTemporaryLives(permanent);
    damageKing(permanent, 3); check('临时扣完才扣永久', permanent.lives === 1 && effectiveLives(permanent) === 1);
    tick(permanent, 30); check('临时到期不恢复永久血', permanent.lives === 1 && !permanent.dead);
    const paused = board(); delete paused._simulationContext; paused.lives = 0; addTemporaryLives(paused);
    game.phase = 'paused'; updateTacticalEffects(paused, 31); tick(paused,31);
    check('暂停不推进时钟临时血', paused.gameTime === 0 && effectiveLives(paused) === 2 && !paused.dead);
    game.phase = 'playing'; tick(paused,30);
    check('恢复后30秒结算临时血', paused.gameTime === 30 && paused.dead);

    const buffs = board(), pawn = piece('bing', 2, 3); buffs.pieces = [pawn];
    const base = damage(buffs,pawn);
    buffPiece(pawn,{ rate: 0.25,duration: 10 },buffs); buffPiece(pawn,{rate:0.4,duration:5,noCrit:true},buffs);
    check('同类攻击增益取最大不乘叠', near(damage(buffs,pawn),base*1.4));
    check('假痴期间不暴击', withBoard(buffs,()=>criticalStats(pawn).rate) === 0);
    tick(buffs,5); check('5秒buff到期保留较弱10秒buff', near(damage(buffs,pawn),base*1.25));
    check('禁暴到期恢复', withBoard(buffs,()=>criticalStats(pawn).rate) > 0);
    tick(buffs,5); check('攻击buff准确到期', near(damage(buffs,pawn),base));
    check('wave时钟每帧仅推进一次', buffs.gameTime === 10);
    const gold = board(), cannon = piece('pao'); gold.pieces = [cannon,piece('bing',1,2)];
    gold.enemies = [enemy('g1',4),enemy('g2',4,3)];
    buffPiece(cannon,{attackGold:1,duration:5},gold); forceSpecial(cannon);
    const startGold = gold.gold; attack(gold,cannon);
    check('炮范围攻击产金仅一次', gold.gold === startGold+1);
    cannon.cdLeft = 999; tick(gold,0.25);
    check('炮追发不产金不蓄势', gold.gold === startGold+1 && cannon.specialCount === 0);
    const beforeSpell = gold.enemies[0].hp;
    spellDamage(cannon,gold.enemies,{multiplier:0.8,board:gold});
    check('法术不产攻击金币不蓄势', gold.gold === startGold+1 && cannon.specialCount === 0);
    check('法术无暴击攻击比例伤害', near(beforeSpell-gold.enemies[0].hp,damage(gold,cannon)*0.8));
    tick(gold,4.75); attack(gold,cannon);
    check('5秒攻击产金到期', gold.gold === startGold+1);
    amplifyEnemy(gold.enemies[0],0.2,5,gold);
    const beforeAmplify = gold.enemies[0].hp;
    spellDamage(cannon,[gold.enemies[0]],{fixed:30,board:gold});
    check('受伤增幅影响固定法术', near(beforeAmplify-gold.enemies[0].hp,36));
    tick(gold,5); const beforeExpired = gold.enemies[0].hp;
    spellDamage(cannon,[gold.enemies[0]],{fixed:30,board:gold});
    check('受伤增幅到期', near(beforeExpired-gold.enemies[0].hp,30));

    const slows = board(); const controlled = enemy('controlled',0,2,{speed:1}); slows.enemies = [controlled];
    check('首次眩晕成功',stunEnemy(controlled,3));
    check('眩晕中不刷新',!stunEnemy(controlled,1.5) && controlled.stunLeft === 3);
    slowEnemy(controlled,0.4,3,3,slows);
    tick(slows,3); check('关门前3秒只眩晕',controlled.progress === 0);
    check('眩晕后遵守免疫',!stunEnemy(controlled,1.5));
    const newborn = enemy('newborn',0,2,{speed:1}); slows.enemies.push(newborn);
    tick(slows,3); check('固定3~6秒减速窗口',near(controlled.progress,1.8));
    check('新生怪不继承法术控制',near(newborn.progress,3));
    tick(slows,1); check('6秒后恢复移动',near(controlled.progress,2.8));
    const windows = board(); windows.enemies=[enemy('window',0,2,{speed:1})];
    slowEnemy(windows.enemies[0],0.4,3,3,windows); tick(windows,7);
    check('跨帧延迟减速积分准确',near(windows.enemies[0].progress,5.8));
    const retreat = board(); retreat.map.path=[{c:0,r:0},{c:1,r:0},{c:1,r:1},{c:2,r:1}];
    retreat.enemies=[enemy('turn',2,1,{progress:2.5})];
    retreatEnemies(retreat,[retreat.enemies[0],retreat.enemies[0]],1);
    check('退怪真实弯路插值且对象去重',near(retreat.enemies[0].progress,1.5)&&near(retreat.enemies[0].fx,1)&&near(retreat.enemies[0].fy,0.5));
    retreatEnemies(retreat,retreat.enemies,99); check('退怪最低0',retreat.enemies[0].progress===0);

    for (const level of [59,60,100]) {
      for (const [type,expected] of [['ju',level>=100?4:6],['pao',level>=100?3:4],['ma',level>=100?4:5]]) {
        const p=piece(type,0,2,{level});
        check(`${type}${level}级阈值`,specialThreshold(p)===(level<60?0:expected));
        check(`${type}${level}级强制蓄势合法性`,forceSpecial(p)===(level>=60));
      }
    }
    for (const level of [60,100]) {
      const b=board(),p=piece('pao',0,2,{level}); b.pieces=[p,piece('bing',1,2)]; b.enemies=[enemy('main',4)];
      const d=damage(b,p), threshold=level>=100?3:4;
      for(let i=1;i<threshold;i++) { attack(b,p); check(`炮${level}第${i}次不提前追发`,b.tacticalCannonShots.length===0); }
      attack(b,p); check(`炮${level}足额触发`,b.tacticalCannonShots.length===1&&p.specialCount===0);
      p.cdLeft=999; tick(b,0.249); check(`炮${level}0.25秒前不追发`,near(100000-b.enemies[0].hp,d*threshold));
      tick(b,0.001); check(`炮${level}追发倍率`,near(100000-b.enemies[0].hp,d*(threshold+(level>=100?0.9:0.7))));
      check(`炮${level}追发不累计`,p.specialCount===0);
    }
    const shared=board(),sp=piece('pao'); shared.pieces=[sp,piece('bing',1,2)]; shared.enemies=[enemy('crit-main',4)];
    let cannonRolls=0; shared._simulationContext.random=()=>{cannonRolls++;return 0;}; forceSpecial(sp);
    attack(shared,sp); const primary=100000-shared.enemies[0].hp; sp.cdLeft=999; tick(shared,0.25);
    check('炮双连发共享一次暴击快照',cannonRolls===1&&near(100000-shared.enemies[0].hp,primary*1.7));
    const forced=board(),fp=piece('pao',0,2,{activeBonds:['马炮合势']}); forced.pieces=[fp,piece('bing',1,2)];
    forced.enemies=[enemy('no-passives',4)]; buffPiece(fp,{attackGold:1,duration:5},forced);
    const forcedGold=forced.gold; forceCannonBurst(fp,forced); tick(forced,0.25);
    check('法术双连发不触发羁绊或攻击产金',forced.enemies[0].stunLeft===0&&forced.gold===forcedGold&&!fp.specialCount);
    const strict=board(), strictP=piece('pao'); strict.pieces=[strictP]; strict.enemies=[enemy('first',4)];
    check('普通炮无架拒绝',withBoard(strict,()=>!canPaoAttack(strictP,strict.enemies[0])));
    check('法术双炮无架拒绝',!forceCannonBurst(strictP,strict));
    strict.pieces.push(piece('bing',1,2));
    const strictD=damage(strict,strictP); forceSpecial(strictP);
    check('法术双炮有架立即主发',forceCannonBurst(strictP,strict)&&near(100000-strict.enemies[0].hp,strictD));
    strict.pieces.pop(); tick(strict,0.25);
    check('追发重验炮架无架取消',near(100000-strict.enemies[0].hp,strictD)&&strictP.specialCount===3);
    const reroute=board(),rp=piece('pao'); reroute.pieces=[rp,piece('bing',1,2)];
    reroute.enemies=[enemy('dead',4,2,{hp:1}),enemy('other',8)];
    forceCannonBurst(rp,reroute); const rerouteD=damage(reroute,rp); tick(reroute,0.25);
    check('追发原目标死亡重选合法目标',near(100000-reroute.enemies.find(e=>e.id==='other').hp,rerouteD*0.7));

    for (const level of [60,100]) {
      const b=board(), p=piece('ma',1,1,{level,cdLeft:0,activeBonds:['马炮合势']}); b.pieces=[p];
      b.enemies=[enemy('landing',3),enemy('shadow1',2),enemy('shadow2',1),enemy('shadow3',0)];
      const d=damage(b,p); forceSpecial(p); combat(b); combat(b,0.3);
      const rate=level>=100?0.8:0.6;
      check(`马${level}落点普通伤害`,near(100000-b.enemies[0].hp,d));
      check(`马${level}前2格残影伤害`,near(100000-b.enemies[2].hp,d*rate));
      check(`马${level}第3格按等级`,near(100000-b.enemies[3].hp,level>=100?d*rate:0));
      check(`马${level}残影无控制标记`,b.enemies[2].stunLeft===0&&!b.enemies[2].maPaoMarkLeft);
      check(`马${level}不额外移动不重复计数`,p.c===1&&p.r===1&&p.specialCount===0);
    }
    for (const level of [60,100]) {
      const b=board(),p=piece('ju',0,2,{level,cdLeft:0}); b.pieces=[p]; b.enemies=[enemy('near',1),enemy('ghost-only',9)];
      const d=damage(b,p); forceSpecial(p); let rolls=0; b._simulationContext.random=()=>{ rolls++; return 1; };
      combat(b); for(let i=0;i<100&&!b.tacticalGhosts.length;i++) combat(b,1/120);
      check(`车${level}有效命中召虚影`,b.tacticalGhosts.length===1&&p.specialCount===0);
      check(`车${level}虚影独立暴击一次`,rolls===2);
      b.pieces=[]; const before=b.enemies[1].hp; combat(b,0.5);
      check(`车${level}源离场快照有效`,near(before-b.enemies[1].hp,d*(level>=100?0.5:0.3)));
      const after=b.enemies[1].hp; combat(b,0); combat(b,0.1);
      check(`车${level}虚影每敌一次`,b.enemies[1].hp===after&&b.pieces.length===0);
    }
    for (const type of ['ju','ma']) for (const level of [60,100]) {
      const b=board(), p=piece(type,type==='ma'?1:0,type==='ma'?1:2,{level}); b.pieces=[p];
      b.enemies=[enemy('repeated',type==='ma'?3:1)];
      buffPiece(p,{attackGold:1,duration:5},b);
      const initialGold=b.gold, threshold=specialThreshold(p);
      for(let count=1;count<=threshold;count++) {
        attack(b,p);
        for(let i=0;i<2000&&(p.charge||p.stomp);i++) combat(b,1/120);
        check(`${type}${level}普通完整动作${count}只计一次`,p.specialCount===count%threshold);
        check(`${type}${level}范围返程残影不重复产金${count}`,b.gold===initialGold+count);
      }
    }
    const source=board(); source.pieces=[piece('pao'),piece('bing',1,2)]; source.enemies=[enemy('copy',4)];
    buffPiece(source.pieces[0],{rate:0.25,duration:10,attackGold:1},source); addTemporaryLives(source);
    slowEnemy(source.enemies[0],0.3,4,0,source); amplifyEnemy(source.enemies[0],0.2,5,source); forceCannonBurst(source.pieces[0],source);
    const before=JSON.stringify(source); const copy=cloneBoard(source); copy._simulationContext={random:()=>1}; tick(copy,0.25);
    check('所有战术状态克隆隔离',JSON.stringify(source)===before&&copy.gameTime===0.25&&source.gameTime===0);
    check('恢复棋盘上下文',game.cur===old);
    return {passed:checks.length,checks};
  } finally {game.cur=old;game.phase=oldPhase;}
}
