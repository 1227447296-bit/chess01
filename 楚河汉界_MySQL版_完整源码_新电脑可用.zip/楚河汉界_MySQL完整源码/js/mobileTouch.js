/** Mobile-only browser defaults are suppressed on game UI, never on editable controls. */
function isEditable(target) {
  return !!target && (!!target.closest?.('input, textarea, select') || target.isContentEditable);
}

export function setupTouchSafeguards(app, touchRoot = app) {
  const guard = event => {
    if (!isEditable(event.target)) event.preventDefault();
  };
  let press = null, lastTap = null;
  const start = event => {
    if (isEditable(event.target)) { press = null; lastTap = null; return; }
    if (event.touches.length !== 1) {
      press = null; lastTap = null;
      event.preventDefault();
      return;
    }
    const touch = event.touches[0];
    press = { id: touch.identifier, x: touch.clientX, y: touch.clientY, moved: false, at: event.timeStamp };
  };
  const move = event => {
    if (isEditable(event.target)) return;
    if (event.touches.length > 1) {
      press = null; lastTap = null;
      event.preventDefault();
    } else if (press) {
      const touch = event.touches[0];
      if (touch && Math.hypot(touch.clientX - press.x, touch.clientY - press.y) > 8) press.moved = true;
    }
    // 单指滚动/拖动不拦截，尤其不能破坏详情滚动。
  };
  const end = event => {
    const current = press;
    press = null;
    if (!current || isEditable(event.target) || event.touches.length || current.moved) { lastTap = null; return; }
    const touch = [...event.changedTouches].find(t => t.identifier === current.id);
    if (!touch || Math.hypot(touch.clientX - current.x, touch.clientY - current.y) > 8 ||
        event.timeStamp - current.at > 500) { lastTap = null; return; }
    // iOS Safari 仍可能忽略 CSS 的双击限制；仅取消近距离连续轻点的第二次默认行为。
    if (lastTap && event.timeStamp - lastTap.at < 350 &&
        Math.hypot(touch.clientX - lastTap.x, touch.clientY - lastTap.y) < 32) event.preventDefault();
    lastTap = { at: event.timeStamp, x: touch.clientX, y: touch.clientY };
  };
  const cancel = () => { press = null; lastTap = null; };
  const options = { passive: false, capture: true };
  app.addEventListener('contextmenu', guard);
  app.addEventListener('selectstart', guard);
  touchRoot.addEventListener('touchstart', start, options);
  touchRoot.addEventListener('touchmove', move, options);
  touchRoot.addEventListener('touchend', end, options);
  touchRoot.addEventListener('touchcancel', cancel, options);
  touchRoot.addEventListener('gesturestart', guard, options);
  touchRoot.addEventListener('gesturechange', guard, options);
  return () => {
    app.removeEventListener('contextmenu', guard);
    app.removeEventListener('selectstart', guard);
    touchRoot.removeEventListener('touchstart', start, true);
    touchRoot.removeEventListener('touchmove', move, true);
    touchRoot.removeEventListener('touchend', end, true);
    touchRoot.removeEventListener('touchcancel', cancel, true);
    touchRoot.removeEventListener('gesturestart', guard, true);
    touchRoot.removeEventListener('gesturechange', guard, true);
  };
}

/** Dismiss only an outside tap, never the start/end of an inner scroll or gameplay drag. */
export function setupDetailDismissal(app, panel, close, root = window) {
  const active = new Set();
  let gesture = null;
  let suppressCloseClick = false;
  const isOpen = () => !panel.classList.contains('hidden');
  const outside = target => app.contains(target) && !panel.contains(target)
    && !target.closest?.('canvas, .shop-card, .cheat-box, input, textarea, select, button, summary')
    && !isEditable(target);
  const moved = event => gesture && Math.hypot(event.clientX - gesture.x, event.clientY - gesture.y) > 6;
  const down = event => {
    active.add(event.pointerId);
    suppressCloseClick = false;
    if (active.size !== 1 || event.isPrimary === false || event.button !== 0) {
      gesture = null;
      suppressCloseClick = true;
      return;
    }
    gesture = { id: event.pointerId, x: event.clientX, y: event.clientY,
      eligible: isOpen() && outside(event.target), moved: false };
  };
  const move = event => {
    if (gesture?.id !== event.pointerId) return;
    if (moved(event)) {
      gesture.moved = true;
      suppressCloseClick = true;
    }
  };
  const up = event => {
    active.delete(event.pointerId);
    if (gesture?.id !== event.pointerId) return;
    move(event); // Include final coordinates even if the last pointermove was omitted.
    // Touch has implicit pointer capture: event.target may still be the press origin.
    const releaseTarget = root.document?.elementFromPoint(event.clientX, event.clientY) || event.target;
    const dismiss = gesture.eligible && !gesture.moved && isOpen() && outside(releaseTarget);
    gesture = null;
    if (dismiss) close();
  };
  const cancel = event => {
    active.delete(event.pointerId);
    if (gesture?.id === event.pointerId) gesture = null;
    suppressCloseClick = true;
  };
  const reset = () => { active.clear(); gesture = null; suppressCloseClick = true; };
  const click = event => {
    if (!event.target.closest?.('.detail-close')) return;
    event.stopPropagation();
    // Keyboard activation has detail=0. A pointer scroll beginning on X must not close.
    if (event.detail === 0 || !suppressCloseClick) close();
  };
  // Capture observes inner origins even when an input stops bubbling. Never capture the pointer
  // or cancel native pointer defaults: the detail panel must retain touch scrolling.
  root.addEventListener('pointerdown', down, true);
  root.addEventListener('pointermove', move, true);
  root.addEventListener('pointerup', up, true);
  root.addEventListener('pointercancel', cancel, true);
  root.addEventListener('blur', reset);
  panel.addEventListener('click', click);
  return () => {
    root.removeEventListener('pointerdown', down, true);
    root.removeEventListener('pointermove', move, true);
    root.removeEventListener('pointerup', up, true);
    root.removeEventListener('pointercancel', cancel, true);
    root.removeEventListener('blur', reset);
    panel.removeEventListener('click', click);
  };
}
