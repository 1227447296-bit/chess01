/**
 * bonusSelect.js —— 开局增益选择界面
 * 进入游戏先展示 3 选 1 增益界面；从 BONUSES 库随机 3 个不重复，供玩家选择。
 * 选择后把增益 flags 写入 gameData 并告知 main.js 进入游戏。
 */
import { BONUSES } from './config.js';
import { game, applyBonusFlags, withBoard } from './gameData.js';

/** 主界面回调：选择完成 → 开始游戏 */
let onStart = null;
export function setStartHook(fn) { onStart = fn; }

/** 从库中随机选 n 个不重复 */
function sample(n) {
  const arr = [...BONUSES];
  const out = [];
  while (out.length < n && arr.length) {
    const i = Math.floor(Math.random() * arr.length);
    out.push(arr.splice(i, 1)[0]);
  }
  return out;
}

/** 渲染增益选择界面 */
export function showBonusSelect() {
  const overlay = document.getElementById('bonus-select');
  const box = document.getElementById('bonus-cards');
  overlay.classList.remove('hidden');
  box.innerHTML = '';

  const three = sample(3);

  three.forEach(bonus => {
    const card = document.createElement('div');
    card.className = 'bonus-card';
    card.innerHTML = `
      <div class="bonus-card-name">${bonus.name}</div>
      <div class="bonus-card-desc">${bonus.desc}</div>
    `;
    card.addEventListener('click', () => selectBonus(bonus));
    box.appendChild(card);
  });
}

/** 选择某个增益（作用于我方；对方 AI 随机获得一个增益）。
 *  注意：调用 onStart（开局）后棋盘会重建，所以增益在 onStart 内应用 —— 这里先记下来。 */
let chosen = null;
function selectBonus(bonus) {
  chosen = bonus;
  const overlay = document.getElementById('bonus-select');
  overlay.classList.add('hidden');
  if (onStart) onStart();
}

/** 开局后（棋盘已重建）把增益写入双方棋盘 */
export function applyChosenBonuses() {
  if (!chosen) return;
  withBoard(game.boards.me, () => { game.bonusId = chosen.id; applyBonusFlags(chosen.flags); });
  const oppBonus = BONUSES[Math.floor(Math.random() * BONUSES.length)];
  withBoard(game.boards.opp, () => { game.bonusId = oppBonus.id; applyBonusFlags(oppBonus.flags); });
  chosen = null;
}

/** 隐藏界面（被动调用） */
export function hideBonusSelect() {
  document.getElementById('bonus-select').classList.add('hidden');
}

export default { showBonusSelect, setStartHook, applyChosenBonuses };