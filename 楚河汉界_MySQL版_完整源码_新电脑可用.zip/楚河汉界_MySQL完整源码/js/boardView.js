/** 棋盘显示坐标：只改变朝向，不改变逻辑地图、攻击规则和路径。 */
export const isSidewaysMap = (map) => map.cols === 5 && map.rows === 8;

export function viewSize(map, sideways = isSidewaysMap(map)) {
  return sideways ? { cols: map.rows, rows: map.cols } : { cols: map.cols, rows: map.rows };
}

/** 逻辑格坐标 → 显示格坐标；也支持单位移动中的小数坐标。 */
export function boardToView(c, r, map, sideways = isSidewaysMap(map), flip = false) {
  const size = viewSize(map, sideways);
  const x = sideways ? map.rows - 1 - r : c;
  const y = sideways ? c : r;
  return { c: x, r: flip ? size.rows - 1 - y : y };
}

/** 显示格坐标 → 逻辑格坐标，与 boardToView 严格互逆。 */
export function viewToBoard(c, r, map, sideways = isSidewaysMap(map), flip = false) {
  const size = viewSize(map, sideways);
  const y = flip ? size.rows - 1 - r : r;
  return sideways ? { c: y, r: map.rows - 1 - c } : { c, r: y };
}

/** 方向向量使用相同变换，供后坐力、拖尾及详情范围图使用。 */
export function vectorToView(dc, dr, sideways = false, flip = false) {
  const x = sideways ? -dr : dc;
  const y = sideways ? dc : dr;
  return { x, y: flip ? -y : y };
}
