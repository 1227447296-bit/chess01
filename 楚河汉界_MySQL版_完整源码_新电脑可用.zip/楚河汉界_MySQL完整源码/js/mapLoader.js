/**
 * mapLoader.js —— Tiled TMX 地图解析
 * 职责：读取 boardN.tmx → 输出 { ground, grass, road, enemySpawn, kingPoint, path }
 *
 * 图层约定（与 Tiled 工程一致）：
 *   Ground —— 背景层，用于放置棋子
 *   grass  —— 草地层，不可放棋子；被铲子铲掉后露出 Ground
 *   road   —— 路径层，不可铲、不可放棋子；敌人沿此层移动
 * 对象层：
 *   enemy  —— 敌人出生点（也是开局帅的出生点）
 *   king   —— 帅走到该点后停住
 *
 * GID 位标志（Tiled 规范）：
 *   0x80000000 水平翻转 | 0x40000000 垂直翻转 | 0x20000000 对角翻转
 */
import { GRID, RES } from './config.js';

const FLIP_H = 0x80000000;
const FLIP_V = 0x40000000;
const FLIP_D = 0x20000000;
const GID_MASK = 0x1FFFFFFF;

/** 解析 csv 图层数据为数字数组 */
function parseCsv(text) {
  return text
    .split(',')
    .map(s => s.trim())
    .filter(s => s.length > 0)
    .map(Number);
}

/** 数字数组 → 二维结构 [row][col] = gid 清位后的值；flags 另行保存 */
function toGrid(values, cols, rows) {
  const gid = [];
  const flags = [];
  for (let r = 0; r < rows; r++) {
    gid.push(new Array(cols).fill(0));
    flags.push(new Array(cols).fill(0));
  }
  for (let i = 0; i < values.length; i++) {
    const r = Math.floor(i / cols);
    const c = i % cols;
    if (r >= rows) break;
    const raw = values[i];
    gid[r][c] = raw & GID_MASK;
    flags[r][c] = raw & (FLIP_H | FLIP_V | FLIP_D);
  }
  return { gid, flags };
}

/** 道路开口随 Tiled 的对角、水平、垂直翻转变化，与渲染的变换顺序一致。 */
function roadOpenings(gid, flags) {
  // 当前图集：9 为右下拐角，23 为上下直道；其它道路瓦片沿用四向连接。
  const openings = gid === 9 ? [[1, 0], [0, 1]]
    : gid === 23 ? [[0, -1], [0, 1]]
    : [[0, 1], [0, -1], [1, 0], [-1, 0]];
  return openings.map(([dc, dr]) => {
    if (flags & FLIP_D) [dc, dr] = [dr, dc];
    if (flags & FLIP_H) dc = -dc;
    if (flags & FLIP_V) dr = -dr;
    return [dc, dr];
  });
}

/** 从 road 层推导有序路径，只连接开口相对的道路，避免相邻路段产生捷径。 */
function buildPath(roadGrid, roadFlags, cols, rows, spawn, kingPoint) {
  if (!spawn) return [];
  const idx = (c, r) => r * cols + c;
  const isRoad = (c, r) => c >= 0 && r >= 0 && c < cols && r < rows && roadGrid[r][c] !== 0;

  // BFS 记录前驱，终点为 kingPoint
  const prev = new Map();
  const visited = new Set([idx(spawn.c, spawn.r)]);
  const queue = [{ c: spawn.c, r: spawn.r }];
  const goal = kingPoint ? idx(kingPoint.c, kingPoint.r) : -1;
  let found = null;

  while (queue.length) {
    const cur = queue.shift();
    if (idx(cur.c, cur.r) === goal) { found = cur; break; }
    const dirs = roadOpenings(roadGrid[cur.r][cur.c], roadFlags[cur.r][cur.c]);
    for (const [dc, dr] of dirs) {
      const nc = cur.c + dc, nr = cur.r + dr;
      if (!isRoad(nc, nr)) continue;
      const connects = roadOpenings(roadGrid[nr][nc], roadFlags[nr][nc])
        .some(([backC, backR]) => backC === -dc && backR === -dr);
      if (!connects) continue;
      const k = idx(nc, nr);
      if (visited.has(k)) continue;
      visited.add(k);
      prev.set(k, cur);
      queue.push({ c: nc, r: nr });
    }
  }

  // 若找不到 king 点，退化为「最长可达链」无效 → 返回空，由调用方兜底
  if (!found) return [];

  const path = [];
  let node = found;
  while (node) {
    path.push({ c: node.c, r: node.r });
    node = prev.get(idx(node.c, node.r));
  }
  path.reverse();
  return path;
}

/** 第 n 张地图的文件路径：config 里单独指定的优先，否则按 board/board{n}.tmx 拼 */
export function mapFileOf(n) {
  return RES.maps[n] || RES.boardDir + RES.mapFilePattern.replace('{n}', String(n));
}

/** 读取地图清单。本地服务器自动列目录，静态网站使用 board/maps.json。 */
export async function scanMaps() {
  const res = await fetch(RES.boardDir + 'maps.json', { cache: 'no-cache' });
  if (!res.ok) throw new Error(`地图清单加载失败 (HTTP ${res.status})`);
  const files = await res.json();
  if (!Array.isArray(files)) throw new Error('地图清单必须是文件名数组');
  return [...new Set(files.filter(f => typeof f === 'string' && /^board\d+\.tmx$/.test(f))
    .map(f => f.slice(5, -4)))];
}

const mapCache = new Map();

/** 预加载全部地图，真实进度按已完成的地图数回调。失败会交给加载页提示重试。 */
export async function preloadMaps(ids, onProgress = () => {}) {
  let loaded = 0;
  onProgress({ loaded, total: ids.length, label: '准备地图' });
  const results = await Promise.allSettled(ids.map(async id => {
    await loadMap(id);
    onProgress({ loaded: ++loaded, total: ids.length, label: `地图 board${id}` });
  }));
  const failed = results.find(r => r.status === 'rejected');
  if (failed) throw failed.reason;
}

/**
 * 加载并解析地图。
 * @param {number|string} level 地图编号（1 对应 board1.tmx，'01' 对应 board01.tmx）
 * @returns {Promise<object>} 地图数据
 */
export async function loadMap(level = 1, onProgress = () => {}) {
  const file = mapFileOf(level);
  if (!mapCache.has(file)) {
    const task = parseMap(level, file, onProgress).catch(error => { mapCache.delete(file); throw error; });
    mapCache.set(file, task);
  }
  const map = await mapCache.get(file);
  onProgress(1);
  return map;
}

async function parseMap(level, file, onProgress) {
  const res = await fetch(file, { cache: 'no-cache' });
  if (!res.ok) throw new Error(`地图加载失败：${file} (HTTP ${res.status})`);
  let text;
  if (res.body?.getReader) {
    const reader = res.body.getReader(), chunks = [];
    const total = Number(res.headers.get('Content-Length'));
    let received = 0;
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      chunks.push(value);
      received += value.byteLength;
      if (total > 0) onProgress(Math.min(0.95, received / total * 0.95));
    }
    const bytes = new Uint8Array(received);
    let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
    text = new TextDecoder().decode(bytes);
  } else {
    text = await res.text();
  }

  const doc = new DOMParser().parseFromString(text, 'application/xml');
  const mapEl = doc.querySelector('map');
  if (!mapEl) throw new Error(`地图格式错误：${file}`);

  const cols = Number(mapEl.getAttribute('width'));
  const rows = Number(mapEl.getAttribute('height'));
  const tile = Number(mapEl.getAttribute('tilewidth')) || GRID.tile;

  const layers = { ground: null, grass: null, road: null };
  const nameMap = {
    [GRID.layerGround]: 'ground',
    [GRID.layerGrass]: 'grass',
    [GRID.layerRoad]: 'road',
  };

  doc.querySelectorAll('layer').forEach(layerEl => {
    const name = layerEl.getAttribute('name');
    const key = nameMap[name];
    if (!key) return;
    const csvEl = layerEl.querySelector('data');
    if (!csvEl || csvEl.getAttribute('encoding') !== 'csv') return;
    layers[key] = parseCsv(csvEl.textContent);
  });

  const groundRaw = layers.ground ? toGrid(layers.ground, cols, rows) : { gid: [], flags: [] };
  const grassRaw  = layers.grass  ? toGrid(layers.grass,  cols, rows) : { gid: [], flags: [] };
  const roadRaw   = layers.road   ? toGrid(layers.road,   cols, rows) : { gid: [], flags: [] };

  /** 对象层：取该层第一个 point 的网格坐标 */
  const readPoint = (layerName) => {
    const group = Array.from(doc.querySelectorAll('objectgroup'))
      .find(g => g.getAttribute('name') === layerName);
    if (!group) return null;
    const obj = group.querySelector('object');
    if (!obj) return null;
    const x = Number(obj.getAttribute('x')) || 0;
    const y = Number(obj.getAttribute('y')) || 0;
    // 对象坐标是像素中心点，转成格坐标
    return { c: Math.floor(x / tile), r: Math.floor(y / tile) };
  };

  const enemySpawn = readPoint(GRID.objEnemy);
  const kingPoint  = readPoint(GRID.objKing);

  const data = {
    level,
    file,
    cols, rows, tile,
    // 布尔网格，逻辑层只关心「有没有」
    ground: groundRaw.gid.map(row => row.map(v => v !== 0)),
    grass:  grassRaw.gid.map(row => row.map(v => v !== 0)),
    road:   roadRaw.gid.map(row => row.map(v => v !== 0)),
    // 渲染用的原始 gid + 翻转标志
    raw: { ground: groundRaw, grass: grassRaw, road: roadRaw },
    enemySpawn,
    kingPoint,
    cleared: new Set(),
    path: buildPath(roadRaw.gid, roadRaw.flags, cols, rows, enemySpawn, kingPoint),
  };

  if (!data.path.length) {
    console.warn('[mapLoader] 未能在 road 层推导出 spawn→king 的路径，请检查图层与对象点。');
  }
  return data;
}

/**
 * 计算某个瓦片在图集中的源矩形（用于 canvas drawImage）
 * @param {number} gid 清位后的 gid（firstgid = 1）
 */
export function gidToTileRect(gid, tileset) {
  const index = gid - 1;
  const col = index % tileset.columns;
  const row = Math.floor(index / tileset.columns);
  return { sx: col * tileset.tileWidth, sy: row * tileset.tileHeight };
}

export const FLAGS = { FLIP_H, FLIP_V, FLIP_D };

export default loadMap;
