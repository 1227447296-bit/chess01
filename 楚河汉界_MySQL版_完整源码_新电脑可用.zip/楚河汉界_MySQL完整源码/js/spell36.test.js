/** 无DOM夹具：import 后调用 runSpell36Fixtures()。不启动服务器、不使用正式随机源。 */
import game, { createBoard, withBoard } from './gameData.js';
import { SPELLS, SPELL_BY_ID, SHOP } from './config.js';
import { useSpell, refresh } from './actions.js';
import { validateSpell, spellStockLeft, spellRandomOutcomes } from './spell.js';
import { availableSpells, spellSituationWeight, refreshShop } from './shop.js';
import { effectiveLives, damageKing, updateTacticalEffects, pieceTacticalStats, enemySlowRate } from './tacticalEffects.js';
import { rescanBonds } from './bond.js';

export function runSpell36Fixtures() {
  const checks = [];
  const check = (name, value) => { checks.push({ name, ok: !!value }); if (!value) throw Error(name); };
  let id = 0;
  const p = (type = 'bing', extra = {}) => ({ id: `spell36-${++id}`, kind: 'piece', type, color: 'red', level: 5, exp: 0,
    stage: 0, mergeCount: 0, c: 1, r: 1, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [], activeBonds: [], ...extra });
  const card = id => ({ source: 'native', type: 'spell', id, tier: SPELL_BY_ID[id].tier, price: SPELL_BY_ID[id].price });
  const fixture = () => {
    const b = createBoard('opp');
    const layer = value => Array.from({ length: 6 }, () => Array(8).fill(value));
    b.map = { cols: 8, rows: 6, ground: layer(true), grass: layer(false), road: layer(false), cleared: new Set(),
      path: Array.from({ length: 8 }, (_, c) => ({ c, r: 0 })), enemySpawn: { c: 0, r: 0 }, kingPoint: { c: 7, r: 0 } };
    b.map.grass[4][5] = true;
    b.gold = 100; b.wave = 12; b.lives = 1;
    b._simulationContext = { uidCounter: 0, random: () => { throw Error('法术预览不可抽取随机'); } };
    b.pieces = [p(), p('ju', { c: 2, color: 'black', level: 60 }), p('shi', { c: 0, level: 10 }),
      p('pao', { c: 0, r: 0, level: 60 }), p('bing', { c: 1, r: 0 })];
    b.enemies = [
      { id: `enemy-${++id}`, kind: 'enemy', hp: 500, maxHp: 500, c: 3, r: 0, fx: 3, fy: 0, progress: 3, speed: 0.2, stunLeft: 0 },
      { id: `enemy-${++id}`, kind: 'enemy', hp: 700, maxHp: 700, c: 4, r: 0, fx: 4, fy: 0, progress: 4, speed: 0.2, stunLeft: 0.2 },
    ];
    return b;
  };
  const inputs = (b, spec) => {
    let target = null, cell = null, options = {};
    if (spec.kind === 'target') {
      target = spec.effect.restrict === 'rankType' ? b.pieces[1] : spec.effect.restrict === 'pao' ? b.pieces[3]
        : spec.effect.restrict === 'shiXiang' ? b.pieces[2] : b.pieces[0];
    }
    if (spec.kind === 'cell') cell = spec.effect.type === 'dig' ? { c: 5, r: 4 } : { c: 6, r: 4 };
    if (spec.selection === 'color') options.color = 'black';
    if (spec.selection === 'secondary') options.secondaryTargetId = b.pieces[1].id;
    const outcomes = spellRandomOutcomes(card(spec.id), target);
    if (outcomes.length) options.simulationOutcome = { type: outcomes[0].type, color: outcomes[0].color };
    return { target, cell, options };
  };
  const savedPhase = game.phase;
  try {
    game.phase = 'playing';
    check('36个唯一ID与名称', SPELLS.length === 36 && new Set(SPELLS.map(s => s.id)).size === 36 && new Set(SPELLS.map(s => s.name)).size === 36);
    check('全部stock1且短描述详情分离', SPELLS.every(s => s.stock === 1 && s.desc && s.desc.length <= 24 && s.detail && s.detail !== s.desc && s.detail.length > s.desc.length));
    check('解锁0/5/12波不变', SHOP.spellTierUnlock[1] === 0 && SHOP.spellTierUnlock[2] === 5 && SHOP.spellTierUnlock[3] === 12);
    withBoard(fixture(), () => {
      for (const wave of [0, 1, 5, 11, 12, 20]) {
        game.wave = wave;
        check(`金蝉脱壳第${wave}波刷出门槛`, availableSpells().some(s => s.id === 'jinchantuoqiao') === (wave >= 12));
      }
      check('金蝉后期解锁不改变费用库存', SPELL_BY_ID.jinchantuoqiao.price === 5 && SPELL_BY_ID.jinchantuoqiao.stock === 1);
    });
    for (const spec of SPELLS) {
      const b = fixture();
      withBoard(b, () => {
        rescanBonds();
        const { target, cell, options } = inputs(b, spec);
        b.shopSlots[0] = card(spec.id);
        const before = JSON.stringify(b);
        check(`${spec.name}取消无消费`, !useSpell(0, target, cell, { ...options, cancelled: true }).ok && JSON.stringify(b) === before);
        check(`${spec.name}公共合法校验无修改`, validateSpell(b.shopSlots[0], target, cell, options).ok && JSON.stringify(b) === before);
        check(`${spec.name}实际公共动作成功`, useSpell(0, target, cell, options).ok && b.spellUsed[spec.id] === 1 && spellStockLeft(spec.id) === 0);
        check(`${spec.name}已用不再入池`, !availableSpells().some(s => s.id === spec.id));
        b.shopSlots[0] = card(spec.id);
        const used = JSON.stringify(b);
        check(`${spec.name}每局仅一次`, !useSpell(0, target, cell, options).ok && JSON.stringify(b) === used);
      });
    }
    for (const [spellId, setup, choose] of [
      ['shushangkaihua', b => { b.pieces[1].stage = 3; }, b => b.pieces[1]],
      ['fankeweizhu', b => { b.pieces[1].level = 29; }, b => b.pieces[1]],
      ['xiaolicangdao', b => { b.pieces[0].specialEnhancements = { huixin: 1 }; }, b => b.pieces[0]],
      ['kuruoji', b => { b.lives = 0; }, () => null],
      ['kongchengji', b => { b.lives = 2; }, () => null],
      ['weiweijiuzhao', b => { b.displacementCooldownUntil = 10; }, () => null],
      ['shangwuchouti', b => { b.enemies.forEach(e => { e.stunLeft = 0; }); }, b => b.pieces[0]],
      ['jiadaofaguo', b => { b.pieces.splice(4, 1); }, b => b.pieces[3]],
      ['jieshihuanhun', b => { while (b.pieces.length < 10) b.pieces.push(p('bing', { c: 7, r: 5 })); }, () => null],
    ]) {
      const b = fixture(); setup(b);
      withBoard(b, () => {
        b.shopSlots[0] = card(spellId);
        const before = JSON.stringify(b);
        check(`${spellId}非法条件零消费`, !useSpell(0, choose(b), spellId === 'jieshihuanhun' ? { c: 6, r: 4 } : null, { color: 'red' }).ok && JSON.stringify(b) === before);
      });
    }
    withBoard(fixture(), () => {
      game.gold = 0; game.shopSlots[0] = card('anduchencang');
      const shovels = game.shovelUsed;
      check('零金币开垦且不计铲子', useSpell(0, null, { c: 5, r: 4 }).ok && game.map.cleared.has('5,4') && game.gold === 0 && game.shovelUsed === shovels);
    });
    withBoard(fixture(), () => {
      const a = game.pieces[0], owned = p('ma', { color: 'black' });
      const native = { source: 'native', type: 'piece', color: 'red', piece: p('bing', { color: 'red' }) };
      game.shopSlots = [card('shengdongjixi'), { source: 'fromBoard', piece: owned }, { source: 'fromBoard', piece: a }, native, null];
      check('声东只翻已拥有棋且同对象一次', useSpell(0).ok && a.color === 'black' && owned.color === 'red' && native.color === 'red' && native.piece.color === 'red');
    });
    for (const color of ['red', 'black']) withBoard(fixture(), () => {
      const a = game.pieces[0]; game.shopSlots[0] = card('paozhuanyinyu');
      a.level = 40; a.exp = 25; a.atkBonus = 100; a.flags = { critRateBonus: 0.1 };
      a.specialEnhancements = { huixin: 1 }; a.tacticalBuffs = [{ rate: 0.4, until: 5 }];
      const others = game.pieces.slice(1), count = game.pieces.length, x = a.c, y = a.r;
      const outcomes = spellRandomOutcomes(game.shopSlots[0], a);
      check('抛砖红黑各半且不需第二目标', outcomes.length === 2 && outcomes.every(o => o.probability === 0.5) && validateSpell(game.shopSlots[0], a).ok);
      const before = JSON.stringify(game.cur);
      check('抛砖模拟不偷抽随机', !useSpell(0, a).ok && JSON.stringify(game.cur) === before);
      check('抛砖原地替换成功', useSpell(0, a, null, { simulationOutcome: { type: 'bing', color } }).ok);
      const fresh = game.pieces.find(p => p.c === x && p.r === y);
      check('抛砖消耗原兵并创建新对象', !game.pieces.includes(a) && fresh !== a && fresh.id !== a.id && game.pieces.length === count);
      check('抛砖新兵颜色等级阶数准确', fresh.type === 'bing' && fresh.color === color && fresh.level === 0 && fresh.stage === 2 && fresh.mergeCount === 2);
      check('抛砖不继承经验强化与临时效果', fresh.exp === 0 && fresh.atkBonus === 0 && !fresh.flags.critRateBonus && !fresh.specialEnhancements && !fresh.tacticalBuffs);
      check('抛砖其他棋子不受影响', others.every(p => game.pieces.includes(p)));
      check('抛砖费用库存不变', game.gold === 94 && game.spellUsed.paozhuanyinyu === 1);
    });
    for (const invalid of [p('bing', { stage: 1 }), p('shi')]) withBoard(fixture(), () => {
      game.pieces[0] = invalid; game.shopSlots[0] = card('paozhuanyinyu');
      const before = JSON.stringify(game.cur);
      check('抛砖拒绝非0阶兵且零消费', !useSpell(0, invalid).ok && JSON.stringify(game.cur) === before);
    });
    withBoard(fixture(), () => {
      while (game.pieces.length < 10) game.pieces.push(p('bing', { c: 7, r: 5 }));
      const a = game.pieces[0]; game.shopSlots[0] = card('paozhuanyinyu');
      check('满场仍可原地替换且不突破10棋子', useSpell(0, a, null, { simulationOutcome: { type: 'bing', color: 'black' } }).ok && game.pieces.length === 10);
    });
    withBoard(fixture(), () => {
      game.shopSlots[0] = card('kuruoji');
      check('苦肉一永久心可用且不提前死亡', useSpell(0).ok && game.lives === 0 && effectiveLives(game.cur) === 2 && !game.cur.dead);
      damageKing(game.cur);
      check('临时心优先挡漏怪', game.lives === 0 && effectiveLives(game.cur) === 1 && !game.cur.dead);
    });
    {
      const b = fixture(); delete b._simulationContext;
      withBoard(b, () => {
        b.shopSlots[0] = card('kuruoji'); game.phase = 'playing'; useSpell(0);
        game.phase = 'paused'; updateTacticalEffects(b, 30);
        check('暂停不消耗临时心30秒', b.gameTime === 0 && effectiveLives(b) === 2 && !b.dead);
        game.phase = 'playing'; updateTacticalEffects(b, 29.99);
        check('临时心到期前有效', !b.dead && effectiveLives(b) === 2);
        updateTacticalEffects(b, 0.02);
        check('永久0且30秒到期必死', b.lives === 0 && effectiveLives(b) === 0 && b.dead);
      });
    }
    game.phase = 'playing';
    withBoard(fixture(), () => {
      game.shopSlots[0] = card('yiyidailao'); const a = game.pieces[0]; useSpell(0, a);
      game.shopSlots[0] = card('jiachibudian'); useSpell(0, a);
      check('攻击buff取最大且禁暴', pieceTacticalStats(a).rate === 0.4 && pieceTacticalStats(a).noCrit);
      updateTacticalEffects(game.cur, 5);
      check('短buff到期仍保留长buff', pieceTacticalStats(a).rate === 0.25 && !pieceTacticalStats(a).noCrit);
      updateTacticalEffects(game.cur, 5);
      check('攻击buff按游戏时钟到期', pieceTacticalStats(a).rate === 0);
    });
    withBoard(fixture(), () => {
      game.shopSlots[0] = card('guanmenzhuozei'); useSpell(0);
      const current = game.enemies[0];
      check('关门立即眩晕但尚未减速', current.stunLeft === 3 && enemySlowRate(current) === 0);
      game.enemies.push({ hp: 10, maxHp: 10, c: 0, r: 0, progress: 0 }); const newborn = game.enemies[2];
      updateTacticalEffects(game.cur, 3);
      check('关门固定3至6秒减速且新生不继承', enemySlowRate(current) === 0.4 && enemySlowRate(newborn) === 0);
      updateTacticalEffects(game.cur, 3);
      check('关门减速6秒到期', enemySlowRate(current) === 0);
    });
    withBoard(fixture(), () => {
      for (const id of ['lidaitaojiang', 'toulianghuanzhu']) {
        const target = id === 'lidaitaojiang' ? game.pieces[0] : game.pieces[1];
        const outcomes = spellRandomOutcomes(card(id), target), before = JSON.stringify(target);
        check(`${id}机会概率总和1且不改源`, Math.abs(outcomes.reduce((n, o) => n + o.probability, 0) - 1) < 1e-9 && JSON.stringify(target) === before);
        game.shopSlots[0] = card(id);
        check(`${id}模拟遗漏随机结果无消费`, !useSpell(0, target).ok && game.gold === 100 && !game.spellUsed[id]);
      }
    });
    {
      const b = fixture(); delete b._simulationContext;
      withBoard(b, () => {
        const a = b.pieces[0]; b.shopSlots[0] = card('lidaitaojiang');
        check('正式接口拒绝注入随机结果', !useSpell(0, a, null, { simulationOutcome: { type: 'shi', color: 'red' } }).ok && b.gold === 100 && a.type === 'bing');
      });
    }
    withBoard(fixture(), () => {
      const b = game.cur; b.shopSlots[0] = card('shunshouqianyang'); useSpell(0);
      check('顺手净花3且获得刷新优惠', b.gold === 97 && b.nextRefreshDiscount === 5);
      // First refresh retains the discount; shop generation uses a private deterministic RNG.
      b._simulationContext.random = () => 0.1;
      check('首次免费不消耗优惠', refresh().ok && b.nextRefreshDiscount === 5 && b.totalRefreshCount === 1);
      const gold = b.gold, base = b.shopRefreshCost;
      check('付费刷新应用并消耗优惠', refresh().ok && b.gold === gold - Math.max(0, base - 5) && b.nextRefreshDiscount === 0 && b.totalShopRefreshCount === 1);
      const neverUsed = SPELLS.find(s => !b.spellUsed[s.id]);
      b.shopSlots[0] = card(neverUsed.id); refreshShop();
      check('未用刷新不扣库存', !b.spellUsed[neverUsed.id]);
    });
    withBoard(fixture(), () => {
      const b = game.cur, owned = { source: 'fromBoard', piece: p() };
      b.shopSlots = [card('zouweishangji'), owned, { source: 'native', type: 'shovel' }, null, null];
      b.nextRefreshDiscount = 5;
      const counters = [b.totalRefreshCount, b.totalShopRefreshCount, b.shopRefreshCost].join();
      check('走为模拟保留回收卡且不抽随机', useSpell(0).shopRefreshOpportunity && b.shopSlots[1] === owned && b.pendingShopRefresh && b.shopSlots.filter(Boolean).length === 1);
      check('走为不改变刷新计数价格与优惠', counters === [b.totalRefreshCount, b.totalShopRefreshCount, b.shopRefreshCost].join() && b.nextRefreshDiscount === 5);
    });
    withBoard(fixture(), () => {
      const b = game.cur; b._simulationContext.random = () => 0.99;
      // Real shop path with an explicit deterministic private RNG; no formal Math.random use.
      b.shopSlots = Array(5).fill(null); b.totalRefreshCount = 1;
      for (let i = 0; i < 10; i++) {
        refreshShop();
        check(`商店${i}最多1法术1铲子`, b.shopSlots.filter(c => c?.type === 'spell').length <= 1 && b.shopSlots.filter(c => c?.type === 'shovel').length <= 1);
        b.gold += 100;
      }
    });
    {
      const a = fixture(); delete a._simulationContext;
      const b = structuredClone(a); b.side = 'me';
      check('相同公开局势双方权重完全一致', SPELLS.every(s => spellSituationWeight(s, a) === spellSituationWeight(s, b)));
      const rescue = SPELL_BY_ID.fudichouxin;
      a.lives = 3; a.enemies.forEach(e => { e.progress = 1; });
      check('平静救场权重1', spellSituationWeight(rescue, a) === 1);
      a.enemies[0].progress = 6;
      check('危险救场权重2', spellSituationWeight(rescue, a) === 2);
      a.lives = 1;
      check('一心救场权重封顶3', spellSituationWeight(rescue, a) === 3);
      a.pieces = a.pieces.filter(p => p.type !== 'pao');
      check('没有炮时假道不入池', spellSituationWeight(SPELL_BY_ID.jiadaofaguo, a) === 0);
    }
    return { passed: checks.length, checks };
  } finally { game.phase = savedPhase; }
}
