/** 士20双目标、士30空地光环、兵20身后攻速、象30象眼控制专项。Node/browser: import('./js/shiSkills.test.js').then(m => m.runShiSkillsFixtures()) */
import game, { createBoard, withBoard } from './gameData.js';
import { PIECE_STATS, GLOBAL_ATK_SPEED_SCALE, LEVEL_UNLOCK, LEVEL_EFFECT_TEXT, MA_STOMP, PAO_SLOW_SECONDS } from './config.js';
import { pieceDamage, levelCdMult, pieceSkillSpeedMult, normalAttackTargetLimit, controlDurationMult, shiAuraSupported, bingBackSupported } from './attackRule.js';
import { updateCombat } from './wave.js';
import { cloneBoard } from './aiSimulation.js';
import { scorePosition } from './aiEvaluation.js';
import { buffPiece } from './tacticalEffects.js';

export function runShiSkillsFixtures() {
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const near = (a, b) => Math.abs(a - b) < 1e-6;
  const piece = (id, type, c, r, level = 0, color = 'red') => ({ id, kind: 'piece', type, color, c, r,
    level, stage: 0, exp: 0, atkBonus: 0, flags: {}, bonds: [], activeBonds: [], cdLeft: 999 });
  const enemy = (id, c, r, extra = {}) => ({ id, kind: 'enemy', c, r, fx: c, fy: r, progress: c,
    hp: 10000, maxHp: 10000, done: false, dying: false, stunLeft: 0, stunImmuneLeft: 0, ...extra });
  const board = (pieces = []) => {
    const grid = Array.from({ length: 7 }, () => Array(8).fill(1));
    const b = createBoard('me', { rows: 7, cols: 8, road: grid, ground: grid, grass: [],
      path: Array.from({ length: 8 }, (_, c) => ({ c, r: 2 })), enemySpawn: { c: 0, r: 2 }, kingPoint: { c: 7, r: 2 } });
    b.pieces = pieces; b._simulationContext = { random: () => 1 };
    return b;
  };
  const old = game.cur, phase = game.phase;
  try {
    game.phase = 'playing';
    check('每个等级只解锁一项', LEVEL_UNLOCK.bing[15] === 'bingFocus' && LEVEL_UNLOCK.bing[20] === 'bingBackSpeed'
      && LEVEL_UNLOCK.shi[20] === 'shiMultiTarget' && LEVEL_UNLOCK.shi[30] === 'shiGroundAura'
      && LEVEL_UNLOCK.xiang[20] === 'xiangNoEye' && LEVEL_UNLOCK.xiang[30] === 'xiangEyeControl');
    for (const type of ['bing', 'shi', 'xiang']) {
      check(`${type}技能展示与逻辑门槛一致`, Object.keys(LEVEL_EFFECT_TEXT[type]).join() === Object.keys(LEVEL_UNLOCK[type]).join());
    }
    check('士20介绍', LEVEL_EFFECT_TEXT.shi[20] === '一次可同时攻击两名敌人');

    // 士20级：一次最多两名敌人，共享一次暴击与产金。
    for (const level of [19, 20]) {
      const b = board([piece('guard', 'shi', 3, 3, level)]);
      withBoard(b, () => check(`士${level}级目标数`, normalAttackTargetLimit(b.pieces[0]) === (level >= 20 ? 2 : 1)));
    }
    for (const count of [1, 2, 3]) {
      const b = board([piece('guard', 'shi', 3, 3, 20)]), p = b.pieces[0]; let rolls = 0;
      b._simulationContext.random = () => { rolls++; return 0; };
      b.enemies = [enemy('main', 2, 2), enemy('same-cell', 2, 2), enemy('other-cell', 4, 2)].slice(0, count);
      b.enemies.unshift(enemy('done', 4, 4, { done: true }), enemy('dying', 4, 4, { dying: true }));
      b.enemies.push(enemy('outside', 6, 3), enemy('self-cell', 3, 3));
      const hit = withBoard(b, () => pieceDamage(p)) * withBoard(b, () => 1.2), gold = b.gold;
      buffPiece(p, { attackGold: 1, duration: 5 }, b); p.cdLeft = 0; withBoard(b, () => updateCombat(0));
      check(`${count}目标全伤封顶2个`, b.enemies.filter(e => near(10000 - e.hp, hit)).length === Math.min(2, count));
      check(`${count}目标单次暴击与产金`, rolls === 1 && b.gold === gold + 1);
      check(`${count}目标跳过无效及范围外`, b.enemies.filter(e => ['done', 'dying', 'outside', 'self-cell'].includes(e.id)).every(e => e.hp === 10000));
    }

    // 士30级：攻击范围（斜邻四格）内的己方棋子攻击+10%，士自身与范围外不受益，多士不叠加。
    {
      const shi = piece('guard', 'shi', 3, 3, 30), ally = piece('ally', 'ju', 4, 4), side = piece('side', 'ju', 4, 3);
      const b = board([shi, ally, side]);
      withBoard(b, () => {
        const base = pieceDamage(side);
        check('斜邻棋子获得士光环', shiAuraSupported(ally) && near(pieceDamage(ally), base * 1.1));
        check('横竖相邻不在士范围', !shiAuraSupported(side));
        check('士自身不享受自身光环', !shiAuraSupported(shi));
        b.pieces.push(piece('guard2', 'shi', 5, 5, 30));
        check('两枚士光环不叠加', near(pieceDamage(ally), base * 1.1));
        b.pieces.pop(); shi.level = 29;
        check('29级未解锁光环', !shiAuraSupported(ally) && near(pieceDamage(ally), base));
        shi.level = 30; ally.color = 'black';
        check('不同颜色己方棋子同样受益', shiAuraSupported(ally));
      });
      const scoreWith = scorePosition(b).score; shi.level = 29;
      check('AI识别士光环收益', scorePosition(b).score < scoreWith);
    }

    // 兵20级：身后一格（不能攻击的方向）的己方棋子攻速+10%。
    {
      const bing = piece('soldier', 'bing', 3, 3, 20), back = piece('back', 'shi', 3, 4), front = piece('front', 'shi', 3, 2);
      const b = board([bing, back, front]);
      b.enemies = [enemy('target', 2, 3)];
      withBoard(b, () => {
        check('兵身后棋子攻速+10%', bingBackSupported(back) && near(pieceSkillSpeedMult(back), 1.1));
        check('兵前方棋子不受益', !bingBackSupported(front) && pieceSkillSpeedMult(front) === 1);
        check('兵自身不受益', !bingBackSupported(bing));
        bing.level = 19;
        check('19级未解锁', !bingBackSupported(back));
        bing.level = 20;
      });
      back.cdLeft = 0; back.c = 3; back.r = 4; b.enemies = [enemy('diag', 2, 5)];
      withBoard(b, () => updateCombat(0));
      check('真实冷却除1.1', near(back.cdLeft, PIECE_STATS.shi.cd * GLOBAL_ATK_SPEED_SCALE * levelCdMult(back) / 1.1));
      const opp = createBoard('opp', b.map);
      opp.pieces = [piece('o-soldier', 'bing', 3, 3, 20), piece('o-back', 'shi', 3, 4)];
      check('对方棋盘同一逻辑方向', withBoard(opp, () => bingBackSupported(opp.pieces[1])));
    }

    // 象30级：位于象眼（斜邻四格）的己方棋子控制时间+10%：马眩晕、炮减速。
    {
      const elephant = piece('elephant', 'xiang', 3, 3, 30), horse = piece('horse', 'ma', 4, 4, 50);
      const b = board([elephant, horse]);
      withBoard(b, () => {
        check('象眼上的马控制+10%', controlDurationMult(horse) === 1.1);
        horse.c = 4; horse.r = 3;
        check('非象眼位置不受益', controlDurationMult(horse) === 1);
        horse.c = 4; horse.r = 4; elephant.level = 29;
        check('29级未解锁', controlDurationMult(horse) === 1);
        elephant.level = 30;
      });
      horse.cdLeft = 0; b.enemies = [enemy('stun', 6, 5)];
      withBoard(b, () => { updateCombat(0); for (let i = 0; i < 10; i++) updateCombat(0.05); });
      check('马眩晕延长10%', near(b.enemies[0].stunLeft + 0, MA_STOMP.stunSecondsLv20 * 1.1) || b.enemies[0].stunLeft > MA_STOMP.stunSecondsLv20);
      check('延长后的眩晕免疫仍按原档', b.enemies[0].stunImmuneNext === MA_STOMP.stunImmuneByStun[MA_STOMP.stunSecondsLv20]);
      const cannon = piece('cannon', 'pao', 4, 2, 70), screen = piece('screen', 'bing', 4, 1);
      const p2 = board([piece('elephant', 'xiang', 3, 3, 30), cannon, screen]);
      p2.enemies = [enemy('slow', 4, 0)]; cannon.cdLeft = 0;
      withBoard(p2, () => updateCombat(0));
      check('炮减速延长10%', near(p2.enemies[0].slowLeft, PAO_SLOW_SECONDS * 1.1));
    }

    const b = board([piece('guard', 'shi', 3, 3, 20)]);
    b.enemies = [enemy('main', 2, 2)];
    const singleScore = scorePosition(b).score; b.enemies.push(enemy('second', 4, 2));
    check('AI识别当前双目标火力', scorePosition(b).score > singleScore);
    const snapshot = JSON.stringify(b), copy = cloneBoard(b); copy._simulationContext = { random: () => 1 };
    copy.pieces[0].cdLeft = 0; withBoard(copy, () => updateCombat(0));
    check('战斗推演不修改原棋盘', JSON.stringify(b) === snapshot);
    check('上下文恢复', game.cur === old);
    return { passed: checks.length, checks };
  } finally { game.cur = old; game.phase = phase; }
}
