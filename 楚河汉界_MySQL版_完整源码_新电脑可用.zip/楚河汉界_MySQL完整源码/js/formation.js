/** 象眼与马腿阵位：统一提供被动加成和范围预览坐标。 */
import game, { cellKey } from './gameData.js';

export const XIANG_EYE_OFFSETS = Object.freeze([
  [-1, -1], [1, -1], [-1, 1], [1, 1],
]);
export const MA_LEG_OFFSETS = Object.freeze([
  [0, -1], [-1, 0], [1, 0], [0, 1],
]);

function hasFormationCell(board, c, r) {
  const { cols, rows, ground, grass, road } = board.map || {};
  if (!(c >= 0 && r >= 0 && c < cols && r < rows)) return false;
  if (road?.[r]?.[c]) return false;
  return !!(ground?.[r]?.[c] || grass?.[r]?.[c]);
}

function positionsFor(source, offsets, board) {
  return offsets
    .map(([dc, dr]) => ({ c: source.c + dc, r: source.r + dr }))
    .filter(cell => hasFormationCell(board, cell.c, cell.r));
}

/** 返回某枚象/马周围能承载对应被动的我方地块。 */
export function formationCells(type, c, r, board = game.cur) {
  if (type === 'xiang') return positionsFor({ c, r }, XIANG_EYE_OFFSETS, board);
  if (type === 'ma') return positionsFor({ c, r }, MA_LEG_OFFSETS, board);
  return [];
}

/** 拖拽预览用：只返回阵位地块，不要求该地块当前为空。 */
export function formationCellKeys(type, c, r, board = game.cur) {
  return new Set(formationCells(type, c, r, board).map(cell => cellKey(cell.c, cell.r)));
}

/** 仅统计道路上的日字目标格；按未获得免马腿时的阻挡计算，始终保留被动。 */
export function blockedMaRoadCells(piece, board = game.cur) {
  if (piece?.type !== 'ma' || !board) return [];
  const cells = [];
  for (const [a, b] of [[1, 2], [2, 1]]) for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
    const dc = a * sx, dr = b * sy;
    const c = piece.c + dc, r = piece.r + dr;
    if (!(c >= 0 && r >= 0 && c < board.map.cols && r < board.map.rows) || !board.map.road?.[r]?.[c]) continue;
    const legC = piece.c + (a === 2 ? sx : 0);
    const legR = piece.r + (b === 2 ? sy : 0);
    const occupied = (board.king?.c === legC && board.king?.r === legR)
      || board.pieces.some(other => other !== piece && (!piece.id || other.id !== piece.id)
        && other.c === legC && other.r === legR);
    if (occupied) cells.push({ c, r });
  }
  return cells;
}

/** 只给场上的马自身加攻，不向友军提供光环；相同棋子快照供AI与面板共用。 */
export function formationBonuses(piece, board = game.cur) {
  const onBoard = piece && board?.pieces?.some(p => p === piece ||
    (piece.id && p.id === piece.id && p.c === piece.c && p.r === piece.r));
  const blocked = onBoard ? blockedMaRoadCells(piece, board).length : 0;
  return { atkRate: (piece?.level >= 70 ? blocked : 0) / 10, blocked };
}

export default { formationCells, formationCellKeys, formationBonuses, blockedMaRoadCells };
