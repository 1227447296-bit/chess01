/** AI 假想局面与全盘评估。只在副本里重扫羁绊，不试走真实操作或抽随机数。 */
import { PIECE_STATS, GLOBAL_ATK_SPEED_SCALE, ENEMY, BOND_CONFIG, LEVEL, RANK, SHOP, SPELL_BY_ID, experienceRequired, enemyStatsForWave } from './config.js';
import { withBoard, isPlaceablePlot, isDiggable } from './gameData.js';
import { rescanBonds } from './bond.js';
import { computeAttackCells } from './rangePreview.js';
import { pieceDamage, levelCdMult, criticalStats, pieceSkillSpeedMult, normalAttackTargetLimit, canPieceAttack } from './attackRule.js';
import { canAbsorb, canEvolve, evolutionOutcomes, absorbOutcomes } from './synthesis.js';
import * as act from './actions.js';
import { hasBoardCapacity } from './boardLimits.js';
import { pieceTacticalStats, effectiveLives, specialThreshold } from './tacticalEffects.js';
import { validateSpell, spellRandomOutcomes } from './spell.js';
import { cardPrice } from './shop.js';

export function clonePosition(board) {
  const { map, _simulationContext, ...state } = board;
  return { ...structuredClone(state), map: { ...map, cleared: new Set(map.cleared) } };
}

/** 原生卡预览不能调用 shop.pieceDataOfCard：那个函数会缓存棋子并分配正式 id。 */
export function previewCard(card, slot) {
  if (!card) return null;
  if (card.piece || card._piece) return structuredClone(card.piece || card._piece);
  if (card.source === 'fromBoard' || card.type !== 'piece') return null;
  return {
    id: `ai-card-${slot}`, kind: 'piece', type: 'bing', color: card.color,
    c: -1, r: -1, level: card.level || 0, exp: 0, stage: 0, mergeCount: 0, atkBonus: 0,
    flags: {}, cdLeft: 0, bonds: [], activeBonds: [],
  };
}

/** 只读已知选择；未固化士象先通过正常选择入口揭示。 */
export function knownEvolutionChoices(piece, force = false) {
  if (!piece || !canEvolve(piece, { force })) return [];
  const outcomes = evolutionOutcomes(piece, { force });
  return [...new Set(outcomes.flatMap(outcome => outcome.choices || []))];
}

/** 与玩家同一校验；仅枚举本方当前可见卡及显式目标，不读取对手商店。 */
export function spellActions(board, slot) {
  const card = board.shopSlots[slot], spec = SPELL_BY_ID[card?.id];
  if (card?.type !== 'spell' || !spec || board.gold < cardPrice(card)) return [];
  return withBoard(board, () => {
    const base = { kind: 'spell', slot, spellId: card.id, effect: spec.effect, cost: cardPrice(card) };
    const options = [];
    if (spec.kind === 'cell') {
      for (let r = 0; r < board.map.rows; r++) for (let c = 0; c < board.map.cols; c++) {
        if (spec.effect.type === 'dig' ? !isDiggable(c, r) : !isPlaceablePlot(c, r)) continue;
        for (const color of spec.selection === 'color' || spec.effect.type === 'spawnBing' ? ['red', 'black'] : [undefined]) {
          options.push({ ...base, c, r, color });
        }
      }
    } else if (spec.kind === 'none') options.push(base);
    else for (const target of board.pieces) {
      if (target.charge || target.stomp) continue;
      if (spec.selection === 'secondary') {
        for (const secondary of board.pieces) {
          if (secondary === target || secondary.charge || secondary.stomp) continue;
          options.push({ ...base, targetId: target.id, secondaryTargetId: secondary.id });
        }
      } else options.push({ ...base, targetId: target.id });
    }
    const legal = options.filter(action => {
      const target = board.pieces.find(p => p.id === action.targetId) || null;
      const secondaryTarget = board.pieces.find(p => p.id === action.secondaryTargetId);
      const cell = Number.isInteger(action.c) ? { c: action.c, r: action.r } : null;
      return validateSpell(card, target, cell, { color: action.color, secondaryTargetId: secondaryTarget?.id }).ok;
    });
    // 只排序、不把随机结果当可选目标。每个机会分支仍由actions实际应用并完整估值。
    const priority = action => {
      const target = board.pieces.find(p => p.id === action.targetId);
      const secondary = board.pieces.find(p => p.id === action.secondaryTargetId);
      if (!target) {
        if (Number.isInteger(action.c)) return -Math.min(...board.map.path.map(cell => Math.abs(cell.c - action.c) + Math.abs(cell.r - action.r)), 99);
        return 0;
      }
      const attack = pieceDamage(target);
      if (spec.effect.type === 'sacrificeLevel') return (secondary?.level || 0) * 2 - attack;
      if (['experience', 'special', 'stageUp', 'randomEvolve'].includes(spec.effect.type)) return attack + (target.level || 0);
      return attack + (secondary ? pieceDamage(secondary) : 0);
    };
    return legal.sort((a, b) => priority(b) - priority(a));
  });
}

/** 仅在副本调用公共操作。隔离UID，意外随机应立即暴露，不碰正式随机流。 */
function mutatePosition(board, action) {
  const previous = board._simulationContext;
  const ids = [...board.pieces, ...board.shopSlots.map(c => c?.piece).filter(Boolean)];
  const counter = Math.max(0, ...ids.map(p => Number(String(p.id).match(/sim-(\d+)$/)?.[1]) || 0));
  board._simulationContext = { uidCounter: counter, random: () => { throw Error('AI预览不得抽取随机候选'); } };
  try {
    return withBoard(board, () => {
      const piece = board.pieces.find(p => p.id === action.pieceId);
      const target = board.pieces.find(p => p.id === action.targetId);
      const movable = p => !!p && !p.charge && !p.stomp;
      switch (action.kind) {
        case 'buy': return act.buyAndPlace(action.slot, action.c, action.r);
        case 'move': return movable(piece) ? act.moveTo(piece, action.c, action.r) : null;
        case 'swap':
          if (!movable(piece) || !movable(target) || ['full', 'overflow'].includes(canAbsorb(target, piece).reason) || canAbsorb(target, piece).ok) return null;
          return act.boardToPiece(piece, target, action);
        case 'merge': return movable(piece) && movable(target) && canAbsorb(target, piece).ok ? act.boardToPiece(piece, target, action) : null;
        case 'shopMerge': {
          const material = previewCard(board.shopSlots[action.slot], action.slot);
          return movable(target) && material && canAbsorb(target, material).ok ? act.shopToPiece(action.slot, target, action) : null;
        }
        case 'evolve': return movable(piece) ? act.evolvePiece(piece, action.evolutionType) : null;
        case 'dig': return act.useShovel(action.slot, action.c, action.r);
        case 'spell': return (!target || movable(target)) ? act.useSpell(action.slot, target || null,
          Number.isInteger(action.c) && Number.isInteger(action.r) ? { c: action.c, r: action.r } : null,
          { color: action.color, evolutionType: action.evolutionType,
            secondaryTargetId: action.secondaryTargetId,
            simulationOutcome: action.simulationOutcome }) : null;
        default: return null;
      }
    });
  } finally {
    if (previous) board._simulationContext = previous;
    else delete board._simulationContext;
  }
}

/** 机会节点是候选集合，集合内的选择必须另花一次正常动作。 */
export function actionBranches(source, action) {
  const card = source.shopSlots[action.slot];
  const effect = action.kind === 'spell' || action.kind === 'prepareEvolution' ? SPELL_BY_ID[card?.id]?.effect : null;
  if (action.kind === 'spell' && (!effect || (action.spellId && card.id !== action.spellId))) return [];
  if ((action.kind === 'buy' || effect?.type === 'spawnBing') && !hasBoardCapacity(source)) return [];
  const targetId = action.kind === 'evolve' ? action.pieceId : action.targetId;
  const target = source.pieces.find(p => p.id === targetId);
  let projected = null, force = false;
  let mergeOutcomes = null;
  if (['randomEvolve', 'randomTransform', 'replaceBing'].includes(effect?.type)) {
    const branches = [];
    // 所有类型×颜色都属于机会节点，不将其中一个结果写入正式action。
    for (const outcome of spellRandomOutcomes(card, target)) {
      const board = clonePosition(source);
      if (!mutatePosition(board, { ...action, simulationOutcome: outcome })?.ok) continue;
      branches.push({ board, probability: outcome.probability, recoveryId: target.id });
    }
    // 合法动作的随机概率必须完整；缺失分支不能默默归一化成乐观结果。
    return Math.abs(branches.reduce((sum, b) => sum + b.probability, 0) - 1) < 1e-9 ? branches : [];
  }
  if (['merge', 'shopMerge'].includes(action.kind)) {
    const material = action.kind === 'merge' ? source.pieces.find(p => p.id === action.pieceId) : previewCard(card, action.slot);
    if (!canAbsorb(target, material).ok) return [];
    projected = { ...target, stage: (target.stage || 0) + 1 + (material.stage || 0) };
    mergeOutcomes = absorbOutcomes(target, material);
  } else if (effect?.type === 'stageUp') {
    if (!target) return [];
    projected = { ...target, stage: (target.stage || 0) + effect.value };
  } else if (effect?.type === 'evolve') {
    if (!target || !canEvolve(target, { force: true })) return [];
    const choices = evolutionOutcomes(target, { force: true });
    const matching = action.kind === 'prepareEvolution' ? choices
      : choices.filter(outcome => outcome.choices.includes(action.evolutionType));
    if (!matching.length) return [];
    const branches = [];
    for (const outcome of matching) {
      const board = clonePosition(source);
      const copy = board.pieces.find(p => p.id === target.id);
      copy.evolutionChoices = [...outcome.choices]; copy.evolutionChoicesType = copy.type;
      if (action.kind !== 'prepareEvolution' && !mutatePosition(board, action)?.ok) continue;
      branches.push({ board, probability: outcome.probability, recoveryId: target.id });
    }
    return branches;
  } else if (action.kind === 'prepareEvolution') {
    // 主动候选已由自动融合规则取代。
    return [];
  }
  if ((action.kind === 'evolve' || effect?.type === 'evolve')) return [];
  const outcomes = mergeOutcomes || [{ probability: 1 }];
  const branches = [];
  for (const outcome of outcomes) {
    const board = clonePosition(source);
    const branchAction = outcome.type ? { ...action, evolutionType: outcome.type, evolutionColor: outcome.color } : action;
    if (!mutatePosition(board, branchAction)?.ok) continue;
    branches.push({ board, probability: outcome.probability, recoveryId: null });
  }
  return branches;
}

/** 静态评分用于筛选，最终防漏判断由短期真实战斗推演完成。 */
export function scorePosition(board) {
  return withBoard(board, () => {
    rescanBonds();
    const path = board.map.path;
    const fire = new Map(), coverage = new Map();
    let development = 0;
    for (const p of board.pieces) {
      const hits = computeAttackCells(p.type, p.color, p.c, p.r, p.flags, p.level, p.activeBonds);
      coverage.set(p.id, hits.length);
      const cd = PIECE_STATS[p.type].cd * levelCdMult(p) * GLOBAL_ATK_SPEED_SCALE * (board.flags.cdRateByType?.[p.type] || 1)
        / pieceSkillSpeedMult(p);
      // 多目标按当前射程内的存活敌人数估值，不把三目标收益当作单目标常驻三倍。
      const targetCount = normalAttackTargetLimit(p) > 1
        ? Math.max(1, Math.min(normalAttackTargetLimit(p), board.enemies.filter(e => !e.done && !e.dying && e.hp > 0 && canPieceAttack(p, e)).length))
        : 1;
      // 静态火力代表持续防线；限时效果另按可攻击秒数估值，不能当永久成长。
      const permanent = { ...p, tacticalBuffs: [] };
      const crit = criticalStats(permanent);
      const dps = pieceDamage(permanent) * (1 + crit.rate * (crit.damage - 1)) * targetCount / Math.max(0.1, cd);
      for (const cell of hits) {
        const key = `${cell.c},${cell.r}`;
        fire.set(key, (fire.get(key) || 0) + dps);
      }
      // 经验是全场共享且60封顶；旧阶数击杀经验表不再代表任何收益。
      const room = Math.max(0, LEVEL.hardCap - (p.level || 0));
      let growth = Math.min(8, room * 0.3) + (room ? Math.min(1, (p.exp || 0) / experienceRequired(p.level || 0)) * 2 : 0);
      if (canEvolve(p)) growth += 4;
      if (p.type === 'shi' || p.type === 'xiang') growth += 8;
      if (RANK.rankTypes.includes(p.type)) growth += 16;
      growth += Math.log1p(Math.min(LEVEL.hardCap, p.level || 0)) * 2;
      development += growth * (hits.length ? 1 : 0.35);
    }
    let output = 0, rear = 0;
    for (let i = 0; i < path.length; i++) {
      const cell = path[i];
      const dps = fire.get(`${cell.c},${cell.r}`) || 0;
      // 饱和火力递减，但不把合理集火当成错误。
      const value = 11 * Math.log1p(dps / 8);
      output += value * (1.12 - 0.12 * i / Math.max(1, path.length - 1));
      if (i >= path.length * 0.6) rear += value;
    }
    let bonds = 0;
    for (const bond of board.bonds) {
      if (bond.effect === 'goldTick') bonds += 6;
      // 士象全的全场+10%已进入火力；限定一组，额外只估少量稳定价值。
      else if (bond.effect === 'waveLevel') bonds += 6;
      else bonds += 3;
    }
    // 接近等级门槛的邻位预留一点潜力，不能让50级远期羁绊支配开局。
    let potential = 0;
    for (let i = 0; i < board.pieces.length; i++) for (let j = i + 1; j < board.pieces.length; j++) {
      const a = board.pieces[i], b = board.pieces[j];
      for (const conf of Object.values(BOND_CONFIG)) {
        const [x, y] = conf.requireType;
        if (!((a.type === x && b.type === y) || (a.type === y && b.type === x))) continue;
        if (conf.colorRule === 'same' && a.color !== b.color || conf.colorRule === 'mixed' && a.color === b.color) continue;
        if (conf.trigger === 'line') {
          if (a.c !== b.c && a.r !== b.r) continue;
          if (board.pieces.some(p => p !== a && p !== b &&
            (a.c === b.c ? p.c === a.c && p.r > Math.min(a.r, b.r) && p.r < Math.max(a.r, b.r)
              : p.r === a.r && p.c > Math.min(a.c, b.c) && p.c < Math.max(a.c, b.c)))) continue;
        } else if (Math.abs(a.c - b.c) + Math.abs(a.r - b.r) !== 1) continue;
        if (board.bonds.some(bond => bond.key && BOND_CONFIG[bond.key] === conf &&
          [bond.aId, bond.bId].includes(a.id) && [bond.aId, bond.bId].includes(b.id))) continue;
        const req = conf.requireLevel;
        // 与 bond.js 一致：数字/all 须两枚都达标，取较远一枚；either/anyOf 任一达标，取较近一枚。
        const need = p => typeof req === 'number' ? req : req?.all?.[p.type] ?? req?.anyOf?.[p.type] ?? req?.either;
        const gaps = [a, b].filter(p => need(p) != null).map(p => Math.max(0, need(p) - p.level));
        const distance = !gaps.length ? 0
          : typeof req === 'number' || req?.all ? Math.max(...gaps) : Math.min(...gaps);
        if (distance > 0 && distance <= 3) potential += 3 / (1 + distance);
      }
    }
    const hp = enemyStatsForWave(Math.max(1, board.wave || 1), ENEMY).hp;
    return { score: output + rear * 0.08 + development + bonds + potential + board.gold * 0.45,
      output, development, bonds, potential, coverage, fire, hp };
  });
}

/** 真正兑现的非战斗机会；不将刷新价格/法术支出记成收入。 */
export function spellOpportunityScore(source, board, action) {
  if (action.kind !== 'spell') return 0;
  let value = -Math.max(0, source.lives - board.lives) * 8;
  const refreshBase = Math.max(0, board.shopRefreshCost || 0);
  const discount = Math.max(0, Math.min(refreshBase, board.nextRefreshDiscount || 0) -
    Math.min(refreshBase, source.nextRefreshDiscount || 0));
  // 优惠不是现金：只计下一次正常刷新能够实际抵扣的部分。
  if (discount && board.gold >= SHOP.price.piece) value += discount * 0.5;
  // 只有保留正常买棋预算、旧店缺少可买棋时才给未知刷新有限的机会价值。
  if (board.pendingShopRefresh && !source.pendingShopRefresh && board.gold >= SHOP.price.piece) {
    const usefulCards = source.shopSlots.filter(card => card?.type === 'piece' || card?.source === 'fromBoard');
    if (!usefulCards.length || !hasBoardCapacity(source)) value += 3;
  }
  if (SPELL_BY_ID[action.spellId]?.effect.type === 'dig' && board.map.cleared.size > source.map.cleared.size && hasBoardCapacity(board)) {
    const distance = Math.min(99, ...board.map.path.map(cell => Math.abs(cell.c - action.c) + Math.abs(cell.r - action.r)));
    value += distance <= 3 ? 3 : 0.5;
  }
  return value;
}

/** 只估公开当前对象，未知商店/未来随机没有确定收益；实际战斗后以真实结果替换。 */
export function spellTacticalScore(source, board, action) {
  if (action.kind !== 'spell') return 0;
  // 无限波次中没有公开的30秒内胜利证明；0永久心的临时续命到期必败。
  if (source.lives > 0 && board.lives <= 0) return -100000;
  const living = b => b.enemies.filter(e => e.hp > 0 && !e.dead && !e.done && !e.dying);
  const enemies = living(source), now = board.gameTime || 0;
  const afterEnemies = new Map(living(board).map(e => [e.id, e]));
  let score = spellOpportunityScore(source, board, action);
  for (const enemy of enemies) {
    const next = afterEnemies.get(enemy.id);
    score += Math.max(0, enemy.hp - (next?.hp || 0)) * 0.06;
    if (!next) score += 8;
    if (!next) continue;
    const pressure = 1 + Math.max(0, (enemy.progress || 0) / Math.max(1, source.map.path.length - 1));
    score += Math.max(0, (enemy.progress || 0) - (next.progress || 0)) * 2 * pressure;
    score += Math.max(0, (next.stunLeft || 0) - (enemy.stunLeft || 0)) * 2 * pressure;
    const slowSeconds = e => (e.tacticalSlows || []).reduce((sum, s) =>
      sum + Math.max(0, s.until - Math.max(now, s.start || now)) * (s.rate || 0), 0);
    score += Math.max(0, slowSeconds(next) - slowSeconds(enemy)) * pressure;
    const amplification = e => Math.max(0, ...(e.tacticalAmplifiers || []).map(s =>
      Math.max(0, s.until - now) * (s.rate || 0)));
    score += Math.max(0, amplification(next) - amplification(enemy)) * Math.min(8, enemy.hp * 0.01);
  }
  if (enemies.length) score += withBoard(board, () => {
    let benefit = 0;
    for (const p of board.pieces) {
      const old = source.pieces.find(x => x.id === p.id);
      if (!old) continue;
      const hits = computeAttackCells(p.type, p.color, p.c, p.r, p.flags, p.level, p.activeBonds);
      if (!hits.length) continue;
      const reachable = enemies.some(e => source.map.path.slice(Math.max(0, Math.floor(e.progress || 0)),
        Math.max(0, Math.floor(e.progress || 0)) + 8).some(cell => hits.some(h => h.c === cell.c && h.r === cell.r)));
      if (!reachable) continue;
      const cd = Math.max(0.1, PIECE_STATS[p.type].cd * levelCdMult(p) * GLOBAL_ATK_SPEED_SCALE * (board.flags.cdRateByType?.[p.type] || 1));
      const buffs = (p.tacticalBuffs || []).filter(e => e.until > now);
      const seconds = Math.min(10, Math.max(0, ...buffs.map(e => e.until - now)));
      const expected = piece => {
        const crit = criticalStats(piece);
        return pieceDamage(piece) * (1 + crit.rate * (crit.damage - 1));
      };
      benefit += Math.max(-20, (expected(p) - expected(old)) * seconds / cd * 0.06);
      const gold = pieceTacticalStats(p, board).attackGold - pieceTacticalStats(old, source).attackGold;
      benefit += Math.max(0, gold) * Math.min(8, seconds / cd) * 0.45;
      const threshold = specialThreshold(p);
      if (threshold && p.specialCount > (old.specialCount || 0)) {
        benefit += Math.min(18, expected(p) * 0.08) *
          (p.specialCount - (old.specialCount || 0)) / threshold;
      }
    }
    return benefit;
  });
  // 临时心只能在当前有漏怪压力时部分抵偿，不能当作永久回血。
  if (enemies.length) score += Math.max(0, effectiveLives(board) - effectiveLives(source)) * 10;
  return score;
}

/** 评估未知结果：期望收益扣除下行风险，不把最好分支当作确定结果。 */
export function riskAdjusted(values, risk = 0.45) {
  if (!values.length) return -Infinity;
  const mean = values.reduce((sum, v) => sum + v.value * v.probability, 0);
  const worst = Math.min(...values.map(v => v.value));
  return mean - Math.max(0, mean - worst) * risk;
}

/** 随机产物可在下一次动作搬位，但不能在本次战斗推演里免费瞬移。 */
function recoveryValue(board, value, targetId = null) {
  const target = board.pieces.find(p => targetId ? p.id === targetId : String(p.id).includes(':preview:'));
  if (!target) return value;
  const scan = clonePosition(board);
  scan.pieces = scan.pieces.filter(p => p.id !== target.id);
  const cells = withBoard(scan, () => {
    const out = [];
    for (let r = 0; r < scan.map.rows; r++) for (let c = 0; c < scan.map.cols; c++) {
      const occupant = scan.pieces.find(p => p.c === c && p.r === r);
      if (occupant) {
        if (occupant.charge || occupant.stomp || canAbsorb(occupant, target).ok) continue;
      } else if (!isPlaceablePlot(c, r)) continue;
      // 换位后原位会放入另一枚棋子；粗选先去掉目的格棋子，最终整盘重算。
      const original = scan.pieces;
      try {
        if (occupant) scan.pieces = original.filter(p => p !== occupant);
        const hits = computeAttackCells(target.type, target.color, c, r, target.flags, target.level, []);
        out.push({ c, r, swap: occupant?.id, coverage: hits.length });
      } finally { scan.pieces = original; }
    }
    return out.sort((a, b) => b.coverage - a.coverage).slice(0, 2);
  });
  let next = value;
  for (const cell of cells) {
    const branch = actionBranches(board, { kind: cell.swap ? 'swap' : 'move', pieceId: target.id,
      targetId: cell.swap, c: cell.c, r: cell.r, cost: 0 })[0];
    if (branch) next = Math.max(next, scorePosition(branch.board).score);
  }
  return value + (next - value) * 0.65;
}

/** 比较已知商店中的一次补位：有钱、有格才计入，绝不假设下次能刷出好牌。 */
function reinforcementValue(board, value) {
  if (!hasBoardCapacity(board)) return value;
  const cards = board.shopSlots.map((card, slot) => ({ card, slot }))
    .filter(({ card }) => card && (card.type === 'piece' || card.source === 'fromBoard') &&
      board.gold >= (card.source === 'native' ? (card.price ?? SHOP.piecePool.find(p => p.type === (card.kind || 'bing'))?.price ?? SHOP.price.piece) : 0));
  let best = value;
  for (const { card, slot } of cards.slice(0, 2)) {
    const piece = previewCard(card, slot);
    if (!piece) continue;
    const cells = withBoard(board, () => {
      const cells = [];
      for (let r = 0; r < board.map.rows; r++) for (let c = 0; c < board.map.cols; c++) {
        if (isPlaceablePlot(c, r)) cells.push({ c, r, hits: computeAttackCells(piece.type, piece.color, c, r,
          piece.flags, piece.level, []).length });
      }
      return cells.sort((a, b) => b.hits - a.hits).slice(0, 1);
    });
    for (const cell of cells) {
      const next = clonePosition(board);
      next.gold -= card.source === 'native' ? (card.price ?? SHOP.piecePool.find(p => p.type === (card.kind || 'bing'))?.price ?? SHOP.price.piece) : 0;
      next.shopSlots[slot] = null;
      next.pieces.push({ ...piece, c: cell.c, r: cell.r });
      best = Math.max(best, scorePosition(next).score);
    }
  }
  return value + (best - value) * 0.75;
}

/** 阶数不足时比较下一手吸附；基础棋种到2阶时，下一次融合会触发自动进化。 */
function* continuationValue(board, targetId, value) {
  const target = board.pieces.find(p => p.id === targetId);
  if (!target || !['bing', 'shi', 'xiang'].includes(target.type)) return value;
  if (canEvolve(target)) {
    let best = value;
    for (const evolutionType of knownEvolutionChoices(target)) {
      const action = { kind: 'evolve', pieceId: target.id, evolutionType, cost: 0 };
      for (const branch of actionBranches(board, action)) {
        best = Math.max(best, scorePosition(branch.board).score);
        yield;
      }
    }
    // 主动进化是后续的一手，不在当前战斗里免费执行或免费搬位。
    return value + (best - value) * 0.65;
  }
  if (target.stage !== 2) return value;
  const actions = withBoard(board, () => {
    const options = [];
    for (const material of board.pieces) {
      if (material.charge || material.stomp || !canAbsorb(target, material).ok) continue;
      options.push({ kind: 'merge', targetId, pieceId: material.id, cost: 0 });
    }
    for (let slot = 0; slot < board.shopSlots.length; slot++) {
      const card = board.shopSlots[slot];
      if (!card || (card.type !== 'piece' && card.source !== 'fromBoard')) continue;
      const cost = card.source === 'native' ? (card.price ?? SHOP.piecePool.find(p => p.type === (card.kind || 'bing'))?.price ?? SHOP.price.piece) : 0;
      if (board.gold < cost) continue;
      const material = previewCard(card, slot);
      if (material && !material.charge && !material.stomp && canAbsorb(target, material).ok) {
        options.push({ kind: 'shopMerge', targetId, slot, cost });
      }
    }
    // 只缩减下一手材料，不缩减随机产物；优先减少撤走已有火力的代价。
    for (const option of options) {
      const material = board.pieces.find(p => p.id === option.pieceId);
      option.loss = material ? computeAttackCells(material.type, material.color, material.c, material.r,
        material.flags, material.level, material.activeBonds).length * pieceDamage(material) : option.cost;
    }
    return options.sort((a, b) => a.loss - b.loss).slice(0, 2);
  });
  let best = value;
  for (const action of actions) {
    const outcomes = [];
    for (const branch of actionBranches(board, action)) {
      outcomes.push({ probability: branch.probability,
        value: recoveryValue(branch.board, scorePosition(branch.board).score) });
      yield;
    }
    best = Math.max(best, riskAdjusted(outcomes));
  }
  return value + (best - value) * 0.65;
}

export function* evaluateActionSteps(source, action, lookahead = false) {
  const branches = actionBranches(source, action), values = [];
  for (const branch of branches) {
    const value = scorePosition(branch.board).score;
    let planned = lookahead ? recoveryValue(branch.board, value, branch.recoveryId) : value;
    yield;
    if (action.kind === 'prepareEvolution') {
      let best = value;
      const target = branch.board.pieces.find(p => p.id === action.targetId);
      for (const evolutionType of knownEvolutionChoices(target, Number.isInteger(action.slot))) {
        const followup = Number.isInteger(action.slot)
          ? { kind: 'spell', slot: action.slot, targetId: target.id, spellId: action.spellId, evolutionType }
          : { kind: 'evolve', pieceId: target.id, evolutionType };
        for (const next of actionBranches(branch.board, followup)) best = Math.max(best, scorePosition(next.board).score);
        yield;
      }
      planned = value + (best - value) * 0.65;
    }
    if (lookahead && ['merge', 'shopMerge', 'spell'].includes(action.kind)) {
      planned = Math.max(planned, reinforcementValue(branch.board, value));
      yield;
      planned = Math.max(planned, yield* continuationValue(branch.board, action.targetId, value));
    }
    const tactical = spellTacticalScore(source, branch.board, action);
    values.push({ ...branch, value: planned + tactical, tactical, staticValue: planned });
  }
  return { ...action, branches: values, score: riskAdjusted(values),
    unsafe: values.some(branch => branch.tactical <= -100000),
    tactical: values.length ? values.reduce((sum, branch) => sum + branch.tactical * branch.probability, 0) : 0 };
}

/** 同步入口供确定性单元测试；正式 AI 使用上面的分帧入口。 */
export function evaluateAction(source, action, lookahead = false) {
  const evaluation = evaluateActionSteps(source, action, lookahead);
  let next;
  do { next = evaluation.next(); } while (!next.done);
  return next.value;
}
