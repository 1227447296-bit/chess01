/**
 * shovel.js —— 铲子 & 地皮逻辑
 * 铲子卡从商店购买后，拖拽到地图上的草地格使用：
 *   草地格（grass 层有瓦片）→ 铲掉，露出下方 Ground，之后可放置棋子（永久空地）。
 *   road 层不可铲除。
 * 地皮状态维护在 gameData.map.cleared（"c,r" 集合）。
 * 「拓荒」法术同款效果，复用 digPlot()。
 */
import game, { cellKey, isDiggable, pieceAt } from './gameData.js';

/**
 * 铲除一格草地。
 * @param {number} c
 * @param {number} r
 * @returns {{ok:boolean, reason?:string}}
 */
export function digPlot(c, r) {
  if (!isDiggable(c, r)) {
    if (game.map.road[r]?.[c]) return { ok: false, reason: '路径不可铲除' };
    return { ok: false, reason: '这里无法挖掘' };
  }
  if (pieceAt(c, r)) return { ok: false, reason: '该格已有棋子' };

  game.map.cleared.add(cellKey(c, r));
  return { ok: true };
}

/** 该格是否已被铲开（露出的空地） */
export function isCleared(c, r) {
  return game.map.cleared.has(cellKey(c, r));
}

/** 便捷：随机挖一块空地（供法术「拓荒」内部调用，也可用于调试） */
export function digRandom() {
  const { grass, cleared } = game.map;
  const rows = grass.length;
  const cols = grass[0]?.length || 0;
  const list = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (grass[r][c] && !cleared.has(cellKey(c, r))) list.push([c, r]);
    }
  }
  if (!list.length) return null;
  const [c, r] = list[Math.floor(Math.random() * list.length)];
  digPlot(c, r);
  return { c, r };
}

export default { digPlot, isCleared, digRandom };
