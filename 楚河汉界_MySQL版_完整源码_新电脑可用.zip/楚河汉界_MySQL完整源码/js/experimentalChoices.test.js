import game from './gameData.js';
import { chooseExperimentalOption } from './experimentalChoices.js';

export async function runExperimentalChoiceFixtures() {
  const phase = game.phase;
  let passed = 0;
  const check = (value, message) => { if (!value) throw new Error(message); passed++; };
  try {
    game.phase = 'playing';
    let pending = chooseExperimentalOption('测试选择', [{ label: '红兵', value: 'red' }]);
    check(game.phase === 'paused', 'Both boards must pause');
    check(document.querySelector('[role="dialog"]') != null, 'Accessible dialog');
    document.querySelector('.experimental-choice button').click();
    check(await pending === 'red', 'Selected value');
    check(game.phase === 'playing', 'Restore play after choice');
    pending = chooseExperimentalOption('测试取消', [{ label: '红兵', value: 'red' }]);
    document.querySelector('.experimental-choice-cancel').click();
    check(await pending === null, 'Cancel returns no choice');
    check(game.phase === 'playing', 'Cancel restores play');
    game.phase = 'paused';
    pending = chooseExperimentalOption('保留暂停', [{ label: '黑卒', value: 'black' }]);
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    check(await pending === null, 'Escape cancels');
    check(game.phase === 'paused', 'Original pause is retained');
    check(!document.querySelector('.experimental-choice-overlay'), 'No leaked overlay');
    return passed;
  } finally {
    game.phase = phase;
  }
}
