/** 默认 HTTPS -> Cloudflare D1，本地默认跳过；本地 ?dataSource=mysql 或
 * window.__CHESS_DATA_SOURCE__='mysql' 启用同源 Node/MySQL API。 */
const matchIds = new WeakMap();
function mysqlMode() {
  const source = window.__CHESS_DATA_SOURCE__ || new URLSearchParams(location.search).get('dataSource');
  return String(source).toLowerCase() === 'mysql'
    && location.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(location.hostname);
}
function apiUrl() { return window.__CHESS_API_URL__ || '/api/match'; }
function status(message, failed = false) {
  if (typeof document === 'undefined') return;
  let panel = document.getElementById('mysql-data-status');
  if (!panel) {
    panel = document.createElement('aside');
    panel.id = 'mysql-data-status';
    panel.setAttribute('role', 'status');
    panel.setAttribute('aria-live', 'polite');
    Object.assign(panel.style, {
      position: 'fixed', bottom: '8px', left: '8px', zIndex: '100000',
      padding: '8px 12px', maxWidth: 'min(460px, 90vw)', background: '#fff5dc',
      color: '#33220b', border: '1px solid #98763d', borderRadius: '6px',
      font: '14px sans-serif', whiteSpace: 'pre-wrap', pointerEvents: 'none',
    });
    document.body.appendChild(panel);
  }
  panel.textContent = `数据源：MySQL（本地）\n${message}`;
  panel.style.borderColor = failed ? '#ba2323' : '#98763d';
}
async function health() {
  status('连接：正在检查…');
  try {
    const url = new URL(apiUrl(), location.href);
    url.pathname = '/api/health'; url.search = '';
    const response = await fetch(url, { signal: AbortSignal.timeout(7000) });
    const result = await response.json();
    if (!response.ok || result.ok !== true || result.source !== 'mysql' || result.connected !== true) throw Error(result.error || '连接检查未通过');
    status('连接：已验证 MySQL · 尚无本次保存\n只读报告：/report');
  } catch (error) { status(`连接：失败 · ${error.message}\n尚未保存，游戏可继续`, true); }
}
if (typeof window !== 'undefined' && mysqlMode()) {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', health, { once: true });
  else void health();
}

/** 仅结束对局摘要。MySQL 模式明确报告成功 id 或失败，绝不降级为假成功。 */
export async function uploadMatch(data) {
  const localMysql = mysqlMode();
  if (location.protocol !== 'https:' && !localMysql) return { ok: true, skipped: true };
  try {
    let payload = data;
    if (localMysql) {
      if (!matchIds.has(data)) matchIds.set(data, crypto.randomUUID());
      payload = { ...data, match_uuid: matchIds.get(data) };
      status('连接：保存中…');
    }
    const response = await fetch(localMysql ? apiUrl() : '/api/match', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload), signal: AbortSignal.timeout(10000),
    });
    let result;
    try { result = await response.json(); } catch { throw Error('服务未返回有效 JSON'); }
    if (!response.ok || result?.ok !== true || !result.match_id) throw Error(result?.error || `HTTP ${response.status}：未确认保存`);
    if (localMysql) status(`保存：成功 · match_id=${result.match_id}${result.duplicate ? '（重复请求，未新增）' : ''}\n只读报告：/report`);
    return result;
  } catch (error) {
    if (localMysql) status(`保存：失败 · ${error.message}\n未确认写入，请勿视为成功`, true);
    else console.warn('[api] 上传对局记录失败（不影响游戏）', error.message);
    return { ok: false, error: error.message };
  }
}
