import game, { createBoard, withBoard } from './gameData.js';
import { applyAbsorb } from './synthesis.js';
import { actionBranches } from './aiEvaluation.js';
import * as actions from './actions.js';
import { randomPieceCard } from './shop.js';

export function runRandomEvolutionFixtures() {
  let passed = 0;
  const check = (ok, name) => { if (!ok) throw Error(name); passed++; };
  const piece = (type, stage, id) => ({ id, kind: 'piece', type, stage, color: 'red', level: 12,
    exp: 7, c: 1, r: 1, atkBonus: 4, flags: {}, bonds: [], specialEnhancements: { huixin: 1 }, critRateBonus: .1 });
  for (const type of ['bing', 'shi', 'xiang']) {
    const pool = type === 'bing' ? ['shi', 'xiang'] : ['ju', 'ma', 'pao'];
    for (let i = 0; i < pool.length; i++) for (const color of ['red', 'black']) {
      const b = createBoard('opp');
      const values = [(i + .25) / pool.length, color === 'red' ? .25 : .75];
      b._simulationContext = { random: () => values.shift() };
      withBoard(b, () => {
        const a = piece(type, 2, 'a'), m = piece(type, 0, 'm');
        check(applyAbsorb(a, m).ok && a.type === pool[i] && a.color === color && a.stage === 0, '真实随机种类颜色');
        check(a.level === 27 && a.exp === 0 && a.atkBonus === 8 && a.critRateBonus === .1 && a.specialEnhancements.huixin === 1, '继承等级强化');
      });
    }
    const b = createBoard('opp');
    b.map = { cols: 3, rows: 3, ground: [], grass: [], road: [], cleared: new Set(), path: [] };
    b.gold = 100;
    b.pieces = [piece(type, 2, 'a'), piece(type, 0, 'm')];
    const before = JSON.stringify(b);
    const branches = actionBranches(b, { kind: 'merge', targetId: 'a', pieceId: 'm' });
    check(branches.length === pool.length * 2 && new Set(branches.map(x => x.board.pieces[0].type + x.board.pieces[0].color)).size === pool.length * 2, 'AI完整产物集合');
    check(Math.abs(branches.reduce((sum, x) => sum + x.probability, 0) - 1) < 1e-10 && branches.every(x => x.board.pieces.length === 1 && x.board.pieces[0].stage === 0), 'AI概率及材料消耗');
    check(JSON.stringify(b) === before, 'AI不修改源');
    withBoard(b, () => {
      b._simulationContext = { random: () => .75 };
      b.shopSlots[0] = { source: 'fromBoard', piece: piece(type, 2, 'shop-a') };
      b.shopSlots[1] = { source: 'fromBoard', piece: piece(type, 0, 'shop-m') };
      check(actions.shopMerge(1, 0).ok && pool.includes(b.shopSlots[0].piece.type) && b.shopSlots[0].piece.stage === 0 && b.shopSlots[0].color === 'black' && !b.shopSlots[1], '商店融合安装产物');
    });
  }
  const b = createBoard('opp');
  b._simulationContext = { random: () => .75 };
  withBoard(b, () => {
    for (const wave of [0, 5, 12, 50]) {
      b.wave = wave;
      check(Array.from({ length: 50 }, randomPieceCard).every(x => x.kind === 'bing'), '所有波次原生卡仅兵');
    }
  });
  return { passed };
}
