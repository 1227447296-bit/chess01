/** 低段每局随机档位与操作隔离；不写段位存档。 */
import game, { createBoard, withBoard } from './gameData.js';
import { setupAI, aiTick, aiInfo, setForcedTier } from './ai.js';
import { loadMap } from './mapLoader.js';
import { AI_PLAY } from './config.js';
import { waitForBenchmarkReady } from './aiBenchmark.test.js';

export async function runAINoviceFixtures() {
  await waitForBenchmarkReady();
  if (game.phase !== 'start') throw Error('Start page required');
  const original = { phase: game.phase, cur: game.cur };
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const map = await loadMap(1);
  const open = (tier = 0, seed = 11, lowRankMode = null, side = 'opp', override = null) => {
    setupAI({ tier }, { seed, lowRankMode, evaluationSlices: 32 });
    const board = createBoard(side, map);
    withBoard(board, () => aiTick(0, 3, override));
    return board;
  };
  try {
    setForcedTier(null);
    game.phase = 'playing';
    let weak = 0;
    for (let seed = 1; seed <= 128; seed++) if (aiInfo(open(0, seed)).lowRankMode === 'novice') weak++;
    check('随机对局同时存在正常和新手档', weak > 32 && weak < 96);
    const first = aiInfo(open(1, 47)).lowRankMode;
    check('同种子开局档位可重复', first === aiInfo(open(1, 47)).lowRankMode);
    for (const tier of [0, 1]) {
      const board = open(tier, 11, 'novice');
      check(`${tier}段可进入新手档`, aiInfo(board).lowRankMode === 'novice');
      for (let n = 0; n < 20; n++) withBoard(board, () => aiTick(0.01, 3));
      check(`${tier}段不会逐帧重抽档位`, aiInfo(board).lowRankMode === 'novice');
      check(`${tier}段初始化不修改经济生命`, board.gold === 25 && board.lives === 3 && !board.dead && board.pieces.length === 0);
      const normal = open(tier, 11, 'normal');
      check(`${tier}段可保留现有正常档`, aiInfo(normal).lowRankMode === 'normal');
    }
    for (let tier = 2; tier <= 7; tier++) {
      check(`${tier}段不受低段弱档影响`, aiInfo(open(tier, 11, 'novice')).lowRankMode === 'normal');
    }
    check('玩家自动下棋不进入弱档', aiInfo(open(0, 11, 'novice', 'me')).lowRankMode === 'normal');
    check('显式段位调试不进入弱档', aiInfo(open(0, 11, 'novice', 'opp', 0)).lowRankMode === 'normal');
    setForcedTier(0);
    check('强制段位不进入弱档', aiInfo(open(0, 11, 'novice')).lowRankMode === 'normal');
    setForcedTier(null);
    const board = open(0, 11, 'novice');
    withBoard(board, () => aiTick(1, 3));
    check('首次仍只执行一次免费刷新', board.totalRefreshCount === 1 && aiInfo(board).lastAction.kind === 'refresh' && board.gold === 25);
    check('新手档使用同样的操作等待范围', board.aiTimer >= AI_PLAY.actionMin && board.aiTimer <= AI_PLAY.actionMax);
    withBoard(board, () => aiTick(0, 3));
    check('等待期间不会补执行第二个动作', board.totalRefreshCount === 1 && board.pieces.length === 0);
    check('棋盘上下文恢复', game.cur === original.cur);
    return { passed: checks.length, sampleNovice: weak, checks };
  } finally {
    game.phase = original.phase;
    game.cur = original.cur;
    setForcedTier(null);
    setupAI({ tier: 7 });
  }
}
