/** 战术效果共用接口。绝对时间只属于传入棋盘，不保存对象外的战斗状态。 */
import game from './gameData.js';

const now = board => board.gameTime || 0;
const active = (effect, board) => effect.until > now(board) && (effect.start || 0) <= now(board);
export function effectiveLives(board = game.cur) {
  return Math.max(0, board.lives || 0) + (board.temporaryLives || [])
    .filter(e => active(e, board)).reduce((n, e) => n + e.amount, 0);
}
export function addTemporaryLives(board = game.cur, amount = 2, duration = 30) {
  if (!(amount > 0) || !(duration > 0) || board.dead) return false;
  (board.temporaryLives || (board.temporaryLives = [])).push({ amount, until: now(board) + duration });
  return true;
}
export function damageKing(board = game.cur, amount = 1) {
  if (board.god || board.dead || !(amount > 0)) return 0;
  const original = amount;
  board.temporaryLives = (board.temporaryLives || []).filter(e => active(e, board)).sort((a,b) => a.until - b.until);
  for (const e of board.temporaryLives) {
    const take = Math.min(amount, e.amount); e.amount -= take; amount -= take;
    if (amount <= 0) break;
  }
  board.temporaryLives = board.temporaryLives.filter(e => e.amount > 0);
  board.lives = Math.max(0, (board.lives || 0) - amount);
  if (effectiveLives(board) <= 0) board.dead = true;
  return original;
}
export function buffPiece(piece, { rate = 0, duration = 0, noCrit = false, attackGold = 0 } = {}, board = game.cur) {
  if (!piece || !(duration > 0)) return false;
  (piece.tacticalBuffs || (piece.tacticalBuffs = [])).push({ rate, noCrit, attackGold, until: now(board) + duration });
  return true;
}
export function pieceTacticalStats(piece, board = game.cur) {
  const effects = (piece.tacticalBuffs || []).filter(e => active(e, board));
  return { rate: Math.max(0, ...effects.map(e => e.rate || 0)), noCrit: effects.some(e => e.noCrit),
    attackGold: Math.max(0, ...effects.map(e => e.attackGold || 0)) };
}
export function slowEnemy(enemy, rate, duration, delay = 0, board = game.cur) {
  if (!enemy || enemy.done || enemy.dying || !(duration > 0)) return false;
  (enemy.tacticalSlows || (enemy.tacticalSlows = [])).push({ rate: Math.min(1, Math.max(0, rate)), start: now(board) + delay, until: now(board) + delay + duration });
  return true;
}
export function enemySlowRate(enemy, board = game.cur) {
  return Math.max(0, ...(enemy.tacticalSlows || []).filter(e => active(e, board)).map(e => e.rate));
}
/** 分段积分固定的延迟窗口，帧跨过3/6秒也不提前或延长减速。 */
export function enemyMovementMultiplier(enemy, dt, base = 1, board = game.cur) {
  if (!(dt > 0)) return Math.min(base, 1 - enemySlowRate(enemy, board));
  const end = now(board), start = end - dt;
  const effects = enemy.tacticalSlows || [];
  const cuts = [start, end];
  for (const e of effects) for (const t of [e.start || 0, e.until]) if (t > start && t < end) cuts.push(t);
  cuts.sort((a,b) => a-b);
  let distance = 0;
  for (let i = 1; i < cuts.length; i++) {
    const midpoint = (cuts[i - 1] + cuts[i]) / 2;
    const rate = Math.max(0, ...effects.filter(e => (e.start || 0) <= midpoint && e.until > midpoint).map(e => e.rate));
    distance += (cuts[i] - cuts[i - 1]) * Math.min(base, 1 - rate);
  }
  return distance / dt;
}
export function amplifyEnemy(enemy, rate, duration, board = game.cur) {
  if (!enemy || enemy.done || enemy.dying || !(duration > 0)) return false;
  (enemy.tacticalAmplifiers || (enemy.tacticalAmplifiers = [])).push({ rate, until: now(board) + duration });
  return true;
}
export function enemyDamageRate(enemy, board = game.cur) {
  return 1 + Math.max(0, ...(enemy.tacticalAmplifiers || []).filter(e => active(e, board)).map(e => e.rate));
}
export function retreatEnemies(board, enemies, cells) {
  const path = board.map.path;
  if (!path.length || !(cells > 0)) return 0;
  let count = 0;
  for (const e of new Set(enemies)) {
    if (!board.enemies.includes(e) || e.done || e.dying || e.hp <= 0) continue;
    e.progress = Math.max(0, (e.progress || 0) - cells);
    const i = Math.min(path.length - 1, Math.floor(e.progress));
    const a = path[i], b = path[i + 1] || a, f = e.progress - i;
    e.fx = a.c + (b.c - a.c) * f; e.fy = a.r + (b.r - a.r) * f;
    e.c = Math.round(e.fx); e.r = Math.round(e.fy); count++;
  }
  return count;
}
export function specialThreshold(piece) {
  if (!piece || piece.level < 60) return 0;
  return ({ ju: piece.level >= 100 ? 4 : 6, pao: piece.level >= 100 ? 3 : 4, ma: piece.level >= 100 ? 4 : 5 })[piece.type] || 0;
}
export function forceSpecial(piece) {
  const threshold = specialThreshold(piece);
  if (!threshold) return false;
  piece.specialCount = threshold - 1;
  return true;
}
let cannonBurst = null;
/** wave 注册纯执行器；不保存棋盘或目标，模拟仍显式使用私有 board。 */
export function registerCannonBurst(fn) { cannonBurst = fn; }
export function forceCannonBurst(piece, board = game.cur) {
  return !!(cannonBurst && cannonBurst(piece, board));
}
export function updateTacticalEffects(board, dt) {
  if (!(dt >= 0) || (game.phase !== 'playing' && !board._simulationContext) || board.dead) return;
  board.gameTime = now(board) + dt;
  board.temporaryLives = (board.temporaryLives || []).filter(e => e.until > now(board) && e.amount > 0);
  for (const p of board.pieces) p.tacticalBuffs = (p.tacticalBuffs || []).filter(e => e.until > now(board));
  for (const e of board.enemies) {
    e.tacticalSlows = (e.tacticalSlows || []).filter(s => s.until > now(board) - dt);
    e.tacticalAmplifiers = (e.tacticalAmplifiers || []).filter(s => s.until > now(board));
  }
  if (effectiveLives(board) <= 0) board.dead = true;
}
