import game, { createBoard, withBoard } from './gameData.js';
import { spellDamage, update, updateCombat } from './wave.js';
import { render, renderState } from './render.js';

export function runDamageFloatersFixtures() {
  const phase = game.phase, state = { ...renderState };
  let passed = 0;
  const check = (ok, text) => { if (!ok) throw Error(text); passed++; };
  try {
    const b = createBoard('me', game.boards.me.map);
    const e = { id: 'damage-test', c: 1, r: 1, fx: 1.25, fy: 1, hp: 100, maxHp: 100, speed: 0, progress: 0 };
    b.enemies = [e]; game.phase = 'playing';
    withBoard(b, () => {
      spellDamage(null, [e], { fixed: 12.5 });
      check(e.hp === 87.5 && b.damageFloaters.length === 1, '实际伤害产生一条飘字');
      check(b.damageFloaters[0].amount === 12.5 && b.damageFloaters[0].c === 1.25, '伤害值与连续坐标准确');
      spellDamage(null, [e], { fixed: 5 });
      check(b.damageFloaters.length === 2, '连续伤害分别显示');
      spellDamage(null, [e], { fixed: 0 });
      check(b.damageFloaters.length === 2, '零伤害不产生飘字');
      game.phase = 'paused'; update(1);
      check(b.gameTime === 0 && b.damageFloaters.length === 2, '暂停不推进飘字');
      game.phase = 'playing'; b.enemies = [];
      const canvas = document.createElement('canvas'); canvas.width = 1000; canvas.height = 1000;
      renderState.canvas = canvas; renderState.ctx = canvas.getContext('2d');
      const texts = [], fillText = renderState.ctx.fillText.bind(renderState.ctx);
      renderState.ctx.fillText = (text, ...args) => { texts.push(text); fillText(text, ...args); };
      for (const sideways of [false, true]) for (const flip of [false, true]) {
        renderState.sideways = sideways; renderState.flip = flip; render(0);
        check(texts.includes('-1250') && texts.includes('-500'), '死亡后横置翻转仍显示×100负伤害值');
      }
      b.gameTime = 0.81; updateCombat(0);
      check(b.damageFloaters.length === 0, '飘字按游戏时间清理');
      b.enemies = [e]; b._simulationContext = { random: () => 1 };
      spellDamage(null, [e], { fixed: 1 });
      check(b.damageFloaters.length === 0 && e.hp === 81.5, 'AI推演扣血相同且不创建视觉对象');
    });
    return { passed };
  } finally { game.phase = phase; Object.assign(renderState, state); }
}
