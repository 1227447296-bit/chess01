/** 开发对照，不结算段位；双盘清场脚本仅用于压力夹具，不代表合法玩家或胜率。 */
import game, { createBoard, withBoard } from './gameData.js';
import { loadMap } from './mapLoader.js';
import * as wave from './wave.js';
import { rescanBonds } from './bond.js';
import { setupAI, aiTick, aiInfo } from './ai.js';
import { canAbsorb } from './synthesis.js';
import { clonePosition, scorePosition, evaluateAction } from './aiEvaluation.js';
import { WAVES, AI_PLAY } from './config.js';

function fusionDiagnostics(board) {
  return withBoard(board, () => {
    const baseline = scorePosition(clonePosition(board)).score;
    const options = [];
    for (const piece of board.pieces) for (const target of board.pieces) {
      if (!canAbsorb(target, piece).ok) continue;
      const action = evaluateAction(board, { kind: 'merge', pieceId: piece.id, targetId: target.id, cost: 0 }, true);
      options.push({ type: target.type, fromStage: piece.stage, toStage: target.stage,
        gain: Math.round((action.score - baseline) * 10) / 10,
        branches: action.branches.map(b => Math.round((b.value - baseline) * 10) / 10) });
    }
    return options.sort((a, b) => b.gain - a.gain).slice(0, 12);
  });
}

export async function waitForBenchmarkReady() {
  if (typeof document === 'undefined') return;
  const screen = document.getElementById('loading-screen');
  if (!screen || screen.classList.contains('hidden')) return;
  await new Promise((resolve, reject) => {
    const observer = new MutationObserver(() => {
      if (screen.classList.contains('has-error')) finish(Error('Resource loading failed'));
      else if (screen.classList.contains('hidden')) finish();
    });
    const timer = setTimeout(() => finish(Error('Resource loading timeout')), 30000);
    function finish(error) {
      observer.disconnect();
      clearTimeout(timer);
      if (error) reject(error); else resolve();
    }
    observer.observe(screen, { attributes: true, attributeFilter: ['class'] });
  });
}

export async function benchmarkAI(ids = ['1', '5', '9'], seeds = [11], duration = 600, options = {}) {
  await waitForBenchmarkReady();
  if (game.phase !== 'start') throw Error('Start page required');
  const clearDelay = options.playerClearDelay ?? null;
  const evaluationSlices = options.evaluationSlices ?? null;
  const variationSeed = options.variationSeed ?? null, variety = options.variety ?? true;
  const rankStreak = options.rankStreak ?? 0;
  const rankTier = options.rankTier ?? null, lowRankMode = options.lowRankMode ?? null;
  const experiment = options.experiment ?? null;
  if ((rankTier !== null && (!Number.isInteger(rankTier) || rankTier < 0 || rankTier > 7)) ||
      (lowRankMode !== null && !['normal', 'novice'].includes(lowRankMode))) throw Error('Invalid low-rank benchmark options');
  if (!Number.isInteger(rankStreak) || rankStreak > 0 || rankStreak < -100 ||
      !Number.isFinite(duration) || duration <= 0 || duration > 1800 || typeof variety !== 'boolean' ||
      (variationSeed !== null && (!Number.isInteger(variationSeed) || variationSeed < 0 || variationSeed > 0xffffffff)) ||
      (evaluationSlices !== null && (!Number.isInteger(evaluationSlices) || evaluationSlices < 1 || evaluationSlices > 64)) ||
      (clearDelay !== null && (!Number.isFinite(clearDelay) || clearDelay < 0.05))) {
    throw Error('Invalid benchmark duration, rank streak, or player clear delay');
  }
  const maps = await Promise.all(ids.map(id => loadMap(id)));
  const originalRandom = Math.random, originalLog = console.log;
  const originalPhase = game.phase, originalWaves = structuredClone(wave.sharedWaves);
  const results = [];
  try {
    console.log = () => {};
    game.phase = 'playing';
    for (let i = 0; i < ids.length; i++) for (const seed of seeds) {
      let state = seed;
      Math.random = () => { state = (Math.imul(state, 1664525) + 1013904223) >>> 0; return state / 4294967296; };
      setupAI({ tier: rankTier ?? 7, sub: 0, stars: 0, streak: rankStreak },
        { seed, evaluationSlices, variationSeed, variety, lowRankMode, reliefTest: rankStreak <= -3, experiment });
      const board = createBoard('opp', maps[i]);
      const player = clearDelay === null ? null : createBoard('me', maps[i]);
      const boards = player ? [player, board] : [board];
      wave.resetSharedWaves();
      for (const b of boards) withBoard(b, () => wave.spawnKing());
      const births = new WeakMap(), waveStarts = [], countdowns = [], spawns = [];
      let advancedAt = null, peakMs = 0, time = 0, firstLeakAt = null, firstBacklogAt = null;
      let peakAlive = 0, oracleClears = 0, totalMs = 0, ticks = 0, leaks = 0;
      const actions = {}, spending = {}, refreshes = [], actionTrace = [];
      let lastAction = null;
      const living = () => board.enemies.filter(e => !e.done && !e.dying && e.hp > 0);
      for (let n = 0; n < duration * 20 && !boards.some(b => b.dead); n++) {
        const oldWave = wave.sharedWaves.wave, oldCount = wave.sharedWaves.spawnedInWave;
        const oldCountdown = wave.sharedWaves.countdown;
        wave.updateSharedWaves(0.05, boards);
        if (player && (player.spawned !== board.spawned || player.wave !== board.wave)) {
          throw Error('Shared spawn symmetry violated');
        }
        if (wave.sharedWaves.wave !== oldWave) {
          const alive = living();
          waveStarts.push({ wave: wave.sharedWaves.wave, at: time, oldAlive: alive.length,
            oldHp: alive.reduce((sum, e) => sum + e.hp, 0) });
          if (alive.length && firstBacklogAt === null) firstBacklogAt = time;
        }
        if (!oldCountdown && wave.sharedWaves.countdown) countdowns.push({ wave: board.wave, at: time });
        if (wave.sharedWaves.wave === oldWave && wave.sharedWaves.spawnedInWave > oldCount) {
          spawns.push({ wave: board.wave, index: wave.sharedWaves.spawnedInWave, at: time });
        }
        if (player) withBoard(player, () => {
          // 清场 oracle 只改变玩家侧：不给金币/经验，不替 AI 清怪，也不直接推动波次。
          // 保留正常死亡闪烁及数组移除，随后由真实共享调度观察清空事实。
          for (const enemy of player.enemies) {
            if (!births.has(enemy)) births.set(enemy, time);
            if (!enemy.done && !enemy.dying && time + 0.05 - births.get(enemy) + 1e-9 >= clearDelay) {
              enemy.hp = 0;
              enemy.dying = true;
              enemy.deathT = 0;
              oracleClears++;
            }
          }
          wave.update(0.05);
        });
        withBoard(board, () => {
          // 与生产循环一致：共享出怪 → 双方战斗 → AI动作 → 定期羁绊重扫。
          wave.update(0.05);
          const beforeGold = board.gold, beforeSlots = board.shopSlots, beforeAction = aiInfo(board).lastAction;
          aiTick(0.05, player?.lives ?? 3, rankTier === null ? 7 : null);
          const action = aiInfo(board).lastAction;
          if (action && action !== beforeAction) {
            const spent = beforeGold - board.gold;
            spending[action.kind] = (spending[action.kind] || 0) + spent;
            if (action.kind === 'refresh') refreshes.push({ at: time, spent, goldBefore: beforeGold,
              discarded: beforeSlots.filter(card => card?.type === 'piece' || card?.source === 'fromBoard')
                .map(card => ({ source: card.source, type: card.piece?.type || 'bing', color: card.color || card.piece?.color })) });
          }
        });
        if (n % 8 === 0) for (const b of boards) withBoard(b, () => rescanBonds());
        const info = aiInfo(board);
        peakMs = Math.max(peakMs, info.evaluationMs);
        totalMs += info.evaluationMs; ticks++;
        peakAlive = Math.max(peakAlive, living().length);
        if (firstLeakAt === null && board.lives < 3) firstLeakAt = time + 0.05;
        if (info.lastAction && info.lastAction !== lastAction) {
          actions[info.lastAction.kind] = (actions[info.lastAction.kind] || 0) + 1;
          const placed = board.pieces.find(piece => piece.c === info.lastAction.c && piece.r === info.lastAction.r);
          actionTrace.push({ at: time, kind: info.lastAction.kind, c: info.lastAction.c, r: info.lastAction.r,
            type: placed?.type ?? null, color: placed?.color ?? null,
            followup: info.plan ? { kind: info.plan.kind, slot: info.plan.slot, c: info.plan.c, r: info.plan.r } : null });
          lastAction = info.lastAction;
        }
        time += 0.05;
        if (advancedAt === null && board.pieces.some(p => ['ju', 'ma', 'pao'].includes(p.type))) advancedAt = time;
      }
      results.push({ id: ids[i], seed, tier: rankTier ?? 7,
        lowRankMode: aiInfo(board).lowRankMode, noviceActions: aiInfo(board).noviceActions,
        mode: player ? 'dual-oracle' : 'single', playerClearDelay: clearDelay,
        evaluationSlices, variationSeed, variety, rankStreak, actionTrace,
        varietyChoices: aiInfo(board).varietyChoices, varietyEligible: aiInfo(board).varietyEligible,
        reliefActivated: aiInfo(board).reliefActivated, reliefActions: aiInfo(board).reliefActions,
        reliefBudgetExhausted: aiInfo(board).reliefBudgetExhausted, reliefLost: aiInfo(board).reliefLost,
        time: Math.round(time), wave: board.wave, lives: board.lives, avgMsPerTick: ticks ? totalMs / ticks : 0,
        leaks: board.waveClearState ? Object.values(board.waveClearState).reduce((sum, w) => sum + (w.leaked || 0), 0) : leaks,
        gold: board.gold, spawned: board.spawned, kills: board.kills,
        playerSpawned: player?.spawned ?? null, playerLives: player?.lives ?? null,
        peakAlive, firstLeakAt, firstBacklogAt, oracleClears,
        advancedAt: advancedAt && Math.round(advancedAt), actions, spending, refreshes, peakMs,
        decisions: aiInfo(board).decisions, cancelled: aiInfo(board).cancelled,
        peakPlanSeconds: aiInfo(board).peakPlanSeconds,
        plansCompleted: aiInfo(board).plansCompleted, plansCancelled: aiInfo(board).plansCancelled,
        waveStarts, countdowns, spawns,
        fusionOptions: fusionDiagnostics(board),
        pieces: board.pieces.map(p => ({ type: p.type, level: p.level, stage: p.stage, color: p.color })) });
    }
    return results;
  } finally {
    Math.random = originalRandom;
    console.log = originalLog;
    game.phase = originalPhase;
    Object.assign(wave.sharedWaves, originalWaves);
  }
}

/** 压力夹具本身的回归，不把 oracle 当成合法玩家强度或胜率。 */
export async function runPressureRegression() {
  await waitForBenchmarkReady();
  if (game.phase !== 'start') throw Error('Start page required');
  const original = { cur: game.cur, phase: game.phase, random: Math.random, log: console.log,
    waves: JSON.stringify(wave.sharedWaves) };
  const checks = [];
  const check = (name, ok) => {
    checks.push({ name, ok: !!ok });
    if (!ok) throw Error(name);
  };
  for (const delay of [2, 0.05]) {
    const [run] = await benchmarkAI(['1'], [11], 70, { playerClearDelay: delay });
    check(`${delay}秒脚本双方出怪一致`, run.playerSpawned === run.spawned && run.spawned > 0);
    check(`${delay}秒经济诊断刷新次数及花费一致`, run.refreshes.length === (run.actions.refresh || 0) &&
      run.refreshes.reduce((sum, item) => sum + item.spent, 0) === (run.spending.refresh || 0));
    check(`${delay}秒脚本只清玩家怪且保留生命`, run.oracleClears > 0 &&
      run.oracleClears <= run.playerSpawned && run.playerLives === 3);
    check(`${delay}秒脚本波内间隔不加速`, run.spawns.every((event, i, events) =>
      !i || event.wave !== events[i - 1].wave ||
      event.at - events[i - 1].at >= WAVES.spawnInterval - 1e-7));
    check(`${delay}秒脚本先出完才倒计时`, run.countdowns.every(countdown => {
      const generated = run.spawns.filter(event => event.wave === countdown.wave);
      const count = WAVES.firstWaveCount + (countdown.wave - 1) * WAVES.countGrowPerWave;
      return generated.length === count && countdown.at > generated[count - 1].at;
    }));
    check(`${delay}秒脚本保留正常波间时间`, run.waveStarts.every(start => {
      const countdown = run.countdowns.find(event => event.wave === start.wave - 1);
      return countdown && start.at - countdown.at >= WAVES.waveInterval - 0.05 - 1e-7;
    }));
    check(`${delay}秒脚本新波下一帧才生成`, run.waveStarts.every(start => {
      const first = run.spawns.find(event => event.wave === start.wave);
      return !first || first.at > start.at;
    }));
    check(`${delay}秒测试恢复共享状态及上下文`, game.cur === original.cur &&
      game.phase === original.phase && JSON.stringify(wave.sharedWaves) === original.waves);
    check(`${delay}秒测试恢复随机和日志函数`, Math.random === original.random && console.log === original.log);
  }
  return { passed: checks.length, checks };
}

/** 固定计算片数隔离机器速度：只验证开发对照可重复，不当作正式帧时或玩家胜率。 */
export async function runDeterministicRegression() {
  await waitForBenchmarkReady();
  if (game.phase !== 'start') throw Error('Start page required');
  const budget = AI_PLAY.evaluationBudgetMs, checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  try {
    AI_PLAY.evaluationBudgetMs = 0;
    const [first] = await benchmarkAI(['1'], [11], 90, { playerClearDelay: 0.05, evaluationSlices: 32 });
    AI_PLAY.evaluationBudgetMs = 11;
    const [second] = await benchmarkAI(['1'], [11], 90, { playerClearDelay: 0.05, evaluationSlices: 32 });
    const stable = ({ peakMs, ...rest }) => JSON.stringify(rest);
    check('固定计算片数不受墙钟预算变化影响', stable(first) === stable(second));
    check('可重复对照实际包含出怪和经济动作', first.spawned > 0 && first.actions.buy > 0 && first.spending.buy > 0);
    check('可重复对照保留双方生成一致', first.spawned === first.playerSpawned && second.spawned === second.playerSpawned);
    AI_PLAY.evaluationBudgetMs = 0;
    setupAI({ tier: 7 }, { seed: 11 });
    const board = createBoard('opp', await loadMap(1));
    board.totalRefreshCount = 1;
    board.shopSlots[0] = { source: 'native', type: 'piece', color: 'red' };
    const phase = game.phase;
    try {
      game.phase = 'playing';
      withBoard(board, () => aiTick(2, 3, 7));
      check('普通开局清除固定片数测试选项', aiInfo(board).decisions === 0 && !aiInfo(board).lastAction);
    } finally {
      game.phase = phase;
    }
    return { passed: checks.length, checks };
  } finally {
    AI_PLAY.evaluationBudgetMs = budget;
    setupAI({ tier: 7 });
  }
}
