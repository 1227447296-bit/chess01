/** 象20级仅无视兵卒、马70级受阻加攻及预览回归。 */
import game, { createBoard, withBoard } from './gameData.js';
import { formationCells, formationBonuses, blockedMaRoadCells } from './formation.js';
import { pieceDamage, canXiangAttack, canMaAttack, hasUnlock } from './attackRule.js';
import { computeAttackPreview } from './rangePreview.js';
import { updateCombat } from './wave.js';
import { cloneBoard } from './aiSimulation.js';
import { render, renderState } from './render.js';
import { PIECE_STATS } from './config.js';

export function runFormationFixtures() {
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(`阵位技能: ${name}`); };
  const near = (a, b) => Math.abs(a - b) < 1e-7;
  const saved = { cur: game.cur, phase: game.phase, drag: game.drag, render: { ...renderState } };
  const p = (id, type, c, r, level = 0, color = 'red') => ({ id, kind: 'piece', type, c, r, color,
    level, stage: 0, exp: 0, flags: {}, cdLeft: 0, bonds: [] });
  const make = side => createBoard(side || 'me', {
    cols: 7, rows: 7,
    ground: Array.from({ length: 7 }, () => Array(7).fill(1)),
    grass: Array.from({ length: 7 }, () => Array(7).fill(0)),
    road: Array.from({ length: 7 }, () => Array(7).fill(0)),
    path: [], enemySpawn: { c: 0, r: 0 }, kingPoint: { c: 6, r: 6 },
  });
  try {
    game.phase = 'playing';
    const b = make(), horse = p('horse', 'ma', 3, 3), blocker = p('blocker', 'bing', 3, 2);
    b.pieces = [horse, blocker]; b.map.road[1][2] = b.map.road[1][4] = 1;
    withBoard(b, () => {
      for (const lv of [0, 69]) {
        horse.level = lv;
        check(`${lv}级马有阻挡但不加攻`, formationBonuses(horse).blocked === 2 && formationBonuses(horse).atkRate === 0);
        check(`${lv}级未解锁受阻奋勇`, !hasUnlock(horse, 'maBlockedAttack'));
      }
      horse.level = 70;
      check('70级准确解锁', hasUnlock(horse, 'maBlockedAttack') && formationBonuses(horse).atkRate === 0.2);
      check('70级伤害计入20%加成', near(pieceDamage(horse), PIECE_STATS.ma.atk * 2.4 * 1.2));
      check('70级灰格计数与受阻格一致', computeAttackPreview('ma', 'red', 3, 3, {}, 70).blocked.length === 2);
      b.map.road[2][1] = b.map.road[4][1] = 1; b.pieces.push(p('left', 'xiang', 2, 3));
      check('四格加40%不受旧上限限制', formationBonuses(horse).blocked === 4 && formationBonuses(horse).atkRate === 0.4);
      for (const [c, r] of [[4, 1], [4, 5], [2, 5], [5, 2], [5, 4]]) b.map.road[r][c] = 1;
      b.pieces.push(p('right', 'pao', 4, 3), p('down', 'shi', 3, 4));
      check('八个道路日字格均受阻加80%', blockedMaRoadCells(horse).length === 8 && formationBonuses(horse).atkRate === 0.8);
      horse.level = 80;
      check('80级无视阻挡但加80%保留', canMaAttack(horse, { c: 2, r: 1 }) && formationBonuses(horse).atkRate === 0.8);
      check('80级预览全红但不取消加攻', computeAttackPreview('ma', 'red', 3, 3, {}, 80).blocked.length === 0 && computeAttackPreview('ma', 'red', 3, 3, {}, 80).hits.length === 8);
      horse.level = 70; horse.flags.noHorseLeg = true;
      check('其他免马腿效果也保留70级技能', canMaAttack(horse, { c: 2, r: 1 }) && formationBonuses(horse).atkRate === 0.8);
      horse.level = 69;
      check('69级即使免马腿仍不加攻', formationBonuses(horse).atkRate === 0);
      horse.level = 70; delete horse.flags.noHorseLeg;
      b.pieces = [horse]; b.king = { c: 3, r: 2 };
      check('帅占马腿按道路格计数', formationBonuses(horse).blocked === 2);
      b.king = null; check('移走阻挡即时取消加攻', formationBonuses(horse).atkRate === 0);
      b.pieces.push(blocker); b.map.road[1][4] = 0;
      check('只计道路受阻格不计另一非道路格', formationBonuses(horse).blocked === 1 && formationBonuses(horse).atkRate === 0.1);
      const copy = cloneBoard(b);
      check('AI快照伤害一致', near(pieceDamage({ ...horse }), pieceDamage(horse)));
      check('AI副本继承70级技能', withBoard(copy, () => formationBonuses(copy.pieces[0]).atkRate === 0.1));
      copy.pieces.pop();
      check('AI副本不污染真实状态', withBoard(copy, () => formationBonuses(copy.pieces[0]).atkRate === 0) && formationBonuses(horse).atkRate === 0.1);
      check('图鉴样本不继承场上加成', formationBonuses({ ...horse, id: 'codex' }).atkRate === 0);
      check('友军不获得光环', formationBonuses(blocker).atkRate === 0 && pieceDamage(blocker) === PIECE_STATS.bing.atk);
    });
    const opp = make('opp'); opp.pieces = [p('opp-horse', 'ma', 3, 3, 70)]; opp.map.road[1][2] = 1;
    check('不同棋盘阻挡不串盘', withBoard(opp, () => formationBonuses(opp.pieces[0]).blocked === 0));
    opp.pieces.push(p('opp-block', 'bing', 3, 2));
    check('对手共用70级规则', withBoard(opp, () => formationBonuses(opp.pieces[0]).atkRate === 0.1));
    const combat = make(), attacker = p('attacker', 'ma', 3, 3, 70), block = p('block', 'bing', 3, 2);
    block.cdLeft = 999; combat.pieces = [attacker, block];
    combat.map.road[1][2] = combat.map.road[1][4] = combat.map.road[2][5] = 1;
    combat.enemies = [{ id: 'target', c: 5, r: 2, hp: 1000, maxHp: 1000, stunLeft: 0, stunImmuneLeft: 0 }];
    combat._simulationContext = { random: () => 0.99 };
    withBoard(combat, () => { updateCombat(0); updateCombat(0.3); });
    check('70级真实践踏伤害加成', near(1000 - combat.enemies[0].hp, PIECE_STATS.ma.atk * 2.4 * 1.2));

    const elephant = make(), a = p('xiang', 'xiang', 3, 3), eye = p('eye', 'xiang', 2, 2);
    elephant.pieces = [a, eye]; elephant.map.road[1][1] = elephant.map.road[2][4] = 1;
    withBoard(elephant, () => {
      for (const level of [0, 20, 999]) {
        a.level = level;
        check(`${level}级无互占象眼被动`, !canXiangAttack(a, { c: 4, r: 2 }) && !canXiangAttack(eye, { c: 3, r: 3 }));
      }
      a.level = 19; eye.type = 'bing';
      check('19级仍被兵阻挡', !canXiangAttack(a, { c: 1, r: 1 }));
      a.level = 20;
      for (const color of ['red', 'black']) {
        eye.color = color;
        check(`20级无视${color}兵卒`, canXiangAttack(a, { c: 1, r: 1 }));
        check(`预览${color}兵卒不标灰`, computeAttackPreview('xiang', 'red', 3, 3, {}, 20).hits.some(c => c.c === 1 && c.r === 1));
      }
      for (const type of ['shi', 'xiang', 'ma', 'ju', 'pao', 'king']) {
        eye.type = type;
        check(`20级仍被${type}塞象眼`, !canXiangAttack(a, { c: 1, r: 1 }));
        check(`预览${type}阻挡标灰`, computeAttackPreview('xiang', 'red', 3, 3, {}, 20).blocked.some(c => c.c === 1 && c.r === 1));
      }
      eye.type = 'xiang'; a.flags.noXiangEye = true;
      check('独立无视象眼法术效果保持不变', canXiangAttack(a, { c: 1, r: 1 }));
      delete a.flags.noXiangEye;
      elephant.flags.xiangNoEye = true;
      check('独立全局无视象眼效果保持不变', canXiangAttack(a, { c: 1, r: 1 }));
      elephant.flags.xiangNoEye = false;
      elephant.pieces = [a]; check('无棋子阻挡正常攻击', canXiangAttack(a, { c: 1, r: 1 }));
      check('没有象眼新增红色攻击范围', !computeAttackPreview('xiang', 'red', 3, 3, {}, 20).hits.some(c => c.c === 4 && c.r === 2));
    });
    const visual = make(); visual.map.road[1][1] = 1;
    for (const sideways of [false, true]) for (const flip of [false, true]) {
      const fills = [], styles = {};
      const ctx = new Proxy({}, {
        get(_, key) {
          if (key === 'measureText') return () => ({ width: 30 });
          if (key === 'createLinearGradient' || key === 'createRadialGradient') return () => ({ addColorStop() {} });
          return (...args) => { if (key === 'fillRect') fills.push({ style: styles.fillStyle, args }); };
        },
        set(_, key, value) { styles[key] = value; return true; },
      });
      Object.assign(renderState, { ctx, tile: 60, sideways, flip, readonly: false });
      game.drag = { active: true, from: 'shop', card: { type: 'piece', kind: 'xiang', color: 'red' }, hoverCell: { c: 3, r: 3 }, hoverKind: 'plot' };
      withBoard(visual, () => render(0));
      check(`象红绿绘制方向${sideways}/${flip}`, fills.filter(f => f.style === 'rgba(65,225,105,0.30)').length === 4 && fills.filter(f => f.style === 'rgba(255,80,80,0.28)').length === 1);
      fills.length = 0; game.drag.card.kind = 'ma'; withBoard(visual, () => render(0));
      check(`马腿位置绿格方向${sideways}/${flip}`, fills.filter(f => f.style === 'rgba(65,225,105,0.30)').length === 4);
    }
    check('边界裁切位置提示', withBoard(make(), () => formationCells('xiang', 0, 0).length === 1 && formationCells('ma', 0, 0).length === 2));
    check('恢复当前棋盘引用', game.cur === saved.cur);
    return { ok: true, count: checks.length, checks };
  } finally { game.cur = saved.cur; game.phase = saved.phase; game.drag = saved.drag; Object.assign(renderState, saved.render); }
}
export default runFormationFixtures;
