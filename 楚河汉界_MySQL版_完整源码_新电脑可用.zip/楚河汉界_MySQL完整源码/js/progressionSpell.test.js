/** 本地无DOM夹具：在浏览器import后调用runProgressionSpellFixtures()；不启动服务器。 */
import game, { createBoard, withBoard } from './gameData.js';
import { MERGE, SHOP, SPELL_BY_ID } from './config.js';
import { canAbsorb, applyAbsorb, canEvolve, getEvolutionChoices, evolveSelected, evolutionOutcomes, doMerge } from './synthesis.js';
import { useSpell, evolvePiece, shopToPiece, shopMerge, boardToPiece } from './actions.js';
import { availableSpells, availablePieceSpecs, pieceDataOfCard, cardPrice } from './shop.js';

export function runProgressionSpellFixtures() {
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  let next = 0;
  const piece = (type = 'bing', stage = 0, extra = {}) => ({ id: `fixture-${++next}`, kind: 'piece', type, stage,
    level: 2, exp: 7, color: 'red', c: 1, r: 1, atkBonus: 0, flags: {}, bonds: [], ...extra });
  const fixture = () => {
    const b = createBoard('opp');
    b.gold = 100; b.wave = 12; b._simulationContext = { random: () => 0.25 };
    const layer = () => Array.from({ length: 4 }, () => Array(6).fill(true));
    b.map = { cols: 6, rows: 4, ground: layer(), grass: [], road: [], cleared: new Set(), path: [] };
    return b;
  };
  const card = id => ({ source: 'native', type: 'spell', id, price: SPELL_BY_ID[id].price });
  for (const type of ['bing', 'shi', 'xiang', 'ju', 'ma', 'pao']) {
    const b = fixture();
    withBoard(b, () => {
      const a = piece(type, 0, { level: 11 }), m = piece(type, 1, { level: 7, atkBonus: 4 });
      b.pieces.push(a, m);
      check(`${type}高阶材料按1+stage计`, applyAbsorb(a, m).ok && a.stage === 2);
      check(`${type}等级相加+3清经验保攻`, a.level === 21 && a.exp === 0 && a.atkBonus === 4);
      check(`${type}不自动进化`, a.type === type && doMerge(a) === a);
      const overflow = piece(type, 1), before = JSON.stringify(a);
      check(`${type}溢出拒绝且不变`, !applyAbsorb(a, overflow).ok && JSON.stringify(a) === before);
      check(`${type}达到3阶自动规则`, applyAbsorb(a, piece(type)).ok &&
        (['ju', 'ma', 'pao'].includes(type) ? a.type === type && a.stage === 3 :
          (type === 'bing' ? ['shi', 'xiang'] : ['ju', 'ma', 'pao']).includes(a.type) && a.stage === 0 && ['red', 'black'].includes(a.color)));
      check(`${type}融合后不可再超阶`, !canAbsorb(a, piece(type)).ok);
    });
  }
  withBoard(fixture(), () => {
    const a = piece('bing', 0, { level: 998 });
    applyAbsorb(a, piece('bing', 0, { level: 999 }));
    check('融合等级999封顶', a.level === 999);
    check('异色永不融合', !canAbsorb(a, piece('bing', 0, { color: 'black' })).ok);
    check('普通融合不提供主动进化', !canEvolve(a));
    check('主动进化候选仅供强制法术入口', getEvolutionChoices(a, { force: true }).length === 2);
    a.atkBonus = 12; a.specialEnhancements = { huixin: 1 }; a.critRateBonus = 0.1;
    const id = a.id;
    check('普通入口不能绕过自动进化', !evolveSelected(a, 'shi').ok && a.id === id && a.stage === 1);
    a.stage = 2;
    const outcomes = evolutionOutcomes(a, { force: true });
    check('强制法术候选不改变自动融合概率', outcomes.length === 1 && outcomes[0].choices.length === 2);
    const choices = getEvolutionChoices(a, { force: true });
    check('士象绑定两个不重复候选且不重抽', new Set(choices).size === 2 && getEvolutionChoices(a, { force: true }).join() === choices.join());
    check('非候选拒绝', !evolveSelected(a, MERGE.fromShiXiang.find(t => !choices.includes(t)), { force: true }).ok);
  });
  withBoard(fixture(), () => {
    const a = piece('bing', 2), m = piece('bing');
    game.pieces.push(a, m);
    check('主动进化入口被自动规则拒绝', !evolvePiece(a).ok && a.type === 'bing');
    game.shopSlots[0] = { source: 'native', type: 'piece', kind: 'ma', color: 'black', level: 0 };
    check('商店原生棋子始终为兵且统一价格', pieceDataOfCard(game.shopSlots[0]).type === 'bing' && cardPrice(game.shopSlots[0]) === 6);
    game.shopSlots[0] = { source: 'fromBoard', piece: piece('bing', 1) };
    game.shopSlots[1] = { source: 'fromBoard', piece: piece('bing') };
    check('商店融合不自动进化', shopMerge(1, 0).ok && game.shopSlots[0].piece.type === 'bing' && game.shopSlots[0].piece.stage === 2);
    const full = piece('bing', 3); game.pieces.push(full);
    const gold = game.gold;
    check('购买满阶目标不扣钱不吞卡', !shopToPiece(0, full).ok && game.gold === gold && !!game.shopSlots[0]);
    check('场上满阶融合拒绝不换位', !boardToPiece(m, full).ok && game.pieces.includes(m));
  });
  for (const id of ['huixin', 'pojun']) {
    withBoard(fixture(), () => {
      const a = piece(), m = piece(); game.pieces.push(a, m);
      game.shopSlots[0] = card(id);
      check(`${id}首次使用成功`, useSpell(0, a).ok);
      game.shopSlots[0] = card(id);
      const gold = game.gold;
      check(`${id}重复无消费`, !useSpell(0, a).ok && game.gold === gold && game.spellUsed[id] === 1 && !!game.shopSlots[0]);
      // 双方都有同一强化，合并只能留一份。
      const stat = SPELL_BY_ID[id].effect.stat, value = SPELL_BY_ID[id].effect.value;
      m.specialEnhancements = { [id]: 1 }; m[stat] = value;
      applyAbsorb(a, m);
      check(`${id}合并仅一份且同步战斗flags`, a[stat] === value && a.flags[stat] === value && a.specialEnhancements[id] === 1);
    });
  }
  withBoard(fixture(), () => {
    game.shopSlots[0] = card('yuanbing');
    let gold = game.gold;
    const pending = useSpell(0, null, { c: 2, r: 1 });
    check('援兵未选颜色零消费', !pending.ok && pending.requiresSelection === 'color' && game.gold === gold && !game.spellUsed.yuanbing && !!game.shopSlots[0]);
    check('援兵取消零消费', !useSpell(0, null, { c: 2, r: 1 }, { cancelled: true }).ok && game.gold === gold);
    check('援兵明确自选色', useSpell(0, null, { c: 2, r: 1 }, { color: 'black' }).ok && game.pieces[0].color === 'black' && game.pieces[0].level === 5 && game.gold === gold - 10);
    const a = piece('shi'); game.pieces.push(a); game.shopSlots[0] = card('heyi'); gold = game.gold;
    const pendingEvolve = useSpell(0, a);
    check('合一低阶也可选择但不提前消费', pendingEvolve.requiresSelection === 'evolutionType' && game.gold === gold && !game.spellUsed.heyi);
    check('合一选候选进化保色', useSpell(0, a, null, { evolutionType: pendingEvolve.choices[0] }).ok && a.stage === 0 && a.color === 'red');
    game.shopSlots[0] = card('huanbing'); gold = game.gold;
    check('缓兵无敌人不消费', !useSpell(0).ok && game.gold === gold);
    game.enemies.push({ hp: 10 }); game.cur.gameTime = 4;
    check('缓兵按游戏时钟写持续与公共冷却', useSpell(0).ok && game.enemies[0].huanbingSlowUntil === 7 && game.enemies[0].huanbingSlowMultiplier === 0.7 && game.cur.huanbingCooldownUntil === 14);
    game.shopSlots[0] = card('huanbing'); gold = game.gold;
    check('缓兵冷却无消费', !useSpell(0).ok && game.gold === gold && game.spellUsed.huanbing === 1);
    game.cur.gameTime = 14;
    check('缓兵实际10秒后可再用', useSpell(0).ok);
  });
  withBoard(fixture(), () => {
    for (const [wave, tier, count] of [[4, 1, 1], [5, 2, 3], [11, 2, 3], [12, 3, 6]]) {
      game.wave = wave;
      check(`第${wave}波池解锁`, Math.max(...availableSpells().map(s => s.tier)) === tier && availablePieceSpecs().length === 1);
    }
    check('集中配置法术数值', SHOP.spellTierUnlock[2] === 5 && SHOP.spellTierUnlock[3] === 12 && SPELL_BY_ID.wanxiang.effect.value === 3);
  });
  return { passed: checks.length, checks };
}
