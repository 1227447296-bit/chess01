/**
 * bondEffect.js —— 羁绊视觉特效渲染
 *
 * 规则：
 * 1. 触发时机：某组双人相邻羁绊由「无效变有效」时触发一次全套特效；
 *    持续相邻期间只播一次屏幕名称弹窗，断开后再连才重新触发。
 * 2. 屏幕中央浮动名称：放大进入，停留约 0.6s 后淡出；同一帧多组羁绊顺序播放。
 * 3. 棋子包围框：每组羁绊单独生成专属发光框，实时跟随两枚棋子位置。
 *    配色：双红=朱红 / 双黑=墨灰 / 异色=红黑渐变。
 * 4. 多羁绊叠加：一枚棋子参与多组羁绊时，每组独立渲染自己的框，支持交叉重叠；
 *    某组断开只删该组框；棋子被合成/放回商店时清除其全部羁绊框。
 */
import { BOND_EFFECT } from './config.js';
import game from './gameData.js';

/** 待播名称队列（只有我方羁绊会入队；顺序播放，防止同帧堆叠） */
const nameQueue = [];

/* ============================================================
 * 每帧同步：检测新增/断开的羁绊，管理弹窗与框
 * ============================================================ */

/**
 * 每帧调用（作用于当前棋盘）：对比 game.bonds 与已播记录 game.bondAnnounced。
 * 只有我方棋盘的新羁绊会弹出屏幕中央名称；对方只画包围框。
 * @returns {Array} 本帧需要渲染的羁绊框列表 [{ bond, a, b }]
 */
export function updateBondEffects() {
  if (game.cur._simulationContext) return [];
  const current = new Set(game.bonds.map(b => b.id));
  const announced = game.bondAnnounced;
  const isMe = game.cur.side === 'me';

  // 断开的：清 announcement 记录（以便重新连接时再播）
  for (const id of Array.from(announced)) {
    if (!current.has(id)) announced.delete(id);
  }

  // 新激活的：入队名称弹窗（仅我方）
  for (const bond of game.bonds) {
    if (!announced.has(bond.id)) {
      announced.add(bond.id);
      if (isMe) nameQueue.push({ name: bond.name, branch: bond.branch, t: 0, phase: 'in' });
    }
  }

  // 推进弹窗队列（同一时刻只播放一个；只在渲染我方时推进）
  if (isMe && nameQueue.length) {
    const cur = nameQueue[0];
    cur.t += 1 / 60;                     // 近似帧时间；如需精确可改为传 dt
    const total = BOND_EFFECT.namePopupMs / 1000;
    if (cur.t > total) nameQueue.shift();
  }

  // 生成框列表
  const boxes = [];
  for (const bond of game.bonds) {
    const a = game.pieces.find(p => p.id === bond.aId);
    const b = game.pieces.find(p => p.id === bond.bId);
    if (!a || !b) continue;
    boxes.push({ bond, a, b });
  }
  return boxes;
}

/** 当前应显示的屏幕中央羁绊名称（无则 null） */
export function currentBondPopup() {
  if (!nameQueue.length) return null;
  const cur = nameQueue[0];
  const total = BOND_EFFECT.namePopupMs / 1000;          // 总时长（1.5s）
  const hold = (BOND_EFFECT.namePopupHoldMs ?? 1000) / 1000;   // 保持清晰时长（1s）
  const t = cur.t;
  // 前 0.15s 快速放大淡入 → 保持清晰到 hold → 之后慢慢减淡消失
  let scale, alpha;
  const fadeIn = 0.15;
  if (t < fadeIn) {
    const q = t / fadeIn;
    scale = 0.8 + q * 0.2;
    alpha = q;
  } else if (t < hold) {
    scale = 1.0;
    alpha = 1;
  } else {
    const q = Math.min(1, (t - hold) / Math.max(0.001, total - hold));
    scale = 1.0 + q * 0.08;
    alpha = 1 - q;              // 慢慢减淡
  }
  return { name: cur.name, branch: cur.branch, scale, alpha };
}

/* ============================================================
 * 包围框绘制
 * ============================================================ */

/**
 * 绘制一组羁绊的发光包围框（由 render.js 在 canvas 上调用）。
 * @param {CanvasRenderingContext2D} ctx
 * @param {(c:number)=>number} cx 格列 → 像素 x（由 render 提供，已含翻转）
 * @param {(r:number)=>number} cy 格行 → 像素 y
 * @param {number} tile 每格像素
 * @param {{bond:object,a:object,b:object}} box
 * @param {number} time 全局时间（秒），用于呼吸动画
 */
export function drawBondBox(ctx, cx, cy, tile, box, time) {
  const { bond, a, b } = box;
  const styles = colorStops(bond.branch);

  ctx.save();
  ctx.lineWidth = 3;
  ctx.shadowBlur = 10;

  // 两个格子各自画一圈（支持交叉、横竖重叠、嵌套同时显示）
  for (const p of [a, b]) {
    const x = cx(p.c) + 3;
    const y = cy(p.r) + 3;
    const w = tile - 6;
    const h = tile - 6;

    const grad = ctx.createLinearGradient(x, y, x + w, y + h);
    grad.addColorStop(0, styles[0]);
    grad.addColorStop(1, styles[1]);
    ctx.strokeStyle = grad;
    ctx.shadowColor = styles[2];
    // 呼吸微动
    const breathe = 1 + Math.sin(time * 3 + p.c + p.r) * 0.03;
    ctx.lineWidth = 3 * breathe;
    roundRect(ctx, x, y, w, h, 8);
    ctx.stroke();
  }
  ctx.restore();
}

/** 配色：双红=朱红 / 双黑=墨灰 / 异色=红黑渐变 */
function colorStops(branch) {
  if (branch === 'red') return [BOND_EFFECT.red.stroke, BOND_EFFECT.red.glow, BOND_EFFECT.red.stroke];
  if (branch === 'black') return [BOND_EFFECT.black.glow, BOND_EFFECT.black.stroke, BOND_EFFECT.black.stroke];
  return [BOND_EFFECT.mix.strokeA, BOND_EFFECT.mix.strokeB, BOND_EFFECT.mix.strokeB];
}

/** 圆角矩形路径 */
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/* ============================================================
 * 清理
 * ============================================================ */

/** 棋子被合成 / 放回商店时，清除它参与的所有羁绊框记录 */
export function clearPieceBondEffects(piece) {
  if (!piece) return;
  for (const id of (piece.bonds || [])) game.bondAnnounced.delete(id);
}

/** 新开一局：清空待播弹窗 */
export function resetBondPopups() { nameQueue.length = 0; }

export default { updateBondEffects, currentBondPopup, drawBondBox, clearPieceBondEffects, resetBondPopups };