import game, { withBoard } from './gameData.js';
import * as act from './actions.js';
import { update } from './wave.js';
import { RANK_SAVE_KEY } from './config.js';
import { loadMap } from './mapLoader.js';
import { CODEX_KEY } from './codex.js';
import { createTutorialBoards, advanceTutorial, startTutorialDefense, nextTutorialEnemy,
  shouldOfferTutorial, TUTORIAL_KEY, TUTORIAL_CELLS, TUTORIAL_PANEL_RECT,
  TUTORIAL_ACTION_REASON, TUTORIAL_DEFENSE_STEP } from './tutorial.js';

export async function runTutorialTests() {
  let passed = 0;
  const assert = (v, msg) => { if (!v) throw new Error(msg); passed++; };
  const storage = values => ({ getItem: key => values[key] ?? null });
  assert(!shouldOfferTutorial(storage({ [TUTORIAL_KEY]: 'skipped' })), '跳过记忆');
  assert(!shouldOfferTutorial(storage({ [TUTORIAL_KEY]: 'completed' })), '完成记忆');
  assert(!shouldOfferTutorial(storage({ [RANK_SAVE_KEY]: '{"tier":0,"sub":1}' })), '有效存档');
  assert(!shouldOfferTutorial(storage({ [RANK_SAVE_KEY]: 'bad', [RANK_SAVE_KEY + '.backup']: '{"tier":1,"sub":2}' })), '有效备份');
  const prev = { boards: game.boards, cur: game.cur, phase: game.phase, floaters: game.floaters };
  const saveKeys = [RANK_SAVE_KEY, RANK_SAVE_KEY + '.backup', CODEX_KEY];
  const saves = saveKeys.map(key => localStorage.getItem(key));
  const originalMap = await loadMap(1);
  const originalCleared = [...originalMap.cleared];
  const boards = await createTutorialBoards();
  try {
    game.boards = boards; game.cur = boards.me; game.phase = 'playing'; game.floaters = [];
    const b = game.cur, opp = game.boards.opp;
    assert(b.map.file === originalMap.file && b.map.raw === originalMap.raw && b.map.path === originalMap.path, '真实board1解析数据，无自制地图');
    assert(b.map !== originalMap && b.map !== opp.map && b.map.cleared !== opp.map.cleared && b.map.cleared !== originalMap.cleared, '教学与缓存、对手地图开垦状态隔离');
    assert(b.king.arrived && b.king.c === originalMap.kingPoint.c && b.king.r === originalMap.kingPoint.r, '真实地图终点帅');
    const black = b.pieces[0];
    assert(black.type === 'bing' && black.color === 'black' && black.level === 10 && black.stage === 0, '预放10级黑卒');
    for (const cell of [TUTORIAL_CELLS.first, TUTORIAL_CELLS.black, TUTORIAL_CELLS.bond]) {
      assert(b.map.ground[cell.r][cell.c] && !b.map.grass[cell.r][cell.c] && !b.map.road[cell.r][cell.c], '指定初始落点为地图原生合法空地');
    }
    assert(b.map.grass[4][2] && !b.map.road[4][2], '指定铲地为真实草地');
    const panel = TUTORIAL_PANEL_RECT;
    for (let r = panel.r; r < panel.r + panel.rows; r++) for (let c = panel.c; c < panel.c + panel.cols; c++) {
      assert(!b.map.road[r][c] && !Object.values(TUTORIAL_CELLS).some(cell => cell.c === c && cell.r === r), '面板不占道路或教学操作格');
    }
    const blocked = fn => {
      const before = JSON.stringify({ gold: b.gold, pieces: b.pieces, cards: b.shopSlots, cleared: [...b.map.cleared], shovel: b.shovelUsed, spells: b.spellUsed });
      const res = fn();
      assert(!res.ok && res.reason === TUTORIAL_ACTION_REASON, '错操作统一提示');
      assert(before === JSON.stringify({ gold: b.gold, pieces: b.pieces, cards: b.shopSlots, cleared: [...b.map.cleared], shovel: b.shovelUsed, spells: b.spellUsed }), '错操作不改变棋盘经济和卡牌');
    };
    assert(b.gold === 36, '额外羁绊红兵预算');
    blocked(() => act.moveTo(black, 2, 5));
    assert(act.refresh().ok && b.gold === 36, '首次真实免费刷新');
    blocked(() => act.refresh());
    assert(advanceTutorial(b) && b.tutorial.step === 0 && b.shopSlots[0].kind === 'bing', '刷新后指定卡牌');
    blocked(() => act.refresh());
    blocked(() => act.buyAndPlace(0, 1, 2)); // 另一块原生合法空地
    blocked(() => act.buyAndPlace(0, 2, 1)); // 道路
    blocked(() => act.buyAndPlace(1, 1, 1));
    assert(act.buyAndPlace(0, 1, 1).ok && b.gold === 30, '真实落子扣6金币');
    assert(advanceTutorial(b) && b.tutorial.step === 1, '进入融合');
    const first = b.pieces.find(p => p !== black);
    blocked(() => act.sellToShop(first, 1));
    blocked(() => act.shopToPiece(0, black));
    assert(act.shopToPiece(0, first).ok, '真实融合');
    assert(first.level === 3 && first.stage === 1 && b.gold === 24, '等级相加+3，阶数+1');
    assert(advanceTutorial(b) && b.shopSlots[0].type === 'shovel', '进入铲子');
    blocked(() => act.useShovel(0, 3, 4)); // 另一块合法草地也不能铲
    blocked(() => act.useShovel(0, 0, 4));
    blocked(() => act.useShovel(1, 2, 4));
    assert(act.useShovel(0, 2, 4).ok && b.gold === 23 && b.shovelUsed === 1, '精确铲指定格');
    assert(advanceTutorial(b) && b.tutorial.step === 3, '进入补充防线');
    blocked(() => act.buyAndPlace(0, 1, 2));
    assert(act.buyAndPlace(0, 2, 4).ok && b.gold === 17, '只能在指定开垦地落子');
    assert(advanceTutorial(b) && b.tutorial.step === 4, '进入羁绊');
    blocked(() => act.buyAndPlace(0, 1, 2));
    blocked(() => act.shopToPiece(0, black));
    blocked(() => act.moveTo(black, 1, 2));
    assert(act.buyAndPlace(0, 2, 5).ok && b.gold === 11, '红兵置于黑卒右侧');
    assert(b.bonds.some(bond => bond.key === 'bing_bing' && bond.name === '二鬼拍门'), '真实羁绊激活');
    assert(advanceTutorial(b) && b.tutorial.step === 5 && b.shopSlots[0].id === 'yiyidailao', '固定法术');
    blocked(() => act.useSpell(0, black));
    assert(act.useSpell(0, first).ok && b.gold === 5 && b.spellUsed.yiyidailao === 1, '真实法术与库存');
    assert(advanceTutorial(b) && b.tutorial.step === TUTORIAL_DEFENSE_STEP, '进入胜负说明');
    assert(startTutorialDefense(b) && !startTutorialDefense(b), '只启动一次防守');
    blocked(() => act.moveTo(first, 1, 2));
    let furthestProgress = 0;
    for (let i = 0; i < 1600; i++) {
      const e = nextTutorialEnemy(b, 0.05);
      if (e) {
        assert(e.c === b.map.enemySpawn.c && e.r === b.map.enemySpawn.r, '使用真实出生点');
        assert(e.hp === (b.tutorial.spawned === 1 ? 96 : 72) && e.maxHp === e.hp, '仅教学敌人提高血量');
        b.enemies.push(e); b.spawned++;
      }
      withBoard(b, () => update(0.05));
      for (const enemy of b.enemies) furthestProgress = Math.max(furthestProgress, enemy.progress);
      if (b.tutorial.spawned === 3 && !b.enemies.length) break;
    }
    assert(furthestProgress >= (b.map.path.length - 1) / 2, '教学敌人可到道路中段，避免开局秒杀');
    assert(b.spawned === 3 && b.kills === 3 && b.lives === 3 && !b.enemies.length, '真实board1战斗清完三敌，无漏怪');
    assert(opp.spawned === 0 && opp.pieces.length === 0 && opp.gameTime === 0, '对手未运行');
    withBoard(opp, () => { assert(act.refresh().ok, '正常盘操作不受限制'); });
    assert(JSON.stringify([...originalMap.cleared]) === JSON.stringify(originalCleared) && opp.map.cleared.size === 0, '不污染原地图或对手');
    assert(saveKeys.every((key, i) => localStorage.getItem(key) === saves[i]), '段位主备份与图鉴存档不变');
    return { passed, failed: 0 };
  } finally { Object.assign(game, prev); }
}

/** 浏览器真实 UI 集成：在主页调用，完成后返回主页；不改已有存档。 */
export async function runTutorialIntegrationTests() {
  let passed = 0;
  const assert = (v, msg) => { if (!v) throw new Error(msg); passed++; };
  const wait = async fn => {
    const deadline = performance.now() + 6000;
    while (!fn()) {
      if (performance.now() > deadline) throw new Error('教程UI等待超时');
      await new Promise(resolve => requestAnimationFrame(resolve));
    }
  };
  assert(game.phase === 'start', '集成测试从主页开始');
  const keys = [RANK_SAVE_KEY, RANK_SAVE_KEY + '.backup', CODEX_KEY, TUTORIAL_KEY];
  const saves = keys.map(key => localStorage.getItem(key));
  const drag = async (source, c, r) => {
    const rect = source.getBoundingClientRect();
    const canvas = document.getElementById('canvas-me').getBoundingClientRect();
    const x = rect.left + rect.width / 2, y = rect.top + rect.height / 2;
    const tx = canvas.left + (c + .5) * canvas.width / 4;
    const ty = canvas.top + (r + .5) * canvas.height / 10;
    const event = (type, target, px, py) => target.dispatchEvent(new PointerEvent(type, {
      bubbles: true, pointerId: 88, pointerType: 'mouse', isPrimary: true,
      clientX: px, clientY: py, button: 0, buttons: type === 'pointerup' ? 0 : 1,
    }));
    event('pointerdown', source, x, y);
    event('pointermove', window, tx, ty);
    event('pointerup', window, tx, ty);
    await new Promise(resolve => requestAnimationFrame(resolve));
  };
  const shopCard = () => document.querySelector('#shop-grid .shop-card[data-slot="0"]');
  try {
    document.getElementById('btn-tutorial').click();
    await wait(() => !!game.boards.me.tutorial);
    const b = game.boards.me;
    await wait(() => document.getElementById('tutorial-panel').getBoundingClientRect().width > 0);
    const checkPanel = () => {
      const panel = document.getElementById('tutorial-panel');
      const p = panel.getBoundingClientRect(), canvas = document.getElementById('canvas-me').getBoundingClientRect();
      assert(p.left >= canvas.left - 1 && p.top >= canvas.top - 1 && p.right <= canvas.right + 1 && p.bottom <= canvas.bottom + 1, '提示完全在真实棋盘内');
      assert(panel.scrollHeight <= panel.clientHeight + 1, '提示全文与按钮无需滚动');
    };
    checkPanel();
    document.getElementById('btn-refresh').click();
    await wait(() => b.tutorial.step === 0);
    const snapshot = () => JSON.stringify({ gold: b.gold, cleared: [...b.map.cleared], pieces: b.pieces.map(p => [p.id, p.c, p.r, p.level]) });
    const wrong = async (c, r) => {
      const before = snapshot();
      await drag(shopCard(), c, r);
      assert(snapshot() === before, 'UI错落点不改变状态');
      assert([...document.querySelectorAll('.flash-hint')].some(el => el.textContent === TUTORIAL_ACTION_REASON), 'UI错落点显示准确提示');
    };
    await wrong(2, 1); // 道路：以前 UI 静默无反应
    await wrong(-1, 1); // 地图外
    await wrong(1, 2); // 合法但非指定格
    await drag(shopCard(), 1, 1); await wait(() => b.tutorial.step === 1); checkPanel();
    await drag(shopCard(), 1, 1); await wait(() => b.tutorial.step === 2); checkPanel();
    await wrong(3, 4);
    await drag(shopCard(), 2, 4); await wait(() => b.tutorial.step === 3); checkPanel();
    await wrong(1, 2);
    await drag(shopCard(), 2, 4); await wait(() => b.tutorial.step === 4); checkPanel();
    await wrong(1, 2);
    await drag(shopCard(), 2, 5); await wait(() => b.tutorial.step === 5); checkPanel();
    assert(b.bonds.some(bond => bond.key === 'bing_bing'), 'UI落子触发真实羁绊');
    await drag(shopCard(), 1, 1); await wait(() => b.tutorial.step === TUTORIAL_DEFENSE_STEP); checkPanel();
    assert(!document.getElementById('tutorial-next').classList.contains('hidden'), '防守按钮显示于棋盘内');
    document.getElementById('tutorial-next').click();
    assert(b.tutorial.defending, 'UI启动真实防守');
    assert(keys.slice(0, 3).every((key, i) => localStorage.getItem(key) === saves[i]), 'UI教学不改原有段位和图鉴');
    return { passed, failed: 0 };
  } finally {
    if (game.boards.me.tutorial) {
      document.getElementById('btn-pause').click();
      document.getElementById('btn-surrender').click();
    }
    keys.forEach((key, i) => { if (saves[i] == null) localStorage.removeItem(key); else localStorage.setItem(key, saves[i]); });
  }
}
