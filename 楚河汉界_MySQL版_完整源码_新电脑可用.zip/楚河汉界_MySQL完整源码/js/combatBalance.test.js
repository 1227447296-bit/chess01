/** 无DOM定向战斗回归；显式调用 runCombatBalanceFixtures()，不启动服务器。 */
import game, { createBoard, withBoard } from './gameData.js';
import { LEVEL, ENEMY, WAVES, experienceRequired, enemyStatsForWave, spawnIntervalForWave } from './config.js';
import { pieceDamage, levelCdMult, criticalStats, canPaoAttack } from './attackRule.js';
import { rescanBonds } from './bond.js';
import { update, updateCombat, registerWaveEnemy, sharedWaves, updateSharedWaves } from './wave.js';
import { cloneBoard, simulateCombat } from './aiSimulation.js';
import { buildSpawnPlan } from './aiSpawnPlan.js';
import { enemySpecForSpawn } from './boss.js';

export function runCombatBalanceFixtures() {
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const near = (a, b) => Math.abs(a - b) < 1e-7;
  const p = (id, type, c, r, extra = {}) => ({ id, kind: 'piece', type, c, r, color: 'red', level: 0,
    exp: 0, stage: 0, atkBonus: 0, flags: {}, cdLeft: 999, bonds: [], activeBonds: [], ...extra });
  const e = (id, c, r, extra = {}) => ({ id, kind: 'enemy', c, r, fx: c, fy: r, hp: 10000,
    maxHp: 10000, speed: 0, progress: 0, done: false, dying: false, deathT: 0,
    stunLeft: 0, stunImmuneLeft: 0, ...extra });
  const board = () => {
    const b = createBoard('me');
    b.map = { cols: 10, rows: 10, ground: [], grass: [], cleared: new Set(),
      road: Array.from({ length: 10 }, () => Array(10).fill(1)),
      path: Array.from({ length: 10 }, (_, c) => ({ c, r: 0 })),
      enemySpawn: { c: 0, r: 0 }, kingPoint: { c: 9, r: 0 } };
    b._simulationContext = { random: () => 1 }; return b;
  };
  const tick = (b, dt = 0) => withBoard(b, () => update(dt));
  const combat = (b, dt = 0) => withBoard(b, () => updateCombat(dt));
  const scan = b => withBoard(b, rescanBonds);
  const prev = game.cur, phase = game.phase, scheduler = { ...sharedWaves };
  try {
    game.phase = 'playing';
    check('经验需求与等级封顶', experienceRequired(0) === 20 && experienceRequired(10) === 70 && LEVEL.hardCap === 999);
    const base = board(); const unit = p('base', 'bing', 1, 1); base.pieces = [unit];
    withBoard(base, () => {
      const damage = pieceDamage(unit); unit.stage = 3;
      check('阶数不再加攻击', near(pieceDamage(unit), damage));
      unit.level = 60; check('等级冷却系数', near(levelCdMult(unit), 0.82));
      unit.level = 100; check('冷却最低80%', near(levelCdMult(unit), 0.8));
      unit.type = 'ju';
      for (const [stage, rate, crit] of [[0, 0.10, 1.2], [1, 0.20, 1.4], [2, 0.30, 1.6], [3, 0.50, 2.0]]) {
        unit.stage = stage;
        check(`${stage}阶暴击${rate}/${crit}`, near(criticalStats(unit).rate, rate) && near(criticalStats(unit).damage, crit));
      }
      unit.type = 'xiang'; unit.stage = 0; unit.level = 35;
      check('象等级不再加暴击', near(criticalStats(unit).rate, 0.10) && near(criticalStats(unit).damage, 1.2));
      unit.flags = { critRateBonus: 1, critDamageBonus: 1 };
      check('永久暴击加成封顶', criticalStats(unit).rate === 0.5 && criticalStats(unit).damage === 2);
      unit.type = 'bing'; unit.critRateBonus = 0.10; unit.critDamageBonus = 0.20;
      check('法术顶层暴击字段兼容且不双算flags', near(criticalStats(unit).rate, 0.20) && near(criticalStats(unit).damage, 1.40));
    });
    const reward = board(); reward.pieces = [p('assist', 'bing', 4, 4, { cdLeft: 0 }),
      p('killer', 'bing', 4, 4, { cdLeft: 0, atkBonus: 100 }), p('idle', 'ma', 0, 9)];
    reward.enemies = [e('victim', 4, 3, { hp: 20, maxHp: 20 })];
    registerWaveEnemy(reward, reward.enemies[0], 1); combat(reward);
    check('击杀立即入账但闪烁未离场', reward.waveClearState[1].killed === 1 && reward.waveClearState[1].leaked === 0 && reward.waveClearState[1].remaining === 1);
    check('全场8击杀者2助攻1', reward.pieces.map(x => x.exp).join(',') === '9,10,8');
    combat(reward); check('击杀去重', reward.kills === 1 && reward.pieces[1].exp === 10);
    check('实际伤害贡献记录', reward.enemies[0].damageContributors.assist === 12 && reward.enemies[0].damageContributors.killer === 8);
    const clear = board(); clear.pieces = [p('red', 'ma', 8, 8), p('black', 'ma', 9, 9, { color: 'black' })];
    for (let i = 0; i < WAVES.firstWaveCount; i++) {
      const enemy = e(`clear-${i}`, 0, 0, { done: true });
      registerWaveEnemy(clear, enemy, 1); registerWaveEnemy(clear, enemy, 1); clear.enemies.push(enemy);
    }
    check('出生登记去重', clear.waveClearState[1].spawned === WAVES.firstWaveCount);
    tick(clear); check('清波全色22经验不直接加级', clear.pieces.every(x => x.level === 1 && x.exp === 2));
    tick(clear); check('清波账本去重', clear.pieces.every(x => x.level === 1 && x.exp === 2) && clear.waveClearState[1].settled);
    check('漏怪账本原因去重', clear.waveClearState[1].leaked === WAVES.firstWaveCount && clear.waveClearState[1].killed === 0);
    const killedCopy = cloneBoard(reward); killedCopy.pieces.forEach(x => { x.cdLeft = 999; });
    tick(killedCopy, 0.2); tick(killedCopy, 0.2);
    check('死亡移除不重复计击杀', killedCopy.waveClearState[1].killed === 1 && killedCopy.waveClearState[1].remaining === 0 && killedCopy.waveClearState[1].leaked === 0);
    const team = board(); team.pieces = [p('b', 'bing', 1, 1, { level: 10 }), p('s', 'shi', 2, 1, { level: 15 })]; scan(team);
    check('士兵突击已删除', team.bonds.length === 0 && team.pieces.every(x => !x.bondMods.atkRate));
    const artillery = board(); const cannon = p('cannon', 'pao', 0, 4, { level: 50, cdLeft: 0 }); artillery.pieces = [cannon];
    artillery.enemies = [e('main', 3, 4), e('corner', 4, 5), e('outside', 5, 5)];
    let cannonDamage; withBoard(artillery, () => {
      cannonDamage = pieceDamage(cannon);
      check('普通炮零架禁止攻击', !canPaoAttack(cannon, artillery.enemies[0]));
      cannon.flags.freeShot = 1;
      check('freeShot不能绕过零架限制', !canPaoAttack(cannon, artillery.enemies[0]));
    });
    combat(artillery);
    check('普通炮无架不伤敌不占冷却', artillery.enemies.every(x => x.hp === 10000) && cannon.cdLeft === 0 && cannon.flags.freeShot === 1);
    artillery.pieces.push(p('screen', 'bing', 1, 4));
    combat(artillery);
    check('普通炮有架完整伤害', near(10000 - artillery.enemies[0].hp, cannonDamage));
    check('炮真3x3其余60%', near(10000 - artillery.enemies[1].hp, cannonDamage * 0.6) && artillery.enemies[2].hp === 10000);
    const heavyBoard = board(); const heavyCannon = p('heavy', 'pao', 0, 4, { level: 50, cdLeft: 0 });
    heavyBoard.pieces = [heavyCannon, p('heavy-partner', 'pao', 0, 1, { color: 'black', level: 50 }), p('heavy-screen', 'bing', 1, 4)];
    heavyBoard.enemies = [e('heavy-main', 3, 4), e('heavy-corner', 4, 5)]; scan(heavyBoard);
    check('重炮杀已删除', !heavyCannon.activeBonds.includes('重炮杀') && heavyBoard.bonds.length === 0);
    combat(heavyBoard);
    check('异色同线双炮只按普通炮伤害', near(10000 - heavyBoard.enemies[0].hp, cannonDamage) && near(10000 - heavyBoard.enemies[1].hp, cannonDamage * 0.6));
    withBoard(artillery, () => {
      artillery.pieces.push(p('screen2', 'bing', 2, 4), p('screen3', 'bing', 3, 4));
      cannon.level = 79;
      check('80级前不能三架', !canPaoAttack(cannon, { c: 4, r: 4 }));
      cannon.level = 80;
      check('80级允许三架', canPaoAttack(cannon, { c: 4, r: 4 }));
      artillery.pieces.push(p('screen4', 'bing', 4, 4));
      check('80级仍不能四架', !canPaoAttack(cannon, { c: 5, r: 4 }));
    });
    const slowSource = board(); slowSource.gameTime = 4;
    slowSource.enemies = [e('spell-slow', 2, 0, { hp: 30, maxHp: 30, speed: 1, progress: 1.5 })];
    const ordinary = simulateCombat(slowSource, { horizon: 8 });
    slowSource.enemies[0].huanbingSlowUntil = 7; slowSource.enemies[0].huanbingSlowMultiplier = 0.7;
    const slowed = simulateCombat(slowSource, { horizon: 8 });
    check('缓兵绝对时钟减速能阻止本窗口漏怪', ordinary.leaks === 1 && slowed.leaks === 0);
    check('缓兵模拟推进私有时钟且不污染源', near(slowed.board.gameTime, 12) && slowSource.gameTime === 4 && near(slowSource.enemies[0].progress, 1.5));
    const infantry = board(); const soldier = p('soldier', 'bing', 4, 4, { level: 15, cdLeft: 0 });
    infantry.pieces = [soldier]; infantry.enemies = [e('focus', 4, 3)];
    const soldierDamage = withBoard(infantry, () => pieceDamage(soldier));
    for (let i = 0; i < 6; i++) { soldier.cdLeft = 0; combat(infantry); }
    check('兵连续攻击不再额外加伤', near(10000 - infantry.enemies[0].hp, soldierDamage * 6));
    check('兵攻速最多四层', soldier.bingSpeedStacks === 4);
    infantry.enemies = [e('replacement', 4, 3)]; soldier.cdLeft = 0; combat(infantry);
    check('兵换目标保留攻速层数', soldier.bingSpeedStacks === 4 && near(10000 - infantry.enemies[0].hp, soldierDamage));
    const advisor = board(); const shi = p('shi', 'shi', 4, 4, { level: 19, cdLeft: 0 });
    advisor.pieces = [shi]; advisor.enemies = [e('shi-main', 5, 3), e('shi-second', 5, 3), e('shi-third', 5, 3)];
    const shiDamage = withBoard(advisor, () => pieceDamage(shi)); combat(advisor);
    check('士19级只攻击一人', near(10000 - advisor.enemies[0].hp, shiDamage) && advisor.enemies[1].hp === 10000 && advisor.enemies[2].hp === 10000);
    shi.level = 20; shi.cdLeft = 0;
    advisor.enemies = [e('shi-a', 5, 3), e('shi-b', 3, 3), e('shi-c', 5, 5), e('shi-d', 3, 5)];
    const multiDamage = withBoard(advisor, () => pieceDamage(shi)); combat(advisor);
    check('士20级同时攻击两人全额伤害', advisor.enemies.filter(x => near(10000 - x.hp, multiDamage)).length === 2 && advisor.enemies.filter(x => x.hp === 10000).length === 2);
    const elephant = board(); const xiang = p('xiang', 'xiang', 4, 4, { level: 35, cdLeft: 0 });
    elephant.pieces = [xiang]; elephant.enemies = [e('low', 2, 2, { hp: 100 }), e('high', 6, 6)];
    const xiangDamage = withBoard(elephant, () => pieceDamage(xiang)); combat(elephant);
    check('象不再按高血优先且无高血增伤', [100 - elephant.enemies[0].hp, 10000 - elephant.enemies[1].hp].some(x => near(x, xiangDamage)));
    const guards = board(); guards.pieces = [p('s1', 'shi', 0, 0, { level: 15 }), p('x1', 'xiang', 1, 0, { level: 15 }),
      p('s2', 'shi', 0, 3, { level: 15 }), p('x2', 'xiang', 1, 3, { level: 15 }), p('remote', 'bing', 8, 8), p('black', 'bing', 9, 9, { color: 'black' })]; scan(guards);
    check('士象全限定一组、己方全场+10%', guards.bonds.filter(b => b.key === 'shi_xiang').length === 1
      && guards.pieces[4].bondMods.teamAtkRate === 0.10 && guards.pieces[5].bondMods.teamAtkRate === 0.10);
    guards.pieces.splice(1, 3); scan(guards);
    check('士象全断开清零', guards.pieces.every(x => x.bondMods.teamAtkRate === 0));
    const horse = board(); horse.pieces = [p('horse', 'ma', 1, 1, { level: 50, cdLeft: 0 }), p('partner', 'pao', 1, 2, { color: 'black', level: 50 })];
    horse.enemies = [e('center', 3, 2), e('cross', 4, 2), e('diagonal', 4, 3)]; scan(horse); combat(horse);
    combat(horse, 0.3);
    check('马炮合势已删除不标记', horse.bonds.length === 0 && !horse.enemies[0].maPaoMarkLeft);
    check('马50眩晕1秒', horse.enemies[0].stunLeft === 1);
    const car = board(); const ju = p('ju', 'ju', 0, 0, { level: 70, cdLeft: 0 }); car.pieces = [ju]; car.enemies = [e('car-target', 1, 0)];
    let rolls = 0; car._simulationContext.random = () => { rolls++; return 0; }; combat(car);
    const damage = withBoard(car, () => pieceDamage(ju));
    for (let i = 0; i < 1000 && ju.charge; i++) { combat(car, 1 / 120); combat(car, 0); }
    check('车动作只掷一次暴击', rolls === 1);
    check('车70返程50%且无秒杀', near(car.enemies[0].hp, 10000 - damage * 1.2 * 1.5));
    for (const n of [1, 10, 11, 20, 21, 24, 25, 50]) {
      const stats = enemyStatsForWave(n);
      check(`共享公式第${n}波`, near(stats.hp, (30 + 9 * (n - 1)) * 1.10 ** Math.max(0, n - 10) * 1.12 ** Math.max(0, n - 24)) && near(stats.speed, Math.min(1.25, 0.65 + 0.02 * (n - 1))));
      const state = { wave: n, waveToSpawn: n + 1, timer: 0, spawnedInWave: 0, countInWave: 2, betweenWaves: false, countdown: false };
      const plan = buildSpawnPlan(state, { WAVES, ENEMY, horizon: 0.1 });
      const firstSpawn = enemySpecForSpawn(n, 0);
      check(`计划与出生规格一致${n}`, near(plan.events[0].hp, firstSpawn.hp) && plan.events[0].speed === firstSpawn.speed);
      const real = board(); Object.assign(sharedWaves, state); updateSharedWaves(0, [real]);
      check(`正式与出生规格一致${n}`, near(real.enemies[0].hp, firstSpawn.hp) && real.enemies[0].speed === firstSpawn.speed && sharedWaves.timer === spawnIntervalForWave(n));
    }
    const source = cloneBoard(reward); source.pieces[0].attackRoll = { critical: true, damage: 42 }; source.enemies[0].damageContributors = { assist: 12 };
    const copy = cloneBoard(source); copy.pieces[0].attackRoll.damage = 0; copy.enemies[0].damageContributors.assist = 99;
    check('贡献与暴击状态深复制', source.pieces[0].attackRoll.damage === 42 && source.enemies[0].damageContributors.assist === 12);
    const before = JSON.stringify(source); simulateCombat(source, { horizon: 1 });
    check('推演不污染源战斗状态', JSON.stringify(source) === before);
    check('恢复棋盘上下文', game.cur === prev);
    return { passed: checks.length, checks };
  } finally { game.cur = prev; game.phase = phase; Object.assign(sharedWaves, scheduler); }
}
