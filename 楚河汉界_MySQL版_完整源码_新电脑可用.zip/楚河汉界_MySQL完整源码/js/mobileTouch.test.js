import { setupTouchSafeguards, setupDetailDismissal } from './mobileTouch.js';

/** Browser fixture: import('./js/mobileTouch.test.js').then(m => m.runMobileTouchFixtures()). */
export function runMobileTouchFixtures() {
  const results = [];
  const check = (name, condition) => {
    results.push({ name, ok: !!condition });
    if (!condition) throw new Error(`Mobile touch regression: ${name}`);
  };
  const app = document.createElement('div');
  app.innerHTML = '<div class="backdrop"></div><div class="panel"><span>details</span><button class="detail-close">X</button></div><input><textarea></textarea><div contenteditable="true"><span>edit</span></div><canvas></canvas><div class="shop-card"></div>';
  document.body.appendChild(app);
  const panel = app.querySelector('.panel'), inside = panel.querySelector('span');
  const backdrop = app.querySelector('.backdrop'), button = panel.querySelector('button');
  const root = new EventTarget();
  let closed = 0;
  const stopGuards = setupTouchSafeguards(app, root);
  const stopDismiss = setupDetailDismissal(app, panel, () => { closed++; panel.classList.add('hidden'); }, root);
  const open = () => { panel.classList.remove('hidden'); closed = 0; };
  const pointer = (type, target, x = 10, y = 10, id = 1, extra = {}) => {
    // Isolated root avoids interfering with the live game's window listeners.
    const event = new PointerEvent(type, { pointerId: id, isPrimary: true, button: 0, clientX: x, clientY: y, cancelable: true, ...extra });
    Object.defineProperty(event, 'target', { value: target });
    root.dispatchEvent(event);
    check(`${type} preserves native default`, !event.defaultPrevented);
  };
  const tap = target => { pointer('pointerdown', target); pointer('pointerup', target); };
  try {
    for (const type of ['contextmenu', 'selectstart']) {
      const blocked = new Event(type, { bubbles: true, cancelable: true });
      inside.dispatchEvent(blocked);
      check(`${type} blocked on game text`, blocked.defaultPrevented);
      for (const target of [app.querySelector('input'), app.querySelector('textarea'), app.querySelector('[contenteditable] span')]) {
        const event = new Event(type, { bubbles: true, cancelable: true });
        target.dispatchEvent(event);
        check(`${type} allowed in editable`, !event.defaultPrevented);
      }
    }
    const touch = (type, target, time, x = 10, y = 10, count = 1) => {
      const event = new Event(type, { cancelable: true });
      const point = { identifier: 1, clientX: x, clientY: y };
      Object.defineProperties(event, {
        target: { value: target }, timeStamp: { value: time },
        touches: { value: type === 'touchend' || type === 'touchcancel' ? [] : Array(count).fill(point) },
        changedTouches: { value: [point] },
      });
      root.dispatchEvent(event);
      return event.defaultPrevented;
    };
    const touchTap = (target, time, x = 10) => {
      touch('touchstart', target, time, x);
      return touch('touchend', target, time + 40, x);
    };
    check('single touch tap retains normal default', !touchTap(inside, 1000));
    check('Safari double tap second default prevented', touchTap(inside, 1150));
    check('third rapid tap also cannot zoom', touchTap(inside, 1300));
    check('separate tap retains normal default', !touchTap(inside, 2000));
    check('distant rapid tap not treated as zoom', !touchTap(backdrop, 2100, 100));
    for (const target of [app.querySelector('input'), app.querySelector('textarea'), app.querySelector('[contenteditable] span')]) {
      check('editable repeated tap remains native', !touchTap(target, 2200) && !touchTap(target, 2300));
    }
    touch('touchstart', inside, 3000);
    check('detail vertical scrolling remains native', !touch('touchmove', inside, 3050, 10, 70));
    check('scroll end not canceled as double tap', !touch('touchend', inside, 3100, 10, 70));
    check('tap following scroll stays native', !touchTap(inside, 3150));
    touch('touchstart', inside, 4000);
    touch('touchcancel', inside, 4010);
    check('canceled gesture resets double tap state', !touchTap(inside, 4100));
    check('noneditable pinch start prevented', touch('touchstart', inside, 4200, 10, 10, 2));
    check('noneditable pinch movement prevented', touch('touchmove', inside, 4250, 10, 10, 2));
    check('editable pinch left native', !touch('touchstart', app.querySelector('input'), 4300, 10, 10, 2));
    for (const type of ['gesturestart', 'gesturechange']) {
      const event = new Event(type, { cancelable: true });
      Object.defineProperty(event, 'target', { value: inside });
      root.dispatchEvent(event);
      check(`Safari ${type} prevented on game UI`, event.defaultPrevented);
    }
    open(); tap(inside); check('inner tap stays open', closed === 0);
    pointer('pointerdown', inside); pointer('pointermove', inside, 10, 70); pointer('pointerup', inside, 10, 70);
    check('inner vertical scroll stays open', closed === 0);
    pointer('pointerdown', inside); pointer('pointerup', backdrop);
    check('inside origin ending outside stays open', closed === 0);
    pointer('pointerdown', backdrop); pointer('pointerup', inside);
    check('outside origin ending inside stays open', closed === 0);
    root.document = { elementFromPoint: () => inside };
    pointer('pointerdown', backdrop); pointer('pointerup', backdrop);
    check('implicit capture release hit-tests inside instead of stale target', closed === 0);
    delete root.document;
    pointer('pointerdown', backdrop); pointer('pointermove', backdrop, 10, 90); pointer('pointerup', backdrop);
    check('outside swipe returning to start stays open', closed === 0);
    pointer('pointerdown', backdrop); pointer('pointerup', backdrop, 10, 90);
    check('final release movement without move event stays open', closed === 0);
    pointer('pointerdown', backdrop); pointer('pointercancel', backdrop); pointer('pointerup', backdrop);
    check('cancel stays open', closed === 0);
    pointer('pointerdown', backdrop); pointer('pointerdown', backdrop, 10, 10, 2);
    pointer('pointerup', backdrop, 10, 10, 2); pointer('pointerup', backdrop);
    check('multitouch stays open', closed === 0);
    for (const target of [app.querySelector('input'), app.querySelector('canvas'), app.querySelector('.shop-card')]) tap(target);
    check('editable and gameplay surfaces do not dismiss', closed === 0);
    tap(backdrop); check('outside tap dismisses once', closed === 1);
    panel.classList.add('hidden'); pointer('pointerdown', backdrop); open(); pointer('pointerup', backdrop);
    check('opening mid gesture does not dismiss', closed === 0);
    pointer('pointerdown', button); pointer('pointermove', button, 10, 60); pointer('pointerup', button, 10, 60);
    button.dispatchEvent(new MouseEvent('click', { bubbles: true, detail: 1 }));
    check('scroll starting on X does not close', closed === 0);
    tap(button); button.dispatchEvent(new MouseEvent('click', { bubbles: true, detail: 1 }));
    check('X pointer click closes once', closed === 1);
    open(); button.click(); check('X keyboard/programmatic activation closes', closed === 1);
    const replacement = document.createElement('button'); replacement.className = 'detail-close'; panel.replaceChildren(replacement);
    open(); replacement.click(); check('delegation survives detail rerender', closed === 1);
    return { ok: true, count: results.length, results };
  } finally {
    stopDismiss(); stopGuards(); app.remove();
  }
}
