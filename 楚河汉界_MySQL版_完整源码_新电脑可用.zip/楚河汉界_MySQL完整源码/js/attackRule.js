/**
 * attackRule.js —— 棋子攻击判定规则
 * 所有攻击判定只在敌人进入符合条件格子时触发。
 * 每个判定函数独立封装：
 *   输入：当前棋子对象、目标敌人坐标（或目标对象）、场上全部棋子数据、地图配置
 *   返回：true / false —— 该棋子是否可以攻击该位置敌人
 *
 * 统一基础规则：攻击距离 = 规则里的目标格子；攻击目标为敌方（敌人 / 帅）。
 *
 * 羁绊/海克斯效果通过 game.flags 与棋子 bondEffect 读取，属于可扩展项。
 * 本模块只负责「能不能打」，具体伤害计算在 wave/render 的命中处理里。
 */
import { PIECE_STATS, LEVEL, LEVEL_UNLOCK, PAO_CARRIAGE, RANK, CRITICAL } from './config.js';
import game, { pieceAt } from './gameData.js';
import { isSidewaysMap, vectorToView } from './boardView.js';
import { pieceTacticalStats } from './tacticalEffects.js';
import { formationBonuses } from './formation.js';

const STATS_OF = (p) => PIECE_STATS[p.type];
const LEVEL_RATE = LEVEL.levelAtkRate;

/**
 * 判断棋子是否已解锁某等级机制（门槛统一以 config.LEVEL_UNLOCK 为准）。
 * @param {object} piece
 * @param {string} mech 机制名（见 config.LEVEL_UNLOCK）
 */
export function hasUnlock(piece, mech) {
  const table = LEVEL_UNLOCK[piece?.type];
  if (!table) return false;
  for (const [lv, name] of Object.entries(table)) {
    if (name === mech && (piece.level || 0) >= Number(lv)) return true;
  }
  return false;
}

/** 棋子是否激活了某个羁绊（按名称） */
function hasBond(piece, name) {
  return !!piece?.activeBonds && piece.activeBonds.includes(name);
}

/* ============================================================
 * 工具：直线中间格子的阻挡检测
 * ============================================================ */

/** 目标之间是否存在棋子阻挡（不含自身与目标本身） */
function hasBlockBetween(aC, aR, bC, bR) {
  const dc = Math.sign(bC - aC);
  const dr = Math.sign(bR - aR);
  let c = aC + dc;
  let r = aR + dr;
  // 直线移动直至抵达目标
  while (c !== bC || r !== bR) {
    if (pieceAt(c, r)) return true;
    c += dc;
    r += dr;
  }
  return false;
}

/** 统计自身与目标之间（不含两端）的棋子数量——用于炮架 */
function countBetween(aC, aR, bC, bR) {
  const dc = Math.sign(bC - aC);
  const dr = Math.sign(bR - aR);
  let count = 0;
  let c = aC + dc;
  let r = aR + dr;
  while (c !== bC || r !== bR) {
    if (pieceAt(c, r)) count++;
    c += dc;
    r += dr;
  }
  return count;
}

/** 共线（同行或同列） */
const sameLine = (aC, aR, bC, bR) => aC === bC || aR === bR;

/**
 * 炮架宽松判定（受「炮架易得」增益影响扩展一格）。
 * 宽松时：目标间棋子数 ∈ [carriageMin, carriageMin + slack]（默认恰 1 枚，宽松则允许 1~2 枚）。
 */
function carriageMatches(aC, aR, bC, bR) {
  const n = countBetween(aC, aR, bC, bR);
  const slack = game.flags.paoRelaxed ? 1 : 0;
  return n >= 1 && n <= 1 + slack;
}

/* ============================================================
 * 六种棋子攻击判定
 * 参数统一：(piece, target)  target 可传 {c, r}（敌人）或坐标
 * ============================================================ */

/**
 * 兵的逻辑攻击偏移：以我方显示方向的上、左、右为基准，不随敌人位置变化。
 * 对方沿用同一逻辑偏移，由棋盘上下翻转显示为下、左、右；普通地图保持原规则。
 * 详情图、预览、实战与 AI 共用此来源。
 */
const ORTHOGONAL = [[0, -1], [-1, 0], [1, 0], [0, 1]];
export function bingAttackOffsets(piece, map = game.map) {
  const sideways = isSidewaysMap(map);
  return ORTHOGONAL.filter(([dc, dr]) => vectorToView(dc, dr, sideways, false).y <= 0);
}

/** 兵身后（不能攻击的）一格；20级起该格己方棋子攻速+10%。 */
export function bingBackOffset(map = game.map) {
  const sideways = isSidewaysMap(map);
  return ORTHOGONAL.find(([dc, dr]) => vectorToView(dc, dr, sideways, false).y > 0);
}

/** 兵：相邻一格，无阻挡限制；方向由共享逻辑偏移决定。 */
export function canBingAttack(piece, target) {
  const dc = target.c - piece.c, dr = target.r - piece.r;
  return bingAttackOffsets(piece).some(([x, y]) => dc === x && dr === y);
}

/** 士：自身斜对角四格（斜向一步），等级技能不扩大攻击范围。 */
export function canShiAttack(piece, target) {
  return Math.abs(target.c - piece.c) === 1 && Math.abs(target.r - piece.r) === 1;
}

/** 是否有己方（同一棋盘）其他棋子提供该机制；多枚来源不叠加。 */
function supportedBy(piece, type, mech, inRange) {
  return game.pieces.some(source => source !== piece && (!piece.id || source.id !== piece.id) &&
    source.type === type && hasUnlock(source, mech) && inRange(source, piece));
}

/** 兵20级：站在兵身后一格的己方棋子攻速+10%。 */
export function bingBackSupported(piece) {
  const [dc, dr] = bingBackOffset();
  return supportedBy(piece, 'bing', 'bingBackSpeed', b => piece.c === b.c + dc && piece.r === b.r + dr);
}

/** 士30级：位于士攻击范围（斜邻四格空地）内的己方棋子攻击力+10%。 */
export function shiAuraSupported(piece) {
  return supportedBy(piece, 'shi', 'shiGroundAura', canShiAttack);
}

/** 象30级：位于象眼（斜邻四格）上的己方棋子控制时间+10%，实际作用于马的眩晕和炮的减速。 */
export function controlDurationMult(piece) {
  return supportedBy(piece, 'xiang', 'xiangEyeControl', canShiAttack) ? 1.1 : 1;
}

/** 与实战、面板、AI共享技能攻速除数。 */
export function pieceSkillSpeedMult(piece) {
  const stacks = hasUnlock(piece, 'bingFocus') && piece.bingSpeedLeft > 0
    ? 1 + Math.min(4, Math.max(0, piece.bingSpeedStacks || 0)) * 0.05 : 1;
  return stacks * (bingBackSupported(piece) ? 1.1 : 1);
}

/** 普通攻击可命中的目标总数；士20级最多2个，其他棋子仍走原有攻击流程。 */
export function normalAttackTargetLimit(piece) {
  return hasUnlock(piece, 'shiMultiTarget') ? 2 : 1;
}

/**
 * 象：斜向 2 格（象走田，共 4 格）。
 * 需判定「塞象眼」（中间那格有棋子则打不到）。
 * 20 级仅无视兵/卒塞象眼，其他棋子仍阻挡。
 */
export function canXiangAttack(piece, target) {
  const { c, r } = piece;
  const dc = Math.abs(target.c - c);
  const dr = Math.abs(target.r - r);

  if (!(dc === 2 && dr === 2)) return false;

  // 塞象眼判定：斜对角的中间格
  const eyeC = (c + target.c) / 2;   // 因为差 2，中间恰好整数
  const eyeR = (r + target.r) / 2;
  if (game.flags.xiangNoEye) return true;          // 象眼加固
  if (piece.flags?.noXiangEye) return true;         // 标记：无视塞象眼
  const blocker = pieceAt(eyeC, eyeR);
  return !blocker || (hasUnlock(piece, 'xiangNoEye') && blocker.type === 'bing');
}

/**
 * 马：日字（2+1 的 L 型），共 8 个可能点位；必须实现「绊马腿」。
 * 80 级解锁「maNoHorseLeg」：永久取消绊马腿。
 */
export function canMaAttack(piece, target) {
  const { c, r } = piece;
  const dc = target.c - c;
  const dr = target.r - r;
  const adc = Math.abs(dc), adr = Math.abs(dr);
  if (!((adc === 2 && adr === 1) || (adc === 1 && adr === 2))) return false;

  if (piece.flags?.noHorseLeg) return true;   // 锐目
  if (hasUnlock(piece, 'maNoHorseLeg')) return true;   // 80 级免马腿

  // 马腿点：与目标直线方向对齐的那格
  let legC, legR;
  if (adc === 2) {          // 横向走 2，马腿在水平起始方向同列
    legC = c + Math.sign(dc);
    legR = r;
  } else {                  // 纵向走 2，马腿在垂直起始方向同行
    legC = c;
    legR = r + Math.sign(dr);
  }
  return !pieceAt(legC, legR);
}

/**
 * 车：横向、纵向直线无限延伸；阻挡判定：自身和目标之间只要存在任意棋子，直线被挡住。
 */
export function canJuAttack(piece, target) {
  if ((piece.c === target.c && piece.r === target.r) || !sameLine(piece.c, piece.r, target.c, target.r)) return false;
  // 50 级「juColumn」整列穿透（攻击本行/列全部敌人）——此处仍按直线可攻击处理，
  // 具体的整列多段结算在 wave.fireJu 里做。
  return !hasBlockBetween(piece.c, piece.r, target.c, target.r);
}

/**
 * 炮：横向、纵向直线；普通需「恰好 1 枚炮架」。
 *   - 100 级「paoCarriage3」：炮架 1~3 枚
 *   - 重炮杀羁绊仍需炮架，不改变炮架数量限制。
 */
export function canPaoAttack(piece, target) {
  if ((piece.c === target.c && piece.r === target.r) || !sameLine(piece.c, piece.r, target.c, target.r)) return false;
  const n = countBetween(piece.c, piece.r, target.c, target.r);
  const carriageMin = PAO_CARRIAGE.min;
  const carriageMax = hasUnlock(piece, 'paoCarriage3') ? PAO_CARRIAGE.max : 1;
  // 兼容存档的 freeShot 不得绕过炮架规则。
  return n >= carriageMin && n <= carriageMax;
}

/* ============================================================
 * 统一入口：根据棋子种类分发
 * ============================================================ */

/** 判断某枚棋子是否能攻击目标坐标（target 给 {c,r}） */
export function canPieceAttack(piece, target) {
  if (!piece || !target) return false;
  const map = {
    bing: canBingAttack,
    shi: canShiAttack,
    xiang: canXiangAttack,
    ma: canMaAttack,
    ju: canJuAttack,
    pao: canPaoAttack,
  };
  const fn = map[piece.type];
  return fn ? fn(piece, target) : false;
}

/** 计算一枚棋子对目标的伤害（基础攻击 + 刻印/增益 + 羁绊固定值，再乘等级倍率）；阶数只影响暴击。 */
export function pieceDamage(piece) {
  const stats = STATS_OF(piece);
  if (!stats) return 0;
  const base = stats.atk
    + (piece.atkBonus || 0)                                  // 法术刻印
    + (game.flags.atkFlatByType?.[piece.type] || 0)          // 开局增益（按种类）
    + (game.flags.atkFlatAll || 0)                           // 开局增益（全体）
    + (piece.bondMods?.atkFlat || 0);                        // 羁绊固定加攻
  const levelMult = 1 + (piece.level || 0) * LEVEL_RATE;
  return base * levelMult * (1 + pieceTacticalStats(piece).rate)
    * (1 + (piece.bondMods?.teamAtkRate || 0)) * (1 + formationBonuses(piece).atkRate)
    * (shiAuraSupported(piece) ? 1.1 : 1);
}

/** 每个攻击动作只掷一次；车/马将结果存入动作状态，所有分段/溅射共享。 */
export function criticalStats(piece) {
  const stage = RANK.critByStage[Math.max(0, Math.min(RANK.max, piece.stage || 0))];
  // 法术新接口写顶层；兼容既有flags存档，二者代表同一刻印，不重复相加。
  const rate = CRITICAL.rate + stage.rate + (piece.critRateBonus || piece.flags?.critRateBonus || 0) + (game.flags.critRateBonus || 0);
  const damage = CRITICAL.damage + stage.damage + (piece.critDamageBonus || piece.flags?.critDamageBonus || 0) + (game.flags.critDamageBonus || 0);
  return { rate: pieceTacticalStats(piece).noCrit ? 0 : Math.max(0, Math.min(CRITICAL.maxRate, rate)), damage: Math.max(1, Math.min(CRITICAL.maxDamage, damage)) };
}
export function rollAttack(piece) {
  const stats = criticalStats(piece);
  const random = game.cur._simulationContext?.random ?? Math.random;
  const critical = random() < stats.rate;
  return { critical, multiplier: critical ? stats.damage : 1, damage: pieceDamage(piece) * (critical ? stats.damage : 1) };
}

/** 等级攻速：冷却倍率 = 1 - 等级 × levelCdRate，最低 cdMinRate */
export function levelCdMult(piece) {
  return Math.max(LEVEL.cdMinRate, 1 - (piece.level || 0) * LEVEL.levelCdRate);
}

// 延迟引用常量在文件顶部已声明
export default { canPieceAttack, bingAttackOffsets, canBingAttack, canShiAttack, canXiangAttack, canMaAttack, canJuAttack, canPaoAttack, pieceDamage, levelCdMult };