/**
 * assets.js —— 资源加载（图片 / 字体）
 * 所有路径来自 config.js 的 RES，禁止在其它模块硬编码资源路径。
 * 提供 Promise 化的加载，全部完成后才进入游戏，避免首帧闪烁。
 */
import { RES } from './config.js';

/** 已加载图片：{ 资源key: HTMLImageElement } */
export const IMG = {};

/** 字体是否就绪 */
export const fontReady = { guofeng: false };

/** 注入 @font-face（中文字体来自项目自带 ttf） */
export function injectFonts() {
  const css = Object.values(RES.fonts).map(f => `
    @font-face {
      font-family: '${f.family}';
      src: url('${f.url}') format('${f.format}');
      font-display: swap;
    }`).join('\n');
  const style = document.createElement('style');
  style.id = 'game-fonts';
  style.textContent = css;
  document.head.appendChild(style);
}

/** 加载单张图片 */
function loadImage(key, url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => { IMG[key] = img; resolve(img); };
    img.onerror = () => reject(new Error(`图片加载失败：${key} → ${url}`));
    img.src = url;
  });
}

/** 等待字体真正可用；不把超时当成加载成功，慢网交给加载页持续提示。 */
async function waitFont(family) {
  if (!document.fonts) return;
  const fonts = await document.fonts.load(`16px "${family}"`);
  if (!fonts.length) throw new Error('字体加载失败');
}

/** 加载全部图片与字体；图片完成后即可进入游戏，字体在后台继续加载。 */
export async function loadAll(onProgress = () => {}) {
  if (!document.getElementById('game-fonts')) injectFonts();
  const images = Object.entries(RES.images);
  const fonts = Object.entries(RES.fonts);
  let loaded = 0;
  onProgress({ loaded, total: images.length, label: '准备图片与字体' });
  const imageTasks = images.map(([key, url]) => loadImage(key, url).then(() => {
    onProgress({ loaded: ++loaded, total: images.length, label: `图片 ${key}` });
  }));
  const fontTasks = fonts.map(([key, font]) => waitFont(font.family).then(() => {
    fontReady[key] = true;
  }).catch(error => {
    console.warn(`[assets] 字体加载失败：${font.family}`, error);
  }));
  const results = await Promise.allSettled(imageTasks);
  const failed = results.filter(r => r.status === 'rejected');
  if (failed.length) throw new Error(`${failed.length} 项图片资源加载失败，请检查网络后重试`);
  // 不阻塞开始页；字体声明使用 font-display: swap，加载完成后会自动替换回国风字体。
  Promise.all(fontTasks).catch(() => {});
  console.log('[assets] 图片资源加载完成', Object.keys(IMG).length, '张；字体后台加载中');
}

/** 取图片元素（未加载成功返回 null） */
export const getImg = (key) => IMG[key] || null;

export default loadAll;
