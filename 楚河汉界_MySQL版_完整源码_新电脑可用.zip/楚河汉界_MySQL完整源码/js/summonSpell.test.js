/** 援兵法术：真实结算、无效落点零副作用、自选颜色与AI接线。 */
import game, { createBoard, withBoard, uid } from './gameData.js';
import { SPELL_BY_ID, SHOP } from './config.js';
import { useSpell } from './actions.js';
import { castSpell, spellStockLeft } from './spell.js';
import { randomCardType } from './shop.js';
import { actionBranches } from './aiEvaluation.js';
import { setupAI, aiTick, aiInfo } from './ai.js';
import { waitForBenchmarkReady } from './aiBenchmark.test.js';

export async function runSummonSpellFixtures() {
  await waitForBenchmarkReady();
  if (game.phase !== 'start') throw Error('Start page required');
  const original = { cur: game.cur, phase: game.phase, random: Math.random };
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const snapshot = b => JSON.stringify(b, (k, v) => v instanceof Set ? [...v] : v);
  const spec = SPELL_BY_ID.yuanbing;
  const fixture = () => {
    const b = createBoard('opp');
    const layer = f => Array.from({ length: 3 }, (_, r) => Array.from({ length: 5 }, (_, c) => f(c, r)));
    b.map = { cols: 5, rows: 3, ground: layer(() => true), grass: layer((c, r) => c === 3 && r === 1),
      road: layer((c, r) => r === 0), cleared: new Set(), path: Array.from({ length: 5 }, (_, c) => ({ c, r: 0 })),
      enemySpawn: { c: 0, r: 0 }, kingPoint: { c: 4, r: 0 } };
    b.totalRefreshCount = 1;
    b.shopSlots[0] = { source: 'native', type: 'spell', id: 'yuanbing', price: spec.price };
    return b;
  };
  try {
    game.phase = 'playing';
    check('援兵二阶10金币库存2张，第5波解锁', spec.tier === 2 && spec.kind === 'cell' && spec.price === 10 && spec.stock === 2 && SHOP.spellTierUnlock[2] === 5);
    for (const [roll, color] of [[0, 'red'], [0.49999, 'red'], [0.5, 'black'], [0.99999, 'black']]) {
      const b = fixture(); let calls = 0;
      Math.random = () => { calls++; return roll; };
      const result = withBoard(b, () => useSpell(0, null, { c: 1, r: 1 }, { color }));
      const p = b.pieces[0];
      check(`自选${color}在随机源${roll}仍确定召唤`, result.ok && b.pieces.length === 1 && p.type === 'bing' && p.color === color && p.level === 5 && p.c === 1 && p.r === 1);
      check(`自选${color}精确扣费库存且不抽随机`, calls === 0 && b.gold === 15 && !b.shopSlots[0] && b.spellUsed.yuanbing === 1);
      check(`随机${roll}标准初始属性`, p.exp === 0 && p.stage === 0 && p.atkBonus === 0 && p.cdLeft === 0 && p.mergeCount === 0);
    }
    for (const [name, mutate, cell, target] of [
      ['未指定格子', () => {}, null], ['道路', () => {}, { c: 1, r: 0 }],
      ['未铲草地', () => {}, { c: 3, r: 1 }], ['越界', () => {}, { c: -1, r: 1 }],
      ['非整数', () => {}, { c: 1.5, r: 1 }], ['缺钱', b => { b.gold = spec.price - 1; }, { c: 1, r: 1 }],
      ['已有棋子', b => b.pieces.push({ id: 'occupied', c: 1, r: 1 }), { c: 1, r: 1 }],
      ['已有帅', b => { b.king = { c: 1, r: 1 }; }, { c: 1, r: 1 }],
      ['指定棋子而非空格', () => {}, { c: 1, r: 1 }, { type: 'bing' }],
      ['库存耗尽', b => { b.spellUsed.yuanbing = 2; }, { c: 1, r: 1 }],
    ]) {
      const b = fixture(); mutate(b); const before = snapshot(b), id = Number(uid('summon').slice(6));
      Math.random = () => { throw Error('无效释放不应抽颜色'); };
      const result = withBoard(b, () => useSpell(0, target || null, cell, { color: 'black' }));
      check(`${name}无效且不扣钱不耗卡库存UID`, !result.ok && snapshot(b) === before && Number(uid('summon').slice(6)) === id + 1);
    }
    const dug = fixture(); dug.map.cleared.add('3,1'); Math.random = () => 0;
    check('已铲草地可以召唤', withBoard(dug, () => useSpell(0, null, { c: 3, r: 1 }, { color: 'black' })).ok);
    const direct = fixture(), directBefore = snapshot(direct);
    Math.random = () => { throw Error('直接施法无效不抽颜色'); };
    check('底层施法也拒绝棋子目标', !withBoard(direct, () => castSpell(direct.shopSlots[0], { type: 'bing' }, { c: 1, r: 1 }, { color: 'black' })).ok && snapshot(direct) === directBefore);
    const source = fixture(), before = snapshot(source), idBefore = Number(uid('summon').slice(6));
    const action = { kind: 'spell', slot: 0, spellId: spec.id, effect: spec.effect, cost: spec.price, c: 1, r: 1, color: 'black' };
    const branches = actionBranches(source, action);
    check('AI自选黑色确定性分支且不抽随机', branches.length === 1 && branches[0].probability === 1 && branches[0].board.pieces[0].color === 'black');
    check('AI预览等级落点费用库存一致', branches.every(({ board: b }) => b.pieces[0].level === 5 && b.pieces[0].c === 1 && b.pieces[0].r === 1 && b.gold === 15 && !b.shopSlots[0] && b.spellUsed.yuanbing === 1));
    check('AI预览不改源或正式UID', snapshot(source) === before && Number(uid('summon').slice(6)) === idBefore + 1);
    const pool = (wave, used) => {
      const b = fixture(); b.wave = wave; b.spellUsed.yuanbing = used;
      const ids = new Set();
      for (let i = 0; i < 100; i++) {
        let count = 0; Math.random = () => count++ === 0 ? 0.999999 : i / 100;
        ids.add(withBoard(b, randomCardType).id);
      }
      return ids;
    };
    check('第5波之前不出现', !pool(4, 0).has(spec.id));
    check('第5波进入二阶卡池', pool(5, 0).has(spec.id));
    check('使用满2次不再刷出', !pool(5, 2).has(spec.id));
    const simulated = fixture(); simulated._simulationContext = { random: () => 0.9 };
    Math.random = () => { throw Error('模拟不得抽正式随机'); };
    check('私有模拟自选色和私有UID', withBoard(simulated, () => useSpell(0, null, { c: 1, r: 1 }, { color: 'black' })).ok && simulated.pieces[0].color === 'black' && simulated.pieces[0].id.includes('sim-'));
    const aiBoard = fixture(); Math.random = () => 0;
    setupAI({ tier: 7 }, { seed: 17, evaluationSlices: 32 });
    withBoard(aiBoard, () => aiTick(2, 3, 7));
    for (let i = 0; i < 1000 && !aiInfo(aiBoard).lastAction; i++) withBoard(aiBoard, () => aiTick(0, 3, 7));
    check('AI经真实动作在合法空地使用援兵', aiInfo(aiBoard).lastAction?.kind === 'spell' && aiBoard.pieces.length === 1 && aiBoard.pieces[0].level === 5 && aiBoard.gold === 15);
    check('AI召唤仍只有一个动作和正常等待', aiInfo(aiBoard).decisions === 1 && aiBoard.aiTimer >= 0.85 && aiBoard.aiTimer <= 1.3);
    check('棋盘上下文正确恢复', game.cur === original.cur);
    return { passed: checks.length, checks };
  } finally {
    Math.random = original.random; game.cur = original.cur; game.phase = original.phase;
    setupAI({ tier: 7 });
  }
}
