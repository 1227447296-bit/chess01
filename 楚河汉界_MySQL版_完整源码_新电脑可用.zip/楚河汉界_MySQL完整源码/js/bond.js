/**
 * bond.js —— 六类羁绊联动（同色 / 异色，旧羁绊全部作废）
 *
 * 触发条件 = 位置 + 等级：
 *   - 横竖相邻（斜向不生效）；「重炮杀」「双车错」要求同一直线且中间无阻挡
 *   - 已知六组按最新门槛判定；扩展组兼容 requireLevel 数字 / 对象
 *   - colorRule 指定同色（same）或异色（mixed）
 *
 * 效果以「机制名」写在 game.bondMods（全局，供 wave / attackRule 读取），
 * 并把激活羁绊名写到两枚棋子 p.activeBonds，供详情面板展示。
 * 条件不满足（棋子移位 / 合成 / 放回商店）时立刻清除。
 */
import { BOND_CONFIG } from './config.js';
import game from './gameData.js';

// 仅保留二鬼拍门、士象全；AI预览与正式扫描使用同一规则。
const BOND_LEVELS = {
  bing_bing: 10,
  shi_xiang: 15,
};

/* ============================================================
 * 位置 / 等级判定
 * ============================================================ */

function isOrthAdjacent(a, b) {
  const dc = Math.abs(a.c - b.c), dr = Math.abs(a.r - b.r);
  return (dc === 1 && dr === 0) || (dc === 0 && dr === 1);
}

function sameLine(a, b) {
  return a.c === b.c || a.r === b.r;
}

function hasBlockBetween(a, b) {
  const { cols, rows } = game.map;
  const dc = Math.sign(b.c - a.c), dr = Math.sign(b.r - a.r);
  let c = a.c + dc, r = a.r + dr;
  while (c !== b.c || r !== b.r) {
    if (c < 0 || r < 0 || c >= cols || r >= rows) return true;
    if (game.pieces.find(o => o.c === c && o.r === r)) return true;
    c += dc; r += dr;
  }
  return false;
}

/** 两组棋子是否种类匹配（顺序无关） */
function typesMatch(a, b, pair) {
  return (a.type === pair[0] && b.type === pair[1]) ||
         (a.type === pair[1] && b.type === pair[0]);
}

/**
 * 判定两枚棋子是否满足该羁绊的等级需求。
 * requireLevel 支持四种写法：
 *   - 数字 n                ：两枚都达到 n 级才触发
 *   - { either: n }         ：任一枚达到 n 级即可（仅显式声明时有效）
 *   - { all: { type: lv } } ：指定种类的那一枚必须达到该等级
 *   - { anyOf: { type: lv }}：满足「任一 (种类 = type 且等级 ≥ lv)」即可
 */
function levelsPass(a, b, conf, key) {
  const rl = BOND_LEVELS[key] ?? conf.requireLevel;
  if (!rl) return true;

  // 数字：两枚都须达标
  if (typeof rl === 'number') {
    return Math.min(a.level, b.level) >= rl;
  }
  // { either: n }：显式声明时任一枚达标即可
  if (rl.either != null) {
    return Math.max(a.level, b.level) >= rl.either;
  }
  // { all: { type: level } }：按种类指定的那一枚要达标
  if (rl.all) {
    for (const [type, minLevel] of Object.entries(rl.all)) {
      const piece = (a.type === type) ? a : (b.type === type) ? b : null;
      if (!piece) return false;
      if (piece.level < minLevel) return false;
    }
    return true;
  }
  // { anyOf: { type: level } }：满足任一条件即可
  if (rl.anyOf) {
    for (const [type, minLevel] of Object.entries(rl.anyOf)) {
      const piece = (a.type === type) ? a : (b.type === type) ? b : null;
      if (piece && piece.level >= minLevel) return true;
    }
    return false;
  }
  return true;
}

/**
 * 两枚棋子之间当前满足的羁绊配置键列表（种类 + 等级 + 位置，与 rescanBonds 同一套判定）。
 * 也供 AI 评估「把棋子放到某格能凑出几个羁绊」使用（调用前临时改坐标即可）。
 */
export function bondKeysBetween(a, b) {
  const keys = [];
  if (a === b || (a.c === b.c && a.r === b.r)) return keys;
  for (const [key, conf] of Object.entries(BOND_CONFIG)) {
    if (!typesMatch(a, b, conf.requireType)) continue;
    if (conf.colorRule === 'same' && a.color !== b.color) continue;
    if (conf.colorRule === 'mixed' && a.color === b.color) continue;
    if (!levelsPass(a, b, conf, key)) continue;
    const posOk = conf.trigger === 'line'
      ? sameLine(a, b) && !hasBlockBetween(a, b)
      : isOrthAdjacent(a, b);
    if (posOk) keys.push(key);
  }
  return keys;
}

/* ============================================================
 * 扫描并重建全部羁绊（作用于当前棋盘）
 * ============================================================ */
export function rescanBonds() {
  const board = game.cur;
  const previous = board.bondOrder || new Map();
  const order = new Map(), candidates = [];
  let sequence = board.bondSequence || 0;
  const list = game.pieces;
  for (const p of list) {
    p.bonds = [];
    p.activeBonds = [];
    p.bondMods = {};
  }
  game.bonds = [];
  game.bondMods = {};

  // 身份与数组顺序无关；重复扫描不改变达成时间，失效后重连才算新达成。
  const compareId = (a, b) => String(a).localeCompare(String(b), 'en', { numeric: true });
  // 同一动作同时达成的组合按逻辑位置破同序，预览ID与正式UID不能改变选择。
  const sorted = [...list].sort((a, b) => a.r - b.r || a.c - b.c || compareId(a.id, b.id));
  for (let i = 0; i < sorted.length; i++) {
    for (let j = i + 1; j < sorted.length; j++) {
      const a = sorted[i], b = sorted[j];
      for (const key of bondKeysBetween(a, b)) {
        const conf = BOND_CONFIG[key];
        const ids = [a.id, b.id].sort(compareId);
        const identity = JSON.stringify([key, ...ids]);
        const achieved = previous.get(identity) ?? ++sequence;
        order.set(identity, achieved);
        candidates.push({
          achieved, a, b,
          bond: {
            id: `${ids[0]}-${ids[1]}-${key}`, key,
            aId: a.id, bId: b.id, name: conf.name, effect: conf.effect,
            branch: a.color === b.color ? a.color : 'mix',
          },
        });
      }
    }
  }
  board.bondOrder = order;
  board.bondSequence = sequence;
  candidates.sort((a, b) => b.achieved - a.achieved);
  // 限定羁绊（limit）每方只保留最早达成的组合；其余配对均生效。
  const limited = new Map();
  for (const { bond, a, b } of [...candidates].reverse()) {
    const limit = BOND_CONFIG[bond.key]?.limit;
    if (limit) {
      const used = limited.get(bond.key) || 0;
      if (used >= limit) continue;
      limited.set(bond.key, used + 1);
    }
    game.bonds.push(bond);
    a.bonds.push(bond.id);
    b.bonds.push(bond.id);
    a.activeBonds.push(bond.name);
    b.activeBonds.push(bond.name);
    game.bondMods[bond.effect] = true;
  }
  // 士象全：己方全场攻击+10%（限定一组，不叠加）。
  const guard = game.bonds.some(bond => bond.effect === 'waveLevel');
  for (const p of list) p.bondMods.teamAtkRate = guard ? 0.10 : 0;
  // 停用即清计时，避免同一帧内停用/恢复继承旧金币进度。
  const active = new Set(game.bonds.map(b => b.id));
  for (const id of Object.keys(board.bondGoldTimers || {})) {
    if (!active.has(id)) delete board.bondGoldTimers[id];
  }
  return game.bonds;
}

/** 详情面板用的辅助：某棋子当前激活了哪些羁绊 */
export function activeBondNames(piece) {
  return piece.activeBonds || [];
}

export const onBoardChanged = rescanBonds;

export default { rescanBonds, onBoardChanged, activeBondNames, bondKeysBetween };