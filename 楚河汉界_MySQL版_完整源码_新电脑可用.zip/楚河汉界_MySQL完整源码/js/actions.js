/**
 * actions.js —— 棋盘操作（玩家拖拽与对手 AI 共用同一套规则）
 *
 * 全部作用于「当前棋盘 game.cur」：玩家操作时为我方；AI 决策时由 ai.js 用 withBoard 切到对方。
 * 每个操作只改数据、不碰 DOM，返回 { ok, reason?, hint? }：
 *   - reason：失败原因（UI 可弹提示）
 *   - hint  ：成功但需要告知玩家的信息（如「无法融合，已购买并交换位置」）
 * 界面刷新（商店重绘 / UI 同步 / 浮字）由调用方负责。
 */
import { SHOP, SPELL_BY_ID } from './config.js';
import game, { spendGold, addGold, isPlaceablePlot, isDiggable } from './gameData.js';
import * as shop from './shop.js';
import { castSpell as applySpell, validateSpell, consumeSpellStock } from './spell.js';
import { digPlot } from './shovel.js';
import { tryMergeDraw, removeFromBoard, canAbsorb, applyAbsorb } from './synthesis.js';
import { rescanBonds } from './bond.js';
import { hasBoardCapacity, BOARD_CAPACITY_REASON } from './boardLimits.js';
import { tutorialActionAllowed, TUTORIAL_ACTION_REASON } from './tutorial.js';
import { recordCodex, recordOwnedPieces } from './codex.js';
const tutorialReason = TUTORIAL_ACTION_REASON;

const OK = { ok: true };
const fail = (reason) => ({ ok: false, reason });

/** 棋盘变动后：重扫羁绊 */
export function afterBoardChange() {
  rescanBonds();
  recordOwnedPieces();
}

/** 落子：写入坐标并加入场上 */
export function placePiece(piece, c, r) {
  piece.c = c;
  piece.r = r;
  game.pieces.push(piece);
}

/** 两枚场上棋子互换位置（不能融合时的兜底操作） */
export function swapPieces(a, b) {
  if (a.c === b.c && a.r === b.r) return;
  const ac = a.c, ar = a.r;
  a.c = b.c; a.r = b.r;
  b.c = ac;  b.r = ar;
}

/** 把 canAbsorb 的失败原因转成中文提示 */
export function absorbReasonText(reason) {
  switch (reason) {
    case 'type':     return '无法融合：棋子种类不同';
    case 'color':    return '无法融合：棋子颜色不同';
    case 'full':     return '无法融合：目标阶数已满';
    case 'overflow': return '无法融合：合并后超出阶数上限';
    case 'self':     return '无法融合：不能与自身融合';
    default:         return '无法融合';
  }
}

/* ============================================================
 * 商店
 * ============================================================ */

/** 刷新商店（首次免费） */
export function refresh() {
  if (!tutorialActionAllowed('refresh', [])) return fail(tutorialReason);
  const res = shop.refreshShop();
  return res.ok ? OK : fail(res.reason || '刷新失败');
}

/** 商店棋子卡 → 空地：购买（回收卡不扣费）并放置 */
export function buyAndPlace(slot, c, r) {
  if (!tutorialActionAllowed('buyAndPlace', [slot, c, r])) return fail(tutorialReason);
  const card = game.shopSlots[slot];
  if (!card || !shop.isPieceCard(card)) return fail('卡位为空');
  if (!isPlaceablePlot(c, r)) return fail('此处无法放置');
  if (!hasBoardCapacity(game.cur)) return fail(BOARD_CAPACITY_REASON);
  const piece = shop.pieceDataOfCard(card);
  if (card.source !== 'fromBoard' && !spendGold(shop.cardPrice(card))) return fail('金币不足');
  placePiece(piece, c, r);
  game.shopSlots[slot] = null;
  afterBoardChange();
  return OK;
}

/**
 * 商店棋子卡 → 场上棋子：
 *   能融合 → 融合（原生卡需买得起）；
 *   不能融合 → 若买得起则自动购买并与场上棋子交换位置（场上那枚进商店该卡位）。
 */
export function shopToPiece(slot, target, options = {}) {
  if (!tutorialActionAllowed('shopToPiece', [slot, target])) return fail(tutorialReason);
  const card = game.shopSlots[slot];
  if (!card || !shop.isPieceCard(card)) return fail('卡位为空');
  const dragPiece = shop.pieceDataOfCard(card);

  const check = canAbsorb(target, dragPiece);
  if (check.ok) {
    if (card.source === 'native' && !spendGold(shop.cardPrice(card))) {
      return fail(`金币不足（需要 ${shop.cardPrice(card)}）`);
    }
    applyAbsorb(target, dragPiece, options);
    game.shopSlots[slot] = null;
    afterBoardChange();
    return OK;
  }

  // 满阶/溢出是真正拒绝，不扣购买费、不吞材料、不用换位掩盖失败。
  if (check.reason === 'full' || check.reason === 'overflow') return fail(absorbReasonText(check.reason));
  // 异种/异色保留原有购买并交换行为。
  const price = shop.cardPrice(card);
  if (card.source !== 'native' || game.gold >= price) {
    if (card.source === 'native' && price != null) spendGold(price);
    const boardC = target.c, boardR = target.r;
    removeFromBoard(target);
    game.shopSlots[slot] = { source: 'fromBoard', piece: target };
    placePiece(dragPiece, boardC, boardR);
    afterBoardChange();
    return { ok: true, hint: '无法融合，已购买并交换位置' };
  }
  return fail(absorbReasonText(check.reason));
}

/**
 * 商店内两颗棋子互相融合（src 并入 dst）。
 * 两张原生卡都要扣费；回收卡视为已拥有。产物标记为已拥有（fromBoard），避免上场再扣费。
 */
export function shopMerge(srcSlot, dstSlot) {
  if (!tutorialActionAllowed('shopMerge', [srcSlot, dstSlot])) return fail(tutorialReason);
  const srcCard = game.shopSlots[srcSlot];
  const dstCard = game.shopSlots[dstSlot];
  if (!srcCard || !dstCard || srcSlot === dstSlot) return fail('卡位为空');

  const srcPiece = shop.pieceDataOfCard(srcCard);
  const dstPiece = shop.pieceDataOfCard(dstCard);
  if (!srcPiece || !dstPiece) return fail('卡位为空');

  const check = canAbsorb(dstPiece, srcPiece);
  if (!check.ok) return fail(absorbReasonText(check.reason));

  const needMoney = (srcCard.source === 'native' ? shop.cardPrice(srcCard) : 0)
                  + (dstCard.source === 'native' ? shop.cardPrice(dstCard) : 0);
  if (needMoney > 0 && !spendGold(needMoney)) return fail(`金币不足（需要 ${needMoney}）`);

  applyAbsorb(dstPiece, srcPiece);
  dstCard.level = dstPiece.level;
  dstCard.stage = dstPiece.stage;
  dstCard.kind = dstPiece.type;
  dstCard.color = dstPiece.color;
  game.shopSlots[srcSlot] = null;
  dstCard.source = 'fromBoard';
  recordCodex('pieces', srcPiece.type);
  recordCodex('pieces', dstPiece.type);
  return OK;
}

/** 铲子卡 → 草地格 */
export function useShovel(slot, c, r) {
  if (!tutorialActionAllowed('useShovel', [slot, c, r])) return fail(tutorialReason);
  const card = game.shopSlots[slot];
  if (!card || card.type !== 'shovel') return fail('卡位为空');
  if ((game.shovelUsed || 0) >= (SHOP.shovelMaxUsed ?? Infinity)) return fail('铲子已达使用上限');
  if (!isDiggable(c, r)) return fail('这里无法挖掘');
  if (!spendGold(SHOP.price.shovel)) return fail('金币不足');
  digPlot(c, r);
  game.shovelUsed = (game.shovelUsed || 0) + 1;
  game.shopSlots[slot] = null;
  afterBoardChange();
  return OK;
}

/**
 * 法术卡：target 为场上棋子（目标型），cell 为空地型落点；其他类型可不传。
 * 失败时退回金币；成功才扣库存。
 */
export function useSpell(slot, target = null, cell = null, options = {}) {
  if (!tutorialActionAllowed('useSpell', [slot, target, cell])) return fail(tutorialReason);
  const card = game.shopSlots[slot];
  if (!card || card.type !== 'spell') return fail('卡位为空');
  const spec = SPELL_BY_ID[card.id];
  if (!spec) return fail('未知法术');
  const check = validateSpell(card, target, cell, options);
  if (!check.ok) return check; // 选择尚未完成或取消，金币/库存/卡位均不变。
  const price = card.price ?? spec.price;
  if (!spendGold(price)) return fail('金币不足');
  const res = applySpell(card, target, cell, options);
  if (!res.ok) { addGold(price); return res; }
  game.shopSlots[slot] = null;
  consumeSpellStock(card.id);
  recordCodex('spells', card.id);
  const refreshed = res.refreshShop ? shop.refreshUnboughtCards() : null;
  afterBoardChange();
  return { ok: true, piece: res.piece, ...(refreshed?.shopRefreshOpportunity ? { shopRefreshOpportunity: true } : {}) };
}

/** 旧主动进化入口保留为兼容接口；新规则在融合达到3阶时自动完成。 */
export function evolvePiece() {
  return fail('进化在融合达到3阶时自动完成');
}

/* ============================================================
 * 场上
 * ============================================================ */

/** 场上棋子拖到另一枚棋子上：能融合则融合，否则互换位置 */
export function boardToPiece(piece, target, options = {}) {
  if (!tutorialActionAllowed('boardToPiece', [piece, target])) return fail(tutorialReason);
  if (!piece || !target || piece.id === target.id) return fail('无效目标');
  const res = tryMergeDraw(target, piece, options);
  if (!res.absorbed && (res.reason === 'full' || res.reason === 'overflow')) return fail(absorbReasonText(res.reason));
  if (!res.absorbed) swapPieces(piece, target);
  afterBoardChange();
  return { ok: true, merged: res.absorbed };
}

/** 场上棋子移到空地 */
export function moveTo(piece, c, r) {
  if (!tutorialActionAllowed('moveTo', [piece, c, r])) return fail(tutorialReason);
  if (!isPlaceablePlot(c, r)) return fail('此处无法放置');
  piece.c = c;
  piece.r = r;
  afterBoardChange();
  return OK;
}

/** 场上棋子拖回商店空位（不扣费） */
export function sellToShop(piece, slot) {
  if (!tutorialActionAllowed('sellToShop', [piece, slot])) return fail(tutorialReason);
  if (game.shopSlots[slot]) return fail('该卡位不是空位');
  removeFromBoard(piece);
  game.shopSlots[slot] = { source: 'fromBoard', piece };
  afterBoardChange();
  return OK;
}

export default {
  refresh, buyAndPlace, shopToPiece, shopMerge, useShovel, useSpell, evolvePiece,
  boardToPiece, moveTo, sellToShop, placePiece, swapPieces, afterBoardChange,
};
