/** 顺手牵羊后的刷新报价、实际扣费与按钮显示回归。 */
import game, { createBoard, withBoard, currentRefreshCost } from './gameData.js';
import { useSpell } from './actions.js';
import { refreshShop } from './shop.js';
import { sharedWaves } from './wave.js';

export async function runRefreshDiscountFixtures() {
  const saved = { boards: game.boards, cur: game.cur, phase: game.phase, waves: { ...sharedWaves } };
  let passed = 0;
  const check = (name, ok) => { if (!ok) throw Error(name); passed++; };
  const frame = () => new Promise(requestAnimationFrame);
  try {
    const me = createBoard('me', saved.boards.me.map);
    const opp = createBoard('opp', saved.boards.me.map);
    me._simulationContext = { random: () => 0.5 };
    game.boards = { me, opp }; game.cur = me; game.phase = 'playing';
    sharedWaves.timer = 999;
    me.gold = 100; me.totalRefreshCount = 1; me.shopRefreshCost = 7;
    me.shopSlots[0] = { source: 'native', type: 'spell', id: 'shunshouqianyang', price: 5 };
    check('顺手牵羊实际施放成功', useSpell(0).ok);
    check('报价从7变为2', currentRefreshCost() === 2 && me.nextRefreshDiscount === 5);
    await frame(); await frame();
    check('刷新按钮显示优惠价2', document.getElementById('refresh-cost').textContent === '2');
    const before = me.gold;
    check('实际刷新仅扣2金币', refreshShop().ok && me.gold === before - 2);
    check('优惠用一次且原价正常涨至10', me.nextRefreshDiscount === 0 && currentRefreshCost() === 10);
    await frame(); await frame();
    check('刷新后按钮恢复下一次价格10', document.getElementById('refresh-cost').textContent === '10');
    me.shopRefreshCost = 4; me.nextRefreshDiscount = 5;
    check('优惠后价格最低0', currentRefreshCost() === 0);
    await frame(); await frame();
    check('0金币报价显示免费', document.getElementById('refresh-cost').textContent === '免费');
    me.totalRefreshCount = 0;
    check('首次免费刷新保留优惠', refreshShop().ok && me.nextRefreshDiscount === 5 && currentRefreshCost() === 0);
    check('首次之后优惠刷新消费一次', refreshShop().ok && me.nextRefreshDiscount === 0 && currentRefreshCost() === 7);
    check('对方报价独立不受影响', withBoard(opp, currentRefreshCost) === 0 && !opp.nextRefreshDiscount);
    return { passed };
  } finally {
    game.boards = saved.boards; game.cur = saved.cur; game.phase = saved.phase;
    Object.assign(sharedWaves, saved.waves);
    await frame();
  }
}
