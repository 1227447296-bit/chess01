/** 真实奖励浮字检查；仅开始页显式运行，不写段位存档。 */
import game, { createBoard, withBoard, addGold, addBoardFloater } from './gameData.js';
import { update } from './wave.js';
import { simulateCombat } from './aiSimulation.js';
import { LEVEL, BOND_GOLD_TICK } from './config.js';
import { waitForBenchmarkReady } from './aiBenchmark.test.js';

export async function runRewardFloaterFixtures() {
  await waitForBenchmarkReady();
  if (game.phase !== 'start') throw Error('Start page required');
  const original = { cur: game.cur, phase: game.phase, floaters: game.floaters };
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const fixture = () => {
    const b = createBoard('opp');
    b.map = { cols: 5, rows: 3, ground: Array.from({ length: 3 }, () => Array(5).fill(true)),
      road: [Array(5).fill(true), Array(5).fill(false), Array(5).fill(false)],
      grass: Array.from({ length: 3 }, () => Array(5).fill(false)), cleared: new Set(),
      path: Array.from({ length: 5 }, (_, c) => ({ c, r: 0 })),
      enemySpawn: { c: 0, r: 0 }, kingPoint: { c: 4, r: 0 } };
    b.pieces = [{ id: 'reward-bing', kind: 'piece', type: 'bing', color: 'red', c: 1, r: 1,
      level: 0, exp: 0, stage: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [] }];
    b.enemies = [{ id: 'reward-enemy', c: 1, r: 0, fx: 1, fy: 0, hp: 1, maxHp: 1,
      speed: 0.65, progress: 1, done: false, dying: false, deathT: 0, stunLeft: 0, stunImmuneLeft: 0 }];
    return b;
  };
  try {
    game.floaters = [];
    game.phase = 'playing';
    const b = fixture(), gold = b.gold;
    withBoard(b, () => update(1 / 30));
    check('击杀金币只结算一次且保持原数值', b.kills === 1 && b.gold === gold + 2);
    check('击杀金币显示金色来源浮字', game.floaters.some(f => f.board === b && f.source === b.pieces[0] && f.kind === 'gold' && f.text === '+2'));
    check('击杀经验显示真实奖励而非升级后经验差', game.floaters.some(f => f.board === b && f.source === b.pieces[0] && f.kind === 'exp' && f.text === `+${LEVEL.killTeamExp + LEVEL.killBonus}`));
    const count = game.floaters.length;
    withBoard(b, () => update(1 / 30));
    check('死亡中的怪不重复奖励或浮字', game.floaters.length === count && b.gold === gold + 2);
    const capped = fixture();
    capped.pieces[0].level = LEVEL.naturalCap.bing;
    withBoard(capped, () => update(1 / 30));
    check('满级不显示未获得的经验', !game.floaters.some(f => f.board === capped && f.kind === 'exp'));
    check('满级击杀仍显示金币', game.floaters.some(f => f.board === capped && f.kind === 'gold'));
    const bond = fixture();
    bond.enemies = [];
    bond.pieces.push({ ...bond.pieces[0], id: 'reward-second', c: 3 });
    bond.bonds = [{ id: 'reward-bond', aId: bond.pieces[0].id, bId: bond.pieces[1].id, effect: 'goldTick' }];
    bond.bondGoldTimers['reward-bond'] = BOND_GOLD_TICK.intervalSec - 0.01;
    const bondGold = bond.gold;
    withBoard(bond, () => update(1 / 30));
    const f = game.floaters.find(f => f.board === bond && f.kind === 'gold');
    check('组合产金按组合显示一次而非给每枚重复记账', bond.gold === bondGold + BOND_GOLD_TICK.gold &&
      f?.text === `+${BOND_GOLD_TICK.gold}` && f.source.pieceIds.join(',') === 'reward-bing,reward-second');
    const before = game.floaters.length;
    simulateCombat(fixture(), { horizon: 1, seed: 17 });
    check('AI战斗推演不生成正式浮字', game.floaters.length === before);
    const sim = fixture();
    sim._simulationContext = {};
    withBoard(sim, () => { addGold(2, null, sim.pieces[0]); addBoardFloater(sim.pieces[0], '+10'); });
    check('模拟奖励和直接浮字入口均隔离', game.floaters.length === before && sim.gold === 27);
    withBoard(b, () => { addGold(3); addGold(-1, null, b.pieces[0]); });
    check('无棋子来源金币和扣费不伪造头顶奖励', game.floaters.length === before);
    for (let i = 0; i < 100; i++) withBoard(b, () => addBoardFloater(b.pieces[0], '+1'));
    check('浮字数量有上限', game.floaters.length === 80);
    check('奖励检查恢复棋盘上下文', game.cur === original.cur);
    return { passed: checks.length, checks };
  } finally {
    game.cur = original.cur;
    game.phase = original.phase;
    game.floaters = original.floaters;
  }
}
