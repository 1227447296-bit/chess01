/** 开发回归入口：在空闲的开始页显式调用 runAIRegression()；不写段位存档。 */
import game, { createBoard, withBoard, uid } from './gameData.js';
import { loadMap, scanMaps } from './mapLoader.js';
import { evolutionOutcomes, absorbOutcomes, applyAbsorb } from './synthesis.js';
import { clonePosition, previewCard, actionBranches, evaluateAction, evaluateActionSteps, scorePosition, riskAdjusted } from './aiEvaluation.js';
import { simulateCombat } from './aiSimulation.js';
import { aiTick, setupAI, aiInfo } from './ai.js';
import { AI_PLAY } from './config.js';
import { waitForBenchmarkReady } from './aiBenchmark.test.js';
import { sharedWaves } from './wave.js';

const snapshot = value => JSON.stringify(value, (key, v) =>
  v instanceof Set ? [...v] : v instanceof Map ? [...v] : v);
const piece = (id, type, c, r, level = 0) => ({
  id, kind: 'piece', type, color: 'red', c, r, level, exp: 0,
  stage: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [], activeBonds: [],
});

export async function runAIRegression() {
  await waitForBenchmarkReady();
  if (game.phase !== 'start') throw new Error('请先回到开始页，避免干扰正在进行的对局');
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw new Error(name); };
  const originalPhase = game.phase, originalBoard = game.cur;
  try {
    for (const type of ['bing', 'shi', 'xiang']) {
      const p = piece('evolve', type, 1, 2, 12), material = piece('material', type, 2, 2, 0);
      p.stage = 2; material.color = p.color;
      p.flags = { noHorseLeg: true, noXiangEye: true, freeShot: 1 };
      const before = snapshot(p), branches = absorbOutcomes(p, material);
      const expectedTypes = type === 'bing' ? ['shi', 'xiang'] : ['ju', 'ma', 'pao'];
      check(type + '自动进化机会节点数量', branches.length === expectedTypes.length * 2);
      check(type + '自动进化概率总和', Math.abs(branches.reduce((sum, b) => sum + b.probability, 0) - 1) < 1e-9);
      check(type + '随机颜色与产物合法', branches.every(b => expectedTypes.includes(b.type) && ['red', 'black'].includes(b.color)));
      check(type + '机会枚举不改源', snapshot(p) === before);
    }
    check('风险评分不选最好分支', riskAdjusted([{ value: 100, probability: 0.5 }, { value: -100, probability: 0.5 }]) < 0);
    const map = await loadMap(1);
    const board = createBoard('opp', map);
    board.totalRefreshCount = 1;
    board.gold = 25;
    board.pieces = [piece('a', 'bing', 1, 1, 5), piece('b', 'bing', 2, 1, 0)];
    board.shopSlots[0] = { source: 'native', type: 'piece', color: 'red' };
    const raw = snapshot(board), first = Number(uid('test').slice(4));
    previewCard(board.shopSlots[0], 0);
    scorePosition(clonePosition(board));
    evaluateAction(board, { kind: 'merge', pieceId: 'b', targetId: 'a', cost: 0 });
    const last = Number(uid('test').slice(4));
    check('候选不分配真实ID', last === first + 1);
    check('预览与评分不改变真实棋盘', snapshot(board) === raw);
    check('原生卡不缓存预览棋子', !board.shopSlots[0].piece);
    board.pieces[0].stage = 1;
    const merge = actionBranches(board, { kind: 'merge', pieceId: 'b', targetId: 'a', cost: 0 });
    check('兵融合候选集合确定一分支', merge.length === 1 && merge[0].probability === 1);
    check('到2阶不自动进化且无待选候选', merge.every(b => b.board.pieces[0].type === 'bing' &&
      b.board.pieces[0].stage === 2 && b.board.pieces[0].evolutionChoices === undefined));
    check('每个分支消耗材料但不影响原盘', merge.every(b => b.board.pieces.length === 1) && board.pieces.length === 2);
    const explicit = actionBranches(merge[0].board, { kind: 'evolve', pieceId: 'a', evolutionType: 'shi', cost: 0 });
    check('普通融合后不能主动选择进化', explicit.length === 0);
    check('候选外进化不合法', actionBranches(merge[0].board,
      { kind: 'evolve', pieceId: 'a', evolutionType: 'ju', cost: 0 }).length === 0);
    const deterministic = clonePosition(board);
    const p = deterministic.pieces[0];
    applyAbsorb(p, deterministic.pieces[1]);
    check('分支继承实际融合等级', merge.every(b => b.board.pieces[0].level === p.level));
    const developing = clonePosition(board);
    developing.pieces = [piece('s1', 'shi', 1, 1, 8), piece('s2', 'shi', 2, 1, 3), piece('s3', 'shi', 3, 1, 2)];
    const developmentBefore = snapshot(developing);
    const planAction = { kind: 'merge', pieceId: 's2', targetId: 's1', cost: 0 };
    const syncPlan = evaluateAction(developing, planAction, true);
    const evaluation = evaluateActionSteps(developing, planAction, true);
    let increment, slices = 0;
    do {
      increment = evaluation.next();
      slices++;
      check('养成规划片' + slices + '恢复当前棋盘', game.cur === originalBoard);
    } while (!increment.done);
    check('养成规划分帧和同步结果一致', snapshot(increment.value) === snapshot(syncPlan) && slices > 2);
    check('下一手规划不提前消耗第三枚或免费进化', syncPlan.branches.length === 1 &&
      syncPlan.branches[0].board.pieces.length === 2 && syncPlan.branches[0].board.pieces[0].type === 'shi' &&
      syncPlan.branches[0].board.pieces[0].stage === 1);
    check('下一手规划不改变真实源', snapshot(developing) === developmentBefore);
    const beforeSimulation = snapshot(board);
    const one = simulateCombat(board, { horizon: 2, seed: 17 });
    const two = simulateCombat(board, { horizon: 2, seed: 17 });
    check('模拟结果可重复', snapshot(one) === snapshot(two));
    check('模拟不改输入棋盘', snapshot(board) === beforeSimulation);
    check('模拟恢复当前棋盘', game.cur === originalBoard);

    setupAI({ tier: 7, sub: 0, stars: 0, streak: 0 });
    const opening = createBoard('opp', map);
    game.phase = 'playing';
    withBoard(opening, () => {
      aiTick(10, 3, 7);
      check('大dt也只首次刷新一个动作', opening.totalRefreshCount === 1 && opening.pieces.length === 0 && opening.gold === 25);
      check('统一操作间隔范围', opening.aiTimer >= AI_PLAY.actionMin && opening.aiTimer <= AI_PLAY.actionMax);
      const before = snapshot(opening);
      aiTick(0.01, 3, 7);
      check('间隔未到不执行动作', opening.pieces.length === 0 && opening.totalRefreshCount === 1 && opening.gold === 25);
      game.phase = 'paused';
      const timer = opening.aiTimer;
      aiTick(10, 3, 7);
      check('暂停不推进AI或计时', opening.aiTimer === timer && opening.pieces.length === 0);
      game.phase = 'playing';
      aiTick(2, 3, 7);
      for (let frame = 0; frame < 120 && aiInfo(opening).decisions < 2; frame++) aiTick(1 / 60, 3, 7);
      check('分帧完成后仍只有一个动作', aiInfo(opening).decisions === 2 && opening.pieces.length <= 1);
      check('金币不为负', opening.gold >= 0);
    });
    const budget = AI_PLAY.evaluationBudgetMs;
    try {
      AI_PLAY.evaluationBudgetMs = 0;
      setupAI({ tier: 7 }, { seed: 17 });
      const pending = createBoard('opp', map);
      pending.totalRefreshCount = 1;
      pending.shopSlots[0] = { source: 'native', type: 'piece', color: 'red' };
      withBoard(pending, () => aiTick(2, 3, 7));
      check('零预算只推进一个计算片不抢先买棋', !aiInfo(pending).lastAction && pending.pieces.length === 0);
      check('分帧候选不泄漏当前棋盘', game.cur === originalBoard);
      pending.gold += 1;
      const unchanged = snapshot([pending.gold, pending.pieces, pending.shopSlots]);
      for (let frame = 0; frame < 500 && aiInfo(pending).decisions === 0; frame++) {
        withBoard(pending, () => aiTick(0, 3, 7));
      }
      check('结构改变后丢弃过期方案', aiInfo(pending).decisions === 1 && !aiInfo(pending).lastAction &&
        snapshot([pending.gold, pending.pieces, pending.shopSlots]) === unchanged);
      check('过期取消也不泄漏当前棋盘', game.cur === originalBoard);
      check('取消后台思考不额外消耗一次操作间隔', pending.aiTimer === 0 && aiInfo(pending).cancelled === 1);
      const oldWaves = { ...sharedWaves };
      try {
        Object.assign(sharedWaves, { wave: 1, waveToSpawn: 2, timer: 0, spawnedInWave: 0,
          countInWave: 5, betweenWaves: false, countdown: false });
        const waveState = snapshot(sharedWaves);
        const incoming = createBoard('opp', map);
        incoming.king = { arrived: true, moving: false };
        incoming.totalRefreshCount = 1;
        incoming.shopSlots[0] = { source: 'native', type: 'piece', color: 'red' };
        setupAI({ tier: 7 }, { seed: 17 });
        withBoard(incoming, () => aiTick(2, 3, 7));
        for (let frame = 0; frame < 1000 && aiInfo(incoming).decisions === 0; frame++) {
          withBoard(incoming, () => aiTick(0, 3, 7));
        }
        check('空场也评估已知待生成怪', aiInfo(incoming).forecastCount > 0 && aiInfo(incoming).battleChecks > 0);
        check('含后续出生的AI思考可分帧完成', aiInfo(incoming).decisions === 1);
        check('AI后续出生推演不推进正式共享出怪', snapshot(sharedWaves) === waveState && game.cur === originalBoard);
      } finally {
        Object.assign(sharedWaves, oldWaves);
      }
    } finally {
      AI_PLAY.evaluationBudgetMs = budget;
    }
    game.phase = 'start';
    for (const id of await scanMaps()) {
      const m = await loadMap(id);
      check('地图' + id + '路径完整', m.path.length === m.road.flat().filter(Boolean).length);
      const empty = createBoard('opp', m);
      check('地图' + id + '空盘评分有效', Number.isFinite(scorePosition(empty).score));
    }
    return { passed: checks.length, checks };
  } finally {
    game.phase = originalPhase;
    game.cur = originalBoard;
  }
}
