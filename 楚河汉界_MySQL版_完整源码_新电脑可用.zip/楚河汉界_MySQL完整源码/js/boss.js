/** 实验版Boss：纯出怪规格供正式调度与AI共用；Boss占本波第一个名额，不额外出怪。 */
import { enemyStatsForWave } from './config.js';

export const BOSS = Object.freeze({
  waves: Object.freeze({
    8: Object.freeze({ hpMultiplier: 4.8, speedMultiplier: 0.432 }),
    15: Object.freeze({ hpMultiplier: 7.2, speedMultiplier: 0.396 }),
    20: Object.freeze({ hpMultiplier: 9.6, speedMultiplier: 0.36 }),
  }),
  spriteKey: 'green_character', // 复用RES.images已存在的素材，不伪造Boss图片路径。
  spriteScale: 1.55,
  announcementText: '王从天降',
  announcementSeconds: 2.4,
  hitSlowRate: 0.1,
  hitSlowSeconds: 0.5,
  hitSlowImmuneSeconds: 0.5,
});

/** spawnIndex是本波0起出怪序号，必须取共享调度而非棋盘累计spawned。 */
export function enemySpecForSpawn(wave, spawnIndex, enemyConfig) {
  const stats = enemyStatsForWave(wave, enemyConfig);
  const boss = spawnIndex === 0 ? BOSS.waves[wave] : null;
  return {
    hp: stats.hp * (boss?.hpMultiplier ?? 1),
    speed: stats.speed * (boss?.speedMultiplier ?? 1),
    isBoss: !!boss,
    bossWave: boss ? wave : null,
    spawnIndex,
    displayName: boss ? '王' : '寇',
    spriteKey: BOSS.spriteKey,
    spriteScale: boss ? BOSS.spriteScale : 1,
  };
}

/** 受击减速不刷新：先减速，再免疫；共用分段移动积分，与其他减速取最强效果。 */
export function applyBossHitSlow(enemy, gameTime) {
  if (!enemy?.isBoss || enemy.done || enemy.dying || !(enemy.hp > 0)) return false;
  if ((enemy.bossHitSlowImmuneUntil || 0) > gameTime) return false;
  const until = gameTime + BOSS.hitSlowSeconds;
  enemy.bossHitSlowImmuneUntil = until + BOSS.hitSlowImmuneSeconds;
  (enemy.tacticalSlows || (enemy.tacticalSlows = [])).push({
    rate: BOSS.hitSlowRate, start: gameTime, until,
  });
  return true;
}

/** 以每盘游戏时钟计时，暂停不老化；只在真实出生登记时创建，旧Boss叠波不重复提示。 */
export function announceBossSpawn(board, enemy, wave) {
  if (!enemy.isBoss) return;
  const startedAt = board.gameTime || 0;
  board.bossAnnouncement = {
    text: BOSS.announcementText, wave, startedAt,
    until: startedAt + BOSS.announcementSeconds,
  };
}

/** 渲染端可读本接口，在整个屏幕正中画一次；不使用棋盤格坐标。 */
export function activeBossAnnouncement(board) {
  const notice = board?.bossAnnouncement;
  return notice && notice.until > (board.gameTime || 0) ? notice : null;
}

export function updateBossAnnouncement(board) {
  if (board.bossAnnouncement && !activeBossAnnouncement(board)) board.bossAnnouncement = null;
}
