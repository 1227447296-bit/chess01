/**
 * render.js —— 全部画面渲染
 * 基于 canvas：
 *   - 地图瓦片（Ground / grass / road 三层，按 GID 从 tilesheet 裁切）
 *   - 棋子底图 + 叠字（兵士象马车炮）+ Lv / 融合计数 / 经验条
 *   - 帅（主公）与红心
 *   - 敌人（green_character）与血条
 *   - 子弹（red_bullet / black_bullet）
 *   - 拖拽悬浮（可放置/不可放置）、目标棋子高亮
 *
 * 资源只通过 assets.js 的 IMG 取（路径来自 config），不在本模块写死路径。
 */
import { GRID, PIECE_STATS, pieceDisplayName, PIECE_TEXT_STYLE, LEVEL, experienceRequired, TILESET, FX, JU_CHARGE, ENEMY_FX, KING, BOND_EFFECT, displayNumber } from './config.js';
import { getImg } from './assets.js';
import game, { isPlaceablePlot, cellKey } from './gameData.js';
import { gidToTileRect } from './mapLoader.js';
import * as BONDEFFECT from './bondEffect.js';
import { computeAttackPreview, draggedPieceInfo } from './rangePreview.js';
import { pieceDamage } from './attackRule.js';
import { effectiveLives, specialThreshold } from './tacticalEffects.js';
import { activeBossAnnouncement } from './boss.js';
import { boardToView, viewToBoard, viewSize, vectorToView } from './boardView.js';
import { TUTORIAL_CELLS } from './tutorial.js';

/** 渲染上下文（每次 render 调用前由 main 设定为对应棋盘的画布） */
export const renderState = {
  canvas: null,
  ctx: null,
  tile: GRID.tile,          // 单格渲染像素
  /** 是否上下翻转（对方棋盘：敌人从「我视角的下方」出现） */
  flip: false,
  sideways: false,         // 5×8 地图横向显示为 8×5，文字与棋子保持正立
  /** 只读棋盘（对方）：不画拖拽 / 不弹羁绊名 */
  readonly: false,
};

/* ============================================================
 * 坐标换算（翻转用坐标映射实现，文字 / 贴图不会倒置）
 * ============================================================ */
function cellPosition(c, r) {
  const p = boardToView(c, r, game.map, renderState.sideways, renderState.flip);
  return { x: p.c * renderState.tile, y: p.r * renderState.tile };
}

/** 像素 → 逻辑格子（含横置与对方翻转反算），供输入换算使用 */
export function pixelToCell(px, py, flip) {
  const tile = renderState.tile;
  return viewToBoard(Math.floor(px / tile), Math.floor(py / tile), game.map, renderState.sideways, flip);
}

/* ============================================================
 * 主渲染（每帧，每个棋盘各调用一次；调用方负责切换 game.cur）
 * ============================================================ */

export function render(time) {
  const { ctx } = renderState;
  if (!ctx) return;
  // 用逻辑尺寸（格数 × tile）：画布真实像素可能被放大以保证清晰（见 main.fitCanvasResolution）
  const size = viewSize(game.map, renderState.sideways);
  const W = size.cols * renderState.tile, H = size.rows * renderState.tile;

  ctx.clearRect(0, 0, W, H);

  renderMap(ctx);
  renderPlots(ctx);            // 已铲开的空地高亮提示
  renderPaint(ctx);            // 攻击涂色（在地图之上，敌人/棋子之下）
  renderKing(ctx);
  renderPieces(ctx, time);
  renderEnemies(ctx);
  renderTacticalGhosts(ctx);
  renderBullets(ctx);
  renderBondBoxes(ctx, time);
  renderRewardFloaters(ctx);
  renderCritBursts(ctx);
  renderDamageFloaters(ctx);
  renderBossAnnouncement(ctx, W, H);
  if (!renderState.readonly) {
    renderBondPopup(ctx, time, W, H);
    renderDrag(ctx);           // 拖拽幽灵与攻击范围预览（仅拖拽时显示）
    renderTutorialTarget(ctx, time);
  }
}

function renderTutorialTarget(ctx, time) {
  const t = game.cur.tutorial;
  if (!t || t.defending || t.finished || t.failed) return;
  const cells = [TUTORIAL_CELLS.first, TUTORIAL_CELLS.first, TUTORIAL_CELLS.shovel,
    TUTORIAL_CELLS.shovel, TUTORIAL_CELLS.bond, TUTORIAL_CELLS.first];
  const cell = cells[t.step];
  if (!cell) return;
  const { x, y } = cellPosition(cell.c, cell.r);
  const tile = renderState.tile;
  ctx.save();
  ctx.strokeStyle = '#fff078'; ctx.lineWidth = 4;
  ctx.shadowColor = '#ffe153'; ctx.shadowBlur = 8 + 4 * Math.sin(time / 180);
  ctx.strokeRect(x + 3, y + 3, tile - 6, tile - 6);
  ctx.restore();
}

/**
 * 伤害飘字档位：按显示伤害（内部伤害×100）的固定数值分档。
 * 2000以下灰、2000-5000黄、5000-8000橙、8000以上红；暴击另带金边并加「暴击」字样。
 */
const DAMAGE_TIERS = [
  { min: 8000, size: 20, fill: '#ff3b30', stroke: '#3b0a08' },
  { min: 5000, size: 17, fill: '#ff7a2f', stroke: '#3b1a08' },
  { min: 2000, size: 15, fill: '#ffd166', stroke: '#3b2a08' },
  { min: 0, size: 12, fill: '#c9c9c9', stroke: '#2a2a2a' },
];
export function damageFloaterStyle(f) {
  const shown = displayNumber(f.amount);
  const tier = DAMAGE_TIERS.find(t => shown >= t.min);
  return f.critical
    ? { ...tier, size: tier.size + 2, stroke: '#7a4b00' }
    : tier;
}

/** 伤害飘字保持屏幕正立；敌人消失后仍在最后命中处完成上飘。 */
function renderDamageFloaters(ctx) {
  const now = game.cur.gameTime || 0;
  const lanes = new Map();
  for (const f of game.cur.damageFloaters || []) {
    if (f.until <= now) continue;
    const enemy = game.enemies.find(e => e.id === f.enemyId);
    const pos = cellPosition(enemy?.fx ?? f.c, enemy?.fy ?? f.r);
    const lane = lanes.get(f.enemyId) || 0;
    lanes.set(f.enemyId, lane + 1);
    const age = Math.max(0, now - f.born);
    const style = damageFloaterStyle(f);
    const x = pos.x + renderState.tile / 2, y = Math.max(10, pos.y - 6 - age * 26 - lane * 13);
    ctx.save();
    ctx.globalAlpha = Math.min(1, (f.until - now) / 0.25);
    if (f.critical) {
      // 暴击：「暴击」金字 + 数字，前0.12秒轻微放大弹出。
      const pop = 1 + 0.25 * Math.max(0, 1 - age / 0.12);
      const size = Math.round(style.size * pop);
      drawText(ctx, '暴击', x, y - size * 0.95,
        { size: Math.round(size * 0.7), fill: '#ffe066', stroke: '#6a3a00', align: 'center', bold: true });
      drawText(ctx, `-${Math.max(1, displayNumber(f.amount))}`, x, y,
        { size, fill: style.fill, stroke: style.stroke, align: 'center', bold: true });
    } else {
      drawText(ctx, `-${Math.max(1, displayNumber(f.amount))}`, x, y,
        { size: style.size, fill: style.fill, stroke: style.stroke, align: 'center', bold: true });
    }
    ctx.restore();
  }
}

/** 暴击：命中点短促的金色光晕 + 星芒，约0.35秒，半径约半格。 */
function renderCritBursts(ctx) {
  const now = game.cur.gameTime || 0;
  const tile = renderState.tile;
  for (const b of game.cur.critBursts || []) {
    if (b.until <= now) continue;
    const t = Math.min(1, Math.max(0, (now - b.born) / (b.until - b.born)));
    const { x, y } = cellPosition(b.c, b.r);
    const cx = x + tile / 2, cy = y + tile / 2;
    const inner = tile * (0.1 + 0.12 * t), outer = tile * (0.28 + 0.22 * t);
    ctx.save();
    ctx.globalAlpha = 1 - t;
    const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, outer);
    glow.addColorStop(0, 'rgba(255,245,180,0.85)');
    glow.addColorStop(0.45, 'rgba(255,200,60,0.45)');
    glow.addColorStop(1, 'rgba(255,170,0,0)');
    ctx.fillStyle = glow;
    ctx.beginPath(); ctx.arc(cx, cy, outer, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#ffe066';
    ctx.shadowColor = '#ffb300'; ctx.shadowBlur = tile * 0.15;
    ctx.lineWidth = Math.max(2, tile * 0.055);
    ctx.lineCap = 'round';
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const a = i * Math.PI / 4 + Math.PI / 8;
      const len = i % 2 ? outer * 0.8 : outer;
      ctx.moveTo(cx + Math.cos(a) * inner, cy + Math.sin(a) * inner);
      ctx.lineTo(cx + Math.cos(a) * len, cy + Math.sin(a) * len);
    }
    ctx.stroke();
    ctx.restore();
  }
}

/** 战车沿逻辑道路行驶，坐标统一经过横置与翻转换算。 */
function renderTacticalGhosts(ctx) {
  const size = renderState.tile;
  for (const ghost of game.cur.tacticalGhosts || []) {
    const node = game.map.path[Math.min(game.map.path.length - 1, Math.floor(ghost.progress))];
    if (!node) continue;
    const { x, y } = cellPosition(ghost.fx ?? node.c, ghost.fy ?? node.r);
    const color = ghost.source.color;
    ctx.save();
    ctx.globalAlpha = 0.72;
    ctx.shadowColor = '#7ed6e8';
    ctx.shadowBlur = 14;
    const img = getImg(color === 'red' ? 'red_character' : 'black_character');
    if (img) ctx.drawImage(img, x, y, size, size);
    drawText(ctx, '車', x + size / 2, y + size / 2 + 2,
      { size: 23, fill: '#b6f2ff', stroke: '#1e4255', align: 'center', bold: true });
    ctx.restore();
  }
  const now = game.cur.gameTime || 0;
  for (const ghost of game.cur.tacticalHorseGhosts || []) {
    if (now < ghost.born || now >= ghost.until) continue;
    const age = now - ghost.born;
    const q = Math.min(1, age / 0.18);
    const { x, y } = cellPosition(ghost.fromC + (ghost.c - ghost.fromC) * q,
      ghost.fromR + (ghost.r - ghost.fromR) * q);
    const lift = Math.sin(q * Math.PI) * size * 0.22;
    ctx.save();
    ctx.globalAlpha = 0.85 * Math.min(1, (ghost.until - now) / 0.25);
    ctx.shadowColor = '#7ed6e8'; ctx.shadowBlur = 18;
    const img = getImg(ghost.color === 'red' ? 'red_character' : 'black_character');
    if (img) ctx.drawImage(img, x, y - lift, size, size);
    drawText(ctx, ghost.color === 'red' ? '马' : '馬', x + size / 2, y - lift + size / 2 + 2,
      { size: 25, fill: '#c9f6ff', stroke: '#1e4255', align: 'center', bold: true });
    if (age >= 0.18 && age < 0.4) {
      ctx.strokeStyle = '#b6f2ff'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(x + size / 2, y + size / 2, size * (0.25 + age), 0, Math.PI * 2); ctx.stroke();
    }
    ctx.restore();
  }
}

/** 奖励数值随棋子/组合移动，保持文字正立；绿色经验与金色金币分行。 */
function renderRewardFloaters(ctx) {
  const tile = renderState.tile;
  ctx.save();
  ctx.textAlign = 'center';
  ctx.textBaseline = 'bottom';
  ctx.font = `bold ${Math.round(tile * 0.24)}px sans-serif`;
  ctx.lineWidth = Math.max(2, tile * 0.04);
  ctx.strokeStyle = 'rgba(30, 28, 20, 0.8)';
  for (const f of game.floaters) {
    if (f.board !== game.cur) continue;
    const sources = f.source.pieceIds
      ? f.source.pieceIds.map(id => game.pieces.find(p => p.id === id)).filter(Boolean)
      : [game.pieces.find(p => p.id === f.source.id)].filter(Boolean);
    if (!sources.length) continue;
    const points = sources.map(p => cellPosition(p.charge?.fx ?? p.c, p.charge?.fy ?? p.r));
    const x = points.reduce((sum, p) => sum + p.x, 0) / points.length + tile / 2;
    const y = Math.min(...points.map(p => p.y)) + tile * 0.12 - tile * 0.42 * f.age / f.life
      - (f.kind === 'gold' ? tile * 0.25 : 0);
    ctx.globalAlpha = Math.min(1, (1 - f.age / f.life) * 3);
    ctx.fillStyle = f.kind === 'gold' ? '#ffd75a' : '#66e889';
    ctx.strokeText(f.text, x, Math.max(tile * 0.25, y));
    ctx.fillText(f.text, x, Math.max(tile * 0.25, y));
  }
  ctx.restore();
}

/* ============================================================
 * 攻击涂色特效（颜料泼洒）
 * 画在地面（地图之上），被敌人/棋子覆盖；浅色、不涂满格，
 * 生命周期内后段逐渐淡出。攻击范围越大泼洒范围越大。
 * ============================================================ */
function renderPaint(ctx) {
  if (!game.paintSplats.length) return;
  const cfg = FX.paint;
  const tile = renderState.tile;

  ctx.save();
  for (const s of game.paintSplats) {
    // 透明度：前段保持，后段线性淡出
    const p = s.age / s.life;
    const alpha = p > cfg.fadeStart ? (1 - (p - cfg.fadeStart) / (1 - cfg.fadeStart)) : 1;
    if (alpha <= 0) continue;

    const tint = cfg.tint[s.color] || cfg.tint.red;
    ctx.fillStyle = `rgba(${tint.r},${tint.g},${tint.b},${(tint.alpha * alpha).toFixed(3)})`;

    // 命中格中心（像素）
    const pos = cellPosition(s.c, s.r);
    const cx = pos.x + tile / 2;
    const cy = pos.y + tile / 2;

    for (const d of s.dots) {
      // 每个点：位置由中心偏移，尺寸为格单位的椭圆（拉伸 + 旋转模拟飞溅）
      const px = cx + d.dx * tile;
      const py = cy + d.dy * tile;
      const rx = d.size * tile * d.stretch;
      const ry = d.size * tile;
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(d.rot || 0);
      ctx.beginPath();
      ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }
  ctx.restore();
}

/* ============================================================
 * 地图瓦片
 * ============================================================ */
function renderMap(ctx) {
  const img = getImg('tilesheet');
  if (!img) { blankMap(ctx); return; }
  const ts = TILESET;
  const { raw } = game.map;
  if (!raw) { blankMap(ctx); return; }

  const drawLayer = (layer, skipCleared) => {
    for (let r = 0; r < layer.gid.length; r++) {
      for (let c = 0; c < layer.gid[r].length; c++) {
        const gid = layer.gid[r][c];
        if (!gid) continue;
        // 草地层：已被铲子挖开的格子不再绘制，露出下方 Ground
        if (skipCleared && game.map.cleared.has(cellKey(c, r))) continue;
        const rect = gidToTileRect(gid, ts);
        drawTileWithFlip(ctx, img, rect, c, r, layer.flags[r][c]);
      }
    }
  };

  drawLayer(raw.ground, false);
  drawLayer(raw.grass, true);    // 草地：铲开的格子跳过
  drawLayer(raw.road, false);
}

/** 空白兜底：只画纯色底，表示地图未加载 */
function blankMap(ctx) {
  ctx.fillStyle = '#3a3a3a';
  const size = viewSize(game.map, renderState.sideways);
  ctx.fillRect(0, 0, size.cols * renderState.tile, size.rows * renderState.tile);
}

/**
 * 按 gid + 翻转标志绘制一个瓦片。
 *
 * Tiled 的翻转标志（高位）：
 *   0x80000000 水平翻转 H | 0x40000000 垂直翻转 V | 0x20000000 对角翻转 D
 * Tiled 官方约定：变换顺序为「先对角 D，再水平 H，最后垂直 V」，
 * 即合成矩阵 M = V · H · D。（旧代码把 D 当成了单纯旋转，导致斜角瓦片方向错乱。）
 *
 * ctx.transform(a,b,c,d,e,f) 中：(x,y) → (a·x + c·y + e, b·x + d·y + f)
 * 因此按 M 的各元素填入 a,b,c,d 即可。
 */
function drawTileWithFlip(ctx, img, rect, c, r, flags) {
  const { x, y } = cellPosition(c, r);
  const w = renderState.tile, h = renderState.tile;   // 逻辑 60，图集 64 → 缩放

  const fH = !!(flags & 0x80000000);
  const fV = !!(flags & 0x40000000);
  const fD = !!(flags & 0x20000000);

  // 计算 2×2 变换矩阵 [a,b,c,d]
  let a = 1, b = 0, cc = 0, d = 1;
  if (!fD) {
    // 无对角：M = V · H（H、V 可交换）
    a = fH ? -1 : 1;
    d = fV ? -1 : 1;
  } else if (!fH && !fV) {
    [a, b, cc, d] = [0, 1, 1, 0];      // D
  } else if (fH && !fV) {
    [a, b, cc, d] = [0, 1, -1, 0];     // H·D（= 顺时针 90°）
  } else if (!fH && fV) {
    [a, b, cc, d] = [0, -1, 1, 0];     // V·D
  } else {
    [a, b, cc, d] = [0, -1, -1, 0];    // V·H·D（= 逆时针 90°）
  }

  ctx.save();
  ctx.translate(x + w / 2, y + h / 2);
  if (renderState.flip) ctx.scale(1, -1);   // 对方在显示坐标里上下翻转
  if (renderState.sideways) ctx.rotate(Math.PI / 2);   // 道路拐角跟随地图横置
  ctx.transform(a, b, cc, d, 0, 0);
  ctx.drawImage(img, rect.sx, rect.sy, 64, 64, -w / 2, -h / 2, w, h);
  ctx.restore();
}

/** 已铲开的草地格：加深提亮，提示可放置 */
function renderPlots(ctx) {
  const tile = renderState.tile;
  ctx.save();
  ctx.strokeStyle = 'rgba(120,255,140,0.35)';
  ctx.lineWidth = 2;
  for (const key of game.map.cleared) {
    const [c, r] = key.split(',').map(Number);
    const { x, y } = cellPosition(c, r);
    ctx.strokeRect(x + 2, y + 2, tile - 4, tile - 4);
  }
  ctx.restore();
}

/* ============================================================
 * 棋子（己方）
 * ============================================================ */

export function pieceBaseAtk(p) {
  return (PIECE_STATS[p.type]?.atk ?? 0) + (p.atkBonus || 0) +
    (game.flags.atkFlatByType?.[p.type] || 0) + (game.flags.atkFlatAll || 0);
}

/** 最终攻击力（基础 × 等级倍率，不含羁绊的额外增伤） */
export function finalAtk(p) {
  return pieceDamage(p);
}

function renderPieces(ctx, time) {
  for (const p of game.pieces) {
    if (game.drag.active && game.drag.piece && game.drag.piece.id === p.id) continue; // 拖拽中源棋子暂不画
    drawPiece(ctx, p, time);
  }
}

/** 绘制单枚棋子：底图 + 叠字 + Lv + 计数 + 经验条 */
export function drawPiece(ctx, p, time, ghostPos = null) {
  const tile = renderState.tile;
  let { x, y } = ghostPos || cellPosition(p.c, p.r);
  const size = tile;                      // 一棋子占一格

  // 车冲刺 / 马践踏：用连续坐标覆盖位置
  if (!ghostPos && p.charge) {
    ({ x, y } = cellPosition(p.charge.fx, p.charge.fy));
    drawChargeWind(ctx, p, x, y, size);
  }
  if (!ghostPos && p.stomp) {
    ({ x, y } = cellPosition(p.stomp.fx, p.stomp.fy));
  }

  // 「吐子」抽搐：朝发射方向位移，正弦弹回（仅真实棋子，拖拽幽灵不抽搐）
  if (!ghostPos && p.recoil) {
    const { nx, ny, t, dur } = p.recoil;
    const k = Math.sin(Math.PI * (t / dur));           // 0→1→0
    const amp = FX.recoil.amplitude;
    const direction = vectorToView(nx, ny, renderState.sideways, renderState.flip);
    x += direction.x * amp * k;
    y += direction.y * amp * k;
  }

  const img = getImg(p.color === 'red' ? 'red_character' : 'black_character');
  if (img) ctx.drawImage(img, x, y, size, size);

  // 阶别发光特效：画在贴图「之上」，让光环圈清晰可见（不遮挡中部文字）
  if (!ghostPos) drawTierGlow(ctx, p, x, y, size, time);

  // 种类字符
  const name = pieceDisplayName(p);
  const st = PIECE_TEXT_STYLE[p.color] || PIECE_TEXT_STYLE.red;

  // Lv（顶部）
  drawText(ctx, `Lv.${p.level}`, x + size / 2, y + 12,
    { size: 12, fill: '#fff', stroke: '#222', align: 'center', bold: true });

  // 种类（中部大字）
  drawText(ctx, name, x + size / 2, y + size / 2 + 2,
    { size: 20, fill: st.fill, stroke: st.stroke, align: 'center', bold: true });

  // 阶（底部）：显示「N阶」= 该棋子的自融合次数 stage
  drawText(ctx, `${p.stage || 0}阶`, x + size / 2, y + size - 11,
    { size: 12, fill: '#ffd75e', stroke: '#222', align: 'center', bold: true });

  // 经验条（最底部，细条）
  drawExpBar(ctx, p, x, y, size);
  const threshold = specialThreshold(p);
  if (!ghostPos && threshold) {
    ctx.save();
    const count = Math.min(threshold, p.specialCount || 0);
    ctx.fillStyle = '#24303b';
    ctx.fillRect(x + size - 5, y + 18, 3, size - 32);
    ctx.fillStyle = '#7ed6e8';
    const height = (size - 32) * count / threshold;
    ctx.fillRect(x + size - 5, y + size - 14 - height, 3, height);
    ctx.restore();
  }

  // 高亮（法术目标）
  if (game.highlightPieceId === p.id && game.drag.active && isSpellDrag()) {
    ctx.save();
    ctx.strokeStyle = '#ffe74d';
    ctx.lineWidth = 2.5;
    ctx.shadowColor = '#ffe74d';
    ctx.shadowBlur = 12;
    ctx.strokeRect(x - 2, y - 2, size + 4, size + 4);
    ctx.restore();
  }

  // 高亮（点击棋子弹出详情面板时的选中）
  if (game.selectedPieceId === p.id) {
    ctx.save();
    ctx.strokeStyle = 'rgba(120,200,255,0.9)';
    ctx.lineWidth = 2.5;
    ctx.shadowColor = 'rgba(120,200,255,0.8)';
    ctx.shadowBlur = 10;
    ctx.strokeRect(x - 2, y - 2, size + 4, size + 4);
    ctx.restore();
  }
}

function isSpellDrag() {
  const card = game.drag.card;
  return card?.type === 'spell';
}

/**
 * 根据「进化强度」绘制棋子周围的持续光环，让玩家一眼看出强弱：
 *   兵（最基础）：浅灰色光环
 *   士 / 象（第一层进化）：青绿光环
 *   车 / 马 / 炮（第二层进化，最强）：金色光环 + 外圈旋转虚线
 * 光环画在贴图下层、紧贴棋子中部文字外圈，脉冲呼吸；
 * 半径收在约 0.44 格以内，不遮挡 Lv / 名称 / 阶数 / 经验条。
 */
function drawTierGlow(ctx, p, x, y, size, time) {
  const type = p.type;
  let tier = 0;                       // 0=兵 1=士象 2=车马炮
  if (type === 'shi' || type === 'xiang') tier = 1;
  else if (type === 'ju' || type === 'ma' || type === 'pao') tier = 2;

  const cx = x + size / 2, cy = y + size / 2;
  const breathe = 0.5 + 0.5 * Math.sin(time * 3 + (p.c + p.r));   // 0~1 呼吸

  // 各档配色
  const style = {
    0: { glow: [200, 200, 200], ring: [220, 220, 220] },   // 兵：浅灰
    1: { glow: [90, 230, 180],  ring: [120, 255, 200] },   // 士象：青绿
    2: { glow: [255, 210, 77],  ring: [255, 220, 110] },   // 车马炮：金
  }[tier];
  const G = style.glow, R = style.ring;

  // 缩小后的半径（卡在「中部大字」与「顶部 Lv / 底部阶数」之间的空档，不挡任何字）
  const baseR = size * 0.28;                 // 约 17px，正好在中心大字外圈
  const haloR = baseR + size * (0.02 + breathe * 0.02);

  ctx.save();

  // 外圈柔和光晕（径向渐变，透明度低）
  const grad = ctx.createRadialGradient(cx, cy, baseR * 0.7, cx, cy, haloR);
  grad.addColorStop(0, `rgba(${G[0]},${G[1]},${G[2]},0)`);
  grad.addColorStop(1, `rgba(${G[0]},${G[1]},${G[2]},${0.22 + breathe * 0.12})`);
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, haloR, 0, Math.PI * 2);
  ctx.fill();

  // 一圈细描边光环（贴紧文字外圈）
  ctx.strokeStyle = `rgba(${R[0]},${R[1]},${R[2]},${0.45 + breathe * 0.35})`;
  ctx.lineWidth = tier === 2 ? 2 : 1.6;
  ctx.beginPath();
  ctx.arc(cx, cy, baseR, 0, Math.PI * 2);
  ctx.stroke();

  // 车 / 马 / 炮：再加一圈更小的旋转虚线，强化「高级」感
  if (tier === 2) {
    ctx.strokeStyle = 'rgba(255,240,170,0.7)';
    ctx.lineWidth = 1.4;
    ctx.setLineDash([3, 4]);
    ctx.lineDashOffset = -time * 26;
    ctx.beginPath();
    ctx.arc(cx, cy, baseR + size * 0.035, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();
}

/** 经验条：本级经验 / 所需；已达自然上限则置满并标【上限】 */
function drawExpBar(ctx, p, x, y, size) {
  const cap = LEVEL.naturalCap[p.type] ?? LEVEL.hardCap;
  const atCap = (p.level || 0) >= cap;
  const need = experienceRequired(p.level);
  const ratio = atCap ? 1 : (need ? (p.exp || 0) / need : 0);

  const bw = size - 8;
  const by = y + size - 4;
  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  ctx.fillRect(x + 4, by, bw, 3);
  ctx.fillStyle = atCap ? '#ffd24d' : '#57e06a';
  ctx.fillRect(x + 4, by, bw * Math.min(1, ratio), 3);
  if (atCap) {
    drawText(ctx, '上限', x + size / 2, by + 12,
      { size: 7, fill: '#ffd24d', stroke: '#000', align: 'center' });
  }
}

/* ============================================================
 * 走路蹦跳（纯视觉）
 * 蹦跳相位 = 沿路径走过的格数 progress，走多快蹦多快；
 * 停下（眩晕 / 帅到位 / 死亡）时幅度逐帧衰减，平稳落地，不会卡在半空。
 * 只改变绘制位置，不修改 e.c / e.r / e.fx / e.fy 等任何逻辑数据。
 * ============================================================ */
function walkHop(ent, ampPx) {
  const cfg = FX.walkHop;
  const prog = ent.progress || 0;
  const moving = ent._hopLastProg != null && prog !== ent._hopLastProg;
  ent._hopLastProg = prog;
  // 幅度权重：移动中渐入 1，停下渐出 0
  const target = moving ? 1 : 0;
  ent._hopW = (ent._hopW ?? 0) + (target - (ent._hopW ?? 0)) * 0.2;

  const h = Math.abs(Math.sin(prog * Math.PI * cfg.hopsPerCell)) * ent._hopW;   // 0 = 着地，1 = 最高点
  const k = cfg.squash * ent._hopW * (1 - 2 * h);   // 着地压扁（k>0），空中拉长（k<0）
  return { lift: h * ampPx, sx: 1 + k, sy: 1 - k, h };
}

/** 在 (cx, footY) 处画一个随离地高度变淡变小的影子 */
function drawHopShadow(ctx, cx, footY, width, h) {
  const a = FX.walkHop.shadowAlpha * (1 - h * 0.5);
  if (a <= 0) return;
  ctx.save();
  ctx.fillStyle = `rgba(0,0,0,${a})`;
  ctx.beginPath();
  ctx.ellipse(cx, footY, width * 0.32 * (1 - h * 0.25), width * 0.08, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** 以脚底中点为锚做蹦跳变换（抬高 + 压扁/拉长），调用方负责 save/restore */
function applyHopTransform(ctx, cx, footY, hop) {
  ctx.translate(cx, footY - hop.lift);
  ctx.scale(hop.sx, hop.sy);
  ctx.translate(-cx, -footY);
}

/* ============================================================
 * 帅（主公）与红心
 * ============================================================ */
function renderKing(ctx) {
  const k = game.king;
  if (!k) return;
  const img = getImg('red_character');
  const size = renderState.tile;
  // 用连续坐标 fx/fy 渲染 → 平滑移动
  const { x, y } = cellPosition(k.fx ?? k.c, k.fy ?? k.r);

  const hop = walkHop(k, FX.walkHop.kingAmp);
  const cx = x + size / 2, footY = y + size - 4;
  drawHopShadow(ctx, cx, footY, size, hop.h);

  ctx.save();
  applyHopTransform(ctx, cx, footY, hop);
  // 阵亡：轻微、快速地左右 / 上下颤抖（持续到结算弹窗）
  if (game.dead) {
    const t = performance.now() / 1000;
    const a = FX.kingDeath.shakePx;
    ctx.translate(Math.sin(t * 47) * a + Math.sin(t * 29) * a * 0.5,
                  Math.cos(t * 41) * a * 0.4);
  }
  // 到位后的呼吸：以脚底为锚，身体缓慢轻微地纵向起伏（略微拉高 / 压回），持续到对局结束
  if (k.arrived && !game.dead) {
    const cfg = FX.kingBreath;
    // 血量越低呼吸越急促：按剩余红心查表得到一次呼吸的时长；
    // 相位连续累加（而不是 时间 / 周期），换频率时不会突然跳变
    const period = cfg.periodByLives[Math.max(1, Math.min(KING.hp, effectiveLives(game.cur)))] ?? cfg.period;
    const now = performance.now() / 1000;
    const dtB = k._breathLast != null ? Math.min(0.1, now - k._breathLast) : 0;
    k._breathLast = now;
    k._breathPhase = (k._breathPhase ?? 0) + dtB * Math.PI * 2 / period;
    // 刚到位时幅度从 0 渐入，避免和蹦跳衔接时突然一跳
    k._breathW = Math.min(1, (k._breathW ?? 0) + 0.02);
    const s = Math.sin(k._breathPhase) * cfg.amount * k._breathW;
    ctx.translate(cx, footY);
    ctx.scale(1 - s * 0.4, 1 + s);
    ctx.translate(-cx, -footY);
  }
  if (img) ctx.drawImage(img, x, y, size, size);
  drawText(ctx, pieceDisplayName(k), x + size / 2, y + size / 2 + 2,
    { size: 20, fill: '#fff3d6', stroke: '#7d1010', align: 'center', bold: true });

  // 红心在「帅」字下方、棋子底部边缘处（跟着帅一起蹦跳 / 呼吸）
  const hy = y + size - 6;
  ctx.font = '9px GuoFeng, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = 2;
  ctx.strokeStyle = '#fff3d6';
  ctx.fillStyle = '#e33';
  const permanent = Math.max(0, game.lives || 0);
  const total = effectiveLives(game.cur);
  for (let i = 0; i < total; i++) {
    ctx.fillStyle = i < permanent ? '#e33' : '#7ed6e8';
    const hx = x + size / 2 - (total - 1) * 5 + i * 10;
    ctx.strokeText('♥', hx, hy);
    ctx.fillText('♥', hx, hy);
  }
  ctx.restore();
}

/* ============================================================
 * 敌人
 * ============================================================ */
// 死亡闪烁用的离屏画布（把敌人剪影染白，只覆盖像素本身，不铺白底）
let _fxCanvas = null;

/** 生成一张「纯白剪影」的图片：只把原图不透明像素染白，透明处保持透明 */
function whitenedSprite(img) {
  if (!_fxCanvas) {
    _fxCanvas = document.createElement('canvas');
    _fxCanvas.width = 128;
    _fxCanvas.height = 128;
  }
  const c = _fxCanvas;
  const cx = c.getContext('2d');
  cx.clearRect(0, 0, c.width, c.height);
  cx.globalCompositeOperation = 'source-over';
  cx.drawImage(img, 0, 0, 128, 128);
  // 只保留图片本身的形状区域，用白色填充
  cx.globalCompositeOperation = 'source-in';
  cx.fillStyle = '#ffffff';
  cx.fillRect(0, 0, c.width, c.height);
  cx.globalCompositeOperation = 'source-over';
  return c;
}

function renderEnemies(ctx) {
  const baseSize = 40;   // 普通敌人画小一点
  const flashDur = ENEMY_FX.deathFlashMs / 1000;
  const tile = renderState.tile;

  for (const e of game.enemies) {
    if (e.done) continue;

    // 死亡：立刻闪白，再快速明暗交替几次后消失（第一帧就是白色，无延迟）
    // 把死亡时长分成 6 段，奇偶交替；t=0 落在「亮」段 → 立刻白闪
    let dyingWhite = false;
    if (e.dying) {
      const seg = Math.floor((e.deathT / flashDur) * 6);
      dyingWhite = (seg % 2) === 0;
    }

    if (!e.dying || dyingWhite) {
      const img = getImg(e.spriteKey || 'green_character');
      const pos = cellPosition(e.fx ?? e.c, e.fy ?? e.r);
      const scale = e.spriteScale || 1;
      const size = baseSize * scale;
      const x = pos.x + (tile - size) / 2;
      const y = pos.y + (tile - size) / 2;

      const hop = walkHop(e, FX.walkHop.enemyAmp);
      const midX = x + size / 2, footY = y + size - 2;
      drawHopShadow(ctx, midX, footY, size, hop.h);

      ctx.save();
      applyHopTransform(ctx, midX, footY, hop);
      if (img) {
        ctx.drawImage(img, 0, 0, 128, 128, x, y, size, size);
        if (e.dying) {
          // 叠加白色剪影（只覆盖敌人像素，不铺白底）
          ctx.drawImage(whitenedSprite(img), 0, 0, 128, 128, x, y, size, size);
        }
      }
      // 敌人标识：中间一个黑色「寇」字（死亡白闪时不画）
      if (!e.dying) {
        drawText(ctx, e.displayName || (e.isBoss ? '王' : '寇'), x + size / 2, y + size / 2 + 1,
          { size: e.isBoss ? 25 : 17, fill: e.isBoss ? '#ffd75e' : '#111', stroke: e.isBoss ? '#7d1010' : 'rgba(255,255,255,0.7)', align: 'center' });
      }
      ctx.restore();

      // 血条（跟随身体抬起，但不随压扁变形）
      const by = y - 4 - hop.lift;
      const ratio = e.hp / e.maxHp;
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(x, by, size, 3);
      ctx.fillStyle = ratio > 0.5 ? '#7be07b' : ratio > 0.25 ? '#e0c34d' : '#e05a5a';
      ctx.fillRect(x, by, size * Math.max(0, ratio), 3);
    }
  }
}

/** Boss出生提示固定在当前画布正中，不随棋盘坐标或翻转移动。 */
function renderBossAnnouncement(ctx, W, H) {
  const notice = activeBossAnnouncement(game.cur);
  if (!notice) return;
  const left = Math.max(0, notice.until - (game.cur.gameTime || 0));
  const alpha = Math.min(1, left / 0.35);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.font = 'bold 42px GuoFeng, sans-serif';
  ctx.lineWidth = 6; ctx.strokeStyle = '#3b1010'; ctx.fillStyle = '#ffd75e';
  ctx.strokeText(notice.text, W / 2, H / 2);
  ctx.fillText(notice.text, W / 2, H / 2);
  ctx.restore();
}

/** 车冲刺时的「风」线条：车后方几条浅灰色细线 */
function drawChargeWind(ctx, p, x, y, size) {
  const ch = p.charge;
  if (!ch) return;
  // 风线从车身向后拖出，方向与冲刺相反
  const direction = vectorToView(-ch.dc, -ch.dr, renderState.sideways, renderState.flip);
  const bx = direction.x, by = direction.y;
  ctx.save();
  ctx.strokeStyle = JU_CHARGE.color;
  ctx.lineWidth = 1.5;
  ctx.globalAlpha = 0.7;

  const centerX = x + size / 2, centerY = y + size / 2;
  const n = JU_CHARGE.windLines;
  for (let i = 0; i < n; i++) {
    const off = (i - (n - 1) / 2) * (size * 0.18);   // 平行偏移（垂直车向）
    const len = size * (0.7 + (i % 2) * 0.3);         // 不同长度更自然
    ctx.beginPath();
    ctx.moveTo(centerX + bx * len * 0.2 - by * off, centerY + by * len * 0.2 + bx * off);
    ctx.lineTo(centerX - bx * len - by * off, centerY - by * len + bx * off);
    ctx.stroke();
  }
  ctx.restore();
}

/* ============================================================
 * 子弹
 * ============================================================ */
function renderBullets(ctx) {
  const half = renderState.tile / 2;
  for (const b of game.bullets) {
    const t = b.t / b.dur;
    const img = getImg(b.color === 'red' ? 'red_bullet' : 'black_bullet');
    const start = cellPosition(b.fromC, b.fromR), end = cellPosition(b.toC, b.toR);
    const from = { x: start.x + half, y: start.y + half };
    const to = { x: end.x + half, y: end.y + half };
    const x = from.x + (to.x - from.x) * t;
    const y = from.y + (to.y - from.y) * t;
    const s = 16 * (b.scale || 1);          // 炮的子弹更大
    if (img) ctx.drawImage(img, x - s / 2, y - s / 2, s, s);
  }
}

/* ============================================================
 * 羁绊特效
 * ============================================================ */
function renderBondBoxes(ctx, time) {
  const boxes = BONDEFFECT.updateBondEffects();
  for (const box of boxes) {
    const projected = {
      ...box,
      a: boardToView(box.a.c, box.a.r, game.map, renderState.sideways, renderState.flip),
      b: boardToView(box.b.c, box.b.r, game.map, renderState.sideways, renderState.flip),
    };
    const pixel = n => n * renderState.tile;
    BONDEFFECT.drawBondBox(ctx, pixel, pixel, renderState.tile, projected, time);
  }
}

function renderBondPopup(ctx, time, W, H) {
  const pop = BONDEFFECT.currentBondPopup();
  if (!pop) return;
  ctx.save();
  ctx.font = `bold ${Math.round(34 * pop.scale)}px GuoFeng, serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  let color = pop.branch === 'red' ? BOND_EFFECT.red.stroke : BOND_EFFECT.black.stroke;
  if (pop.branch !== 'red' && pop.branch !== 'black') {
    const half = ctx.measureText(pop.name).width / 2;
    const gradient = ctx.createLinearGradient(W / 2 - half, 0, W / 2 + half, 0);
    gradient.addColorStop(0, BOND_EFFECT.mix.strokeA);
    gradient.addColorStop(0.48, BOND_EFFECT.mix.strokeA);
    gradient.addColorStop(0.52, BOND_EFFECT.mix.strokeB);
    gradient.addColorStop(1, BOND_EFFECT.mix.strokeB);
    color = gradient;
  }
  ctx.globalAlpha = pop.alpha;
  ctx.strokeStyle = '#fff3d6';
  ctx.lineWidth = 4;
  ctx.strokeText(pop.name, W / 2, H * 0.4);
  ctx.fillStyle = color;
  ctx.fillText(pop.name, W / 2, H * 0.4);
  ctx.restore();
}

/* ============================================================
 * 拖拽渲染
 * ============================================================ */
function renderDrag(ctx) {
  const d = game.drag;
  if (!d.active) return;

  // 悬停格子反馈：可放置 / 不可放置
  if (d.hoverCell) {
    const tile = renderState.tile;
    const { x, y } = cellPosition(d.hoverCell.c, d.hoverCell.r);
    const ok = d.hoverKind === 'plot' || d.hoverKind === 'piece';
    ctx.save();
    ctx.strokeStyle = ok ? 'rgba(90,255,120,0.9)' : 'rgba(255,70,70,0.8)';
    ctx.lineWidth = 3;
    ctx.setLineDash([5, 3]);
    ctx.strokeRect(x, y, tile, tile);
    ctx.restore();

    // 攻击范围预览：只要悬停的不是路径格（原位 / 空地 / 草地 / 其它棋子上都算），
    // 就预览该位置的 road 格：可攻击用浅红，被棋子阻挡用浅黑
    if (!game.map.road[d.hoverCell.r]?.[d.hoverCell.c]) {
      drawAttackPreview(ctx, d.hoverCell);
    }
  }
  // 跟随鼠标的棋子 / 卡牌幽灵不画在棋盘画布里（会被画布边界裁掉，在商店上方看不到），
  // 改由 renderDragGhost 画在覆盖整个舞台的拖拽层上。
}

/**
 * 拖拽幽灵：画在全舞台覆盖层（main 的 #drag-layer）上，商店区 / 棋盘外也能看见。
 * 调用方已用 setTransform 把坐标缩放到「棋盘逻辑像素」（1 格 = renderState.tile），
 * x / y 为同一坐标系下的指针位置。
 */
export function renderDragGhost(ctx, x, y) {
  const d = game.drag;
  if (!d.active) return;

  if (d.piece) {
    // 画一个跟随鼠标的放大棋子幽灵，带半透明光环反馈「拿在手上」
    const s = renderState.tile * 1.4;   // 放大 1.4 倍，更醒目
    const gx = x - s / 2;
    const gy = y - s / 2;

    ctx.save();
    // 光环
    ctx.beginPath();
    ctx.arc(x, y, s * 0.62, 0, Math.PI * 2);
    ctx.fillStyle = d.piece.color === 'red' ? 'rgba(255,110,110,0.18)' : 'rgba(140,130,255,0.20)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,240,170,0.55)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.restore();

    const img = getImg(d.piece.color === 'red' ? 'red_character' : 'black_character');
    if (img) ctx.drawImage(img, gx, gy, s, s);
    drawText(ctx, pieceDisplayName(d.piece), gx + s / 2, gy + s / 2 + 2,
      { size: s * 0.42, fill: d.piece.color === 'red' ? '#fff3d6' : '#ffe9a8',
        stroke: d.piece.color === 'red' ? '#7d1010' : '#000', align: 'center', bold: true });
    // 底部显示当前阶数，方便判断能否继续融合
    drawText(ctx, `${d.piece.stage || 0}阶`, gx + s / 2, gy + s - 11,
      { size: s * 0.2, fill: '#ffd75e', stroke: '#222', align: 'center', bold: true });
  } else if (d.card) {
    drawDraggedCard(ctx, d.card, x, y);
  }
}

/** 攻击范围预览：可攻击的路径格保持浅红，被棋子阻挡的路径格用浅黑 */
function drawAttackPreview(ctx, cell) {
  const info = draggedPieceInfo(game.drag);
  if (!info) return;

  // 关键：把真实棋子的标记 / 等级 / 激活羁绊透传给判定，
  // 否则预览高亮与实战不一致（免马腿 / 免象眼 / 士象全 共享范围等新格子不会亮）。
  // 拖场上棋子时它还占着原位：预览期间暂时把它移出棋盘，避免自己挡住自己（象眼 / 马腿 / 车炮直线）。
  const dragged = game.drag.from === 'board' ? game.drag.piece : null;
  const idx = dragged ? game.pieces.indexOf(dragged) : -1;
  if (idx >= 0) game.pieces.splice(idx, 1);
  let preview;
  try {
    preview = computeAttackPreview(
      info.type, info.color, cell.c, cell.r,
      info.flags, info.level, info.activeBonds);
  } finally {
    if (idx >= 0) game.pieces.splice(idx, 0, dragged);
  }
  if (!preview.hits.length && !preview.blocked.length && !preview.support.length) return;

  const tile = renderState.tile;
  ctx.save();
  for (const { c, r } of preview.blocked) {
    const { x, y } = cellPosition(c, r);
    ctx.fillStyle = 'rgba(35,35,35,0.20)';
    ctx.fillRect(x + 1, y + 1, tile - 2, tile - 2);
    ctx.strokeStyle = 'rgba(35,35,35,0.40)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x + 1, y + 1, tile - 2, tile - 2);
  }
  for (const { c, r } of preview.support) {
    const { x, y } = cellPosition(c, r);
    ctx.fillStyle = 'rgba(65,225,105,0.30)';
    ctx.fillRect(x + 1, y + 1, tile - 2, tile - 2);
    ctx.strokeStyle = 'rgba(80,255,125,0.85)';
    ctx.lineWidth = 2;
    ctx.strokeRect(x + 1, y + 1, tile - 2, tile - 2);
  }
  for (const { c, r } of preview.hits) {
    const { x, y } = cellPosition(c, r);
    // 浅红填充 + 描边
    ctx.fillStyle = 'rgba(255,80,80,0.28)';
    ctx.fillRect(x + 1, y + 1, tile - 2, tile - 2);
    ctx.strokeStyle = 'rgba(255,110,110,0.7)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x + 1, y + 1, tile - 2, tile - 2);
  }
  ctx.restore();
}

/** 拖拽中的商店卡牌幽灵 */
function drawDraggedCard(ctx, card, x, y) {
  const s = 48;
  ctx.save();
  ctx.font = '24px GuoFeng, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  // 兵/棋子卡：只画棋子素材本身（透明背景），不画任何底板框
  if (card.type === 'piece') {
    const img = getImg(card.color === 'red' ? 'red_character' : 'black_character');
    if (img) ctx.drawImage(img, x - s, y - s, s * 2, s * 2);
    drawText(ctx, '兵', x, y + 3, { size: 24, fill: '#fff', stroke: '#222', align: 'center', bold: true });
    ctx.restore();
    return;
  }

  // 铲子：只画素材本身（透明背景）
  if (card.type === 'shovel') {
    const img = getImg('shovel');
    if (img) ctx.drawImage(img, 0, 0, 87, 162, x - 24, y - 48, 48, 90);
    ctx.restore();
    return;
  }

  // 法术牌 / 其它：浅色半透明纸底（能看清下面的棋盘），墨线描边
  ctx.fillStyle = 'rgba(251,248,241,0.45)';
  roundRectPath(ctx, x - s, y - s, s * 2, s * 2, 8);
  ctx.fill();
  ctx.strokeStyle = 'rgba(184,50,42,0.75)';
  ctx.lineWidth = 2;
  ctx.stroke();

  if (card.type === 'spell') {
    drawText(ctx, '术', x, y - 2, { size: 30, fill: '#b8322a', stroke: 'rgba(255,255,255,0.8)', align: 'center' });
    drawText(ctx, card.name || '', x, y + 26, { size: 12, fill: '#2b2620', stroke: 'rgba(255,255,255,0.85)', align: 'center' });
  }
  ctx.restore();
}

/* ============================================================
 * 通用文字 / 路径工具
 * ============================================================ */
function drawText(ctx, text, x, y, opt) {
  ctx.save();
  // 仓耳周珂正大榜书本身是很粗的榜书字体，不再叠加浏览器「伪加粗」（会把笔画糊在一起）；
  // opt.bold 仅保留语义，不写进 font。
  const size = opt.size || 12;
  ctx.font = `${size}px GuoFeng, sans-serif`;
  ctx.textAlign = opt.align || 'left';
  ctx.textBaseline = 'middle';
  // 描边宽度随字号缩放并保持纤细：粗描边会填满笔画间的空隙，导致字糊成一坨
  ctx.lineWidth = Math.max(1, size * 0.09);
  ctx.lineJoin = 'round';
  ctx.strokeStyle = opt.stroke || '#000';
  ctx.strokeText(text, x, y);
  ctx.fillStyle = opt.fill || '#fff';
  ctx.fillText(text, x, y);
  ctx.restore();
}

function roundRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export default { render, renderState, finalAtk, pieceBaseAtk, drawPiece, cellPosition };