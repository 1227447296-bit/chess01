/**
 * config.js —— 全局配置中心
 * 所有数值、资源路径、概率、卡池、法术、增益全部集中在此，逻辑代码不硬编码。
 * 需要调数值 / 换素材 / 加关卡，只改这个文件。
 */

/* ============================================================
 * 一、资源配置（所有图片 / 字体路径集中管理）
 * ============================================================ */
export const RES = {
  /** 国风中文字体（项目自带，禁止使用系统默认字体） */
  fonts: {
    guofeng: {
      family: 'GuoFeng',
      url: 'font/仓耳周珂正大榜书.ttf',
      format: 'truetype',
    },
  },
  /** 图片素材 */
  images: {
    tilesheet:      'assets/tiles/tilesheet.png', // Tiled 图集（Ground / grass / road 层共用）
    black_character:'piece/black_character.png',  // 黑色棋子底图（兵/士/象/马/车/炮 共用）
    red_character:  'piece/red_character.png',    // 红色棋子底图（同上复用）
    green_character:'piece/green_character.png',  // 敌人底图
    black_bullet:   'piece/black_bullet.png',     // 黑方子弹
    red_bullet:     'piece/red_bullet.png',       // 红方子弹
    shovel:         'piece/genericItem_color_022.png', // 铲子
  },
  /**
   * 地图文件：每局从 board/ 目录里随机挑一张，按 TMX 实际宽高自动排版。
   * 本地 serve.ps1 自动列出 board数字.tmx（也支持 board01 等补零编号）。
   * 发布静态网站前运行 update-maps.ps1 更新 board/maps.json，并随地图一起上传。
   * 如需给某个编号指定特殊路径，可在 maps 里加一行 `5: 'board/xxx.tmx'`。
   */
  boardDir: 'board/',
  mapFilePattern: 'board{n}.tmx',   // 自动拼路径，n 为地图编号
  maps: {},
};

/**
 * Tiled 图集参数（对应 board1.tmx 里引用的 sampleSheet.tsx）。
 * 说明：tmx 内引用的 tsx 使用了项目外相对路径，无法直接解析，
 *      因此图集参数在这里显式声明，tmx 只用来读「图层数据 + 对象层」。
 */
export const TILESET = {
  tileWidth: 64,
  tileHeight: 64,
  columns: 14,
  image: RES.images.tilesheet,
};

/** 地图网格逻辑尺寸（与 tmx 保持一致：8 列 × 16 行，每格 60px） */
export const GRID = {
  cols: 8,
  rows: 16,
  tile: 60,          // 逻辑像素，等于 tmx 的 tilewidth/tileheight
  // 图层名（严格对应 Tiled 里的图层名）
  layerGround: 'Ground',
  layerGrass: 'grass',
  layerRoad: 'road',
  objEnemy: 'enemy',
  objKing: 'king',
};

/* ============================================================
 * 二、己方棋子基础数值
 * 攻击冷却 = 两次攻击之间的间隔（秒）；冷却读完后才可发起下一次攻击
 * ============================================================ */
export const PIECE_STATS = {
  bing:  { name: '兵', atk: 12, cd: 1.4 },
  shi:   { name: '士', atk: 18, cd: 1.6 },
  xiang: { name: '象', atk: 22, cd: 2.0 },
  ma:    { name: '马', atk: 20.8, cd: 1.8 },   // 原 26，削减 20%
  ju:    { name: '车', atk: 30.4, cd: 2.2 },   // 原 38，削减 20%
  pao:   { name: '炮', atk: 25.6, cd: 2.4 },   // 原 32，削减 20%
};

/** 仅用于显示，红黑异字不改变棋种或规则。 */
const PIECE_DISPLAY_NAMES = {
  red: { king: '帅', shi: '仕', xiang: '相', ju: '车', ma: '马', pao: '炮', bing: '兵' },
  black: { king: '将', shi: '士', xiang: '象', ju: '車', ma: '馬', pao: '砲', bing: '卒' },
};
export function pieceDisplayName(piece) {
  return PIECE_DISPLAY_NAMES[piece.color === 'black' ? 'black' : 'red'][piece.type] || PIECE_STATS[piece.type]?.name || '';
}

/**
 * 全局攻速倍率：作用于所有棋子的最终攻击冷却。
 * 冷却越短攻速越快 —— 数值 <1 表示加速。当前 0.7（整体提速约 30%）。
 * 想再调快/调慢只改这一处即可。
 */
export const GLOBAL_ATK_SPEED_SCALE = 0.7;

/** 棋子颜色 */
export const COLORS = { red: 'red', black: 'black' };

/** 棋子叠字配色（底图上的中文标识，做对比度适配） */
export const PIECE_TEXT_STYLE = {
  red:   { fill: '#fff3d6', stroke: '#7d1010' },
  black: { fill: '#ffe9a8', stroke: '#000000' },
};

/* ============================================================
 * 三、等级 / 经验 / 战力加成
 * ============================================================ */
export const LEVEL = {
  /** 每 1 级攻击力 +2%（基础攻击 × (1 + 等级 × levelAtkRate)） */
  levelAtkRate: 0.02,
  /** 每级冷却因子-.003，最低.8；等级上限60。 */
  levelCdRate: 0.003,
  cdMinRate: 0.8,
  expBase: 20,
  killTeamExp: 8, killBonus: 2, assistBonus: 1,
  waveExpBase: 20, waveExpPerWave: 2,
  /** 升级所需经验 = expBase + 本级等级 × expPerLevelFactor */
  expPerLevelFactor: 5,
  /** 硬封顶，任何融合 / 打怪都不可超过 */
  hardCap: 999,
  /** 各棋子自然升级上限（仅指打怪经验路线，融合不受此限制）
   *  全部棋子统一 999 级 */
  naturalCap: {
    bing: 999,
    shi: 999,
    xiang: 999,
    ju: 999,
    ma: 999,
    pao: 999,
  },
  /** 兼容旧模块字段；战斗统一全场8经验，不再按阶数奖励。 */
  expByRank: Object.fromEntries(['bing', 'shi', 'xiang', 'ju', 'ma', 'pao'].map(type =>
    [type, { 0: 8, 1: 8, 2: 8, 3: 8 }])),
};

/* ============================================================
 * 三·五、击杀金币
 * ============================================================ */
export const GOLD_ON_KILL = {
  default: 2,
};

/** 「二鬼拍门」羁绊：每组激活中的羁绊，每隔 intervalSec 秒产出 gold 金币（暂停时不计时） */
export const BOND_GOLD_TICK = { intervalSec: 10, gold: 1 };

/* ============================================================
 * 三·六、等级解锁机制（达到指定等级后自动生效，纯机制、无数值 buff）
 * ============================================================ */
export const experienceRequired = level => LEVEL.expBase + LEVEL.expPerLevelFactor * Math.max(0, level || 0);
export const CRITICAL = { rate: 0.10, damage: 1.2, maxRate: 0.5, maxDamage: 2 };

/** 界面显示倍率：攻击、血量、伤害飘字统一×100，只影响显示，不改内部数值。 */
export const DISPLAY_SCALE = 100;
export const displayNumber = value => Math.round((value || 0) * DISPLAY_SCALE);

/** 每个等级只解锁一项；羁绊由 BOND_CONFIG 的等级门槛在同一等级展示。 */
export const LEVEL_UNLOCK = {
  bing: { 15: 'bingFocus', 20: 'bingBackSpeed' },
  shi: { 20: 'shiMultiTarget', 30: 'shiGroundAura' },
  xiang: { 20: 'xiangNoEye', 30: 'xiangEyeControl' },
  ju: { 50: 'juColumn', 70: 'juReturnDmg', 80: 'juFullReturn' },
  ma: { 50: 'maStun3', 70: 'maBlockedAttack', 80: 'maNoHorseLeg', 90: 'maImmuneDamage' },
  pao: { 50: 'paoBlast2', 70: 'paoSlow', 80: 'paoCarriage3' },
};

/** 车 20 级秒杀概率 */
export const JU_CRIT = { chance: 0.10 };
/** 炮100级允许1~3枚炮架，100级前普通情形恰好1枚。 */
export const PAO_CARRIAGE = { min: 1, max: 3 };
/** 炮80级解锁30%减速，持续1秒。 */
export const PAO_SLOW_SECONDS = 1;

/* ============================================================
 * 四、敌人与波次
 * ============================================================ */
export const ENEMY = {
  baseHp: 30,               // 基础血量（已减半：原 60）
  baseSpeed: 0.65,          // 格 / 秒
  hpGrowPerWave: 9,         // 每往后一波血量 +9
  speedGrowPerWave: 0.02,   // 格/秒，每波增加
  maxSpeed: 1.25,
  hpLateRate: 1.10, hpLateAfterWave: 10,
  hpEndRate: 1.12, hpEndAfterWave: 24,
  growthEnabled: true,      // 成长总开关（关掉即可测试基础数值）
  killGold: 2,              // 击杀奖励金币
  imgSize: 128,
  /**
   * 第 N 波之后血量提升（不累计，只乘一次）。
   * hpDoubleAfterWave = 15 表示「第 15 波之后」（即第 16 波起）敌人血量 ×hpDoubleFactor。
   * （养成放慢后由第 10 波推迟到第 15 波，给车马炮成型留出时间）
   */
  hpDoubleAfterWave: 15,
  hpDoubleFactor: 1.5,
};

export const WAVES = {
  firstWaveCount: 5,        // 第 1 波 5 只
  countGrowPerWave: 1,      // 每波 +1（第 n 波 = 4 + n 只）
  spawnInterval: 1.5,       // 同波内出怪间隔（秒）
  waveInterval: 5,          // 波与波之间的间隔（秒）
  startDelay: 6,            // 帅走到位后，到第 1 波出怪的准备时间（秒）：留时间买兵、布阵
};

/** 唯一敌人波次公式，真实出怪、AI计划共用；旧 double 字段仅兼容，不参与计算。 */
export function enemyStatsForWave(wave, enemy = ENEMY) {
  const n = Math.max(1, wave), index = n - 1;
  if (!enemy.growthEnabled) return { hp: enemy.baseHp, speed: enemy.baseSpeed };
  return {
    hp: (enemy.baseHp + enemy.hpGrowPerWave * index)
      * (enemy.hpLateRate ?? 1.10) ** Math.max(0, n - (enemy.hpLateAfterWave ?? 10))
      * (enemy.hpEndRate ?? 1.12) ** Math.max(0, n - (enemy.hpEndAfterWave ?? 24)),
    speed: Math.min(enemy.maxSpeed ?? 1.25, enemy.baseSpeed + enemy.speedGrowPerWave * index),
  };
}
export function spawnIntervalForWave(wave) { return wave <= 10 ? 1.5 : wave <= 20 ? 1.35 : wave <= 24 ? 1.2 : 1; }

/** 帅（主公）配置 */
export const KING = {
  hp: 3,                    // 3 颗红心
  speedKnife: 2.2,          // 出生点走向 king 点的速度（格/秒）
};

/* ============================================================
 * 五、商店配置
 *
 * 养成节奏估算（击杀 2 金币、开局 20 金币）：
 *   原生棋子卡全部为兵；士/象、车/马/炮只能由融合自动进化或实验法术产生。
 *   新：20×6 + (4+7+10+13+16+19) ≈ 190 金币 → 约 85 次击杀 → 约第 10 波（约 4~5 分钟）
 *   旧：20×4 + (3+5+7+9+11)      ≈ 115 金币 → 约 48 次击杀 → 约第 5 波（约 2 分钟）
 * ============================================================ */
export const SHOP = {
  slotCount: 5,             // 商店卡位数量
  /** 刷新费用：首次刷新免费（0），之后第 1 次付费 4，再每次 +3（4 → 7 → 10 …） */
  refreshFirstFree: true,   // 首次刷新免费总开关
  refreshBaseCost: 4,       // 首次付费价（也是免费后恢复的价格）
  refreshCostStep: 3,
  /** 铲子总数上限：玩家「实际使用」满 10 把后不再刷出铲子；刷新掉未使用的铲子不计入 */
  shovelMaxUsed: 10,

  /** 原生卡牌固定售价 */
  price: {
    piece: 6,               // 红兵 / 黑兵
    shovel: 1,              // 铲子（已改：1 金币）
  },

  /** 卡池基础权重 */
  weights: {
    pieceRedBing: 30,
    pieceBlackBing: 30,
    shovel: 14,
    spell: 26,
  },

  /** 解锁波次；实验版原生棋子卡固定全部为兵，其他棋种只可由融合/法术产生。 */
  piecePool: [
    { type: 'bing', wave: 0, price: 6, weight: 60, level: 0 },
  ],
  spellTierWeight: { 1: 100, 2: 45, 3: 22 },
  /** 按实际波次解锁，而非刷新次数。 */
  spellTierUnlock: { 1: 0, 2: 5, 3: 12 },
};

/* ============================================================
 * 六、棋子合成规则
 * ============================================================ */
export const MERGE = {
  needCount: 3,               // 达到3阶时自动随机进化；不再提供2阶主动进化
  maxStage: 3,                // 所有棋种统一0..3阶
  levelBonus: 3,
  levelCap: 999,
  evolutionChoiceCount: 2,
  fromBing: ['shi', 'xiang'],
  fromShiXiang: ['ju', 'ma', 'pao'],
};

/* ============================================================
 * 六·五、车 / 马 / 炮 的「阶（rank）」机制
 * 等级(level) 与阶(rank) 独立：
 *   - 等级：击杀打怪提升，决定数值与等级技能
 *   - 阶  ：同种同色融合时提升；兵/士/象达到3阶自动进化，车/马/炮不进化
 * ============================================================ */
export const RANK = {
  max: 3,
  /** 0..3阶只提供暴击；兵/士/象到3阶即进化，3阶暴击仅车/马/炮实际持有。 */
  critByStage: [
    { rate: 0, damage: 0 },
    { rate: 0.10, damage: 0.20 },
    { rate: 0.20, damage: 0.40 },
    { rate: 0.40, damage: 0.80 },
  ],
  /** 不进化、只升阶的棋子 */
  rankTypes: ['ju', 'ma', 'pao'],
};

/**
 * 车：冲刺（棋子本体沿攻击方向冲出去）
 */
export const JU_CHARGE = {
  speed: 12,          // 冲刺速度（格/秒）
  returnSpeed: 18,    // 返回速度
  color: '#c9ccd2',   // 风线条颜色（浅灰）
  windLines: 3,       // 车尾部风线条数量
};

/**
 * 炮：爆炸范围以「高 × 宽」(纵向格数 × 横向格数) 表示。
 * 基础1×1（单格）；50级解锁「paoBlast2」后为3×3。与阶数无关。
 */
export const PAO_BLAST = {
  baseHigh: 1,
  baseWide: 1,
  bulletScale: 1.9,   // 炮的子弹素材放大倍数（比普通棋子大）
};

/**
 * 马：践踏（本体冲到目标格，造成十字 5 格伤害 + 眩晕）
 *   基础眩晕0.5秒；50级1秒，50级不再延长常规眩晕。与阶数无关。
 *   眩晕结束后进入眩晕免疫（时长按本次眩晕时长查 stunImmuneByStun）；
 *   眩晕中不可被再次眩晕 / 延长 —— 控制占比上限 = 眩晕 /（眩晕 + 免疫），攻速再快也不会永晕。
 *   眩晕期间正常受伤、可被打死。
 *   马不再发射子弹：本体快速冲到攻击格，践踏后慢速返回原位。
 */
export const MA_STOMP = {
  stunSeconds: 0.5,          // 基础眩晕
  stunSecondsLv20: 1,        // 兼容字段名；50级解锁「maStun3」后
  stunSecondsLv50: 2,        // 旧配置兼容，常规攻击不读取
  bondStunSeconds: 0.5,      // 「马炮合势」羁绊：炮命中附带的眩晕
  /** 眩晕时长 → 眩晕结束后的免疫时长（控制占比上限：20% / 29% / 33%） */
  stunImmuneByStun: { 0.5: 2, 1: 2.5, 2: 4 },
  stunImmuneDefault: 2.5,    // 未在上表中的眩晕时长使用的免疫
  /** 马冲刺参数：冲出去快，返回慢 */
  outSpeed: 14,        // 冲向目标的速度（格/秒）
  backSpeed: 6,        // 返回原位速度（慢）
};

/* ============================================================
 * 六·六、敌人状态（眩晕 / 死亡特效）
 * ============================================================ */
export const ENEMY_FX = {
  /** 死亡：先闪烁一下再消失 */
  deathFlashMs: 180,
  deathFlashColor: '#ffffff',
  /** 眩晕：头顶显示星环 */
  stunColor: '#ffe74d',
};

/* ============================================================
 * 七、法术牌配置（spellList）
 * kind : 'target' 拖到场上棋子上生效 | 'none' 无目标（拖出商店即生效）
 * tier : 1/2/3 阶（解锁门槛见 SHOP.spellTierUnlock）
 * stock: 本局库存 —— 「实际使用」满该次数后不再刷出（刷新掉未用的不计，同铲子规则）
 * restrict（可选）：目标限制，见 spell.js validate
 *
 * 数值参照（击杀 2 金币、兵 6 金币）：一阶 ≈ 1 个兵的价值，二阶 ≈ 1.5~2 个兵，三阶 ≈ 3 个兵以上。
 * ============================================================ */
export const SPELLS = [
  { id: 'mantianguohai', tier: 1, kind: 'target', price: 4, stock: 1, name: '瞒天过海', desc: '单棋转换红黑色', detail: '指定一枚场上棋子转换红黑色，保留等级、阶数和全部强化。', role: 'growth', effect: { type: 'flipColor' } },
  { id: 'weiweijiuzhao', tier: 2, kind: 'none', price: 9, stock: 1, name: '围魏救赵', desc: '全体敌人后退1格', detail: '本盘当前全体敌人沿真实道路后退1格，最低到出生点。与其他位移法术共用10秒冷却，后来出生的敌人不受影响。', role: 'rescue', effect: { type: 'retreat', cells: 1, cooldown: 10 } },
  { id: 'jiedaosharen', tier: 2, kind: 'target', price: 10, stock: 1, name: '借刀杀人', desc: '借单棋攻击全体敌人', detail: '指定本方棋子，对当前全体敌人造成其攻击力80%的伤害。不暴击、不触发普通攻击被动、金币或特殊技蓄势。', role: 'offense', effect: { type: 'damageAll', multiplier: 0.8 } },
  { id: 'yiyidailao', tier: 1, kind: 'target', price: 6, stock: 1, name: '以逸待劳', desc: '单棋伤害+25%·10秒', detail: '指定棋子攻击伤害提高25%，持续10秒。同类限时攻击增益取最高值，不相乘叠加。', role: 'offense', effect: { type: 'buff', rate: 0.25, seconds: 10 } },
  { id: 'chenhuodajie', tier: 1, kind: 'target', price: 5, stock: 1, name: '趁火打劫', desc: '普攻产金·10秒', detail: '指定棋子10秒内每次有效普通攻击获得1金币；一动作命中多目标只算一次，车返程、炮追加、残影和法术攻击不产金。', role: 'growth', effect: { type: 'buff', attackGold: 1, seconds: 10 } },
  { id: 'shengdongjixi', tier: 2, kind: 'none', price: 8, stock: 1, name: '声东击西', desc: '已拥有棋子全部转色', detail: '翻转场上棋子与商店回收棋子的红黑色，同一棋子只翻转一次。未购买的原生棋子卡不改变，保留成长。', role: 'growth', effect: { type: 'flipOwnedColors' } },
  { id: 'wuzhongshengyou', tier: 1, kind: 'none', price: 6, stock: 1, name: '无中生有', desc: '获得9金币', detail: '支付6金币施放，获得9金币，净收益3金币。', role: 'growth', effect: { type: 'gainGold', value: 9 } },
  { id: 'anduchencang', tier: 1, kind: 'cell', price: 0, stock: 1, name: '暗度陈仓', desc: '免费开垦一格草地', detail: '指定一块可挖草地永久开垦，不移动棋子、不消耗铲子卡使用次数。道路、已开垦或被占据的位置不可选。', role: 'growth', effect: { type: 'dig' } },
  { id: 'geanguanhuo', tier: 2, kind: 'target', price: 8, stock: 1, name: '隔岸观火', desc: '单棋获得40~60经验', detail: '指定棋子获得40经验；施放时该棋子没有有效羁绊则获得60经验，遵守正常等级上限。', role: 'growth', effect: { type: 'experience', value: 40, bonus: 60, condition: 'unbonded' } },
  { id: 'xiaolicangdao', tier: 2, kind: 'target', price: 9, stock: 1, name: '笑里藏刀', desc: '永久暴击率+10%', detail: '指定棋子永久暴击率提高10个百分点，每枚棋子只能获得一次；与原会心强化标记兼容，保留至进化。', role: 'growth', effect: { type: 'special', marker: 'huixin', stat: 'critRateBonus', value: 0.10 } },
  { id: 'lidaitaojiang', tier: 3, kind: 'target', price: 14, stock: 1, name: '李代桃僵', desc: '兵随机进化士或象', detail: '指定一枚兵，以相同概率变成士或象，红黑色独立随机；保留等级与强化，阶数回到0，清除攻击动作。', role: 'growth', effect: { type: 'randomEvolve', restrict: 'bing' } },
  { id: 'shunshouqianyang', tier: 1, kind: 'none', price: 5, stock: 1, name: '顺手牵羊', desc: '得2金·下次刷新减5', detail: '获得2金币，下一次付费刷新费用降低5金币，最低为0。首次免费刷新不会消耗优惠；刷新涨价与次数仍按正常付费刷新处理。', role: 'growth', effect: { type: 'refreshDiscount', value: 2, discount: 5 } },
  { id: 'dacaojingshe', tier: 1, kind: 'none', price: 5, stock: 1, name: '打草惊蛇', desc: '全敌3000伤·减速1秒', detail: '当前全体敌人受到3000固定伤害，减速20%持续1秒；后来出生的敌人不继承。不暴击、不触发普通攻击收益。', role: 'rescue', effect: { type: 'damageSlowAll', fixed: 30, rate: 0.2, seconds: 1 } },
  { id: 'jieshihuanhun', tier: 2, kind: 'cell', selection: 'color', price: 10, stock: 1, name: '借尸还魂', desc: '自选颜色召唤5级兵', detail: '在合法空地召唤一枚5级兵，自选红黑色。满场、取消选色或落点不合法时不扣金币、不消耗法术。', role: 'growth', effect: { type: 'spawnBing', value: 5 } },
  { id: 'diaohulishan', tier: 2, kind: 'none', price: 10, stock: 1, name: '调虎离山', desc: '近敌退2格·减速2秒', detail: '最靠近帅的当前敌人沿道路后退2格并减速30%持续2秒；最低到出生点，与其他位移法术共用10秒冷却。', role: 'rescue', effect: { type: 'retreatNearest', cells: 2, rate: 0.3, seconds: 2, cooldown: 10 } },
  { id: 'yuqinguzong', tier: 2, kind: 'none', price: 9, stock: 1, name: '欲擒故纵', desc: '最高血敌易伤20%·5秒', detail: '当前剩余生命最高的敌人5秒内受到的伤害提高20%，后来出生的敌人不继承。', role: 'offense', effect: { type: 'vulnerable', rate: 0.2, seconds: 5 } },
  { id: 'paozhuanyinyu', tier: 1, kind: 'target', price: 6, stock: 1, name: '抛砖引玉', desc: '耗0阶兵·原地生2阶兵', detail: '消耗一枚场上0阶兵，在原位置生成一枚0级、2阶的新兵，红黑色各50%随机。新兵不继承原兵的经验或强化，无需第二目标。', role: 'growth', effect: { type: 'replaceBing', stage: 2, restrict: 'bing' } },
  { id: 'qinzeiqinwang', tier: 3, kind: 'target', price: 16, stock: 1, name: '擒贼擒王', desc: '借棋重击最高血敌', detail: '指定棋子，对当前剩余生命最高的敌人造成其最大生命12%的伤害，上限为所选棋子攻击力500%。不暴击、不触发普攻收益。', role: 'offense', effect: { type: 'execute', hpRate: 0.12, cap: 5 } },
  { id: 'fudichouxin', tier: 3, kind: 'none', price: 15, stock: 1, name: '釜底抽薪', desc: '全敌减速30%·4秒', detail: '本盘当前全体敌人减速30%持续4秒，与其他减速取较强效果，不相乘叠加。后来出生的敌人不继承。', role: 'rescue', effect: { type: 'slowEnemies', rate: 0.3, seconds: 4 } },
  { id: 'hunshuimoyu', tier: 1, kind: 'target', price: 6, stock: 1, name: '浑水摸鱼', desc: '单棋获得30~50经验', detail: '指定棋子获得30经验；当前存在减速或眩晕的敌人时改为50经验，遵守正常等级上限。', role: 'growth', effect: { type: 'experience', value: 30, bonus: 50, condition: 'controlled' } },
  { id: 'jinchantuoqiao', tier: 3, kind: 'target', price: 5, stock: 1, name: '金蝉脱壳', desc: '出售单棋·获得5金币', detail: '第12波起才会刷出。将指定的普通场上棋子彻底出售并获得5金币，不是放回商店。施放价格5金币，净金币变化为0；帅不可选。', role: 'growth', effect: { type: 'sell', value: 5 } },
  { id: 'guanmenzhuozei', tier: 3, kind: 'none', price: 16, stock: 1, name: '关门捉贼', desc: '全敌晕3秒·再慢3秒', detail: '当前全体敌人眩晕3秒，遵守眩晕免疫；减速40%的窗口固定为施放后第3至第6秒。后来出生的敌人不继承。', role: 'rescue', effect: { type: 'stunSlowAll', stun: 3, rate: 0.4, seconds: 3, delay: 3 } },
  { id: 'yuanjiaojingong', tier: 2, kind: 'target', selection: 'secondary', price: 10, stock: 1, name: '远交近攻', desc: '异色邻棋伤害+20%·10秒', detail: '指定一枚棋子及一枚与它横竖相邻的异色友军，两者攻击伤害提高20%持续10秒。第二枚必须明确选择，可取消；同类攻击增益取最高值。', role: 'offense', effect: { type: 'pairBuff', rate: 0.2, seconds: 10 } },
  { id: 'jiadaofaguo', tier: 3, kind: 'target', price: 15, stock: 1, name: '假道伐虢', desc: '炮立即双连发', detail: '指定炮立即向合法目标发射100%伤害主炮，0.25秒后追加70%伤害。严格遵守炮架与目标合法性；不累计特殊技蓄势、不产生普攻金币。', role: 'offense', effect: { type: 'cannonBurst', restrict: 'pao' } },
  { id: 'toulianghuanzhu', tier: 3, kind: 'target', price: 16, stock: 1, name: '偷梁换柱', desc: '车马炮随机换种', detail: '指定车、马或炮，随机变为另外两种之一；保留颜色、等级、阶数和强化，清除攻击动作与旧棋种特殊技蓄势。', role: 'growth', effect: { type: 'randomTransform', restrict: 'rankType' } },
  { id: 'zhisangmahuai', tier: 2, kind: 'target', price: 8, stock: 1, name: '指桑骂槐', desc: '士象同色邻军+20%·5秒', detail: '指定士或象，对施放时与其横竖相邻的同色友军施加攻击伤害+20%，持续5秒；不包含自身，之后移动不改变该次快照对象。', role: 'offense', effect: { type: 'neighborBuff', rate: 0.2, seconds: 5, restrict: 'shiXiang' } },
  { id: 'jiachibudian', tier: 1, kind: 'target', price: 6, stock: 1, name: '假痴不癫', desc: '伤害+40%·禁暴5秒', detail: '指定棋子5秒内攻击伤害提高40%，同时不能暴击。同类限时攻击增益取最高值，不相乘叠加。', role: 'offense', effect: { type: 'buff', rate: 0.4, noCrit: true, seconds: 5 } },
  { id: 'shangwuchouti', tier: 2, kind: 'target', price: 10, stock: 1, name: '上屋抽梯', desc: '重击最靠近帅的受控敌', detail: '指定棋子，对当前减速或眩晕且最靠近帅的敌人造成其攻击力200%的伤害。没有受控敌人时不能施放；不暴击、不触发普攻收益。', role: 'offense', effect: { type: 'damageControlled', multiplier: 2 } },
  { id: 'shushangkaihua', tier: 3, kind: 'target', price: 18, stock: 1, name: '树上开花', desc: '车马炮提升1阶', detail: '指定车、马或炮提升1阶，最高3阶，保留等级、颜色和强化。满阶时不能施放。', role: 'growth', effect: { type: 'stageUp', value: 1, restrict: 'rankType' } },
  { id: 'fankeweizhu', tier: 3, kind: 'target', price: 18, stock: 1, name: '反客为主', desc: '补满核心特殊技蓄势', detail: '指定60级及以上的车、马或炮，补满其特殊技蓄势，于下次有效普通攻击触发，不立即攻击、不额外产金。', role: 'offense', effect: { type: 'forceSpecial', restrict: 'rankType', minLevel: 60 } },
  { id: 'meirenji', tier: 3, kind: 'none', price: 16, stock: 1, name: '美人计', desc: '最靠近帅3敌晕1.5秒', detail: '当前最靠近帅的至多3名敌人眩晕1.5秒，遵守现有眩晕免疫；后来出生的敌人不继承。', role: 'rescue', effect: { type: 'stunNearest', count: 3, seconds: 1.5 } },
  { id: 'kongchengji', tier: 3, kind: 'none', price: 18, stock: 1, name: '空城计', desc: '一心时近3敌后退3格', detail: '仅永久心与有效临时心合计为1时可用，最靠近帅的至多3名当前敌人沿道路后退3格，最低到出生点；与位移法术共用10秒冷却。', role: 'rescue', effect: { type: 'lastStand', count: 3, cells: 3, cooldown: 10 } },
  { id: 'fanjianji', tier: 2, kind: 'target', price: 10, stock: 1, name: '反间计', desc: '近敌同格受120%伤害', detail: '指定本方棋子，最靠近帅的敌人及与它同格的当前敌人受到所选棋子攻击力120%的伤害。不暴击、不触发普攻收益。', role: 'offense', effect: { type: 'damageNearestCell', multiplier: 1.2 } },
  { id: 'kuruoji', tier: 3, kind: 'none', price: 14, stock: 1, name: '苦肉计', desc: '扣1永久心·得2临时心', detail: '扣除1永久心，获得2临时心持续30秒，临时心优先抵挡漏怪。永久1心时可施放变为0永久+2临时；临时心耗尽或到期且永久0立即落败。永久0心不能施放，不回复永久心。', role: 'rescue', effect: { type: 'temporaryLives', cost: 1, value: 2, seconds: 30 } },
  { id: 'lianhuanji', tier: 3, kind: 'none', price: 20, stock: 1, name: '连环计', desc: '全场伤害+25%·8秒', detail: '施放时场上全体棋子攻击伤害提高25%，持续8秒；后来上场的棋子不继承。同类限时攻击增益取最高值，不相乘叠加。', role: 'offense', effect: { type: 'buffAll', rate: 0.25, seconds: 8 } },
  { id: 'zouweishangji', tier: 1, kind: 'none', price: 4, stock: 1, name: '走为上计', desc: '免费换未购买商店卡', detail: '移除本法术后免费刷新当前未购买的卡牌；已拥有的回收棋子保留，不增加刷新价格与计数，不消耗付费刷新优惠。仍遵守每店最多1法术、1铲子。', role: 'growth', effect: { type: 'freeRefresh' } },
];

/* ============================================================
 * 八、开局增益（海克斯）库：随机 3 个不重复供选择，整局生效
 * key 为写入 game.flags 的字段名，由各模块读取
 * ============================================================ */
/** 开局三选一增益总开关：false = 暂时关闭，点「开始游戏」直接开局（无增益） */
export const BONUS_SELECT_ENABLED = false;

export const BONUSES = [
  {
    id: 'yise', name: '异色相融',
    desc: '本局同名棋子融合不再受颜色限制（红黑同种可一起合成）',
    flags: { mergeIgnoreColor: true },
  },
  {
    id: 'changju', name: '长车劲击',
    desc: '本局所有【车】攻击力 +50',
    flags: { atkFlatByType: { ju: 50 } },
  },
  {
    id: 'mata', name: '马踏如风',
    desc: '本局所有【马】攻击冷却缩短 30%',
    flags: { cdRateByType: { ma: 0.7 } },
  },
  {
    id: 'paojia', name: '炮架易得',
    desc: '炮架判定放宽，更易找到炮架发起攻击',
    flags: { paoRelaxed: true },
  },
  {
    id: 'bingchao', name: '兵潮集结',
    desc: '本局所有小兵攻击力 +25',
    flags: { atkFlatByType: { bing: 25 } },
  },
  {
    id: 'jingsuan', name: '精打细算',
    desc: '商店每次刷新的涨价幅度降低一半',
    flags: { refreshStepHalf: true },
  },
  {
    id: 'xiangyan', name: '象眼加固',
    desc: '本局所有【象】无视塞象眼限制',
    flags: { xiangNoEye: true },
  },
  {
    id: 'surong', name: '速融之法',
    desc: '保留为实验增益占位；自动进化仍统一在3阶触发',
    flags: { mergeNeedOne: true },
  },
  {
    id: 'jianshi', name: '坚士御敌',
    desc: '本局所有士受到的全部伤害降低 20%（棋子不承伤，仅作配置预留）',
    flags: { shiDamageReduce: 0.2 },
  },
  {
    id: 'liren', name: '利刃同调',
    desc: '本局所有棋子基础攻击力 +15',
    flags: { atkFlatAll: 15 },
  },
];

/* ============================================================
 * 九、羁绊配置（仅保留两组；士兵突击、马炮合势、重炮杀、双车错已删除）
 *
 * 触发条件：位置 + 等级 同时满足（横竖相邻）。两枚棋子都须达到门槛等级。
 * 同色仅允许双红或双黑；异色必须一红一黑。
 * 羁绊效果与新等级解锁机制可叠加共存；条件不满足立刻移除。
 * ============================================================ */
export const BOND_CONFIG = {
  /** 二鬼拍门：红兵与黑卒相邻，两者都须达10级，每组每10秒+1金币。 */
  bing_bing: {
    trigger: 'adjacent', requireType: ['bing', 'bing'],
    requireLevel: 10,
    colorRule: 'mixed',
    name: '二鬼拍门',
    effect: 'goldTick',
  },
  /** 士象全（限定技）：同色士象相邻，两者都须达15级；每方只生效一组，己方全部棋子攻击+10%。 */
  shi_xiang: {
    trigger: 'adjacent', requireType: ['shi', 'xiang'],
    requireLevel: 15, colorRule: 'same', limit: 1,
    name: '士象全',
    effect: 'waveLevel',
  },
};

/** 同色全场奖励按有效羁绊组数叠加。 */
export const BOND_TEAM_EXP = 10;
/** 旧模块兼容；已取消清波加级，战斗逻辑不读取。 */
export const BOND_WAVE_LEVEL = 0;

/** 羁绊视觉特效配色规则 */
export const BOND_EFFECT = {
  red:  { stroke: '#b84b46', glow: '#d47a70' },  // 双红：朱红 / 暗红
  black:{ stroke: '#45434a', glow: '#77727a' },  // 双黑：墨灰
  mix:  { strokeA: '#b84b46', strokeB: '#45434a' }, // 异色：红黑搭配
  namePopupMs: 1500,       // 名称弹窗总时长（毫秒）：前 1 秒清晰，后 0.5 秒淡出
  namePopupHoldMs: 1000,   // 保持清晰的时长，之后开始慢慢减淡
};

/* ============================================================
 * 九·五、详情面板展示用的文本（等级效果 / 羁绊效果说明）
 * 这些只用于给玩家看，不参与任何逻辑判定。
 * ============================================================ */

/** 每种棋子「等级效果」的中文说明（键 = 等级）；羁绊在详情中另行列出。 */
export const LEVEL_EFFECT_TEXT = {
  bing: { 15: '每次攻击攻速+5%，最多4层；5秒不攻击则清零', 20: '身后一格的己方棋子攻速+10%' },
  shi: { 20: '一次可同时攻击两名敌人', 30: '攻击范围内空地上的己方棋子攻击力+10%' },
  xiang: { 20: '无视兵／卒塞象眼', 30: '象眼上的己方棋子控制时间+10%' },
  ju: { 50: '去程穿透并逐格命中', 70: '返程造成50%伤害', 80: '返程造成100%伤害' },
  ma: { 50: '践踏眩晕提升至1秒', 70: '受阻奋勇：每个受阻道路攻击格使自身攻击力+10%', 80: '无视绊马腿', 90: '对眩晕免疫敌人伤害+20%' },
  pao: { 50: '3×3爆炸：主目标100%，其余60%', 70: '减速30%，持续1秒', 80: '允许1~3枚炮架' },
};

/** 每个羁绊的中文说明（键 = 羁绊 effect 名） */
export const BOND_EFFECT_TEXT = {
  goldTick:  '二鬼拍门：异色兵相邻且两者都须≥10级；每10秒+1金币',
  waveLevel: '士象全（限定技）：同色士象相邻且两者都须≥15级；己方全场攻击+10%，每方只能激活一组',
};

/** 详情按当前棋子的颜色显示搭档和效果，等级由左侧词条标注。 */
export function bondDetailText(piece, conf) {
  const partnerType = conf.requireType.find(type => type !== piece.type) || piece.type;
  const color = conf.colorRule === 'mixed'
    ? (piece.color === 'black' ? 'red' : 'black') : piece.color;
  const partner = pieceDisplayName({ type: partnerType, color });
  const position = conf.trigger === 'line' ? '同线且中间无阻挡' : '相邻';
  const effects = {
    goldTick: '每10秒获得1金币',
    waveLevel: '己方全场攻击+10%；限定技，每方只能激活一组',
  };
  return `${conf.name}：与${partner}${position}，${effects[conf.effect] || ''}`;
}

/* ============================================================
 * 十、其它杂项
 * ============================================================ */
export const MISC = {
  goldFloatMs: 700,        // 金币浮动文字持续时间
  initialGold: 25,         // 开局金币（后续收入只有击杀，初始给一笔启动资金；够买开局 4 个兵）
  dragGhostScale: 1.0,
};

/* ============================================================
 * 攻击表现特效（子弹 / 涂色泼洒）
 * ============================================================ */
export const FX = {
  /**
   * 发射子弹时棋子的「吐子」抽搐：朝发射方向瞬间位移再弹回。
   * amplitude：最大位移像素；duration：单次抽搐时长（秒）
   */
  recoil: {
    amplitude: 6,          // 位移像素
    duration: 0.16,        // 秒
  },

  /** 子弹命中后在地面留下的颜料泼洒 */
  paint: {
    lifeMs: 3200,          // 涂色在地面保留时长（毫秒），随后缓缓淡出
    fadeStart: 0.55,       // 从生命周期的这个比例开始淡出
    dotCount: {            // 每次命中生成的随机小圆点数量（按攻击范围大小）
      single: 7,           // 单体攻击（约 1 格）
      aoe: 26,             // 范围攻击（约 3×3）
    },
    dotRadius: {           // 小圆点半径（格为单位，0~0.5 表示半格）
      single: [0.06, 0.16],
      aoe: [0.05, 0.14],
    },
    /** 涂色颜色（浅色，半透明）：红方浅红 / 黑方浅黑 */
    tint: {
      red:   { r: 255, g: 90,  b: 90,  alpha: 0.34 },
      black: { r: 40,  g: 40,  b: 52,  alpha: 0.30 },
    },
    aoeRadiusCells: 1,     // 范围攻击泼洒半径（格）：1 → 覆盖 3×3
  },

  /**
   * 走路蹦跳（纯视觉，不影响逻辑坐标 / 攻击判定）：帅入场与敌人移动时一蹦一蹦。
   * 蹦跳相位由「沿路径走过的格数」驱动 → 走得快蹦得快，眩晕 / 停下时自然不蹦。
   */
  walkHop: {
    hopsPerCell: 2,        // 每走 1 格蹦几下
    kingAmp: 6,            // 帅的蹦跳高度（像素）
    enemyAmp: 5,           // 敌人的蹦跳高度（像素）
    squash: 0.08,          // 落地压扁 / 空中拉长的幅度（0 = 关闭）
    shadowAlpha: 0.25,     // 脚下影子不透明度（离地越高越淡、越小）
  },

  /** 帅到位后的呼吸起伏（纯视觉）：以脚底为锚纵向轻微伸缩；血量越低呼吸越快 */
  kingBreath: {
    period: 3.2,           // 默认一次完整呼吸的时长（秒），越大越慢
    periodByLives: { 3: 3.2, 2: 1.9, 1: 1.0 },   // 按剩余红心：满血 3.2s → 1 颗心 1s（急促）
    amount: 0.035,         // 起伏幅度（身高的比例），越大越明显
  },

  /** 帅阵亡（纯视觉）：特写镜头里轻微颤抖 */
  kingDeath: {
    shakePx: 1.2,          // 颤抖幅度（棋盘逻辑像素，1 格 = 60）
  },
};

/* ============================================================
 * 十一、段位（排位）
 * subs：该大段的小段数；protect：升入该大段时补满的「掉大段保护」次数
 * 每小段 3 星；至高为最高段，到顶后星数继续累加。
 * ============================================================ */
export const RANKS = [
  { name: '塑料',   subs: 2,   protect: 2, color: '#b9c2cc' },
  { name: '陶瓷',   subs: 2,   protect: 2, color: '#e7d7c1' },
  { name: '不锈钢', subs: 3,   protect: 2, color: '#9fb4c7' },
  { name: '钛合金', subs: 3,   protect: 2, color: '#8fd3e0' },
  { name: '黄金',   subs: 4,   protect: 1, color: '#ffd24d' },
  { name: '钻石',   subs: 4,   protect: 1, color: '#7fd8ff' },
  { name: '传说',   subs: 5,   protect: 0, color: '#c58bff' },
  { name: '至高',   subs: 999, protect: 0, color: '#ff6a5a' },
];
export const STARS_PER_SUB = 3;
/** 段位存档 localStorage 键 */
export const RANK_SAVE_KEY = 'cnchess.experimental.rank.v1';

/* ============================================================
 * 十二、匹配
 * ============================================================ */
export const MATCH = {
  minSec: 0,               // 匹配耗时随机 0~2 秒
  maxSec: 2,
  revealSec: 1.2,          // 匹配成功后展示对手卡片的时长
};

/* ============================================================
 * 十三、对手 AI 档位（按大段索引 0~7，由弱到强）
 *
 * 操作节奏统一由 AI_PLAY 控制，所有段位每次只执行一个动作。
 * think/actions 保留配置兼容，不再用于高段加速或批量操作。
 * placeSmart 控制候选落点质量，mistake 只表示在合理候选中选择次优方案。
 * reserve/spellUse/refreshEagerness 为决策偏好，不改变资源和规则。
 * bondPlan/colorPlan 保留旧配置兼容；新评估器统一检查实际羁绊及融合机会。
 * ============================================================ */
export const AI_PLAY = {
  openingDelay: 0.9,
  actionMin: 0.85,
  actionMax: 1.3,
  moveCooldown: 3.0,
  movePenalty: 3,
  maxCandidates: 48,
  evaluationBudgetMs: 7,
  simulationBudgetMs: 12,
  horizon: 8,
  simStep: 1 / 30,
  leakPenalty: 180,
  // 仅用于实测调参参考，绝不据此指定某一局胜负；顶端负期望不能堵住正常升段。
  playerWinTargets: [0.78, 0.73, 0.67, 0.61, 0.55, 0.5, 0.46, 0.43],
};

export const AI_PROFILES = [
  /* 塑料   */ { think: 3.0, actions: 1, placeSmart: 0.15, mistake: 0.35, reserve: 0,  bondPlan: 0.00, colorPlan: 0.0, spellUse: 0.10, refreshEagerness: 0.25 },
  /* 陶瓷   */ { think: 2.6, actions: 1, placeSmart: 0.30, mistake: 0.28, reserve: 0,  bondPlan: 0.05, colorPlan: 0.1, spellUse: 0.20, refreshEagerness: 0.35 },
  /* 不锈钢 */ { think: 2.1, actions: 2, placeSmart: 0.50, mistake: 0.20, reserve: 2,  bondPlan: 0.20, colorPlan: 0.3, spellUse: 0.35, refreshEagerness: 0.45 },
  /* 钛合金 */ { think: 1.7, actions: 2, placeSmart: 0.65, mistake: 0.14, reserve: 4,  bondPlan: 0.40, colorPlan: 0.5, spellUse: 0.50, refreshEagerness: 0.55 },
  /* 黄金   */ { think: 1.35, actions: 3, placeSmart: 0.80, mistake: 0.09, reserve: 6, bondPlan: 0.60, colorPlan: 0.7, spellUse: 0.65, refreshEagerness: 0.65 },
  /* 钻石   */ { think: 1.0, actions: 3, placeSmart: 0.90, mistake: 0.05, reserve: 8,  bondPlan: 0.80, colorPlan: 0.85, spellUse: 0.80, refreshEagerness: 0.75 },
  /* 传说   */ { think: 0.8, actions: 4, placeSmart: 0.96, mistake: 0.03, reserve: 9,  bondPlan: 0.90, colorPlan: 0.95, spellUse: 0.90, refreshEagerness: 0.80 },
  /* 至高   */ { think: 0.6, actions: 4, placeSmart: 1.00, mistake: 0.015, reserve: 10, bondPlan: 1.00, colorPlan: 1.0, spellUse: 1.00, refreshEagerness: 0.85 },
];

/** 仅塑料/陶瓷每局抽一次；正常档仍走原策略，不改操作间隔。 */
export const AI_NOVICE = {
  chance: 0.5,
  smartPlacement: 0.25,
  mergeChance: 0.06,
  developmentPieces: 5,
};

export const AI_RELIEF = {
  enabled: false, // 自然失误尚未通过“连败后赢一局”验收，不在正式对局启用。
  lossStreak: 3,
  minTier: 5,
  startSec: 30,
  maxMistakes: 5,
  minInterval: 6,
};

/** 跨局仅做有上限的轻微强度修正；不改变操作速度，不按比分强控输赢。 */
export const AI_ADAPT = {
  streakStep: 0.08,
  streakCap: 0.35,
  leadHearts: 2,
  relaxMult: 1.5,          // 放松时：think × relaxMult，mistake × relaxMult
  tightenMult: 0.8,        // 收紧时：think × tightenMult，mistake × tightenMult（不超过本档上限）
  /** 基础偏置：按大段 0~7，负数 = 让 AI 弱一点（低段给玩家更多胜率） */
  tierBias: [-0.6, -0.5, -0.35, -0.25, -0.15, -0.05, 0, 0],
};

/* ============================================================
 * 十四、随机昵称：「状态的食物 + 5 位数字」
 * ============================================================ */
export const NAME_MOODS = [
  '飞翔', '游泳', '愤怒', '喜悦', '发呆', '奔跑', '打盹', '哼歌', '跳舞', '害羞',
  '得意', '好奇', '兴奋', '冲浪', '滑雪', '放风筝', '追风', '偷笑', '淡定', '潇洒',
  '勇敢', '迷糊', '骄傲', '调皮', '闪耀', '旋转', '潜水', '爬山', '赶路', '钓鱼',
  '微笑', '大笑', '思考', '躲猫猫', '晒太阳', '散步', '蹦跶', '吹口哨', '翻跟头', '捣蛋',
];
export const NAME_FOODS = [
  '冰淇淋', '西瓜', '草莓', '土豆', '番茄', '茄子', '南瓜', '玉米', '芒果', '榴莲',
  '菠萝', '饺子', '汤圆', '包子', '奶茶', '蛋挞', '布丁', '年糕', '橙子', '香蕉',
  '荔枝', '蘑菇', '胡萝卜', '青椒', '豆腐', '葡萄', '柠檬', '椰子', '粽子', '月饼',
  '棉花糖', '甜甜圈', '烤红薯', '小笼包', '煎饼', '桃子', '樱桃', '蓝莓', '花生', '火龙果',
];

/** 便捷查表 */
export const SPELL_BY_ID = Object.fromEntries(SPELLS.map(s => [s.id, s]));
export const BONUS_BY_ID = Object.fromEntries(BONUSES.map(b => [b.id, b]));

export default {
  RES, TILESET, GRID, PIECE_STATS, COLORS, PIECE_TEXT_STYLE, LEVEL,
  ENEMY, WAVES, KING, SHOP, MERGE, RANK, JU_CHARGE, PAO_BLAST, MA_STOMP, ENEMY_FX, SPELLS, BONUSES, BOND_CONFIG,
  BOND_EFFECT, LEVEL_EFFECT_TEXT, BOND_EFFECT_TEXT, MISC, FX, SPELL_BY_ID, BONUS_BY_ID,
};
