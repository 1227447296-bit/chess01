import game, { createBoard } from './gameData.js';
import { SPELLS } from './config.js';

/** Uses real shop pointer handlers to inspect each of the 36 card details. */
export async function runSpell36UIFixtures() {
  // Module imports can finish before boot has built the actual shop slots.
  for (let frame = 0; !document.getElementById('shop-grid').children.length && frame < 300; frame++) {
    await new Promise(requestAnimationFrame);
  }
  if (!document.getElementById('shop-grid').children.length) throw Error('Game shop is not initialized');
  const saved = { boards: game.boards, cur: game.cur, phase: game.phase,
    selected: game.selectedPieceId, detail: game.detailCardSlot };
  const views = ['game-view', 'start-screen', 'game-over'].map(id => document.getElementById(id));
  const classes = views.map(el => el.className);
  let passed = 0;
  const check = (ok, label) => { if (!ok) throw Error(label); passed++; };
  try {
    const me = createBoard('me', saved.boards.me.map);
    const opp = createBoard('opp', saved.boards.me.map);
    game.boards = { me, opp }; game.cur = me; game.phase = 'playing';
    game.selectedPieceId = null; game.detailCardSlot = -1;
    views[0].classList.remove('hidden'); views[1].classList.add('hidden'); views[2].classList.add('hidden');
    check(SPELLS.length === 36, 'Exactly 36 visible spell definitions');
    for (const spec of SPELLS) {
      me.shopSlots[0] = { source: 'native', type: 'spell', id: spec.id, tier: spec.tier, price: spec.price };
      const placeholder = document.createElement('div');
      placeholder.className = 'shop-card'; placeholder.dataset.slot = '0';
      document.getElementById('shop-grid').children[0].replaceChildren(placeholder);
      placeholder.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerId: 111, clientX: 1, clientY: 1 }));
      window.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 111, clientX: 1, clientY: 1 }));
      const panel = document.getElementById('detail-panel');
      check(!panel.classList.contains('hidden') && panel.textContent.includes(spec.name), spec.name + ' detail opens');
      check(panel.querySelector('.spell-detail-text')?.textContent === spec.detail, spec.name + ' full detail distinct from card');
      const short = document.querySelector('.shop-card[data-slot="0"] .card-desc');
      check(short?.textContent === spec.desc && spec.desc.length <= 26, spec.name + ' short card text');
      check(panel.textContent.includes('1 / 1'), spec.name + ' one-copy stock shown');
      panel.querySelector('.detail-close')?.click();
    }
    return { passed };
  } finally {
    game.boards = saved.boards; game.cur = saved.cur; game.phase = saved.phase;
    game.selectedPieceId = saved.selected; game.detailCardSlot = saved.detail;
    views.forEach((el, i) => { el.className = classes[i]; });
    document.getElementById('detail-panel').classList.add('hidden');
  }
}
