/** Node regression: run with a Node-compatible runtime; no browser, saves, or original project needed. */
import assert from 'node:assert/strict';
import game, { createBoard, withBoard, uid } from './gameData.js';
import { SPELL_BY_ID, AI_PLAY, LEVEL } from './config.js';
import { actionBranches, clonePosition, evaluateAction, evaluateActionSteps, scorePosition, knownEvolutionChoices, previewCard } from './aiEvaluation.js';
import { actionKey, equivalentAction } from './aiVariety.js';
import { setupAI, aiTick, aiInfo } from './ai.js';
import { criticalStats } from './attackRule.js';
import { sharedWaves } from './wave.js';
import { simulateCombat } from './aiSimulation.js';
import * as act from './actions.js';

const snapshot = x => JSON.stringify(x, (_, v) => v instanceof Map ? [...v] : v instanceof Set ? [...v] : v);
const piece = (id, type = 'bing', extra = {}) => ({ id, kind: 'piece', type, color: 'red', c: 2, r: 3,
  level: 15, exp: 0, stage: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [], activeBonds: [], ...extra });
const map = (rows = 7, cols = 7, c = 3) => ({ rows, cols,
  ground: Array.from({ length: rows }, () => Array(cols).fill(true)),
  grass: Array.from({ length: rows }, () => Array(cols).fill(false)),
  road: Array.from({ length: rows }, () => Array.from({ length: cols }, (_, x) => x === c)),
  path: Array.from({ length: rows }, (_, r) => ({ c, r })),
  cleared: new Set(), enemySpawn: { c, r: 0 }, kingPoint: { c, r: rows - 1 } });
const evolutionMap = () => {
  const m = map();
  m.path = Array.from({ length: 6 }, (_, i) => ({ c: i + 1, r: 3 }));
  m.road = Array.from({ length: 7 }, (_, r) => Array.from({ length: 7 }, (_, c) => r === 3 && c > 0));
  m.enemySpawn = m.path[0]; m.kingPoint = m.path.at(-1);
  return m;
};
const fixture = (pieces = [], gold = 60, geometry = map()) => {
  const b = createBoard('opp', geometry);
  b.totalRefreshCount = 1; b.gold = gold; b.pieces = pieces;
  return b;
};
const spell = (board, id, targetId, extra = {}) => {
  const spec = SPELL_BY_ID[id];
  board.shopSlots[0] = { source: 'native', type: 'spell', id, price: spec.price };
  return { kind: 'spell', slot: 0, spellId: id, targetId, effect: spec.effect, cost: spec.price, ...extra };
};
let passed = 0;
const check = (name, fn) => { fn(); passed++; console.log('PASS', name); };
const original = { cur: game.cur, phase: game.phase, waves: { ...sharedWaves }, random: Math.random };
try {
  Object.assign(sharedWaves, { wave: 1, waveToSpawn: 2, countInWave: 5, timer: 100, betweenWaves: true, countdown: false, spawnedInWave: 0 });
  check('native higher-tier shop preview preserves type, level and no real UID/cache', () => {
    const card = { source: 'native', type: 'piece', kind: 'ju', color: 'black', level: 8, price: 16 };
    const before = Number(uid('test').slice(4));
    const p = previewCard(card, 0);
    assert.equal(p.type, 'ju'); assert.equal(p.level, 8); assert.equal(p.color, 'black');
    assert.equal(card.piece, undefined); assert.equal(Number(uid('test').slice(4)), before + 1);
  });
  check('merge reaches stage 2 without evolving and does not consume RNG', () => {
    const b = fixture([piece('a', 'shi', { stage: 1 }), piece('b', 'shi', { c: 1, level: 7 })]);
    const before = snapshot(b), id = Number(uid('test').slice(4));
    Math.random = () => { throw Error('formal random consumed'); };
    const branches = actionBranches(b, { kind: 'merge', pieceId: 'b', targetId: 'a', cost: 0 });
    assert.equal(branches.length, 1);
    const p = branches[0].board.pieces[0];
    assert.equal(p.type, 'shi'); assert.equal(p.stage, 2); assert.equal(p.color, 'red');
    assert.equal(p.evolutionChoices, undefined);
    assert.equal(branches[0].board.gold, b.gold);
    assert.equal(snapshot(b), before); assert.equal(Number(uid('test').slice(4)), id + 1);
    Math.random = original.random;
  });
  check('stage 2 plus material enumerates random auto-evolution without formal RNG', () => {
    const b = fixture([piece('a', 'shi', { stage: 2, color: 'black' }),
      piece('b', 'shi', { color: 'black', c: 1 })]);
    Math.random = () => { throw Error('formal random consumed'); };
    const branches = actionBranches(b, { kind: 'merge', pieceId: 'b', targetId: 'a' });
    assert.equal(branches.length, 6);
    assert.ok(Math.abs(branches.reduce((sum, x) => sum + x.probability, 0) - 1) < 1e-9);
    assert.ok(branches.every(x => ['ju', 'ma', 'pao'].includes(x.board.pieces[0].type) &&
      ['red', 'black'].includes(x.board.pieces[0].color) && x.board.pieces[0].stage === 0));
    assert.equal(actionBranches(b, { kind: 'evolve', pieceId: 'a', evolutionType: 'ma' }).length, 0);
    Math.random = original.random;
  });
  check('summoning chosen color is one deterministic branch and legal shared action', () => {
    for (const color of ['red', 'black']) {
      const b = fixture(), a = spell(b, 'yuanbing', undefined, { c: 1, r: 1, color });
      const before = snapshot(b), branches = actionBranches(b, a);
      assert.equal(branches.length, 1); assert.equal(branches[0].board.pieces[0].color, color);
      assert.equal(branches[0].board.pieces[0].level, 5); assert.equal(branches[0].board.gold, 50);
      const copy = clonePosition(b);
      withBoard(copy, () => assert.ok(act.useSpell(0, null, { c: 1, r: 1 }, { color }).ok));
      assert.equal(copy.pieces[0].color, color); assert.equal(copy.gold, branches[0].board.gold);
      assert.equal(snapshot(b), before);
    }
  });
  check('heyi unknown choice is revealed separately, probability mass preserved, no free evolution', () => {
    const b = fixture([piece('a', 'xiang')]);
    const a = spell(b, 'heyi', 'a');
    assert.equal(actionBranches(b, { ...a, evolutionType: 'ju' }).length, 0);
    Math.random = () => { throw Error('preview rerolled heyi'); };
    const revealed = evaluateAction(b, { ...a, kind: 'prepareEvolution', cost: 0 });
    assert.equal(revealed.branches.length, 3);
    for (const branch of revealed.branches) {
      assert.equal(branch.board.pieces[0].type, 'xiang'); assert.equal(branch.board.gold, b.gold);
      assert.ok(branch.board.shopSlots[0]); assert.equal(branch.board.spellUsed.heyi, undefined);
    }
    assert.equal(b.pieces[0].evolutionChoices, undefined);
    Math.random = original.random;
  });
  check('heyi explicit chosen type preserves all enhancements and charges actual card price', () => {
    const p = piece('a', 'bing', { color: 'black', stage: 0, atkBonus: 12, critRateBonus: .1, specialEnhancements: { huixin: 1 } });
    const b = fixture([p]), a = spell(b, 'heyi', 'a', { evolutionType: 'xiang' });
    b.shopSlots[0].price = 13;
    const result = actionBranches(b, a)[0].board;
    assert.equal(result.gold, 47); assert.equal(result.spellUsed.heyi, 1);
    assert.equal(result.pieces[0].type, 'xiang'); assert.equal(result.pieces[0].color, 'black');
    assert.equal(result.pieces[0].critRateBonus, .1); assert.equal(result.pieces[0].specialEnhancements.huixin, 1);
  });
  check('level cap and all-species stage cap follow actual spell/action validation', () => {
    const b = fixture([piece('a', 'bing', { level: 59, exp: 50, stage: 2 })]);
    let a = spell(b, 'jinglian', 'a');
    const cap = actionBranches(b, a)[0].board.pieces[0]; assert.equal(cap.level, LEVEL.hardCap); assert.equal(cap.exp, 0);
    a = spell(b, 'rongyin', 'a');
    const result = actionBranches(b, a)[0].board.pieces[0]; assert.equal(result.type, 'bing'); assert.equal(result.stage, 3);
    b.pieces[0].stage = 3; assert.equal(actionBranches(b, a).length, 0);
  });
  check('special spells improve crit expectation and cannot be applied twice', () => {
    for (const [id, stat] of [['huixin', 'rate'], ['pojun', 'damage']]) {
      const b = fixture([piece('a', 'ju', { level: 35 })]), a = spell(b, id, 'a');
      const before = withBoard(b, () => criticalStats(b.pieces[0]));
      const after = actionBranches(b, a)[0].board;
      assert.ok(after.pieces[0].specialEnhancements[id]);
      const crit = withBoard(after, () => criticalStats(after.pieces[0]));
      assert.ok(crit[stat] > before[stat], `${id} must reach combat criticalStats`);
      const fixedGold = clonePosition(after); fixedGold.gold = b.gold;
      assert.ok(scorePosition(fixedGold).output > scorePosition(clonePosition(b)).output);
      spell(after, id, 'a'); assert.equal(actionBranches(after, a).length, 0);
    }
  });
  check('huanbing touches current enemies only and honors shared cooldown without source mutation', () => {
    const b = fixture(); b.gameTime = 4;
    b.enemies = [{ id: 'e', c: 3, r: 1, progress: 1, hp: 30, maxHp: 30, speed: 1 }];
    const a = spell(b, 'huanbing'), before = snapshot(b), out = actionBranches(b, a)[0].board;
    assert.equal(out.huanbingCooldownUntil, 14); assert.equal(out.enemies[0].huanbingSlowUntil, 7);
    assert.equal(out.enemies[0].huanbingSlowMultiplier, .7); assert.equal(snapshot(b), before);
    spell(out, 'huanbing'); assert.equal(actionBranches(out, a).length, 0);
    out.gameTime = 14; assert.equal(actionBranches(out, a).length, 1);
  });
  check('illegal capacity, funds, target and overflow/swap produce no optimistic branches', () => {
    const b = fixture([piece('a', 'bing', { stage: 3 }), piece('b', 'bing', { c: 1 })], 0);
    assert.equal(actionBranches(b, { kind: 'swap', pieceId: 'b', targetId: 'a' }).length, 0);
    assert.equal(actionBranches(b, { kind: 'merge', pieceId: 'b', targetId: 'a' }).length, 0);
    const a = spell(b, 'huixin', 'a'); assert.equal(actionBranches(b, a).length, 0);
    assert.equal(actionBranches(b, { ...a, targetId: 'missing' }).length, 0);
    b.shopSlots[0] = { source: 'native', type: 'piece', kind: 'ju', color: 'red', price: 16 };
    assert.equal(actionBranches(b, { kind: 'buy', slot: 0, c: 1, r: 1, cost: 0 }).length, 0);
  });
  check('stage damage is immediate 12% per step, old rank-XP and cap leftovers have no value', () => {
    const b = fixture([piece('a', 'bing', { level: 60 })]);
    const zero = scorePosition(clonePosition(b)); b.pieces[0].stage = 3;
    const third = scorePosition(clonePosition(b));
    for (const [cell, dps] of zero.fire) assert.ok(Math.abs(third.fire.get(cell) / dps - 1.36) < 1e-9);
    const before = scorePosition(clonePosition(b)).score;
    b.pieces[0].exp = 99999; assert.equal(scorePosition(clonePosition(b)).score, before);
    const table = LEVEL.expByRank;
    try {
      LEVEL.expByRank = { bing: { 3: 99999999 } };
      assert.equal(scorePosition(clonePosition(b)).score, before);
    } finally { LEVEL.expByRank = table; }
  });
  check('bond valuation respects same-color requirements, concrete type thresholds and cap60', () => {
    const b = fixture([piece('a', 'shi', { level: 10 }), piece('b', 'xiang', { c: 1, level: 10 })]);
    assert.ok(scorePosition(clonePosition(b)).bonds > 0);
    b.pieces.forEach(p => { p.level = 60; }); assert.equal(scorePosition(clonePosition(b)).bonds, 0);
    const potential = fixture([piece('a', 'bing', { level: 0 }), piece('b', 'shi', { c: 1, level: 9 })]);
    assert.equal(scorePosition(clonePosition(potential)).potential, 1.5);
    potential.pieces[1].color = 'black'; assert.equal(scorePosition(clonePosition(potential)).potential, 0);
  });
  check('yielding lookahead restores board on every slice and never consumes RNG or real IDs', () => {
    const b = fixture([piece('a', 'shi', { stage: 1 }), piece('b', 'shi', { c: 1 })]);
    const before = snapshot(b), current = game.cur, id = Number(uid('test').slice(4));
    Math.random = () => { throw Error('lookahead touched formal random'); };
    const action = { kind: 'merge', pieceId: 'b', targetId: 'a', cost: 0 };
    const sync = evaluateAction(b, action, true), iterator = evaluateActionSteps(b, action, true);
    let part, slices = 0;
    do { part = iterator.next(); slices++; assert.equal(game.cur, current); assert.equal(snapshot(b), before); } while (!part.done);
    assert.ok(slices > 3); assert.equal(snapshot(part.value), snapshot(sync));
    assert.equal(Number(uid('test').slice(4)), id + 1); Math.random = original.random;
  });
  check('new choice identity cannot collide or enter a color-changing equivalent fallback', () => {
    assert.notEqual(actionKey({ kind: 'spell', color: 'red' }), actionKey({ kind: 'spell', color: 'black' }));
    assert.notEqual(actionKey({ kind: 'evolve', evolutionType: 'ma' }), actionKey({ kind: 'evolve', evolutionType: 'ju' }));
    const a = { kind: 'buy', slot: 0, cost: 6, gain: 10, score: 10, color: 'red', branches: [{ value: 10 }] };
    assert.equal(equivalentAction({ ...a, color: 'black' }, a), false);
  });
  const decide = board => {
    const n = aiInfo(board).decisions;
    withBoard(board, () => aiTick(2, 3, 7));
    for (let i = 0; i < 5000 && aiInfo(board).decisions === n; i++) withBoard(board, () => aiTick(0, 3, 7));
    assert.equal(aiInfo(board).decisions, n + 1, 'one decision must finish');
    assert.ok(board.aiTimer >= AI_PLAY.actionMin && board.aiTimer <= AI_PLAY.actionMax);
  };
  game.phase = 'playing';
  check('AI candidates use automatic evolution opportunity nodes, not active evolution', () => {
    setupAI({ tier: 7 }, { seed: 17, evaluationSlices: 64 });
    const b = fixture([piece('a', 'shi', { c: 0, stage: 2 }), piece('b', 'shi', { c: 1 })], 0, evolutionMap());
    const branches = actionBranches(b, { kind: 'merge', pieceId: 'b', targetId: 'a' });
    assert.equal(branches.length, 6);
    assert.ok(branches.every(x => ['ju', 'ma', 'pao'].includes(x.board.pieces[0].type)));
    assert.equal(actionBranches(b, { kind: 'evolve', pieceId: 'a', evolutionType: 'ju' }).length, 0);
  });
  check('AI actually chooses and executes reinforcement color', () => {
    setupAI({ tier: 7 }, { seed: 17, evaluationSlices: 64 });
    const b = fixture([], 10); spell(b, 'yuanbing'); decide(b);
    assert.equal(b.pieces.length, 1); assert.equal(b.pieces[0].color, aiInfo(b).lastAction.color);
    assert.equal(b.gold, 0); assert.equal(b.spellUsed.yuanbing, 1);
  });
  check('AI actually reveals then confirms heyi without redraw or extra resources', () => {
    setupAI({ tier: 7 }, { seed: 17, evaluationSlices: 64 });
    const b = fixture([piece('a', 'xiang', { c: 0, level: 15 })], 16, evolutionMap()); spell(b, 'heyi', 'a');
    decide(b); assert.equal(aiInfo(b).lastAction?.kind, 'prepareEvolution');
    const choices = knownEvolutionChoices(b.pieces[0], true);
    assert.equal(choices.length, 2); assert.equal(b.gold, 16); assert.equal(b.pieces[0].type, 'xiang');
    decide(b); assert.equal(aiInfo(b).lastAction?.spellId, 'heyi');
    assert.ok(choices.includes(b.pieces[0].type)); assert.equal(b.gold, 0); assert.equal(b.spellUsed.heyi, 1);
  });
  check('AI actually executes huixin and pojun on legal unmarked targets', () => {
    for (const id of ['huixin', 'pojun']) {
      setupAI({ tier: 7 }, { seed: 17, evaluationSlices: 64 });
      const m = evolutionMap(); m.cols = 32;
      m.ground = Array.from({ length: 7 }, () => Array(32).fill(true));
      m.grass = Array.from({ length: 7 }, () => Array(32).fill(false));
      m.road = Array.from({ length: 7 }, (_, r) => Array.from({ length: 32 }, (_, c) => r === 3 && c > 0));
      m.path = Array.from({ length: 31 }, (_, i) => ({ c: i + 1, r: 3 })); m.kingPoint = m.path.at(-1);
      const p = piece('a', 'ju', { c: 0, level: 35,
        ...(id === 'pojun' ? { critRateBonus: .1, specialEnhancements: { huixin: 1 } } : {}) });
      const b = fixture([p], SPELL_BY_ID[id].price, m); spell(b, id, 'a'); decide(b);
      assert.equal(aiInfo(b).lastAction?.spellId, id); assert.equal(b.gold, 0);
      assert.equal(b.pieces[0].specialEnhancements[id], 1); assert.equal(b.spellUsed[id], 1);
    }
  });
  check('AI actually casts tactical huanbing and simulation keeps future spawns unaffected', () => {
    setupAI({ tier: 7 }, { seed: 17, evaluationSlices: 64 });
    const b = fixture([], 7, map(20, 3, 1)); b.gameTime = 0;
    b.enemies = [{ id: 'e', c: 1, r: 11.5, progress: 11.5, hp: 30, maxHp: 30, speed: 1 }];
    const slowAction = spell(b, 'huanbing');
    const slowBoard = actionBranches(b, slowAction)[0].board;
    const beforeCombat = simulateCombat(b, { horizon: AI_PLAY.horizon, seed: 173 });
    const afterCombat = simulateCombat(slowBoard, { horizon: AI_PLAY.horizon, seed: 173 });
    assert.ok(afterCombat.leaks < beforeCombat.leaks, `slow must rescue in real simulation (${beforeCombat.leaks}/${afterCombat.leaks})`);
    decide(b); assert.equal(aiInfo(b).lastAction?.spellId, 'huanbing');
    assert.equal(b.gold, 0); assert.equal(b.huanbingCooldownUntil, 10);
    const before = snapshot(b), waves = snapshot(sharedWaves);
    const sim = simulateCombat(b, { horizon: 2, seed: 9, spawnPlan: [{ at: 1, wave: 1, hp: 30, speed: 1 }] });
    assert.equal(snapshot(b), before); assert.equal(snapshot(sharedWaves), waves);
    const future = sim.board.enemies.find(e => e.id !== 'e');
    assert.ok(future); assert.equal(future.huanbingSlowUntil, undefined);
  });
  console.log(`AI experimental regression: ${passed} passed`);
} finally {
  Math.random = original.random; game.cur = original.cur; game.phase = original.phase;
  Object.assign(sharedWaves, original.waves);
}
