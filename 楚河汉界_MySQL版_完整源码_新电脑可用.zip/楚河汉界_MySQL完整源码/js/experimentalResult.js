/** Called only after both boards have advanced through the same update. */
export function experimentalResult(me, opp) {
  if (!me.dead && !opp.dead) return null;
  if (!me.dead) return 'win';
  if (!opp.dead) return 'lose';
  const wave = Math.max(me.wave || 0, opp.wave || 0);
  const a = me.waveClearState?.[wave] || {};
  const b = opp.waveClearState?.[wave] || {};
  const leaksA = a.leaked || 0, leaksB = b.leaked || 0;
  if (leaksA !== leaksB) return leaksA < leaksB ? 'win' : 'lose';
  const killsA = a.killed || 0, killsB = b.killed || 0;
  if (killsA !== killsB) return killsA > killsB ? 'win' : 'lose';
  return 'draw';
}

export function runExperimentalResultFixtures() {
  let passed = 0;
  const board = (dead, leaked = 0, killed = 0) => ({ dead, wave: 25, waveClearState: { 25: { leaked, killed } } });
  const check = (actual, expected) => {
    if (actual !== expected) throw new Error(`Result ${actual}, expected ${expected}`);
    passed++;
  };
  check(experimentalResult(board(false), board(false)), null);
  check(experimentalResult(board(false), board(true)), 'win');
  check(experimentalResult(board(true), board(false)), 'lose');
  check(experimentalResult(board(true, 1), board(true, 2)), 'win');
  check(experimentalResult(board(true, 3), board(true, 2)), 'lose');
  check(experimentalResult(board(true, 2, 10), board(true, 2, 9)), 'win');
  check(experimentalResult(board(true, 2, 8), board(true, 2, 9)), 'lose');
  check(experimentalResult(board(true, 2, 9), board(true, 2, 9)), 'draw');
  return passed;
}
