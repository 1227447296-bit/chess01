/** 兵15级攻速叠层专项；不读写玩家存档。 */
import game, { createBoard, withBoard } from './gameData.js';
import { PIECE_STATS, GLOBAL_ATK_SPEED_SCALE, LEVEL_EFFECT_TEXT } from './config.js';
import { pieceDamage, pieceSkillSpeedMult, levelCdMult } from './attackRule.js';
import { updateCombat, update, spellDamage } from './wave.js';
import { cloneBoard } from './aiSimulation.js';

export function runBingSpeedFixtures() {
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const near = (a, b) => Math.abs(a - b) < 1e-7;
  const enemy = id => ({ id, kind: 'enemy', c: 3, r: 2, fx: 3, fy: 2, hp: 100000,
    maxHp: 100000, speed: 0, progress: 0, done: false, dying: false, deathT: 0, stunLeft: 0 });
  const make = (level = 15, color = 'red') => {
    const b = createBoard('me');
    b.map = { cols: 7, rows: 7, ground: [], grass: [], road: Array.from({ length: 7 }, () => Array(7).fill(1)),
      cleared: new Set(), path: [{ c: 0, r: 0 }, { c: 1, r: 0 }] };
    b._simulationContext = { random: () => 1 };
    b.pieces = [{ id: 'soldier', kind: 'piece', type: 'bing', color, c: 3, r: 3,
      level, stage: 0, exp: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [], activeBonds: [] }];
    b.enemies = [enemy('first')];
    return b;
  };
  const combat = (b, dt = 0) => withBoard(b, () => updateCombat(dt));
  const speed = b => withBoard(b, () => pieceSkillSpeedMult(b.pieces[0]));
  const attack = b => { b.pieces[0].cdLeft = 0; combat(b); };
  const previous = game.cur, phase = game.phase;
  try {
    game.phase = 'playing';
    check('介绍简短同步', LEVEL_EFFECT_TEXT.bing[15] === '每次攻击攻速+5%，最多4层；5秒不攻击则清零');
    for (const color of ['red', 'black']) {
      const b = make(15, color), p = b.pieces[0];
      const damage = withBoard(b, () => pieceDamage(p));
      const cooldown = PIECE_STATS.bing.cd * GLOBAL_ATK_SPEED_SCALE * levelCdMult(p);
      for (let i = 1; i <= 6; i++) {
        attack(b);
        check(`${color}第${i}次攻速层数`, p.bingSpeedStacks === Math.min(4, i));
        check(`${color}第${i}次攻速倍率`, near(speed(b), 1 + Math.min(4, i) * 0.05));
        check(`${color}第${i}次冷却`, near(p.cdLeft, cooldown / (1 + Math.min(4, i) * 0.05)));
      }
      check(`${color}移除旧连击增伤`, near(100000 - b.enemies[0].hp, damage * 6));
      b.enemies = [enemy('replacement')]; attack(b);
      check(`${color}换目标不清层`, p.bingSpeedStacks === 4 && near(100000 - b.enemies[0].hp, damage));
      b.enemies = []; combat(b, 4.999);
      check(`${color}五秒前保留`, p.bingSpeedStacks === 4 && near(speed(b), 1.2));
      combat(b, 0.001);
      check(`${color}五秒边界清零`, p.bingSpeedStacks === 0 && p.bingSpeedLeft === 0 && speed(b) === 1);
      combat(b, 10);
      check(`${color}空攻击不叠层`, p.bingSpeedStacks === 0);
      b.enemies = [enemy('restart')]; attack(b);
      check(`${color}超时后从一层重叠`, p.bingSpeedStacks === 1 && near(speed(b), 1.05));
      b.enemies = []; combat(b, 4);
      b.enemies = [enemy('refresh')]; attack(b); b.enemies = []; combat(b, 1.1);
      check(`${color}每次攻击刷新五秒`, p.bingSpeedStacks === 2 && near(p.bingSpeedLeft, 3.9));
      const copy = cloneBoard(b); combat(copy, 4);
      check(`${color}AI副本独立到期`, speed(copy) === 1 && near(speed(b), 1.1));
      const left = p.bingSpeedLeft;
      delete b._simulationContext; game.phase = 'paused';
      withBoard(b, () => update(30));
      check(`${color}暂停冻结层数时间`, p.bingSpeedLeft === left && p.bingSpeedStacks === 2);
      game.phase = 'playing';
    }
    const locked = make(14); attack(locked);
    check('14级未解锁', !locked.pieces[0].bingSpeedStacks && speed(locked) === 1);
    const magic = make();
    spellDamage(magic.pieces[0], magic.enemies, { board: magic, fixed: 10 });
    check('法术伤害不叠层', !magic.pieces[0].bingSpeedStacks && speed(magic) === 1);
    const saved = make(); saved.pieces[0].bingFocus = 4; saved.pieces[0].bingTargetId = 'first';
    const damage = withBoard(saved, () => pieceDamage(saved.pieces[0])); attack(saved);
    check('旧存档连击字段不再加伤', near(100000 - saved.enemies[0].hp, damage));
    saved.pieces[0].type = 'shi';
    check('其他棋种不继承兵叠层攻速', speed(saved) === 1);
    return { ok: true, count: checks.length, checks };
  } finally { game.cur = previous; game.phase = phase; }
}
