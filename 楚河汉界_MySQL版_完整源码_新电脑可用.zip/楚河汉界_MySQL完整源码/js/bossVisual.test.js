/** Canvas调用级回归：Boss尺寸、标识与横置/翻转下的中央提示。 */
import game, { createBoard, withBoard } from './gameData.js';
import { render, renderState } from './render.js';
import { enemySpecForSpawn, announceBossSpawn } from './boss.js';
import { viewSize } from './boardView.js';

export function runBossVisualFixtures() {
  let passed = 0;
  const check = (name, ok) => { if (!ok) throw Error(name); passed++; };
  const saved = { ...renderState }, previous = game.cur;
  try {
    for (const sideways of [false, true]) for (const flip of [false, true]) {
      const calls = [];
      const ctx = new Proxy({}, {
        get(_target, key) {
          if (key === 'measureText') return () => ({ width: 40 });
          if (key === 'createLinearGradient' || key === 'createRadialGradient') return () => ({ addColorStop() {} });
          return (...args) => calls.push({ key, args });
        },
        set() { return true; },
      });
      const b = createBoard('me', { cols: 5, rows: 8, ground: [], grass: [], road: [], cleared: new Set(), path: [] });
      const spec = enemySpecForSpawn(8, 0), normalSpec = enemySpecForSpawn(8, 1);
      const boss = { id: 'boss', ...spec, c: 2, r: 3, fx: 2, fy: 3, progress: 0, maxHp: spec.hp };
      const ordinary = { id: 'ordinary', ...normalSpec, c: 1, r: 2, fx: 1, fy: 2, progress: 0, maxHp: normalSpec.hp };
      b.enemies = [boss, ordinary];
      announceBossSpawn(b, boss, 8);
      Object.assign(renderState, { ctx, tile: 60, sideways, flip, readonly: true });
      withBoard(b, () => render(0));
      const labels = calls.filter(c => c.key === 'fillText');
      check('Boss王与普通寇同时显示', labels.some(c => c.args[0] === '王') && labels.some(c => c.args[0] === '寇'));
      const size = viewSize(b.map, sideways);
      const notice = labels.find(c => c.args[0] === '王从天降');
      check('横置/翻转提示始终位于画布正中', notice && notice.args[1] === size.cols * 30 && notice.args[2] === size.rows * 30);
      const bars = calls.filter(c => c.key === 'fillRect' && c.args[3] === 3);
      check('Boss身体及血条尺度为普通1.55倍', bars.some(c => c.args[2] === 62) && bars.some(c => c.args[2] === 40));
      const sprites = calls.filter(c => c.key === 'drawImage' && c.args.length === 9);
      check('实际素材按62和40像素绘制', sprites.some(c => c.args[7] === 62 && c.args[8] === 62) && sprites.some(c => c.args[7] === 40 && c.args[8] === 40));
      b.gameTime = 2.4; calls.length = 0;
      withBoard(b, () => render(0));
      check('2.4秒后不再绘制提示', !calls.some(c => c.key === 'fillText' && c.args[0] === '王从天降'));
    }
    check('恢复棋盘上下文', game.cur === previous);
    return { passed };
  } finally { Object.assign(renderState, saved); }
}
