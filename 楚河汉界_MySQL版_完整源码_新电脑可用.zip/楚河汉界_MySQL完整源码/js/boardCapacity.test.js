/** Browser fixtures: import('./js/boardCapacity.test.js').then(m => m.runBoardCapacityFixtures()). */
import game, { createBoard, withBoard, uid, onGoldChange, setGoldChangeHook } from './gameData.js';
import { SHOP, SPELL_BY_ID } from './config.js';
import { buyAndPlace, useSpell, moveTo, boardToPiece, shopToPiece } from './actions.js';
import { castSpell } from './spell.js';
import { actionBranches, evaluateAction, riskAdjusted } from './aiEvaluation.js';
import { MAX_BOARD_PIECES, BOARD_CAPACITY_REASON, hasBoardCapacity } from './boardLimits.js';

export function runBoardCapacityFixtures() {
  if (game.phase !== 'start') throw Error('Start page required');
  const original = { cur: game.cur, random: Math.random, hook: onGoldChange, floaters: game.floaters };
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const snapshot = b => JSON.stringify(b, (k, v) => v instanceof Set ? [...v] : v);
  const piece = (id, c = -1, r = -1, color = 'red') => ({
    id, kind: 'piece', type: 'bing', color, c, r, level: 0, exp: 0, stage: 0,
    atkBonus: 0, mergeCount: 0, flags: {}, cdLeft: 0, bonds: [], activeBonds: [],
  });
  const native = (color = 'red') => ({ source: 'native', type: 'piece', color });
  const spec = SPELL_BY_ID.jieshihuanhun;
  const spell = () => ({ source: 'native', type: 'spell', id: spec.id, price: spec.price });
  const cell = { c: 5, r: 3 };
  const fixture = (side, count = MAX_BOARD_PIECES) => {
    const b = createBoard(side);
    const layer = f => Array.from({ length: 4 }, (_, r) => Array.from({ length: 6 }, (_, c) => f(c, r)));
    b.map = { cols: 6, rows: 4, ground: layer(() => true), grass: layer(() => false),
      road: layer((c, r) => r === 0), cleared: new Set(),
      path: Array.from({ length: 6 }, (_, c) => ({ c, r: 0 })),
      enemySpawn: { c: 0, r: 0 }, kingPoint: { c: 5, r: 0 } };
    b.king = { id: `${side}-king`, type: 'king', c: 5, r: 0 };
    b.gold = 100; b.totalRefreshCount = 1;
    b.pieces = Array.from({ length: count }, (_, i) => piece(`${side}-${i}`, i % 6, 1 + Math.floor(i / 6)));
    return b;
  };
  let goldEvents = 0;
  const unchangedFailure = (name, b, run) => {
    const before = snapshot(b), card = b.shopSlots[0], pieces = [...b.pieces], events = goldEvents;
    const id = withBoard(original.cur, () => Number(uid('capacity').slice(8)));
    const result = withBoard(b, run);
    const nextId = withBoard(original.cur, () => Number(uid('capacity').slice(8)));
    check(`${name}: capacity failure`, !result.ok && result.reason === BOARD_CAPACITY_REASON);
    check(`${name}: board/card/pieces unchanged`, snapshot(b) === before && b.shopSlots[0] === card &&
      b.pieces.every((p, i) => p === pieces[i]));
    check(`${name}: no UID/payment/floater effects`, nextId === id + 1 && goldEvents === events && !game.floaters.length);
  };
  try {
    game.floaters = [];
    setGoldChangeHook(() => { goldEvents++; });
    Math.random = () => { throw Error('Capacity fixture must not consume random'); };
    check('approved per-board limit is ten', MAX_BOARD_PIECES === 10);
    for (const side of ['me', 'opp']) {
      for (const [name, card] of [
        ['uncached native', native()],
        ['cached native', { ...native(), piece: piece('cached') }],
        ['legacy cached native', { ...native(), _piece: piece('legacy') }],
        ['returned card', { source: 'fromBoard', piece: piece('returned') }],
      ]) {
        const b = fixture(side); b.shopSlots[0] = card;
        unchangedFailure(`${side} full buy ${name}`, b, () => buyAndPlace(0, cell.c, cell.r));
      }
      const over = fixture(side, 11); over.shopSlots[0] = native();
      unchangedFailure(`${side} over-limit buy`, over, () => buyAndPlace(0, cell.c, cell.r));
      for (const direct of [false, true]) {
        const b = fixture(side); b.shopSlots[0] = spell();
        unchangedFailure(`${side} full ${direct ? 'direct cast' : 'spell action'}`, b,
          () => direct ? castSpell(b.shopSlots[0], null, cell, { color: 'black' }) : useSpell(0, null, cell, { color: 'black' }));
      }
      const simulated = fixture(side); simulated.shopSlots[0] = spell();
      simulated._simulationContext = { uidCounter: 7, random: () => { throw Error('Full summon consumed simulation random'); } };
      unchangedFailure(`${side} full simulation summon`, simulated, () => useSpell(0, null, cell, { color: 'black' }));

      const nine = fixture(side, 9); nine.shopSlots[0] = native();
      check(`${side} king excluded; ninth to tenth buy legal`, hasBoardCapacity(nine) &&
        withBoard(nine, () => buyAndPlace(0, cell.c, cell.r)).ok && nine.pieces.length === 10 &&
        nine.gold === 100 - SHOP.price.piece && !nine.shopSlots[0] && !!nine.king);
      const summoned = fixture(side, 9); summoned.shopSlots[0] = spell();
      let rolls = 0; Math.random = () => { rolls++; return 0.75; };
      check(`${side} ninth to tenth summon legal`, withBoard(summoned, () => useSpell(0, null, cell, { color: 'black' })).ok &&
        summoned.pieces.length === 10 && summoned.pieces[9].color === 'black' &&
        summoned.gold === 100 - spec.price && summoned.spellUsed[spec.id] === 1 && rolls === 0);
      Math.random = () => { throw Error('Capacity fixture must not consume random'); };

      const b = fixture(side), first = b.pieces[0], second = b.pieces[1];
      check(`${side} full-board movement legal`, withBoard(b, () => moveTo(first, cell.c, cell.r)).ok && b.pieces.length === 10);
      second.color = 'black';
      check(`${side} full-board swap legal`, withBoard(b, () => boardToPiece(first, second)).ok &&
        b.pieces.length === 10 && second.c === cell.c && second.r === cell.r);
      b.shopSlots[0] = native('black');
      check(`${side} full-board native equal exchange legal`, withBoard(b, () => shopToPiece(0, first)).ok &&
        b.pieces.length === 10 && b.shopSlots[0].piece === first && b.gold === 100 - SHOP.price.piece);
      const replacement = b.pieces.find(p => p.c === first.c && p.r === first.r);
      const paid = b.gold;
      check(`${side} full-board returned equal exchange legal`, withBoard(b, () => shopToPiece(0, replacement)).ok &&
        b.pieces.length === 10 && b.pieces.includes(first) && b.shopSlots[0].piece === replacement && b.gold === paid);
      b.shopSlots[0] = native();
      check(`${side} full-board shop merge legal`, withBoard(b, () => shopToPiece(0, first)).ok &&
        b.pieces.length === 10 && first.stage === 1 && !b.shopSlots[0]);
      const merge = fixture(side);
      check(`${side} full-board board merge legal`, withBoard(merge, () => boardToPiece(merge.pieces[1], merge.pieces[0])).ok &&
        merge.pieces.length === 9 && merge.pieces[0].stage === 1);

      const source = fixture(side); source.shopSlots[0] = native(); source.shopSlots[1] = spell();
      for (const action of [
        { kind: 'buy', slot: 0, ...cell, cost: SHOP.price.piece },
        { kind: 'spell', slot: 1, spellId: spec.id, effect: spec.effect, color: 'black', ...cell, cost: spec.price },
      ]) {
        const before = snapshot(source);
        check(`${side} AI full ${action.kind} returns no branches`, actionBranches(source, action).length === 0 && snapshot(source) === before);
        const evaluation = evaluateAction(source, action, true);
        check(`${side} AI illegal ${action.kind} unselectable`, !evaluation.branches.length && evaluation.score === -Infinity);
        const guarded = { ...source, uncloneable: () => {} };
        const guardedAction = { ...action, get cost() { throw Error('Illegal branch read cost'); } };
        check(`${side} AI illegal ${action.kind} rejects before clone/cost/cache`, actionBranches(guarded, guardedAction).length === 0);
        const almost = fixture(side, 9); almost.shopSlots = source.shopSlots;
        const branches = actionBranches(almost, action);
        check(`${side} AI legal tenth ${action.kind}`, branches.length === 1 &&
          branches.every(branch => branch.board.pieces.length === 10 && branch.board.gold === 100 - action.cost));
      }
      check(`${side} AI full move still branches`, actionBranches(source,
        { kind: 'move', pieceId: source.pieces[0].id, ...cell }).length === 1);
      check(`${side} AI full shop merge still branches`, actionBranches(source,
        { kind: 'shopMerge', slot: 0, targetId: source.pieces[0].id, cost: SHOP.price.piece })[0].board.pieces.length === 10);
    }
    const left = fixture('me', 9), right = fixture('opp');
    left.shopSlots[0] = native(); right.shopSlots[0] = native();
    const rightBefore = snapshot(right);
    check('capacity is per-board, not combined', withBoard(right, () => withBoard(left,
      () => buyAndPlace(0, cell.c, cell.r))).ok && left.pieces.length === 10 && snapshot(right) === rightBefore);
    check('empty branch risk is unselectable, never NaN', riskAdjusted([]) === -Infinity);
    check('all board contexts restored', game.cur === original.cur);
    return { passed: checks.length, checks };
  } finally {
    Math.random = original.random; setGoldChangeHook(original.hook);
    game.cur = original.cur; game.floaters = original.floaters;
  }
}
