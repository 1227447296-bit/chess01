/**
 * aiSimulation.js —— 有界、只读的己方短期真实战斗推演。
 * 默认不生成新怪；可显式注入有限 spawnPlan，只复用 wave.update 的战斗。
 * 计划事件仅出生在私有克隆，不触碰正式共享调度、UID或随机。
 * _simulationContext 仅安装在私有克隆上，绝不替换 Math.random 或正式波次/phase。
 */
import game, { createBoard, withBoard } from './gameData.js';
import { update as updateBoard, registerWaveEnemy } from './wave.js';
import { rescanBonds } from './bond.js';
import { BOSS } from './boss.js';

const MAX_HORIZON = 30;
const MAX_STEPS = 7200;
const EPSILON = 1e-9;

// 地图几何在正式游戏里也由双方共享；只标记已知只读字段，未知扩展仍深复制。
// 不 freeze 源对象（freeze 本身也会改变输入），也不共享 cleared。
const READ_ONLY_MAP_KEYS = ['ground', 'grass', 'road', 'path', 'enemySpawn', 'kingPoint', 'raw'];
const readOnlyMapData = new WeakSet();
function markReadOnlyMapData(value) {
  if (!value || typeof value !== 'object' || readOnlyMapData.has(value)) return;
  readOnlyMapData.add(value);
  for (const child of Object.values(value)) markReadOnlyMapData(child);
}

/** 深复制可变数据图；地图几何只读共享，保留 Set/Map、环及共享引用，不分配 UID。 */
export function cloneBoard(source) {
  if (source?.map) {
    for (const key of READ_ONLY_MAP_KEYS) markReadOnlyMapData(source.map[key]);
  }
  const seen = new Map();
  function copy(value) {
    if (value === null || typeof value !== 'object') return value;
    if (readOnlyMapData.has(value)) return value;
    if (seen.has(value)) return seen.get(value);
    if (value instanceof Set) {
      const out = new Set();
      seen.set(value, out);
      for (const item of value) out.add(copy(item));
      return out;
    }
    if (value instanceof Map) {
      const out = new Map();
      seen.set(value, out);
      for (const [key, item] of value) out.set(copy(key), copy(item));
      return out;
    }
    const out = Array.isArray(value) ? [] : {};
    seen.set(value, out);
    for (const key of Object.keys(value)) {
      if (key !== '_simulationContext') out[key] = copy(value[key]);
    }
    return out;
  }
  return copy(source);
}

function seededRandom(seed) {
  let state = Number(seed) >>> 0;
  return () => {
    state += 0x6D2B79F5;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const aliveEnemies = board => board.enemies.filter(e => !e.done && !e.dying && e.hp > 0);

/**
 * @param {object} source 完整棋盘快照；本次到时的候选动作应先作用于调用者的克隆。
 * @param {object} options
 * @param {number} [options.horizon=10] 推演秒数，封顶30秒。
 * @param {number} [options.step=1/30] 步长限制在1/240～1/30，避免车逐格命中被大步长跳过。
 * @param {number} [options.seed=173] 独立暴击随机种子，不复制/消耗正式随机状态。
 * @param {Array<{at:number,wave:number,hp:number,speed:number}>} [options.spawnPlan]
 *   显式有限事件，at非负且严格递增（秒）；建议用 buildSpawnPlan(...).events。
 *   at是调度tick结束时间，出生在该tick战斗更新前，非t0批量生成。
 *   与计划使用相同horizon/step；不规则事件时间或延迟动作边界可细分战斗tick。
 *   创建时复制事件值；horizon以外事件不阻止早停，不读取正式调度或推断后续波次。
 * @param {number} [options.actionDelay] 可选的下一手反应时间，必须显式>0。
 * @param {function} [options.mutateAfterDelay] 只接收克隆棋盘的同步、确定性变换，最多调用一次。
 *   不得访问真实棋盘、调用随机合成/刷新/UID生成函数或返回Promise；随机分支须在外层枚举。
 *   移动/撤回不自动清冷却、冲刺或践踏状态。回调到时后才重扫羁绊，绝非零延迟回位。
 *   地图几何是只读共享数据；回调只能更换几何字段，不能原地修改其数组/坐标/raw。
 * @returns {{advance: function, done: boolean, result: object|null}}
 * advance(maxSteps=Infinity, timeBudgetMs=Infinity) 或 advance({maxSteps,timeBudgetMs})。
 * 时间预算为软上限：不可抢占单次战斗tick；创建时克隆、完成时汇总也非分帧操作。
 * 未完成时 result/advance 返回 null，不能把机会分支的半截统计当完整结果。
 */
export function createCombatSimulation(source, options = {}) {
  const { horizon = 10, step = 1 / 30, seed = 173, actionDelay, mutateAfterDelay, spawnPlan } = options;
  if (!source || !source.map || !Array.isArray(source.pieces) || !Array.isArray(source.enemies)) {
    throw new TypeError('simulateCombat requires a complete board');
  }
  if (!Number.isFinite(horizon) || !Number.isFinite(step) || step <= 0 || !Number.isFinite(seed)) {
    throw new TypeError('horizon, positive step and seed must be finite numbers');
  }
  if (mutateAfterDelay !== undefined && typeof mutateAfterDelay !== 'function') {
    throw new TypeError('mutateAfterDelay must be a function');
  }
  if (mutateAfterDelay && (!Number.isFinite(actionDelay) || actionDelay <= 0)) {
    throw new TypeError('a delayed mutation requires an explicit positive actionDelay');
  }
  const duration = Math.max(0, Math.min(MAX_HORIZON, horizon));
  const dt = Math.max(1 / 240, Math.min(1 / 30, step));
  if (spawnPlan !== undefined && !Array.isArray(spawnPlan)) throw new TypeError('spawnPlan must be an event array');
  let previousAt = -Infinity;
  const events = (spawnPlan || []).map(event => {
    if (!event || !Number.isFinite(event.at) || event.at < 0 || event.at <= previousAt ||
        !Number.isSafeInteger(event.wave) || event.wave < 1 ||
        !Number.isFinite(event.hp) || event.hp <= 0 || !Number.isFinite(event.speed) || event.speed < 0) {
      throw new TypeError('spawnPlan requires strictly increasing non-negative times and valid enemy stats');
    }
    previousAt = event.at;
    // 复制显式出生规格；旧的手写hp/speed事件仍是普通怪，不能按波次再次推断Boss。
    const isBoss = event.isBoss === true;
    return { at: event.at, wave: event.wave, hp: event.hp, speed: event.speed,
      isBoss, bossWave: isBoss ? event.wave : null, spawnIndex: event.spawnIndex,
      displayName: event.displayName ?? (isBoss ? '王' : '寇'),
      spriteKey: event.spriteKey ?? BOSS.spriteKey,
      spriteScale: event.spriteScale ?? (isBoss ? BOSS.spriteScale : 1),
    };
  }).filter(event => event.at <= duration + EPSILON);
  const board = cloneBoard(source);
  const enemyIds = new Set(board.enemies.map(enemy => enemy.id));
  let localEnemyId = 0;
  let eventIndex = 0;
  let generatedCount = 0;
  let generatedHp = 0;
  function injectEnemy(event) {
    let id;
    do { id = `sim-spawn-${++localEnemyId}`; } while (enemyIds.has(id));
    enemyIds.add(id);
    const spawn = board.map.enemySpawn;
    if (!spawn) throw new TypeError('spawnPlan requires map.enemySpawn');
    board.wave = event.wave;
    board.spawned += 1;
    board.enemies.push({
      id, kind: 'enemy', c: spawn.c, r: spawn.r, fx: spawn.c, fy: spawn.r,
      hp: event.hp, maxHp: event.hp, speed: event.speed, progress: 0,
      isBoss: event.isBoss, bossWave: event.bossWave, spawnIndex: event.spawnIndex,
      displayName: event.displayName, spriteKey: event.spriteKey, spriteScale: event.spriteScale,
      done: false, dying: false, deathT: 0, stunLeft: 0, stunImmuneLeft: 0,
    });
    registerWaveEnemy(board, board.enemies[board.enemies.length - 1], event.wave);
    generatedCount++;
    generatedHp += event.hp;
  }
  // 纯表现数据无需复制后继续演算；死亡闪烁/charge/stomp属于规则，必须保留。
  board.bullets = [];
  board.paintSplats = [];
  const context = { random: seededRandom(seed) };
  const startLives = board.lives;
  const startKills = board.kills;
  const startGold = board.gold;
  const startRemainingHp = aliveEnemies(board).reduce((sum, e) => sum + e.hp, 0);
  let elapsed = 0;
  let steps = 0;
  let bondTimer = 0;
  let mutationApplied = false;

  let initialized = false;
  let done = false;
  let result = null;
  let failure;
  let failed = false;
  let advancing = false;
  const now = () => globalThis.performance?.now() ?? Date.now();
  const hasEnemies = () => board.enemies.some(e =>
    (!e.done && !e.dying && e.hp > 0) ||
    // 真实波次的死亡闪烁尚未离场，必须继续更新以兑现清波奖励。
    (board.waveClearState?.[e.spawnWave] && !board.waveClearState[e.spawnWave].settled));
  const finished = () => elapsed >= duration - EPSILON || steps >= MAX_STEPS || board.dead ||
    ((!mutateAfterDelay || mutationApplied) && eventIndex >= events.length && !hasEnemies());

  function finish() {
    const remaining = aliveEnemies(board);
    result = {
      leaks: Math.max(0, startLives - board.lives),
      kills: Math.max(0, board.kills - startKills),
      remainingHp: remaining.reduce((sum, e) => sum + e.hp, 0),
      remainingEnemies: remaining.length,
      startRemainingHp,
      generatedCount,
      generatedHp,
      goldGain: board.gold - startGold,
      lives: board.lives,
      dead: board.dead,
      elapsed,
      steps,
      mutationApplied,
      truncated: horizon > MAX_HORIZON || (steps >= MAX_STEPS && elapsed < duration - EPSILON),
      board,
    };
    done = true;
    return result;
  }

  function advance(maxSteps = Infinity, timeBudgetMs = Infinity) {
    if (typeof maxSteps === 'object' && maxSteps !== null) {
      ({ maxSteps = Infinity, timeBudgetMs = Infinity } = maxSteps);
    }
    if (!(maxSteps >= 0) || !(timeBudgetMs >= 0) ||
        typeof maxSteps !== 'number' || typeof timeBudgetMs !== 'number') {
      throw new TypeError('advance budgets must be non-negative numbers or Infinity');
    }
    if (failed) throw failure;
    if (advancing) throw new Error('simulation advance cannot be reentrant');
    if (done) return result;
    const limit = Math.floor(maxSteps);
    if (!limit || !timeBudgetMs) return null;
    const deadline = timeBudgetMs === Infinity ? Infinity : now() + timeBudgetMs;
    let advanced = 0;
    advancing = true;
    Object.defineProperty(board, '_simulationContext', { value: context, configurable: true });
    try {
      withBoard(board, () => {
        if (!initialized) {
          rescanBonds();
          initialized = true;
        }
        while (!finished() && advanced < limit && (deadline === Infinity || now() < deadline)) {
          if (mutateAfterDelay && !mutationApplied && elapsed + EPSILON >= actionDelay) {
            const changed = mutateAfterDelay(board);
            if (changed && typeof changed.then === 'function') {
              throw new TypeError('simulation mutation must be synchronous');
            }
            mutationApplied = true;
            rescanBonds();
            if (finished()) break;
          }
          let tick = Math.min(dt, duration - elapsed);
          if (mutateAfterDelay && !mutationApplied && actionDelay > elapsed + EPSILON) {
            tick = Math.min(tick, actionDelay - elapsed);
          }
          // 调度先于该 tick 的战斗；只注入下一事件，不在 t0 预塞未来敌人。
          const nextEvent = events[eventIndex];
          if (nextEvent) {
            // 显式 at:0 事件占用一个零时长私有tick，避免吞掉后续很近的事件。
            tick = Math.min(tick, Math.max(0, nextEvent.at - elapsed));
          }
          if (nextEvent && nextEvent.at <= elapsed + tick + EPSILON) {
            injectEnemy(nextEvent);
            eventIndex++;
          }
          updateBoard(tick);
          elapsed += tick;
          steps += 1;
          advanced += 1;
          bondTimer += tick;
          // 跨 advance 保留计时；只有正式 tick 累计满0.4秒才重扫。
          if (bondTimer + EPSILON >= 0.4) {
            bondTimer = 0;
            rescanBonds();
          }
        }
      });
      if (finished()) finish();
    } catch (error) {
      // 出错后的部分状态不可重试、更不可作为完整机会分支提交。
      failed = true;
      failure = error;
      throw error;
    } finally {
      delete board._simulationContext;
      advancing = false;
    }
    return result;
  }

  return { advance, get done() { return done; }, get result() { return result; } };
}

/** 兼容既有同步调用者；分帧调用者应显式使用 createCombatSimulation。 */
export function simulateCombat(source, options = {}) {
  const simulation = createCombatSimulation(source, options);
  return simulation.advance();
}

/** 无DOM/存档的最小回归fixture；显式调用，不在模块加载时执行。 */
export function runSimulationFixtures() {
  const assert = (condition, message) => { if (!condition) throw new Error(message); };
  const makeBoard = () => {
    const board = createBoard('me');
    board.map = {
      cols: 5, rows: 3,
      ground: Array.from({ length: 3 }, () => Array(5).fill(1)),
      grass: Array.from({ length: 3 }, () => Array(5).fill(0)),
      road: [Array(5).fill(1), Array(5).fill(0), Array(5).fill(0)],
      cleared: new Set(['1,1']),
      path: Array.from({ length: 5 }, (_, c) => ({ c, r: 0 })),
      enemySpawn: { c: 0, r: 0 }, kingPoint: { c: 4, r: 0 }, raw: null,
    };
    board.enemies = [{
      id: 'fixture-enemy', c: 1, r: 0, fx: 1, fy: 0, hp: 10, maxHp: 10,
      speed: 0.65, progress: 1, done: false, dying: false, deathT: 0,
      stunLeft: 0, stunImmuneLeft: 0,
    }];
    board.pieces = [{
      id: 'fixture-bing', kind: 'piece', type: 'bing', color: 'red', c: 1, r: 1,
      level: 0, exp: 0, stage: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [],
    }];
    return board;
  };
  const originalCur = game.cur;
  const originalPhase = game.phase;
  const board = makeBoard();
  const before = JSON.stringify(board);
  const a = simulateCombat(board, { horizon: 1, seed: 17 });
  const b = simulateCombat(board, { horizon: 1, seed: 17 });
  assert(a.kills === 1 && a.leaks === 0 && a.goldGain === 2, 'fixture: kill/reward');
  assert(a.board.pieces[0].exp === 10 && a.board.pieces[0].level === 0, 'fixture: shared kill experience without free level');
  assert(JSON.stringify(a) === JSON.stringify(b), 'fixture: reproducible results');
  assert(JSON.stringify(board) === before && board.map.cleared.has('1,1'), 'fixture: source unchanged');
  assert(game.cur === originalCur && game.phase === originalPhase, 'fixture: global context unchanged');
  assert(a.steps === 1, 'fixture: stop immediately after final kill');
  const empty = makeBoard();
  empty.enemies = [];
  assert(simulateCombat(empty).steps === 0, 'fixture: empty combat does not tick');

  const leaking = makeBoard();
  leaking.pieces = [];
  leaking.enemies[0].progress = 3.99;
  const leak = simulateCombat(leaking, { horizon: 0.1 });
  assert(leak.leaks === 1 && leak.kills === 0, 'fixture: existing enemy leaks');

  const delayed = makeBoard();
  delayed.pieces = [];
  delayed.enemies[0].progress = 3.8;
  const late = simulateCombat(delayed, {
    horizon: 1, actionDelay: 0.5,
    mutateAfterDelay: clone => { clone.pieces = cloneBoard(board.pieces); },
  });
  assert(late.leaks === 1 && late.mutationApplied, 'fixture: delayed move cannot undo earlier leak');

  const alias = makeBoard();
  alias.shopSlots[0] = { source: 'fromBoard', piece: alias.pieces[0] };
  const aliasCopy = cloneBoard(alias);
  assert(aliasCopy.shopSlots[0].piece === aliasCopy.pieces[0], 'fixture: clone preserves aliases');
  assert(aliasCopy.pieces[0] !== alias.pieces[0], 'fixture: nested data isolated');
  let caught = false;
  try {
    simulateCombat(board, { horizon: 1, actionDelay: 0.1, mutateAfterDelay: () => { throw new Error('fixture'); } });
  } catch { caught = true; }
  assert(caught && game.cur === originalCur && game.phase === originalPhase, 'fixture: exception restores context');

  const slow = makeBoard();
  slow.enemies[0].hp = slow.enemies[0].maxHp = 10000;
  const sync = simulateCombat(slow, { horizon: 1, seed: 39 });
  const incremental = createCombatSimulation(slow, { horizon: 1, seed: 39 });
  assert(!incremental.done && incremental.result === null && incremental.advance(0) === null,
    'fixture: unstarted/zero-budget simulation has no result');
  assert(incremental.advance({ maxSteps: 2, timeBudgetMs: 0 }) === null,
    'fixture: zero time budget does no work');
  assert(incremental.advance(2) === null && !incremental.done &&
    game.cur === originalCur && !slow._simulationContext, 'fixture: slice restores context');
  while (!incremental.done) incremental.advance({ maxSteps: 2, timeBudgetMs: 10 });
  assert(JSON.stringify(incremental.result) === JSON.stringify(sync), 'fixture: sliced result matches sync');
  assert(incremental.advance(1) === incremental.result, 'fixture: completed result is stable');
  assert(aliasCopy.map !== alias.map && aliasCopy.map.path === alias.map.path &&
    aliasCopy.map.ground === alias.map.ground && aliasCopy.map.cleared !== alias.map.cleared,
    'fixture: share only read-only map geometry');
  const graph = { piece: slow.pieces[0] };
  graph.self = graph;
  graph.set = new Set([graph.piece]);
  graph.map = new Map([[graph.piece, graph]]);
  const graphCopy = cloneBoard(graph);
  assert(graphCopy.self === graphCopy && graphCopy.set.has(graphCopy.piece) &&
    graphCopy.map.get(graphCopy.piece) === graphCopy, 'fixture: Set/Map/cycle aliases preserved');
  const pending = createCombatSimulation(delayed, {
    horizon: 1, actionDelay: 0.5,
    mutateAfterDelay: clone => { clone.pieces = cloneBoard(board.pieces); },
  });
  while (!pending.done) pending.advance(1);
  assert(JSON.stringify(pending.result) === JSON.stringify(late), 'fixture: delayed mutation survives slices');
  return { ok: true, checks: 20 };
}

export default simulateCombat;
