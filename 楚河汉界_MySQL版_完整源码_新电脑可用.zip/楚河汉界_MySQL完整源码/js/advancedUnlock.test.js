import game, { createBoard, withBoard } from './gameData.js';
import { LEVEL_UNLOCK, LEVEL_EFFECT_TEXT, SPELL_BY_ID, enemyStatsForWave } from './config.js';
import { hasUnlock } from './attackRule.js';
import { bondKeysBetween } from './bond.js';
import { specialThreshold } from './tacticalEffects.js';
import { enemySpecForSpawn } from './boss.js';
import { update, updateCombat } from './wave.js';
import { render, renderState } from './render.js';

export function runAdvancedUnlockTests() {
  let passed = 0;
  const check = (ok, msg) => { if (!ok) throw Error(msg); passed++; };
  for (const type of ['ju', 'ma', 'pao']) {
    for (const [lv, mech] of Object.entries(LEVEL_UNLOCK[type])) {
      check((type === 'ma' ? [50,70,80,90] : [50,70,80]).includes(+lv), '所有门槛已映射');
      check(!hasUnlock({ type, level: +lv - 1 }, mech), '技能门槛前不解锁');
      check(hasUnlock({ type, level: +lv }, mech), '技能准确解锁');
      check(LEVEL_EFFECT_TEXT[type][lv], '详情同门槛');
    }
    check(specialThreshold({type,level:59}) === 0, '59级无蓄势');
    check(specialThreshold({type,level:60}) === {ju:6,ma:5,pao:4}[type], '60级基础特殊技');
    check(specialThreshold({type,level:99}) === {ju:6,ma:5,pao:4}[type], '99级不提前强化');
    check(specialThreshold({type,level:100}) === {ju:4,ma:4,pao:3}[type], '100级强化');
  }
  check(SPELL_BY_ID.fankeweizhu.effect.minLevel === 60, '反客为主门槛同步');
  const b = createBoard('me', {cols:8,rows:4,ground:[],grass:[],road:[],path:Array.from({length:8},(_,c)=>({c,r:2}))});
  const prev = {cur:game.cur,phase:game.phase,render:{...renderState}};
  try {
    game.phase = 'playing';
    withBoard(b, () => {
      for (const [aType,bType,key] of [['ma','pao','ma_pao'],['pao','pao','pao_pao'],['ju','ju','ju_ju']]) {
        const a={id:'a',type:aType,color:'red',c:0,r:0,level:999}, mate={id:'b',type:bType,color:'black',c:1,r:0,level:999};
        b.pieces=[a,mate];
        check(!bondKeysBetween(a,mate).includes(key), '车马炮50级羁绊已删除');
      }
      for (const [wave,hp,speed] of [[8,4.8,.432],[15,7.2,.396],[20,9.6,.36]]) {
        const base=enemyStatsForWave(wave), boss=enemySpecForSpawn(wave,0);
        check(Math.abs(boss.hp-base.hp*hp)<1e-6 && Math.abs(boss.speed-base.speed*speed)<1e-6,'王血量减20%移速减10%');
      }
      for (const level of [60,100]) {
        b._simulationContext={random:()=>1}; b.gameTime=0; b.tacticalHorseGhosts=[];
        const horse={id:'horse',kind:'piece',type:'ma',color:'red',c:1,r:1,level,stage:0,exp:0,flags:{},cdLeft:0,specialCount:specialThreshold({type:'ma',level})-1};
        b.pieces=[horse]; b.enemies=[{id:'e',kind:'enemy',c:3,r:2,fx:3,fy:2,progress:3,speed:0,hp:100000,maxHp:100000,stunLeft:0,stunImmuneLeft:0}];
        updateCombat(0);updateCombat(.3);
        check(b.tacticalHorseGhosts.length===(level===100?3:2),'特殊技真实生成马虚影');
        b.pieces=[]; b.enemies=[]; b.gameTime=.2;
        for (const sideways of [false,true]) for (const flip of [false,true]) {
          const calls=[]; const ctx=new Proxy({}, {get(_,key){if(key==='measureText')return()=>({width:30});if(key==='createLinearGradient'||key==='createRadialGradient')return()=>({addColorStop(){}});return(...args)=>calls.push({key,args});},set(){return true;}});
          Object.assign(renderState,{ctx,tile:60,sideways,flip,readonly:true});render(.2);
          check(calls.some(c=>c.key==='fillText'&&c.args[0]==='马'),'马虚影文字可见且正立');
          check(calls.some(c=>c.key==='drawImage'&&c.args.length===5),'马虚影确实绘制棋子素材');
        }
        update(1);
        check(b.tacticalHorseGhosts.length===0,'虚影攻击后自动消失');
      }
    });
    return {passed};
  } finally {game.cur=prev.cur;game.phase=prev.phase;Object.assign(renderState,prev.render);}
}
