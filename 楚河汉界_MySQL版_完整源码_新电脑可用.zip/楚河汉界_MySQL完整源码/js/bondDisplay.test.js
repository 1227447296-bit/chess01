import { BOND_CONFIG, BOND_EFFECT, bondDetailText, pieceDisplayName } from './config.js';
import { drawBondBox } from './bondEffect.js';

export function runBondDisplayFixtures() {
  let passed = 0;
  const check = (name, ok) => {
    if (!ok) throw new Error(name);
    passed++;
  };
  const expected = {
    red: { bing: '兵', shi: '仕', xiang: '相', ma: '马', pao: '炮', ju: '车', king: '帅' },
    black: { bing: '卒', shi: '士', xiang: '象', ma: '馬', pao: '砲', ju: '車', king: '将' },
  };
  for (const [color, names] of Object.entries(expected)) {
    for (const [type, name] of Object.entries(names)) {
      const piece = { color, type };
      check(`${color}/${type}显示字`, pieceDisplayName(piece) === name);
      for (const conf of Object.values(BOND_CONFIG).filter(c => c.requireType.includes(type))) {
        const text = bondDetailText(piece, conf);
        const partnerType = conf.requireType.find(t => t !== type) || type;
        const partnerColor = conf.colorRule === 'mixed' ? (color === 'red' ? 'black' : 'red') : color;
        check(`${name}/${conf.name}搭档`, text.includes(`与${expected[partnerColor][partnerType]}`));
        check(`${name}/${conf.name}无旧版比较文案`, !/不再加级|不再升级|旧版|原版/.test(text));
        if (conf.effect === 'waveLevel') check(`${name}/士象说明限定`, text.includes('全场攻击+10%') && text.includes('只能激活一组'));
        check(`${name}/${conf.name}不重复等级条件`, !/任一|任意|5级|10级|50级|翻倍|兵士突击/.test(text));
      }
    }
  }
  check('二鬼拍门名称保留', BOND_CONFIG.bing_bing.name === '二鬼拍门');
  check('只保留两组羁绊', Object.keys(BOND_CONFIG).join() === 'bing_bing,shi_xiang');
  check('士象全需两者都15级且限定一组', BOND_CONFIG.shi_xiang.requireLevel === 15 && BOND_CONFIG.shi_xiang.limit === 1);
  check('移除旧金币和经验翻倍效果', Object.values(BOND_CONFIG).every(c => !['gold3', 'expDouble'].includes(c.effect)));
  check('红黑搭配使用红黑双色', BOND_EFFECT.mix.strokeA === BOND_EFFECT.red.stroke && BOND_EFFECT.mix.strokeB === BOND_EFFECT.black.stroke);
  for (const branch of ['red', 'black', 'mix']) {
    const stops = [];
    const ctx = {
      save() {}, restore() {}, beginPath() {}, moveTo() {}, arcTo() {}, closePath() {}, stroke() {},
      createLinearGradient() { return { addColorStop(at, color) { stops.push(color); } }; },
    };
    drawBondBox(ctx, c => c * 60, r => r * 60, 60, {
      bond: { branch }, a: { c: 0, r: 0 }, b: { c: 1, r: 0 },
    }, 0);
    const palette = branch === 'mix'
      ? [BOND_EFFECT.mix.strokeA, BOND_EFFECT.mix.strokeB]
      : [BOND_EFFECT[branch].stroke, BOND_EFFECT[branch].glow];
    check(`${branch}框使用统一色系`, stops.length === 4 && stops.every(c => palette.includes(c)));
    check(`${branch}框非纯红纯黑`, stops.every(c => !['#000', '#000000', '#f00', '#ff0000'].includes(c)));
  }
  return passed;
}
