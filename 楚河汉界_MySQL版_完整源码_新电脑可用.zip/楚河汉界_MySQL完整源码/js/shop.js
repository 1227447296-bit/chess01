/**
 * shop.js —— 商店逻辑
 * 刷新、消耗金币、卡牌生成、高阶法术概率提升、购买逻辑、商店空位双向拖拽。
 *
 * 商店卡位来源（source 标记，UI 区分）：
 *   { source:'native', type:'pieceShovel'|'spell', ... } —— 原生刷新卡，显示价格
 *   { source:'fromBoard', piece }                        —— 场上棋子放回，无价格、不扣费
 */
import { SHOP, SPELLS, SPELL_BY_ID } from './config.js';
import game, { uid, spendGold, currentRefreshCost } from './gameData.js';
import { spellStockLeft, hasLegalSpellTarget } from './spell.js';
import { effectiveLives } from './tacticalEffects.js';

/* ============================================================
 * 卡牌生成
 * ============================================================ */

/** 仅本盘公开状态；双方商店共享同一个倍率，不读取未来怪或对方商店。 */
export function spellSituationWeight(spec, board = game.cur) {
  if (!hasLegalSpellTarget(spec, board)) return 0;
  const alive = board.enemies.filter(e => e.hp > 0 && !e.done && !e.dead && !e.dying);
  const end = Math.max(1, board.map.path.length - 1);
  const danger = alive.some(e => (e.progress || 0) >= end * 0.7);
  if (spec.role === 'rescue') return effectiveLives(board) <= 1 ? 3 : danger ? 2 : 1;
  return !danger && ['growth', 'offense'].includes(spec.role) ? 1.3 : 1;
}

/** 已解锁、仍有库存并有当前合法结构性目标的法术。 */
export function availableSpells() {
  const tiers = [1, 2, 3].filter(t => game.wave >= SHOP.spellTierUnlock[t]);
  return SPELLS.filter(s => tiers.includes(s.tier) && spellStockLeft(s.id) > 0 && spellSituationWeight(s) > 0);
}

/** 依据当前权重 + 法术解锁阶数 / 库存，抽一张「原生卡」类型 */
export function randomCardType() {
  // 铲子是否还能刷出：玩家「已实际使用」的铲子未达上限才可
  const shovelAvailable = (game.shovelUsed || 0) < (SHOP.shovelMaxUsed ?? Infinity);
  // 法术同理：可刷池为空（全部用完库存）→ 法术权重归 0
  const spells = availableSpells();

  const w = SHOP.weights;
  const pieceWeight = availablePieceSpecs().reduce((sum, p) => sum + p.weight, 0);
  const shovelW = shovelAvailable ? w.shovel : 0;     // 达上限 → 铲子权重归 0
  const spellW = spells.length ? w.spell : 0;

  const total = pieceWeight + shovelW + spellW;
  let roll = random() * total;

  // 兵（先红后黑，各半）
  if (roll < pieceWeight) {
    return randomPieceCard();
  }
  roll -= pieceWeight;
  if (roll < shovelW) {
    return { source: 'native', type: 'shovel' };
  }
  return pickSpell(spells);
}

const random = () => (game.cur?._simulationContext?.random ?? Math.random)();
export function availablePieceSpecs() {
  // 实验版原生棋子卡固定为兵；高阶棋种只由融合/法术产生。
  return SHOP.piecePool.filter(p => p.type === 'bing' && game.wave >= p.wave);
}
export function randomPieceCard() {
  const pool = availablePieceSpecs();
  let roll = random() * pool.reduce((sum, p) => sum + p.weight, 0);
  let pick = pool[pool.length - 1];
  for (const spec of pool) {
    if (roll < spec.weight) { pick = spec; break; }
    roll -= spec.weight;
  }
  return { source: 'native', type: 'piece', kind: pick.type, color: random() < 0.5 ? 'red' : 'black',
    level: pick.level, price: pick.price, stage: 0, mergeCount: 0 };
}
function randColorBing() {
  const spec = SHOP.piecePool.find(p => p.type === 'bing');
  return { source: 'native', type: 'piece', kind: 'bing', color: random() < 0.5 ? 'red' : 'black',
    level: spec.level, price: spec.price, stage: 0, mergeCount: 0 };
}

/** 从可刷法术池内按阶权重抽一张（pool 由 availableSpells 提供，非空） */
function pickSpell(spells) {
  const w = SHOP.spellTierWeight;
  const pool = spells.map(s => ({ s, wt: (w[s.tier] || 1) * spellSituationWeight(s) })).filter(p => p.wt > 0);
  if (!pool.length) return randomPieceCard();
  const total = pool.reduce((a, p) => a + p.wt, 0);
  let roll = random() * total;
  let pick = pool[pool.length - 1].s;   // 容错：浮点误差时取最后一张
  for (const p of pool) {
    if (roll < p.wt) { pick = p.s; break; }
    roll -= p.wt;
  }
  return { source: 'native', type: 'spell', id: pick.id, price: pick.price, name: pick.name, tier: pick.tier, kind: pick.kind };
}

/* ============================================================
 * 刷新
 * ============================================================ */

/** 刷新商店：扣费、递增刷新价、累计刷新计数、重新生成卡位 */
export function refreshShop() {
  // 首次刷新免费（用 totalRefreshCount 判断，免费那次也会 +1，不会一直免费）
  const free = SHOP.refreshFirstFree && game.totalRefreshCount === 0;
  const cost = currentRefreshCost();

  if (!free && !spendGold(cost)) return { ok: false, reason: '缺金币' };
  if (!free) game.cur.nextRefreshDiscount = 0;

  // 累计本局总刷新次数（含免费那次）
  game.totalRefreshCount += 1;

  // 付费刷新：累计付费次数（用于法术解锁）并递增下次价格
  if (!free) {
    game.totalShopRefreshCount += 1;
    const step = game.flags.refreshStepHalf
      ? Math.max(1, Math.round(SHOP.refreshCostStep / 2))
      : SHOP.refreshCostStep;
    game.shopRefreshCost += step;
  }

  // 固定卡组：本局第 1 次刷新（免费那次）固定 2 红兵 + 2 黑兵 + 1 铲子
  if (game.totalRefreshCount === 1) {
    game.shopSlots = firstRefreshPack();
  } else {
    game.shopSlots = rollShopSlots();
  }

  return { ok: true };
}

/**
 * 生成本次刷新的整组卡位（含数量上限限制 + 自动排序）：
 *   - 法术牌最多出现 1 张
 *   - 铲子最多出现 1 把
 * 其余位置由小兵填充。是「最多」，不是「一定有」。
 * 排序：红棋 → 黑棋 → 铲子 → 法术牌（从左往右）。
 */
function rollShopSlots() {
  const slots = [];
  let spellCount = 0;
  let shovelCount = 0;

  for (let i = 0; i < SHOP.slotCount; i++) {
    let card = randomCardType();

    // 超上限则改判为兵
    if (card.type === 'spell') {
      if (spellCount >= 1) card = randColorBing();
      else spellCount += 1;
    } else if (card.type === 'shovel') {
      if (shovelCount >= 1) card = randColorBing();
      else shovelCount += 1;
    }
    slots.push(card);
  }
  return sortShopSlots(slots);
}

/** 走为上计：不动回收卡，不涨价/计数，不消耗折扣。模拟仅产生明确机会节点。 */
export function refreshUnboughtCards() {
  if (game.cur._simulationContext) {
    game.shopSlots = game.shopSlots.map(card => card?.source === 'fromBoard' ? card : null);
    game.cur.pendingShopRefresh = true;
    return { ok: true, shopRefreshOpportunity: true };
  }
  let spellCount = 0, shovelCount = 0;
  game.shopSlots = game.shopSlots.map(card => {
    if (card?.source === 'fromBoard') return card;
    let next = randomCardType();
    if (next.type === 'spell') {
      if (spellCount) next = randColorBing();
      else spellCount++;
    } else if (next.type === 'shovel') {
      if (shovelCount) next = randColorBing();
      else shovelCount++;
    }
    return next;
  });
  return { ok: true };
}

/** 商店卡位排序：红棋 → 黑棋 → 铲子 → 法术牌 */
function sortShopSlots(slots) {
  const rank = (card) => {
    if (!card) return 99;
    if (card.type === 'piece' || card.source === 'fromBoard') {
      return card.color === 'red' ? 0 : 1;
    }
    if (card.type === 'shovel') return 2;
    if (card.type === 'spell') return 3;
    return 4;
  };
  // 保留 null（空位）在最后
  return slots
    .map((card, i) => ({ card, i }))
    .sort((a, b) => rank(a.card) - rank(b.card) || a.i - b.i)
    .map(x => x.card);
}

/** 第 1 次刷新固定：2 红兵 + 2 黑兵 + 1 把铲子（并排序） */
function firstRefreshPack() {
  const pack = [];
  for (const color of ['red', 'red', 'black', 'black']) {
    pack.push({ ...randColorBing(), color });
  }
  pack.push({ source: 'native', type: 'shovel' });
  return sortShopSlots(pack);
}

/* ============================================================
 * 购买校验
 * ============================================================ */

/** 原生卡售价 */
export function cardPrice(card) {
  if (card.source !== 'native') return null;    // 从场上回收的棋子：无价格
  if (card.type === 'shovel') return SHOP.price.shovel;
  if (card.type === 'piece') return card.kind && card.kind !== 'bing' ? SHOP.price.piece : (card.price ?? SHOP.price.piece);
  if (card.type === 'spell') return card.price ?? SPELL_BY_ID[card.id]?.price ?? 0;
  return null;
}

/** 后台金币是否足够购买某卡位 */
export function canAfford(slotIndex) {
  const card = game.shopSlots[slotIndex];
  if (!card) return false;
  const price = cardPrice(card);
  if (price === null) return true;   // 回收棋子无需扣费
  return game.gold >= price;
}

/** 尝试购买（起手拖拽时校验）；成功返回 true */
export function tryPurchase(slotIndex) {
  const card = game.shopSlots[slotIndex];
  if (!card) return false;
  const price = cardPrice(card);
  // 回收棋子无需扣费
  if (card.source !== 'native' || price === null) return true;
  return spendGold(price);
}

/** 把某卡位对应「场上棋子」拖到另一空位（空位之间的搬运在 main.js 处理） */

/* ============================================================
 * 卡牌数据（拖拽时展示）
 * ============================================================ */

/** 由卡位 card 生成一张可拖拽的「原生兵棋子」数据（购买成功后才调用） */
export function makePieceFromCard(card) {
  return {
    id: uid('p'),
    kind: 'piece',
    type: 'bing',                     // 原生棋子卡永远是兵；kind 仅兼容旧存档字段
    color: card.color,
    c: -1,            // 尚未落子，由放置时写入
    r: -1,
    level: card.level || 0,
    exp: 0,
    mergeCount: 0,
    atkBonus: 0,
    flags: {},
    stage: 0,         // 阶（自融合次数）
    cdLeft: 0,
    bonds: [],
  };
}

/**
 * 取某个卡位所代表的「棋子数据」（唯一数据源字段统一为 card.piece）。
 * - 场上回收卡（fromBoard）：card.piece 即其棋子对象
 * - 原生兵卡（native piece）：惰性生成并缓存在 card.piece，供商店内融合 / 拖拽 / 预览使用
 * 注意：融合结果也写回 card.piece，因此这里绝不能再生成新的兵，否则会「退化回兵」。
 * @returns {object|null}
 */
export function pieceDataOfCard(card) {
  if (!card) return null;
  if (card.source === 'fromBoard') return card.piece || null;
  if (card.type === 'piece') {
    if (!card.piece) {
      // 兼容旧字段 _piece：若存在则迁移
      card.piece = card._piece || makePieceFromCard(card);
      delete card._piece;
    }
    return card.piece;
  }
  return null;
}

/** 判断该卡位是否是「可参与融合的棋子卡」 */
export const isPieceCard = (card) => !!card && (card.type === 'piece' || card.source === 'fromBoard');

/** 判断是否是法术卡 */
export const isSpellCard = (card) => card?.type === 'spell';

export default {
  refreshShop, randomCardType, cardPrice, canAfford, tryPurchase,
  makePieceFromCard, pieceDataOfCard, isPieceCard, isSpellCard,
};