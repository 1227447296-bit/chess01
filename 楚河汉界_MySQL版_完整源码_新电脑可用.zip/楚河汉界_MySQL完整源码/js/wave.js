/**
 * wave.js —— 波次管理器、敌人移动、帅的流程、战斗结算、游戏结束
 *
 * 流程：开局增益选完 → 帅从 enemy 出生点沿 road 走到 king 点停住（血 3 颗红心）→
 *       待帅到位 → 开始按波次出怪 → 敌人沿 road 向帅移动 →
 *       敌人抵达路线终点（帅所在处）扣帅一点血 → 帅血归零游戏结束。
 *
 * 数量/等待见 WAVES；血量、移速和出怪间隔统一取 config 的波次 helper。
 */
import {
  WAVES, KING, LEVEL, PIECE_STATS, GLOBAL_ATK_SPEED_SCALE, FX,
  JU_CHARGE, PAO_BLAST, MA_STOMP, ENEMY_FX,
  GOLD_ON_KILL, PAO_SLOW_SECONDS,
  BOND_GOLD_TICK, experienceRequired, spawnIntervalForWave,
} from './config.js';
import game, { addGold, addBoardFloater, withBoard } from './gameData.js';
import { pieceDamage, canPieceAttack, hasUnlock, levelCdMult, rollAttack, pieceSkillSpeedMult, normalAttackTargetLimit, controlDurationMult } from './attackRule.js';
import { rescanBonds } from './bond.js';
import { enemySpecForSpawn, announceBossSpawn, updateBossAnnouncement, applyBossHitSlow } from './boss.js';
import { effectiveLives, damageKing, updateTacticalEffects, pieceTacticalStats,
  enemyMovementMultiplier, enemyDamageRate, specialThreshold, registerCannonBurst } from './tacticalEffects.js';

/** 基础经验和群体经验共用升级规则；调用者在整次奖励结束后统一重扫。 */
export function grantExperience(piece, amount) {
  const cap = Math.min(LEVEL.hardCap, LEVEL.naturalCap[piece.type] ?? LEVEL.hardCap);
  if (piece.level >= cap) { piece.exp = 0; return false; }
  const before = piece.level;
  piece.level = Math.max(0, piece.level || 0);
  piece.exp = (piece.exp || 0) + amount;
  addBoardFloater(piece, `+${amount}`, 'exp');
  while (piece.level < cap && piece.exp >= experienceRequired(piece.level)) {
    piece.exp -= experienceRequired(piece.level);
    piece.level++;
  }
  if (piece.level >= cap) piece.exp = 0;
  return piece.level !== before;
}

/** 正式出怪与私有推演共用；只有实际出齐整波，才允许离场结算。 */
export function registerWaveEnemy(board, enemy, wave) {
  if (enemy._waveRegistered) return;
  enemy._waveRegistered = true;
  enemy.spawnWave = wave;
  announceBossSpawn(board, enemy, wave);
  const ledger = board.waveClearState || (board.waveClearState = {});
  const state = ledger[wave] || (ledger[wave] = {
    spawned: 0, remaining: 0, killed: 0, leaked: 0,
    expected: WAVES.firstWaveCount + (wave - 1) * WAVES.countGrowPerWave,
    settled: false,
  });
  state.spawned++;
  state.remaining++;
}

/** 离场原因独立去重；击杀即计killed，抵达终点即计leaked，remaining等死亡闪烁结束才减。 */
function recordWaveOutcome(enemy, outcome) {
  const state = game.cur.waveClearState?.[enemy.spawnWave];
  if (!state || enemy._waveOutcome) return;
  enemy._waveOutcome = outcome;
  state[outcome] = (state[outcome] || 0) + 1;
}

/** 按出生波逐方结算；漏怪也算离场，但致败的最后一漏不会获奖。 */
function settleClearedWaves() {
  for (const [wave, state] of Object.entries(game.cur.waveClearState || {})) {
    if (state.settled || state.spawned < state.expected || state.remaining !== 0) continue;
    state.settled = true;
    if (game.dead || effectiveLives(game.cur) <= 0) continue;
    let changed = false;
    for (const p of game.pieces) {
      const amount = LEVEL.waveExpBase + LEVEL.waveExpPerWave * Number(wave);
      changed = grantExperience(p, amount) || changed;
    }
    if (changed) rescanBonds();
  }
}

/**
 * 二鬼拍门：每组激活中的羁绊各自累计时间，满 intervalSec 秒产出金币。
 * 计时存在 game.bondGoldTimers（按羁绊 id），羁绊断开即清除该组计时。
 * 只在 update（游戏进行中）里调用，暂停时自然不计时。
 */
function updateBondGold(dt) {
  const timers = game.bondGoldTimers || (game.bondGoldTimers = {});
  const alive = new Set();
  for (const b of game.bonds) {
    if (b.effect !== 'goldTick') continue;
    alive.add(b.id);
    timers[b.id] = (timers[b.id] || 0) + dt;
    while (timers[b.id] >= BOND_GOLD_TICK.intervalSec) {
      timers[b.id] -= BOND_GOLD_TICK.intervalSec;
      addGold(BOND_GOLD_TICK.gold, null, { pieceIds: [b.aId, b.bId] });
    }
  }
  for (const id of Object.keys(timers)) if (!alive.has(id)) delete timers[id];
}

/* ============================================================
 * 帅的流程
 * ============================================================ */

/** 初始化帅：从敌人生成点沿 path 出发，走向 king 点 */
export function spawnKing() {
  const spawn = game.map.enemySpawn;
  const kingPoint = game.map.kingPoint;
  if (!spawn || !kingPoint) throw new Error('地图缺少 enemy 或 king 对象点');

  const start = posAlongPath(0);
  game.king = {
    id: 'king-' + game.cur.side, kind: 'king', type: 'king',
    color: 'red',
    c: start.c, r: start.r,
    level: 1, exp: 0, mergeCount: 0, atkBonus: 0,
    flags: {}, cdLeft: 0, bonds: [],
    moving: game.map.path.length > 1,
    arrived: false,
    // 沿路径走过的总格数（浮点）；渲染位置由它插值得出，保证平滑移动
    progress: 0,
    fx: start.fx, fy: start.fy,     // 连续（浮点）格坐标，仅用于渲染
  };
}

/* ============================================================
 * 沿路径的连续位置插值
 * ============================================================ */

/**
 * 把「已走过的格数进度」换算成连续格坐标。
 * progress = 0 → 位于 path[0]；progress = 1.5 → 位于 path[1] 与 path[2] 中点。
 * @returns {{c:number, r:number, fx:number, fy:number, end:boolean}}
 */
function posAlongPath(progress) {
  const path = game.map.path;
  if (!path.length) return { c: 0, r: 0, fx: 0, fy: 0, end: true };

  const maxProg = path.length - 1;
  if (progress >= maxProg) {
    const n = path[maxProg];
    return { c: n.c, r: n.r, fx: n.c, fy: n.r, end: true };
  }
  const i = Math.floor(progress);
  const frac = progress - i;
  const a = path[i], b = path[i + 1] || a;
  const fx = a.c + (b.c - a.c) * frac;
  const fy = a.r + (b.r - a.r) * frac;
  // 逻辑格取最近格（用于攻击判定 / 到达判定）
  return { c: Math.round(fx), r: Math.round(fy), fx, fy, end: false };
}

/** 每帧更新帅移动：沿 path 走到 king 点后停住（连续插值，平滑不跳格） */
function updateKing(dt) {
  const king = game.king;
  if (!king || !king.moving) return;

  king.progress += KING.speedKnife * dt;
  const pos = posAlongPath(king.progress);
  king.c = pos.c; king.r = pos.r;
  king.fx = pos.fx; king.fy = pos.fy;

  if (pos.end) { king.moving = false; king.arrived = true; }
}

/* ============================================================
 * 敌人出生与移动
 * ============================================================ */

/** 生成一只敌人（出生点 = enemy 对象点，随后沿 path 向帅移动） */
function spawnEnemy(spawnIndex) {
  const spawn = game.map.enemySpawn;
  const spec = enemySpecForSpawn(game.wave, spawnIndex);

  game.spawned += 1;
  game.enemies.push({
    id: 'e' + Math.random().toString(36).slice(2, 8),
    kind: 'enemy',
    c: spawn.c, r: spawn.r,
    fx: spawn.c, fy: spawn.r,      // 连续格坐标，仅用于渲染（平滑移动）
    ...spec, maxHp: spec.hp,
    progress: 0,                   // 沿路径走过的总格数（浮点）
    done: false,
    dying: false,                  // 死亡闪烁中
    deathT: 0,
    stunLeft: 0,                   // 眩晕剩余秒
    stunImmuneLeft: 0,             // 眩晕免疫剩余秒
  });
  registerWaveEnemy(game.cur, game.enemies[game.enemies.length - 1], game.wave);
}

/** 每帧更新所有敌人：沿 path 前进；走到尽头则扣帅血；处理眩晕 / 死亡闪烁 */
function updateEnemies(dt) {
  const path = game.map.path;
  const maxProg = path.length - 1;

  for (const e of game.enemies) {
    if (e.done) continue;

    // 死亡优先：眩晕中的敌人被打死后也要正常进入死亡闪烁并按闪烁时长移除，
    // 否则它会被眩晕分支 continue 卡住，死亡白影滞留到眩晕结束。
    if (e.dying) {
      e.deathT += dt;
      continue;
    }

    if (e.maPaoMarkLeft > 0) e.maPaoMarkLeft = Math.max(0, e.maPaoMarkLeft - dt);
    if (e.slowLeft > 0) e.slowLeft = Math.max(0, e.slowLeft - dt);
    // 眩晕倒计时（眩晕期间不移动、且不消耗免疫时间）
    if (e.stunLeft > 0) {
      e.stunLeft -= dt;
      if (e.stunLeft <= 0) {
        // 眩晕刚结束 → 此刻才开始免疫计时（免疫从眩晕结束后算起）
        e.stunLeft = 0;
        e.stunImmuneLeft = e.stunImmuneNext ?? MA_STOMP.stunImmuneDefault;
      }
      continue;
    }
    // 眩晕已结束 → 免疫倒计时
    if (e.stunImmuneLeft > 0) e.stunImmuneLeft -= dt;

    // 炮减速与缓兵不相乘，取较强效果；缓兵使用棋盘游戏时钟的绝对到期时间。
    let speedMul = e.slowLeft > 0 ? 0.7 : 1;
    const spellRemaining = Math.max(0, (e.huanbingSlowUntil || 0) - (game.cur.gameTime || 0));
    if (spellRemaining > 0) {
      const spellMul = Math.max(0, Math.min(1, e.huanbingSlowMultiplier ?? 0.7));
      const activeFraction = dt > 0 ? Math.min(1, spellRemaining / dt) : 1;
      speedMul -= Math.max(0, speedMul - spellMul) * activeFraction;
    }

    speedMul = enemyMovementMultiplier(e, dt, speedMul);
    e.progress += e.speed * speedMul * dt;
    if (e.progress >= maxProg) {
      e.done = true;
      recordWaveOutcome(e, 'leaked');
      hitKing();
      continue;
    }
    const pos = posAlongPath(e.progress);
    e.c = pos.c; e.r = pos.r;
    e.fx = pos.fx; e.fy = pos.fy;
  }
  // 移除：已到终点 或 死亡闪烁结束
  game.enemies = game.enemies.filter(e => {
    const removed = e.done || (e.dying && e.deathT >= ENEMY_FX.deathFlashMs / 1000);
    if (removed) {
      recordWaveOutcome(e, e.dying ? 'killed' : 'leaked');
      const state = game.cur.waveClearState?.[e.spawnWave];
      if (state && !e._waveRemoved) { state.remaining = Math.max(0, state.remaining - 1); e._waveRemoved = true; }
    }
    return !removed;
  });
  settleClearedWaves();
}

/** 敌人抵达终点 → 扣一点帅血，归零则本方落败（结束判定由 main 统一处理） */
function hitKing() {
  if (game.phase !== 'playing' && !game.cur._simulationContext) return;
  if (game.god) return;                       // 作弊：不掉红心
  damageKing(game.cur);
}

/* ============================================================
 * 战斗：棋子攻击
 * ============================================================ */

/** 每帧更新战斗：先推进车冲刺 + 马践踏，再让每枚棋子冷却读完后寻敌开火 */
export function updateCombat(dt) {
  if (game.cur.damageFloaters) game.cur.damageFloaters = game.cur.damageFloaters.filter(f => f.until > (game.cur.gameTime || 0));
  if (game.cur.critBursts) game.cur.critBursts = game.cur.critBursts.filter(f => f.until > (game.cur.gameTime || 0));
  updateCannonShots();
  updateGhosts(dt);
  updateCharges(dt);                       // 车：冲刺推进
  updateStomps(dt);                        // 马：践踏推进（本体冲到目标再慢速返回）

  for (const p of game.pieces) {
    if (p.bingSpeedLeft > 0) {
      p.bingSpeedLeft = Math.max(0, p.bingSpeedLeft - dt);
      if (p.bingSpeedLeft <= 1e-9) { p.bingSpeedLeft = 0; p.bingSpeedStacks = 0; }
    }
    if (p.charge || p.stomp) continue;     // 冲刺/践踏中不参与常规攻击
    if (p.cdLeft > 0) p.cdLeft -= dt;
    if (p.cdLeft > 0) continue;

    const target = findAttackTarget(p);
    if (!target) continue;                 // 没有目标（如炮无炮架）不占用冷却

    fire(p, target);
    p.cdLeft = pieceCooldown(p);           // 成功攻击后刷新冷却；车/马由各自更新结束时刷新
  }
}

/** 推进马践踏：out（快冲）→ 结算 → back（慢返回）→ 回原位 */
function updateStomps(dt) {
  for (const p of game.pieces) {
    const s = p.stomp;
    if (!s) continue;

    if (s.phase === 'out') {
      // 直线冲向目标格（快）
      const dx = s.tc - s.homeC;
      const dy = s.tr - s.homeR;
      const dist = Math.hypot(dx, dy) || 1;
      s.t += MA_STOMP.outSpeed * dt;
      const pct = Math.min(1, s.t / dist);
      s.fx = s.homeC + dx * pct;
      s.fy = s.homeR + dy * pct;

      if (pct >= 1) {
        // 抵达目标格 → 结算伤害/眩晕，进入返回
        const target = { c: s.tc, r: s.tr };
        if (!s.dealt) { resolveMaStomp(p, target); s.dealt = true; }
        s.phase = 'back';
        s.t = 0;
      }
    } else if (s.phase === 'hold') {
      s.t -= dt;
      if (s.t <= 0) s.phase = 'back';
    } else { // back：慢速返回原位
      const dx = s.homeC - s.tc;
      const dy = s.homeR - s.tr;
      const dist = Math.hypot(dx, dy) || 1;
      s.t += MA_STOMP.backSpeed * dt;
      const pct = Math.min(1, s.t / dist);
      s.fx = s.tc + dx * pct;
      s.fy = s.tr + dy * pct;

      if (pct >= 1) {
        p.stomp = null;                    // 回到原位
        p.cdLeft = pieceCooldown(p);       // 践踏结束才刷新冷却
      }
    }
  }
}

/** 最终攻击冷却 = 基础冷却 × 全局攻速倍率 × 等级攻速 × 增益倍率 × 羁绊倍率 */
function pieceCooldown(p) {
  const base = PIECE_STATS[p.type]?.cd ?? 1;
  const global = GLOBAL_ATK_SPEED_SCALE;                       // 全局攻速
  const lv = levelCdMult(p);                                   // 等级：每级 -0.5%
  const bonus = game.flags.cdRateByType?.[p.type] ?? 1;       // 开局海克斯
  const bond = p.bondMods?.cdRate ?? 1;                        // 羁绊
  return base * global * lv * bonus * bond / pieceSkillSpeedMult(p);
}

/** 寻找攻击目标：所有符合判定范围的敌人中取最近的一只 */
function findAttackTarget(p) {
  let best = null, bestDist = Infinity;
  for (const e of game.enemies) {
    if (e.done || e.dying || e.hp <= 0) continue;
    if (!canPieceAttack(p, e)) continue;
    const d = Math.abs(e.c - p.c) + Math.abs(e.r - p.r);
    if (d < bestDist) { bestDist = d; best = e; }
  }
  return best;
}

/**
 * 开火：按棋子种类分发攻击方式。
 *   车 ju ：本体冲刺
 *   炮 pao：范围爆炸
 *   马 ma ：践踏十字 5 格 + 眩晕
 *   其它   ：子弹单体
 */
function fire(p, target) {
  p.attackRoll = rollAttack(p);
  if (hasUnlock(p, 'bingFocus')) {
    p.bingSpeedStacks = Math.min(4, (p.bingSpeedLeft > 0 ? p.bingSpeedStacks || 0 : 0) + 1);
    p.bingSpeedLeft = 5;
  }
  if (p.type === 'ju')  return fireJu(p, target);
  if (p.type === 'pao') return firePao(p, target);
  if (p.type === 'ma')  return fireMa(p, target);
  return fireNormal(p, target);
}

/** 唯一伤害入口：只有实际扣血才记录贡献，最后击杀单独奖励；critical 只用于显示暴击特效。 */
function dealDamage(p, e, amount, critical = false) {
  if (e.done || e.dying || e.hp <= 0 || !(amount > 0)) return 0;
  amount *= enemyDamageRate(e);
  const actual = Math.min(e.hp, amount);
  const contributions = e.damageContributors || (e.damageContributors = {});
  if (p?.id) contributions[p.id] = (contributions[p.id] || 0) + actual;
  e.hp -= amount;
  if (actual > 0) applyBossHitSlow(e, game.cur.gameTime || 0);
  if (!game.cur._simulationContext) {
    const now = game.cur.gameTime || 0;
    const floaters = game.cur.damageFloaters || (game.cur.damageFloaters = []);
    floaters.push({ enemyId: e.id, c: e.fx ?? e.c, r: e.fy ?? e.r,
      amount: actual, ratio: e.maxHp > 0 ? actual / e.maxHp : 0, critical: !!critical,
      born: now, until: now + 0.8 });
    if (critical) {
      const bursts = game.cur.critBursts || (game.cur.critBursts = []);
      bursts.push({ c: e.fx ?? e.c, r: e.fy ?? e.r, born: now, until: now + 0.35 });
    }
  }
  if (e.hp <= 0) onEnemyKilled(e, p);
  return actual;
}
/** 法术只走扣血/击杀结算，不暴击、不产攻击金币、不累计核心特殊技。 */
export function spellDamage(source, enemies, { multiplier = 1, fixed, board = game.cur } = {}) {
  return withBoard(board, () => {
    const amount = fixed ?? pieceDamage(source) * multiplier;
    let total = 0;
    for (const e of new Set(enemies)) {
      if (board.enemies.includes(e)) total += dealDamage(source, e, amount);
    }
    return total;
  });
}

/** 每次有效普通动作的唯一记账点；范围、返程和追加均共享动作快照。 */
function completeNormalAction(p, action, impact) {
  if (!action || action.tacticalCounted || action.spell) return;
  action.tacticalCounted = true;
  const gold = pieceTacticalStats(p).attackGold;
  if (gold > 0) addGold(gold, null, p);
  const threshold = specialThreshold(p);
  if (!threshold) return;
  p.specialCount = (p.specialCount || 0) + 1;
  if (p.specialCount < threshold) return;
  p.specialCount = 0;
  if (p.type === 'pao') queueCannonShot(p, impact, action, p.level >= 100 ? 0.9 : 0.7);
  if (p.type === 'ju') {
    // 独立一次暴击快照，战车不持有源对象，离场之后仍继续存在。
    const snapshot = rollAttack(p);
    (game.cur.tacticalGhosts || (game.cur.tacticalGhosts = [])).push({
      source: { id: p.id, type: p.type, color: p.color },
      damage: snapshot.damage * (p.level >= 100 ? 0.5 : 0.3),
      progress: game.map.path.length - 1, hit: {},
    });
  }
  if (p.type === 'ma') {
    const path = game.map.path;
    let index = path.findIndex(n => n.c === impact.c && n.r === impact.r);
    if (index < 0) return;
    const count = p.level >= 100 ? 3 : 2;
    const rate = p.level >= 100 ? 0.8 : 0.6;
    for (let step = 1; step <= count && index - step >= 0; step++) {
      const cell = path[index - step];
      for (const e of game.enemies) {
        if (e.c === cell.c && e.r === cell.r) dealDamage(p, e, action.damage * rate);
      }
      spawnPaint(cell.c, cell.r, p.color, false);
      const from = path[index - step + 1];
      const now = game.cur.gameTime || 0;
      (game.cur.tacticalHorseGhosts || (game.cur.tacticalHorseGhosts = [])).push({
        color: p.color, c: cell.c, r: cell.r, fromC: from.c, fromR: from.r,
        born: now + (step - 1) * 0.1, until: now + (step - 1) * 0.1 + 0.7,
      });
    }
  }
}
function queueCannonShot(p, target, action, rate) {
  (game.cur.tacticalCannonShots || (game.cur.tacticalCannonShots = [])).push({
    pieceId: p.id, targetId: target.id, until: (game.cur.gameTime || 0) + 0.25,
    action: { ...action, spell: true }, rate,
  });
}
function updateCannonShots() {
  const shots = game.cur.tacticalCannonShots || [];
  game.cur.tacticalCannonShots = shots.filter(s => s.until > (game.cur.gameTime || 0));
  for (const shot of shots) {
    if (shot.until > (game.cur.gameTime || 0)) continue;
    const p = game.pieces.find(p => p.id === shot.pieceId && p.type === 'pao');
    if (!p) continue;
    const original = game.enemies.find(e => e.id === shot.targetId && !e.done && !e.dying && e.hp > 0 && canPieceAttack(p, e));
    const target = original || findAttackTarget(p);
    if (target) firePao(p, target, { ...shot.action, damage: shot.action.damage * shot.rate }, false);
  }
}
registerCannonBurst((p, board) => withBoard(board, () => {
  if (!p || p.type !== 'pao' || !board.pieces.includes(p) || board.dead) return false;
  const target = findAttackTarget(p);
  if (!target) return false;
  const action = { damage: pieceDamage(p), critical: false, multiplier: 1, spell: true, noPassives: true };
  firePao(p, target, action, false);
  queueCannonShot(p, target, action, 0.7);
  return true;
}));
function updateGhosts(dt) {
  const ghosts = game.cur.tacticalGhosts || [];
  for (const ghost of ghosts) {
    const from = ghost.progress;
    ghost.progress = Math.max(0, from - 6 * dt);
    const pos = posAlongPath(ghost.progress);
    ghost.c = pos.c; ghost.r = pos.r; ghost.fx = pos.fx; ghost.fy = pos.fy;
    for (const e of game.enemies) {
      if (ghost.hit[e.id] || e.progress < ghost.progress - 0.5 || e.progress > from + 0.5) continue;
      if (e.done || e.dying || e.hp <= 0) continue;
      ghost.hit[e.id] = true;
      dealDamage(ghost.source, e, ghost.damage);
    }
  }
  game.cur.tacticalGhosts = ghosts.filter(g => g.progress > 0);
}
function attackDamage(p, target, action = p.attackRoll) {
  let damage = action?.damage ?? pieceDamage(p);
  if (hasUnlock(p, 'maImmuneDamage') && target.stunImmuneLeft > 0) damage *= 1.2;
  return damage;
}

/* ---------- 普通棋子（兵 / 士 / 象）：子弹单体 ---------- */
function fireNormal(p, target) {
  spawnBullet(p, target.c, target.r, { aoe: false });
  const dmg = attackDamage(p, target);
  const critical = !!p.attackRoll?.critical;
  dealDamage(p, target, dmg, critical);
  completeNormalAction(p, p.attackRoll, target);
  if (normalAttackTargetLimit(p) > 1) {
    const secondaries = game.enemies.filter(e => e !== target && !e.done && !e.dying && e.hp > 0 && canPieceAttack(p, e))
      .sort((a, b) => (Math.abs(a.c - p.c) + Math.abs(a.r - p.r)) - (Math.abs(b.c - p.c) + Math.abs(b.r - p.r)))
      .slice(0, normalAttackTargetLimit(p) - 1);
    for (const secondary of secondaries) {
      spawnBullet(p, secondary.c, secondary.r, { aoe: false });
      dealDamage(p, secondary, dmg, critical);
      spawnPaint(secondary.c, secondary.r, p.color, false);
    }
  }

  spawnPaint(target.c, target.r, p.color, false);
  setRecoil(p, target.c, target.r);
}

/* ---------- 炮：范围爆炸（基础1×1，50级起3×3）+ 大子弹 ---------- */
function firePao(p, target, action = p.attackRoll, normal = true) {
  if (!canPieceAttack(p, target) || target.done || target.dying || target.hp <= 0) return false;
  // 基础范围固定；50级解锁后变为3×3，阶数只影响溅射率。
  let high = PAO_BLAST.baseHigh;
  let wide = PAO_BLAST.baseWide;
  if (hasUnlock(p, 'paoBlast2')) { high = 3; wide = 3; }
  // 马炮合势羁绊不改变炮范围，仅加眩晕（见下）

  const halfH = Math.floor(high / 2);
  const halfW = Math.floor(wide / 2);

  spawnBullet(p, target.c, target.r, { aoe: true, scale: PAO_BLAST.bulletScale });

  // 入口已用 canPieceAttack 验证炮架（包含帅）。
  const dmg = action?.damage ?? pieceDamage(p);
  const splashRate = 0.60;
  const slow = hasUnlock(p, 'paoSlow');
  const slowSeconds = PAO_SLOW_SECONDS * controlDurationMult(p);

  for (const e of game.enemies) {
    if (e.done || e.dying || e.hp <= 0) continue;
    if (Math.abs(e.c - target.c) <= halfW && Math.abs(e.r - target.r) <= halfH) {
      dealDamage(p, e, dmg * (e === target ? 1 : splashRate), action?.critical);
      if (e.dying) continue;
      if (slow) applySlow(e, slowSeconds);
    }
  }

  if (normal) completeNormalAction(p, action, target);
  if (p.flags?.freeShot > 0) p.flags.freeShot -= 1;   // 兼容旧存档，不影响炮架

  spawnPaint(target.c, target.r, p.color, true);
  setRecoil(p, target.c, target.r);
}

/** 施加减速（仅机制：延长移动间隔，不改数值 buff） */
function applySlow(enemy, seconds) {
  enemy.slowLeft = Math.max(enemy.slowLeft || 0, seconds);
}

/* ---------- 马：本体冲到攻击格，践踏十字 5 格 + 眩晕 ---------- */
function fireMa(p, target) {
  // 马不再发射子弹：本体沿直线冲/跃到目标格（用 stomp 状态驱动渲染与判定）
  p.stomp = {
    phase: 'out',            // 'out' 冲向目标 | 'hold' 践踏瞬间 | 'back' 慢速返回
    homeC: p.c, homeR: p.r,
    tc: target.c, tr: target.r,
    t: 0,
    fx: p.c, fy: p.r,        // 连续坐标（渲染用）
    action: { ...p.attackRoll },
    dealt: false,            // 伤害是否已结算（抵达目标格时结算一次）
  };
  // 冷却在践踏结束返回原位时刷新
}

/** 结算马的践踏伤害 + 眩晕（抵达目标格时调用一次） */
function resolveMaStomp(p, target) {
  // 眩晕基础0.5秒，50级升至1秒；象30级象眼上的马再延长10%，免疫仍按原档位。
  const baseStun = hasUnlock(p, 'maStun3') ? MA_STOMP.stunSecondsLv20 : MA_STOMP.stunSeconds;
  const stunSec = baseStun * controlDurationMult(p);
  const cells = [
    [target.c, target.r], [target.c + 1, target.r], [target.c - 1, target.r],
    [target.c, target.r + 1], [target.c, target.r - 1],
  ];

  for (const e of game.enemies) {
    if (e.done || e.dying || e.hp <= 0) continue;
    if (!cells.some(([cc, rr]) => e.c === cc && e.r === rr)) continue;
    dealDamage(p, e, attackDamage(p, e, p.stomp?.action), p.stomp?.action?.critical);
    completeNormalAction(p, p.stomp?.action, target);
    if (e.dying) continue;
    applyStun(e, stunSec, baseStun);
  }

  spawnPaint(target.c, target.r, p.color, false);
}

/* ---------- 车：50级穿透，80级半额返程，100级全额返程；双车错第二段独立去重 ---------- */
function fireJu(p, target) {
  const dc = Math.sign(target.c - p.c);
  const dr = Math.sign(target.r - p.r);

  // 双车错羁绊已删除，车只沿直线冲刺；保留拐弯数据结构以兼容旧存档快照。
  const canBend = false;

  // 第一段直线距离
  const maxDist1 = scanChargeDistance(p, dc, dr);
  if (maxDist1 <= 0) return;

  // 第二段（拐弯后）方向与距离（若非拐弯则为直线延伸 0）
  let bendDir = null, maxDist2 = 0;
  if (canBend) {
    const directions = Math.abs(dc) > 0
      ? [{ dc: 0, dr: 1 }, { dc: 0, dr: -1 }]
      : [{ dc: 1, dr: 0 }, { dc: -1, dr: 0 }];
    const endC = p.c + dc * maxDist1, endR = p.r + dr * maxDist1;
    // 保留原方向优先；第二段只能沿连续道路，旧方向无路时再尝试另一侧。
    for (const direction of directions) {
      const distance = scanChargeFrom(endC, endR, direction.dc, direction.dr, p.id, true);
      if (distance <= 0) continue;
      bendDir = direction;
      maxDist2 = distance;
      break;
    }
  }

  p.charge = {
    dc, dr,
    useBend: canBend && maxDist2 > 0,
    dc2: bendDir?.dc || 0, dr2: bendDir?.dr || 0,
    maxDist1, maxDist2,
    progress1: 0, progress2: 0,
    phase: 'out',            // 'out' | 'bend' | 'hold' | 'back'
    holdT: 0,
    homeC: p.c, homeR: p.r,
    fx: p.c, fy: p.r,
    hit: {},
    column: hasUnlock(p, 'juColumn'),
    returnDmg: hasUnlock(p, 'juReturnDmg'),
    action: { ...p.attackRoll },
    secondRate: p.bondMods?.juSecondRate ?? 0.8,
    returnRate: hasUnlock(p, 'juFullReturn') ? 1 : hasUnlock(p, 'juReturnDmg') ? 0.5 : 0,
  };
}

/** 从指定格扫描最远冲刺距离；仅拐弯段要求连续道路，普通直线不受影响。 */
function scanChargeFrom(sx, sy, dc, dr, selfId, roadOnly = false) {
  const { cols, rows } = game.map;
  let dist = 0, c = sx, r = sy;
  while (true) {
    c += dc; r += dr;
    if (c < 0 || r < 0 || c >= cols || r >= rows) return dist;
    if (roadOnly && !game.map.road[r]?.[c]) return dist;
    if (game.pieces.find(o => o.id !== selfId && o.c === c && o.r === r)) return dist;
    dist++;
  }
}

/** 沿 (dc,dr) 扫描可冲刺的最远格数（遇到其它棋子即止） */
function scanChargeDistance(p, dc, dr) {
  return scanChargeFrom(p.c, p.r, dc, dr, p.id);
}

/** 车对单个敌人的一次命中：去程、返程各自去重。 */
function juHit(p, e, ch) {
  const returning = ch.phase === 'back';
  const second = returning ? ch.progress2 > 0 : ch.phase === 'bend';
  const key = `${returning ? 'back' : 'out'}-${second ? 2 : 1}`;
  const hits = ch.segmentHits || (ch.segmentHits = {});
  const hit = hits[key] || (hits[key] = {});
  if (hit[e.id]) return;
  hit[e.id] = true;
  dealDamage(p, e, attackDamage(p, e, ch.action) * (second ? ch.secondRate : 1) * (returning ? ch.returnRate : 1), ch.action?.critical);
  completeNormalAction(p, ch.action, e);
}

/** 推进冲刺（冲出 → 可选拐弯 → 停顿 → 返回）；返回按原路折返 */
function updateCharges(dt) {
  for (const p of game.pieces) {
    const ch = p.charge;
    if (!ch) continue;

    if (ch.phase === 'out' || ch.phase === 'bend') {
      // ---- 前向：冲出去 ----
      if (ch.phase === 'out') {
        ch.progress1 += JU_CHARGE.speed * dt;
        if (ch.progress1 > ch.maxDist1) ch.progress1 = ch.maxDist1;
        ch.fx = ch.homeC + ch.dc * ch.progress1;
        ch.fy = ch.homeR + ch.dr * ch.progress1;
      } else {
        ch.progress2 += JU_CHARGE.speed * dt;
        if (ch.progress2 > ch.maxDist2) ch.progress2 = ch.maxDist2;
        const endC = ch.homeC + ch.dc * ch.maxDist1;
        const endR = ch.homeR + ch.dr * ch.maxDist1;
        ch.fx = endC + ch.dc2 * ch.progress2;
        ch.fy = endR + ch.dr2 * ch.progress2;
      }

      // 命中判定：
      //   - 低于 50 级（非穿透）：车碰到所在格敌人 → 命中并停下
      //   - 50 级穿透：车移动经过的每一格上的敌人才命中（穿过继续冲）
      const curC = Math.round(ch.fx), curR = Math.round(ch.fy);
      // 只结算「车当前所在格」上的敌人（穿透也是逐格经过时命中，不是全屏瞬杀）
      const hitEnemies = game.enemies.filter(x => !x.done && !x.dying && x.hp > 0 && x.c === curC && x.r === curR);
      if (hitEnemies.length) {
        for (const enemy of hitEnemies) {
          juHit(p, enemy, ch);
          if (!ch.column) break;
        }
        if (!ch.column) {
          ch.phase = 'hold'; ch.holdT = 0.1;
        }
      }

      // 段结束
      const segDone = (ch.phase === 'out' && ch.progress1 >= ch.maxDist1) ||
                      (ch.phase === 'bend' && ch.progress2 >= ch.maxDist2);
      if (segDone) {
        if (ch.phase === 'out' && ch.useBend) ch.phase = 'bend';
        else { ch.phase = 'hold'; ch.holdT = 0.12; }
      }
    } else if (ch.phase === 'hold') {
      ch.holdT -= dt;
      if (ch.holdT <= 0) ch.phase = 'back';

    } else { // ---- back：原路折返（先退第二段，再退第一段）----
      // 返回段伤害（80 级解锁）：车退到某格、该格上有敌人才结算
      if (ch.returnDmg) {
        const curC = Math.round(ch.fx), curR = Math.round(ch.fy);
        for (const e of game.enemies.filter(x => !x.done && !x.dying && x.hp > 0 && x.c === curC && x.r === curR)) juHit(p, e, ch);
      }

      if (ch.progress2 > 0) {
        ch.progress2 -= JU_CHARGE.returnSpeed * dt;
        if (ch.progress2 < 0) ch.progress2 = 0;
        const endC = ch.homeC + ch.dc * ch.maxDist1;
        const endR = ch.homeR + ch.dr * ch.maxDist1;
        ch.fx = endC + ch.dc2 * ch.progress2;
        ch.fy = endR + ch.dr2 * ch.progress2;
      } else {
        ch.progress1 -= JU_CHARGE.returnSpeed * dt;
        if (ch.progress1 < 0) ch.progress1 = 0;
        ch.fx = ch.homeC + ch.dc * ch.progress1;
        ch.fy = ch.homeR + ch.dr * ch.progress1;
        if (ch.progress1 <= 0) {
          p.charge = null;
          p.cdLeft = pieceCooldown(p);
        }
      }
    }
  }
}

/* ---------- 共用：子弹 / 后座 / 眩晕 ---------- */
function spawnBullet(p, tx, ty, { aoe = false, scale = 1 } = {}) {
  if (game.cur._simulationContext) return; // 推演只保留战斗，不生成表现或消耗表现随机数
  game.bullets.push({
    id: Math.random().toString(36).slice(2, 9),
    kind: 'bullet',
    color: p.color,
    fromC: p.c, fromR: p.r,
    toC: tx, toR: ty,
    aoe, scale,
    t: 0, dur: 0.18,
  });
}

/** 棋子朝发射方向的「吐子」抽搐（兵/士/象/炮） */
function setRecoil(p, tx, ty) {
  if (game.cur._simulationContext) return;
  const ddx = tx - p.c, ddy = ty - p.r;
  const len = Math.hypot(ddx, ddy) || 1;
  p.recoil = { nx: ddx / len, ny: ddy / len, t: 0, dur: FX.recoil.duration };
}

/**
 * 眩晕：眩晕中 / 免疫期内都不生效（不刷新、不延长），保证每次眩晕后必有一段免疫。
 * 免疫时长按本次眩晕时长查表，在眩晕结束时才开始计时（见 updateEnemies）。
 */
export function stunEnemy(enemy, seconds) { return applyStun(enemy, seconds); }
/** immuneKey：延长后的眩晕仍按原始眩晕档位查免疫时长。 */
function applyStun(enemy, seconds, immuneKey = seconds) {
  if (!enemy || enemy.done || enemy.dying || !(seconds > 0) || enemy.stunLeft > 0 || enemy.stunImmuneLeft > 0) return false;
  enemy.stunLeft = seconds;
  enemy.stunImmuneNext = MA_STOMP.stunImmuneByStun[immuneKey] ?? MA_STOMP.stunImmuneDefault;
  return true;
}

/* ============================================================
 * 攻击涂色特效（颜料泼洒）
 * ============================================================ */

/**
 * 生成一次命中涂色：
 * - 单体攻击：以命中格为中心，随机小圆点散布在约 1 格范围内
 * - 范围攻击（炮）：散布在约 3×3 格范围内
 * 每次的小圆点位置 / 大小随机，形成自然泼洒感；不涂满整格。
 */
function spawnPaint(c, r, color, isAoe) {
  if (game.cur._simulationContext) return;
  const cfg = FX.paint;
  const spread = isAoe ? cfg.aoeRadiusCells : 0.35;      // 散布半径（格）
  const count = isAoe ? cfg.dotCount.aoe : cfg.dotCount.single;
  const [rMin, rMax] = isAoe ? cfg.dotRadius.aoe : cfg.dotRadius.single;

  const dots = [];
  for (let i = 0; i < count; i++) {
    // 极坐标随机，sqrt 让点更均匀铺开
    const ang = Math.random() * Math.PI * 2;
    const dist = Math.sqrt(Math.random()) * spread;
    const size = rMin + Math.random() * (rMax - rMin);
    dots.push({
      dx: Math.cos(ang) * dist,
      dy: Math.sin(ang) * dist,
      size,
      // 每个点自身再稍微拉长一点点，更像颜料飞溅
      stretch: 0.7 + Math.random() * 0.6,
      rot: Math.random() * Math.PI,
    });
  }

  game.paintSplats.push({
    id: Math.random().toString(36).slice(2, 9),
    c, r,
    color,
    dots,
    age: 0,
    life: cfg.lifeMs / 1000,     // 秒
  });

  // 数量上限保护
  if (game.paintSplats.length > 80) game.paintSplats.splice(0, game.paintSplats.length - 80);
}

/**
 * 全场击杀经验8，击杀者额外2，其他实际伤害参与者额外1；不再按阶数/羁绊击杀加经验。
 * 敌人先进入死亡闪烁，闪烁结束后由 updateEnemies 移除并检查清波奖励。
 */
function onEnemyKilled(e, killer) {
  if (e.dying) return;                 // 防止重复结算（范围伤害可能命中同一只）
  e.dying = true;
  recordWaveOutcome(e, 'killed');
  e.deathT = 0;
  game.kills += 1;
  addGold(GOLD_ON_KILL.default, null, killer);

  let changed = false;
  for (const piece of game.pieces) {
    const bonus = piece.id === killer?.id ? LEVEL.killBonus
      : (e.damageContributors?.[piece.id] > 0 ? LEVEL.assistBonus : 0);
    changed = grantExperience(piece, LEVEL.killTeamExp + bonus) || changed;
  }
  if (changed) rescanBonds();
}

/* ============================================================
 * 波次调度：两边棋盘共用同一个计时器，同时出怪、同样数量
 *   一波出完后，只要「任意一方」先把场上敌人清空（打死或漏到帅那里），
 *   就开始倒计时 waveInterval 秒，然后双方一起开下一波 ——
 *   清得慢的一方不会拖住节奏，没清完的怪会和下一波叠在一起。
 * ============================================================ */

/** 共享波次状态（每局由 resetSharedWaves 重置） */
export const sharedWaves = {
  waveToSpawn: 2,                       // 下一次要生成的波次号
  wave: 1,                              // 当前波次
  timer: WAVES.startDelay,              // 当前计时（出怪间隔 / 波间隔）
  spawnedInWave: 0,                     // 本波已生成数量
  countInWave: WAVES.firstWaveCount,    // 本波总数量
  betweenWaves: false,                  // 是否处于「波间等待」
  countdown: false,                     // 波间倒计时是否已开始（先清完的一方触发）
};

/** 新开一局：重置共享波次（第 1 波立即生效，waveToSpawn 指向第 2 波） */
export function resetSharedWaves() {
  Object.assign(sharedWaves, {
    waveToSpawn: 2, wave: 1, timer: WAVES.startDelay,
    spawnedInWave: 0, countInWave: WAVES.firstWaveCount, betweenWaves: false, countdown: false,
  });
}

/**
 * 每帧调用一次（不是每个棋盘各调用一次）。
 * @param {number} dt
 * @param {object[]} boards 参与对局的棋盘（我方 + 对方）
 */
export function updateSharedWaves(dt, boards) {
  if (game.phase !== 'playing') return;
  // 双方的帅都走到位才开始出怪（两边地图相同，帅同时到位）
  if (boards.some(b => b.king && !b.king.arrived)) return;

  const w = sharedWaves;
  const spawnAll = () => boards.forEach(b => withBoard(b, () => { game.wave = w.wave; spawnEnemy(w.spawnedInWave); }));

  if (w.spawnedInWave < w.countInWave) {
    // 出怪阶段：两边同一时刻各出一只
    w.timer -= dt;
    if (w.timer <= 0) {
      spawnAll();
      w.spawnedInWave += 1;
      w.timer = spawnIntervalForWave(w.wave);
    }
  } else if (!w.betweenWaves) {
    // 本波出完，进入波间等待（等任意一方先清空）
    w.betweenWaves = true;
    w.timer = WAVES.waveInterval;
  } else if (w.countdown || boards.some(b => b.enemies.length === 0)) {
    // 波间等待：先清完的一方一清空就开始计时（一旦开始就不再暂停），计时结束双方一起开下一波
    w.countdown = true;
    w.timer -= dt;
    if (w.timer <= 0) startNextWave(boards);
  }
}

/** 开始下一波（双方同时） */
function startNextWave(boards) {
  const w = sharedWaves;
  w.wave = w.waveToSpawn;
  w.countInWave = WAVES.firstWaveCount + (w.wave - 1) * WAVES.countGrowPerWave;
  w.spawnedInWave = 0;
  w.timer = 0;                 // 下一帧立即开始出第 1 只
  w.betweenWaves = false;
  w.countdown = false;
  w.waveToSpawn += 1;
  boards.forEach(b => { b.wave = w.wave; });
}

/** 作弊：双方直接跳到第 n 波（清场后立即开波） */
export function jumpToWave(n, boards) {
  boards.forEach(b => { b.enemies = []; b.waveClearState = {}; b.bossAnnouncement = null; });
  sharedWaves.waveToSpawn = Math.max(1, n);
  startNextWave(boards);
}

/** 游戏结束 */
export function endGame() {
  game.phase = 'over';
}

/* ============================================================
 * 每帧主更新（每个棋盘各调用一次；出怪由 updateSharedWaves 统一负责）
 * ============================================================ */
export function update(dt) {
  if (game.phase !== 'playing' && !game.cur._simulationContext) return;
  if (game.dead) return;
  updateTacticalEffects(game.cur, dt);
  updateBossAnnouncement(game.cur);
  game.cur.tacticalHorseGhosts = (game.cur.tacticalHorseGhosts || []).filter(g => g.until > game.cur.gameTime);
  if (game.dead) return;
  updateKing(dt);
  updateEnemies(dt);
  updateCombat(dt);
  updateBondGold(dt);
  // gameTime 只由本次 updateTacticalEffects 推进；暂停与私有模拟共用该入口。

  // 子弹动画推进
  for (const b of game.bullets) b.t += dt;
  game.bullets = game.bullets.filter(b => b.t < b.dur);

  // 涂色特效老化 + 淡出清理
  for (const s of game.paintSplats) s.age += dt;
  game.paintSplats = game.paintSplats.filter(s => s.age < s.life);

  // 棋子「吐子」抽搐推进（马的践踏已由 updateStomps 推进，不在这里处理）
  for (const p of game.pieces) {
    if (p.recoil) {
      p.recoil.t += dt;
      if (p.recoil.t >= p.recoil.dur) p.recoil = null;
    }
  }
}

/** 开始游戏（作用于当前棋盘）：帅出生；出怪节奏由共享波次 sharedWaves 统一控制（见 resetSharedWaves） */
export function startGame() {
  game.wave = 1;
  game.kills = 0;
  game.cur.gameTime = 0;
  game.cur.temporaryLives = [];
  game.cur.tacticalGhosts = [];
  game.cur.tacticalHorseGhosts = [];
  game.cur.tacticalCannonShots = [];
  game.cur.damageFloaters = [];
  game.cur.critBursts = [];
  game.cur.huanbingCooldownUntil = 0;
  game.cur.waveClearState = {};
  game.cur.bossAnnouncement = null;
  game.enemies = [];
  game.bullets = [];
  spawnKing();
}

export default { startGame, update, spawnKing, endGame, jumpToWave, updateSharedWaves, resetSharedWaves };