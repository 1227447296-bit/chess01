/** 实验版融合：同种同色合并，达到3阶时自动随机进化。 */
import { MERGE } from './config.js';
import game from './gameData.js';

const evolvable = type => type === 'bing' || type === 'shi' || type === 'xiang';
const random = () => (game.cur?._simulationContext?.random ?? Math.random)();
export const stageCap = () => MERGE.maxStage;
export function mergedLevel(a, b) {
  return Math.min(MERGE.levelCap, (a.level || 0) + (b.level || 0) + MERGE.levelBonus);
}

export function canAbsorb(target, material) {
  if (!target || !material) return { ok: false, reason: 'empty' };
  if (target === material || (target.id != null && target.id === material.id)) return { ok: false, reason: 'self' };
  if (target.type !== material.type) return { ok: false, reason: 'type' };
  if (target.color !== material.color) return { ok: false, reason: 'color' };
  if ((target.stage || 0) >= stageCap()) return { ok: false, reason: 'full' };
  if ((target.stage || 0) + 1 + (material.stage || 0) > stageCap()) return { ok: false, reason: 'overflow' };
  return { ok: true, reason: 'ok' };
}

function absorbBonuses(target, material) {
  target.atkBonus = (target.atkBonus || 0) + (material.atkBonus || 0);
  const criticalBonuses = {};
  for (const stat of ['critRateBonus', 'critDamageBonus']) {
    criticalBonuses[stat] = Math.max(target[stat] || 0, material[stat] || 0,
      target.flags?.[stat] || 0, material.flags?.[stat] || 0);
  }
  target.flags = { ...(material.flags || {}), ...(target.flags || {}), ...criticalBonuses };
  target.specialEnhancements = { ...(material.specialEnhancements || {}), ...(target.specialEnhancements || {}) };
  for (const marker of ['huixin', 'pojun']) {
    if (target.specialEnhancements[marker] || material.specialEnhancements?.[marker]) target.specialEnhancements[marker] = 1;
  }
  for (const stat of ['critRateBonus', 'critDamageBonus']) target[stat] = criticalBonuses[stat];
}

function evolutionTypes(type) {
  if (type === 'bing') return MERGE.fromBing;
  if (type === 'shi' || type === 'xiang') return MERGE.fromShiXiang;
  return [];
}

function evolvedData(target, type, color) {
  const result = { ...target, type, color, level: Math.min(MERGE.levelCap, target.level || 0),
    exp: 0, stage: 0, mergeCount: 0, cdLeft: 0, bonds: [],
    flags: { ...(target.flags || {}) }, specialEnhancements: { ...(target.specialEnhancements || {}) } };
  delete result.evolutionChoices;
  delete result.evolutionChoicesType;
  delete result.bingSpeedStacks;
  delete result.bingSpeedLeft;
  return result;
}

/** 自动进化的完整机会节点；AI/测试枚举这些节点，不抽正式随机。 */
export function absorbOutcomes(target, material) {
  const check = canAbsorb(target, material);
  if (!check.ok) return [];
  const stage = (target.stage || 0) + 1 + (material.stage || 0);
  if (stage < MERGE.needCount || !evolvable(target.type)) return [{ probability: 1 }];
  const types = evolutionTypes(target.type);
  const outcomes = [];
  const base = { ...target, level: mergedLevel(target, material), stage, exp: 0,
    atkBonus: (target.atkBonus || 0) + (material.atkBonus || 0),
    flags: { ...(material.flags || {}), ...(target.flags || {}) },
    specialEnhancements: { ...(material.specialEnhancements || {}), ...(target.specialEnhancements || {}) } };
  for (const type of types) for (const color of ['red', 'black']) {
    outcomes.push({ probability: 1 / (types.length * 2), type, color,
      piece: evolvedData(base, type, color) });
  }
  return outcomes;
}

/** 融合并可选定自动进化结果；未提供结果时才使用正式随机源。 */
export function applyAbsorb(target, material, options = {}) {
  const check = canAbsorb(target, material);
  if (!check.ok) return { ...check, needMerge: false };
  target.level = mergedLevel(target, material);
  target.exp = 0;
  target.stage = (target.stage || 0) + 1 + (material.stage || 0);
  target.mergeCount = target.stage;
  absorbBonuses(target, material);
  if (target.stage >= MERGE.needCount && evolvable(target.type)) {
    const types = evolutionTypes(target.type);
    const type = types.includes(options.evolutionType) ? options.evolutionType : types[Math.floor(random() * types.length)];
    const color = options.evolutionColor === 'red' || options.evolutionColor === 'black'
      ? options.evolutionColor : (random() < 0.5 ? 'red' : 'black');
    Object.assign(target, evolvedData(target, type, color));
    return { ok: true, needMerge: false, autoEvolved: true, type, color, canEvolve: false };
  }
  return { ok: true, needMerge: false, autoEvolved: false, canEvolve: false };
}

// 主动进化仅作为法术等实验机制的强制入口；普通融合不会产生选择节点。
export function canEvolve(piece, { force = false } = {}) {
  return !!piece && force && evolvable(piece.type);
}
export function getEvolutionChoices(piece, { force = false } = {}) {
  if (!canEvolve(piece, { force })) return [];
  if (piece.evolutionChoicesType === piece.type && Array.isArray(piece.evolutionChoices)) return [...piece.evolutionChoices];
  const pool = [...evolutionTypes(piece.type)];
  if (piece.type === 'bing') piece.evolutionChoices = pool;
  else {
    // 法术的候选仍沿用实验版「两选一」机制；只在正式法术选择时抽取。
    piece.evolutionChoices = [];
    while (piece.evolutionChoices.length < 2) {
      const i = Math.min(pool.length - 1, Math.floor(random() * pool.length));
      piece.evolutionChoices.push(pool.splice(i, 1)[0]);
    }
  }
  piece.evolutionChoicesType = piece.type;
  return [...piece.evolutionChoices];
}
export function evolutionOutcomes(piece, { force = false } = {}) {
  // 直接对一个3阶快照建模时也返回自动进化机会节点；真实融合优先使用 absorbOutcomes。
  if (!force && piece && piece.stage >= MERGE.needCount && evolvable(piece.type)) {
    const types = evolutionTypes(piece.type);
    return types.flatMap(type => ['red', 'black'].map(color => ({
      probability: 1 / (types.length * 2), type, color, piece: evolvedData(piece, type, color),
    })));
  }
  if (!canEvolve(piece, { force })) return [];
  if (piece.evolutionChoicesType === piece.type && Array.isArray(piece.evolutionChoices)) {
    const choices = [...piece.evolutionChoices];
    return [{ probability: 1, choices, pieces: choices.map(type => evolvedData(piece, type, piece.color)) }];
  }
  if (piece.type === 'bing') {
    const choices = [...MERGE.fromBing];
    return [{ probability: 1, choices, pieces: choices.map(type => evolvedData(piece, type, piece.color)) }];
  }
  const outcomes = [];
  for (let i = 0; i < MERGE.fromShiXiang.length; i++) for (let j = i + 1; j < MERGE.fromShiXiang.length; j++) {
    const choices = [MERGE.fromShiXiang[i], MERGE.fromShiXiang[j]];
    outcomes.push({ probability: 1 / 3, choices, pieces: choices.map(type => evolvedData(piece, type, piece.color)) });
  }
  return outcomes;
}
export function buildMerged(target) { return target; }
export function evolveSelected(piece, evolutionType, { force = false } = {}) {
  if (!canEvolve(piece, { force })) return { ok: false, reason: '该棋子不能主动进化' };
  const choices = getEvolutionChoices(piece, { force });
  if (!choices.includes(evolutionType)) return { ok: false, reason: '请选择已绑定的进化候选', choices };
  Object.assign(piece, evolvedData(piece, evolutionType, piece.color));
  return { ok: true, piece };
}
export function doMerge(target) { return target; }

export function rollResultType(type) {
  const pool = evolutionTypes(type);
  return pool.length ? pool[Math.floor(random() * pool.length)] : type;
}
export function rollResultColor() { return random() < 0.5 ? 'red' : 'black'; }

export function tryMergeDraw(target, material, options = {}) {
  const check = canAbsorb(target, material);
  if (!check.ok) return { absorbed: false, result: null, merged: false, reason: check.reason };
  const result = applyAbsorb(target, material, options);
  removeFromBoard(material);
  return { absorbed: true, result: target, merged: true, autoEvolved: result.autoEvolved };
}
export function removeFromBoard(piece) {
  const index = game.pieces.findIndex(p => p.id === piece.id);
  if (index >= 0) game.pieces.splice(index, 1);
}

export default { tryMergeDraw, canAbsorb, applyAbsorb, absorbOutcomes, buildMerged, doMerge,
  rollResultType, rollResultColor, removeFromBoard, mergedLevel, stageCap, canEvolve,
  getEvolutionChoices, evolveSelected, evolutionOutcomes };
