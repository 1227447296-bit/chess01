/** 开始页显式运行：铲地预约的真实两手执行及失效回归，不改正式地图或存档。 */
import game, { createBoard, withBoard } from './gameData.js';
import { loadMap } from './mapLoader.js';
import { aiTick, setupAI, aiInfo } from './ai.js';
import { AI_PLAY, SHOP } from './config.js';
import { actionBranches, clonePosition, scorePosition } from './aiEvaluation.js';
import { simulateCombat } from './aiSimulation.js';
import { sharedWaves } from './wave.js';
import { waitForBenchmarkReady } from './aiBenchmark.test.js';

const piece = (id, type, c, r, level = 0) => ({
  id, kind: 'piece', type, color: 'red', c, r, level, exp: 0,
  stage: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [], activeBonds: [],
});

export async function runAIPlanFixtures() {
  await waitForBenchmarkReady();
  if (game.phase !== 'start') throw new Error('请先回到开始页');
  const map = await loadMap(1), phase = game.phase, cur = game.cur;
  const budget = AI_PLAY.evaluationBudgetMs, checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw new Error(name); };
  const tick = (board, dt) => withBoard(board, () => aiTick(dt, 3, 7));
  const finish = (board, dt = 2) => {
    const count = aiInfo(board).decisions;
    tick(board, dt);
    for (let frame = 0; frame < 20000 && aiInfo(board).decisions === count; frame++) tick(board, 0);
    check('分帧决策完成且恢复上下文', aiInfo(board).decisions === count + 1 && game.cur === cur);
  };
  const fixture = (moving = false) => {
    setupAI({ tier: 7 }, { seed: 17 });
    const board = createBoard('opp', map);
    // 仅测试副本关闭初始空地，保证必须先开地；不修改 loadMap 缓存的数组。
    board.map.grass = map.ground.map((row, r) => row.map((v, c) => !!v && !map.road[r][c]));
    board.totalRefreshCount = 1;
    board.shopSlots[0] = { source: 'native', type: 'shovel' };
    if (moving) {
      const p = piece('mover', 'bing', 0, 0, 10);
      board.pieces = [p];
      let lowest = Infinity, origin;
      for (let r = 0; r < map.rows; r++) for (let c = 0; c < map.cols; c++) {
        if (!map.ground[r][c] || map.road[r][c]) continue;
        p.c = c; p.r = r;
        const score = scorePosition(clonePosition(board)).score;
        if (score < lowest) { lowest = score; origin = { c, r }; }
      }
      Object.assign(p, origin);
      board.map.cleared.add(`${p.c},${p.r}`);
    } else board.shopSlots[1] = { source: 'native', type: 'piece', color: 'red' };
    finish(board);
    check('只铲地并保存下一手' + (moving ? '搬棋' : '买棋'), aiInfo(board).lastAction?.kind === 'dig' &&
      aiInfo(board).plan?.kind === (moving ? 'move' : 'buy') && board.gold === 25 - SHOP.price.shovel &&
      board.pieces.length === (moving ? 1 : 0));
    return board;
  };
  try {
    game.phase = 'playing';
    AI_PLAY.evaluationBudgetMs = 0;
    const buying = fixture(), buyPlan = aiInfo(buying).plan;
    const buyTimer = buying.aiTimer;
    tick(buying, 0.01);
    check('铲地后必须等待正常操作间隔', buying.pieces.length === 0 && buying.aiTimer === buyTimer - 0.01);
    finish(buying);
    check('下一手在预约格真实买棋并扣款', buying.pieces.length === 1 && buying.pieces[0].c === buyPlan.c &&
      buying.pieces[0].r === buyPlan.r && buying.gold === 25 - SHOP.price.shovel - SHOP.price.piece &&
      !buying.shopSlots[1] && !aiInfo(buying).plan && aiInfo(buying).plansCompleted === 1);
    check('兑现买棋后仍有正常间隔', buying.aiTimer >= AI_PLAY.actionMin && buying.aiTimer <= AI_PLAY.actionMax);

    const moving = fixture(true), movePlan = aiInfo(moving).plan;
    const origin = { c: moving.pieces[0].c, r: moving.pieces[0].r };
    check('铲地不提前搬棋', moving.pieces[0].c === origin.c && moving.pieces[0].r === origin.r &&
      (origin.c !== movePlan.c || origin.r !== movePlan.r));
    finish(moving);
    check('下一手搬原棋而非免费复制', moving.pieces.length === 1 && moving.pieces[0].id === 'mover' &&
      moving.pieces[0].c === movePlan.c && moving.pieces[0].r === movePlan.r &&
      moving.gold === 25 - SHOP.price.shovel && aiInfo(moving).plansCompleted === 1);
    tick(moving, 0.01);
    check('兑现搬棋后不连做第二手', aiInfo(moving).decisions === 2);

    const invalidations = [
      ['卡被替换，即使同类型同颜色', false, board => { board.shopSlots[1] = { ...board.shopSlots[1] }; }],
      ['卡已消失', false, board => { board.shopSlots[1] = null; }],
      ['金币不足', false, board => { board.gold = 0; }],
      ['落点被占', false, (board, plan) => { board.pieces.push(piece('occupant', 'shi', plan.c, plan.r)); }],
      ['源棋消失', true, board => { board.pieces = []; }],
      ['源棋正在冲锋', true, board => { board.pieces[0].charge = { phase: 'out' }; }],
      ['源棋正在践踏', true, board => { board.pieces[0].stomp = { phase: 'out' }; }],
      ['源棋位置已经改变', true, board => { board.pieces[0].c = 3; board.pieces[0].r = 0; }],
      ['预约过期', false, () => {}],
    ];
    for (const [name, isMoving, mutate] of invalidations) {
      const board = fixture(isMoving), plan = aiInfo(board).plan;
      mutate(board, plan);
      // 没有任何候选时可正常刷新，但不能兑现已经失效的买棋/搬棋预约。
      tick(board, name === '预约过期' ? 9 : 2);
      check(name + '取消旧预约且不盲目兑现', !aiInfo(board).plan && aiInfo(board).plansCancelled === 1 &&
        aiInfo(board).plansCompleted === 0 && !['buy', 'move'].includes(aiInfo(board).lastAction.kind) && game.cur === cur);
    }

    const expired = fixture();
    tick(expired, 2);
    check('预约执行前仍需分帧思考', aiInfo(expired).decisions === 1 && expired.pieces.length === 0);
    finish(expired, 9);
    check('思考过程中到期也在执行前取消', !aiInfo(expired).plan && expired.pieces.length === 0 &&
      aiInfo(expired).plansCancelled === 1 && expired.aiTimer === 0);

    const incoming = fixture(), oldWaves = { ...sharedWaves };
    try {
      incoming.king = { arrived: true, moving: false };
      Object.assign(sharedWaves, { wave: 1, waveToSpawn: 2, timer: 0, spawnedInWave: 0,
        countInWave: 5, betweenWaves: false, countdown: false });
      const waveState = JSON.stringify(sharedWaves);
      finish(incoming);
      check('空场预约也经过确定待生成怪推演再兑现', aiInfo(incoming).plansCompleted === 1 &&
        aiInfo(incoming).forecastCount > 0 && aiInfo(incoming).battleChecks > 0);
      check('预约推演不推进正式共享调度', JSON.stringify(sharedWaves) === waveState && incoming.enemies.length === 0);
    } finally {
      Object.assign(sharedWaves, oldWaves);
    }

    const unsafe = fixture(), unsafePlan = aiInfo(unsafe).plan;
    const guard = piece('guard', 'ma', 1, 2);
    guard.atkBonus = 35;
    unsafe.pieces.push(guard);
    unsafe.map.cleared.add('1,2');
    unsafe.enemies = [{ id: 'threat', ...map.path[2], progress: 2, hp: 80, maxHp: 80, speed: 2,
      done: false, dying: false, deathT: 0, slowLeft: 0, hitTimer: 0 }];
    const before = simulateCombat(unsafe, { horizon: 8, seed: 173 });
    const after = simulateCombat(actionBranches(unsafe, unsafePlan)[0].board, { horizon: 8, seed: 173 });
    check('危险夹具中预约买棋确实堵马腿导致新增漏怪', before.leaks === 0 && after.leaks > before.leaks);
    finish(unsafe);
    check('危险预约不能因优先权被强行执行', aiInfo(unsafe).plansCompleted === 0 &&
      !aiInfo(unsafe).plan && aiInfo(unsafe).plansCancelled === 1 && unsafe.shopSlots[1] && aiInfo(unsafe).battleChecks > 0);
    check('推演没有提前推进真实敌人或扣血', unsafe.enemies[0].hp === 80 && unsafe.lives === 3);
    return { passed: checks.length, checks };
  } finally {
    AI_PLAY.evaluationBudgetMs = budget;
    game.phase = phase;
    game.cur = cur;
  }
}
