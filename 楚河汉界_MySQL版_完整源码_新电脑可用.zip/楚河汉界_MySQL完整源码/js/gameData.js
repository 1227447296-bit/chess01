/**
 * gameData.js —— 全局游戏状态
 *
 * 同屏对决：我方 / 对方各有一份「棋盘状态 board」（金币、棋子、敌人、商店、波次、羁绊…）。
 * 为了让各业务模块（shop / spell / synthesis / bond / wave / attackRule …）无需改写，
 * game 上的「每方字段」都是转发到「当前棋盘 game.cur」的 getter/setter：
 *   - 默认 game.cur = 我方棋盘（玩家操作、商店渲染都作用于我方）
 *   - 更新 / 渲染 / AI 决策对方棋盘时，用 withBoard(opp, fn) 临时切换
 * 界面类字段（phase / drag / 选中 / 详情）全局只有一份。
 */
import { SHOP, MISC, KING, MERGE } from './config.js';

/** 唯一自增 id 生成器（两边棋盘共用，保证 id 全局唯一） */
let _uid = 1;
export const uid = (prefix = 'e') => {
  const simulation = game.cur?._simulationContext;
  if (simulation) {
    simulation.uidCounter = (simulation.uidCounter || 0) + 1;
    return `${prefix}sim-${simulation.uidCounter}`;
  }
  return `${prefix}${_uid++}`;
};

/** 生成 [col,row] 键 */
export const cellKey = (c, r) => `${c},${r}`;

/** 开局增益效果标记的默认值 */
function defaultFlags() {
  return {
    mergeIgnoreColor: false,
    atkFlatByType: {},
    cdRateByType: {},
    paoRelaxed: false,
    refreshStepHalf: false,
    xiangNoEye: false,
    mergeNeedOne: false,
    atkFlatAll: 0,
    shiDamageReduce: 0,
  };
}

/** 未加载地图时的空地图 */
function emptyMap() {
  return {
    cols: 0, rows: 0,
    ground: [], grass: [], road: [],
    cleared: new Set(),
    enemySpawn: null, kingPoint: null,
    path: [], raw: null,
  };
}

/**
 * 创建一方的棋盘状态。
 * @param {'me'|'opp'} side
 * @param {object} [sharedMap] 已解析的地图；瓦片 / 路径两边共用，铲开的格子 cleared 每边一份
 */
export function createBoard(side, sharedMap = null) {
  return {
    side,

    /* ---------------- 经济 / 进度 ---------------- */
    gold: MISC.initialGold,
    /** 刷新价格独立存储，不随波次重置 */
    shopRefreshCost: SHOP.refreshBaseCost,
    /** 本局累计「成功扣费刷新」次数，用于解锁高阶法术池 */
    totalShopRefreshCount: 0,
    /** 本局总刷新次数（含首次免费那次），用于判断免费次数是否已用 */
    totalRefreshCount: 0,
    /** 本局已「实际使用」的铲子数量（刷新掉未使用的不计） */
    shovelUsed: 0,
    /** 本局各法术已「实际使用」次数 { spellId: n }，达到 SPELLS[].stock 后不再刷出 */
    spellUsed: {},
    /** 实验版游戏时间与应急法术公共冷却，仅在本盘实际推进时更新。 */
    gameTime: 0,
    temporaryLives: [],
    tacticalGhosts: [],
    tacticalHorseGhosts: [],
    tacticalCannonShots: [],
    huanbingCooldownUntil: 0,
    /** 当前波次（0 = 未开始） */
    wave: 0,
    /** 帅的生命（红心数） */
    lives: KING.hp,
    /** 已击杀数量 */
    kills: 0,
    /** 本局本方出过的怪总数（双方应始终相同） */
    spawned: 0,
    /** 本方逐出生波离场账本；不依赖共享调度当前波，允许旧怪叠波。 */
    waveClearState: {},
    /** 红心归零（本方落败） */
    dead: false,
    /** 作弊：不掉红心 */
    god: false,
    /** AI 决策计时（对方 AI / 作弊 auto 时的我方 AI 各用各的） */
    aiTimer: null,

    /* ---------------- 本局增益（海克斯） ---------------- */
    bonusId: null,
    flags: defaultFlags(),

    /* ---------------- 地图 ---------------- */
    map: sharedMap ? { ...sharedMap, cleared: new Set() } : emptyMap(),

    /* ---------------- 场上单位 ---------------- */
    /**
     * 棋子对象：
     * { id, kind:'piece', type:'bing|shi|xiang|ma|ju|pao', color:'red'|'black', c, r,
     *   level, exp, stage, atkBonus, flags:{...}, cdLeft, bonds:[] }
     */
    pieces: [],
    /** 帅（主公），结构与 piece 类似但 type='king' */
    king: null,
    /** 敌人：{ id, c, r, hp, maxHp, speed, progress, ... } */
    enemies: [],
    /** 子弹特效 */
    bullets: [],
    /** 攻击涂色特效（颜料泼洒） */
    paintSplats: [],
    paintSeed: 0,

    /* ---------------- 商店 ---------------- */
    /**
     * 商店卡位，长度固定 SHOP.slotCount：
     * null —— 空位 | { source:'native', type:'piece'|'shovel'|'spell', ... } | { source:'fromBoard', piece }
     */
    shopSlots: new Array(SHOP.slotCount).fill(null),

    /* ---------------- 羁绊 ---------------- */
    /** 已激活的羁绊组：[{ id, key, branch, aId, bId, name, effect }] */
    bonds: [],
    /** 本方激活的羁绊机制标记 { effect: true } */
    bondMods: {},
    /** 满足条件组合的达成顺序（含因上限暂未激活的组合），仅本盘使用 */
    bondOrder: new Map(),
    bondSequence: 0,
    /** 二鬼拍门计时（按羁绊 id） */
    bondGoldTimers: {},
    /** 已播放过名称弹窗的羁绊 id */
    bondAnnounced: new Set(),
    // 出怪节奏不在棋盘上：双方共用 wave.js 的 sharedWaves，保证同时出怪、数量相同
  };
}

/** 转发到当前棋盘的字段 */
const SIDE_KEYS = [
  'side', 'gold', 'shopRefreshCost', 'totalShopRefreshCount', 'totalRefreshCount',
  'shovelUsed', 'spellUsed', 'wave', 'lives', 'kills', 'spawned', 'dead', 'god',
  'bonusId', 'flags', 'map', 'pieces', 'king', 'enemies', 'bullets', 'paintSplats', 'paintSeed',
  'shopSlots', 'bonds', 'bondMods', 'bondGoldTimers', 'bondAnnounced',
];

export const game = {
  /** 'start' 开始页 | 'matching' 匹配中 | 'playing' 游戏中 | 'paused' 暂停 | 'over' 结束 */
  phase: 'start',

  /** 两方棋盘 */
  boards: { me: null, opp: null },
  /** 当前作用的棋盘（默认我方） */
  cur: null,

  /* ---------------- 拖拽状态（仅我方） ---------------- */
  drag: {
    active: false,
    /** 'shop' | 'board' */
    from: null,
    /** 商店卡位索引 */
    slotIndex: -1,
    /** 场上棋子引用（从 board 拖起时为棋子对象） */
    piece: null,
    /** 卡牌数据（从 shop 拖起时） */
    card: null,
    /** 鼠标位置（我方画布像素） */
    x: 0,
    y: 0,
    /** 当前悬停的格子 {c,r} 或 null */
    hoverCell: null,
    /** 当前悬停的棋子（法术目标） */
    hoverPiece: null,
    /** 悬停类型：'plot' | 'piece' | 'shopSlot' | 'shopMerge' | 'invalid' | null */
    hoverKind: null,
    /** 悬停商店空位索引 */
    hoverSlot: -1,
  },

  /* ---------------- 其它界面状态 ---------------- */
  floaters: [],
  /** 详情面板正在展示的商店卡位（铲子 / 法术卡，-1 = 无） */
  detailCardSlot: -1,
  /** 当前高亮的棋子 id（法术拖拽时） */
  highlightPieceId: null,
  /** 当前选中的棋子 id（单击棋子 → 详情面板；可以是对方棋子） */
  selectedPieceId: null,
  selectPulse: 0,
};

for (const k of SIDE_KEYS) {
  Object.defineProperty(game, k, {
    get() { return game.cur[k]; },
    set(v) { game.cur[k] = v; },
    enumerable: true,
  });
}

game.boards.me = createBoard('me');
game.boards.opp = createBoard('opp');
game.cur = game.boards.me;

/** 新开一局：两方棋盘全部重建（地图共用） */
export function resetBoards(sharedMap) {
  game.boards.me = createBoard('me', sharedMap);
  game.boards.opp = createBoard('opp', sharedMap);
  game.floaters.length = 0;
  game.cur = game.boards.me;
}

/** 在指定棋盘上执行 fn（执行完恢复原棋盘），返回 fn 的返回值 */
export function withBoard(board, fn) {
  const prev = game.cur;
  game.cur = board;
  try { return fn(); } finally { game.cur = prev; }
}

/* ============================================================
 * 状态读写工具（全部作用于当前棋盘）
 * ============================================================ */

/** 在棋盘对象头顶创建短暂奖励浮字；模拟副本和非棋子来源不进入正式画面。 */
export function addBoardFloater(source, text, kind = 'exp') {
  const board = game.cur;
  if (!board || board._simulationContext || !source || !text) return;
  game.floaters.push({ board, source, text: String(text), kind, age: 0, life: 0.9 });
  if (game.floaters.length > 80) game.floaters.splice(0, game.floaters.length - 80);
}

/** 金币变更并触发浮字（由 main.js 挂载渲染回调；只为我方显示） */
export let onGoldChange = () => {};
export function setGoldChangeHook(fn) { onGoldChange = fn; }

export function addGold(delta, screenPos = null, source = null) {
  game.gold = Math.max(0, game.gold + delta);
  if (!game.cur._simulationContext) {
    if (game.cur.side === 'me') onGoldChange(delta, screenPos);
    if (delta > 0 && source) addBoardFloater(source, `+${delta}`, 'gold');
  }
}

/** 扣费校验 + 扣费（金币不足返回 false，不产生任何变化）；统一走浮字提示 */
export function spendGold(amount, screenPos = null) {
  if (game.gold < amount) return false;
  game.gold -= amount;
  if (game.cur.side === 'me' && !game.cur._simulationContext) onGoldChange(-amount, screenPos);
  return true;
}

/** 依据本方增益刷新 flags（开局增益选择后调用） */
export function applyBonusFlags(flags) {
  game.flags = { ...defaultFlags(), ...flags };
  // 合并按类型加的固定攻击：多来源时累加
  game.flags.atkFlatByType = { ...(flags.atkFlatByType || {}) };
}

/** 当前融合进化阈值：实验版统一固定为3阶，增益不再降低规则门槛。 */
export function currentMergeNeed() {
  return MERGE.needCount;
}

/**
 * 当前这一次刷新所需金币。
 * 首次刷新免费（受 SHOP.refreshFirstFree 控制，返回 0，且不影响后续价格）；
 * 之后返回基础刷新价减去下一次刷新优惠，最低为0。
 * 判断「是否首次」用 totalRefreshCount（含免费那次），
 * 避免首次免费后因付费次数仍为 0 而每次都判成首次 → 一直免费。
 */
export function currentRefreshCost() {
  if (SHOP.refreshFirstFree && game.totalRefreshCount === 0) return 0;
  return Math.max(0, game.shopRefreshCost - (game.cur.nextRefreshDiscount || 0));
}

/** 按 id 找场上棋子 */
export function findPiece(id) {
  if (game.king && game.king.id === id) return game.king;
  return game.pieces.find(p => p.id === id) || null;
}

/** 按格子找棋子 / 帅 */
export function pieceAt(c, r) {
  if (game.king && game.king.c === c && game.king.r === r) return game.king;
  return game.pieces.find(p => p.c === c && p.r === r) || null;
}

/** 该格是否为「可放置空地」：纯 Ground 且无 grass / road，或已被铲开且无棋子 */
export function isPlaceablePlot(c, r) {
  const { cols, rows } = game.map;
  if (c < 0 || r < 0 || c >= cols || r >= rows) return false;
  if (pieceAt(c, r)) return false;
  if (game.map.road[r]?.[c]) return false;                 // road 不可放置、不可铲
  if (game.map.grass[r]?.[c] && !game.map.cleared.has(cellKey(c, r))) return false;
  return !!game.map.ground[r]?.[c];                        // 必须存在 Ground 层
}

/** 该格能否被铲子铲（草地且未铲开） */
export function isDiggable(c, r) {
  const { cols, rows } = game.map;
  if (c < 0 || r < 0 || c >= cols || r >= rows) return false;
  if (game.map.road[r]?.[c]) return false;
  return !!game.map.grass[r]?.[c] && !game.map.cleared.has(cellKey(c, r));
}

export default game;
