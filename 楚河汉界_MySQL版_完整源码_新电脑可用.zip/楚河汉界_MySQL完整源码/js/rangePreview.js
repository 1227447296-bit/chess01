/**
 * rangePreview.js —— 放置前的攻击范围预览
 *
 * 用途：拖拽棋子（或商店兵卡）悬浮到「可放置的空地」上方时，
 *       自动以该格为中心、按该棋子的攻击判定规则，算出它能够打到的所有格子，
 *       并只标出其中的 road（敌人路径）格：可攻击用浅红，被棋子阻挡用浅黑。
 *       棋子一旦放置（或取消拖拽），高亮立即消失。
 *
 * 判定完全复用 attackRule.js，保证「预览能打到」= 「实际能打到」。
 */
import game, { pieceAt } from './gameData.js';
import { canPieceAttack } from './attackRule.js';
import { formationCells } from './formation.js';

/**
 * 计算某枚（假想）棋子放在 (c, r) 时能攻击到的 road 格集合。
 * @param {string} type   棋子种类 bing/shi/xiang/ma/ju/pao
 * @param {string} color  棋子颜色
 * @param {number} c
 * @param {number} r
 * @param {object} [flags] 真实棋子身上的永久标记（法术刻印等）
 * @param {number} [level] 真实棋子等级（决定象 10 级免象眼 / 马 80 级免马腿等解锁机制）
 * @param {string[]} [activeBonds] 真实棋子激活的羁绊名（决定重炮杀等影响范围的羁绊）
 * @returns {Array<{c:number, r:number}>} 可被攻击到的 road 格列表
 */
export function computeAttackCells(type, color, c, r, flags = {}, level = 1, activeBonds = []) {
  if (!type) return [];

  // 构造一枚临时棋子用于判定（不进入 game.pieces，不影响真实棋盘）
  // flags / level / activeBonds 透传，保证「预览能打到」= 「实战能打到」。
  const ghost = {
    id: '__preview__',
    kind: 'piece',
    type, color,
    c, r,
    level,
    atkBonus: 0,
    flags: { ...flags },
    stage: 0,
    activeBonds: [...activeBonds],
  };

  const { cols, rows, road } = game.map;
  const hits = [];
  for (let rr = 0; rr < rows; rr++) {
    for (let cc = 0; cc < cols; cc++) {
      if (!road[rr]?.[cc]) continue;              // 只关心能打到敌人的路径格
      if (cc === c && rr === r) continue;
      if (canPieceAttack(ghost, { c: cc, r: rr })) hits.push({ c: cc, r: rr });
    }
  }
  return hits;
}

/**
 * 显示用预览：正常可打格与被棋子阻挡的格分开返回。
 * 不改变 computeAttackCells 的含义，AI 评分仍只统计真正能攻击到的路径格。
 * 炮缺少炮架不属于「被挡住」，只有已有炮架但阻挡过多的格才标黑。
 */
export function computeAttackPreview(type, color, c, r, flags = {}, level = 1, activeBonds = []) {
  const hits = computeAttackCells(type, color, c, r, flags, level, activeBonds);
  let potential = [];
  if (type === 'xiang' || type === 'ma') {
    const clearFlags = { ...flags, noXiangEye: true, noHorseLeg: true };
    potential = computeAttackCells(type, color, c, r, clearFlags, level, activeBonds);
  } else if (type === 'ju' || type === 'pao') {
    const { cols, rows, road } = game.map;
    for (let rr = 0; rr < rows; rr++) for (let cc = 0; cc < cols; cc++) {
      if (!road[rr]?.[cc] || (cc === c && rr === r) || (cc !== c && rr !== r)) continue;
      if (type === 'pao') {
        const dc = Math.sign(cc - c), dr = Math.sign(rr - r);
        let hasScreen = false;
        for (let x = c + dc, y = r + dr; x !== cc || y !== rr; x += dc, y += dr) {
          if (pieceAt(x, y)) { hasScreen = true; break; }
        }
        if (!hasScreen) continue;
      }
      potential.push({ c: cc, r: rr });
    }
  }
  const hitKeys = new Set(hits.map(p => `${p.c},${p.r}`));
  return { hits, blocked: potential.filter(p => !hitKeys.has(`${p.c},${p.r}`)),
    support: formationCells(type, c, r) };
}

/**
 * 从拖拽状态推导出「正在拖拽的棋子的信息」。
 * - 从棋盘拖起：用棋子自身数据
 * - 从商店拖起：用该卡位的棋子数据（原生卡 / 回收卡统一走 card.piece）
 * @returns {{type:string, color:string, flags:object, level:number, stage:number, activeBonds:string[]}|null}
 */
export function draggedPieceInfo(drag) {
  if (!drag) return null;
  let p = null;
  if (drag.from === 'board' && drag.piece) p = drag.piece;
  else if (drag.from === 'shop' && drag.card) {
    p = drag.piece || drag.card.piece
      || (drag.card.type === 'piece' ? { type: drag.card.kind || 'bing', color: drag.card.color, flags: {}, level: drag.card.level || 0, stage: 0 } : null);
  }
  if (!p) return null;
  return {
    type: p.type,
    color: p.color,
    flags: p.flags || {},
    level: p.level || 0,
    stage: p.stage || 0,
    activeBonds: p.activeBonds || [],
  };
}

export default { computeAttackCells, computeAttackPreview, draggedPieceInfo };
