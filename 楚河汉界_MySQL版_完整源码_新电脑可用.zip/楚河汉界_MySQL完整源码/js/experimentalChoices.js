import game from './gameData.js';

let active = false;

/** Choice dialogs pause both boards; no board context is retained across await. */
export function chooseExperimentalOption(title, options) {
  if (active || !options.length || !['playing', 'paused'].includes(game.phase)) return Promise.resolve(null);
  active = true;
  const previousPhase = game.phase;
  const previousFocus = document.activeElement;
  game.phase = 'paused';
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.className = 'experimental-choice-overlay';
    const dialog = document.createElement('section');
    dialog.className = 'experimental-choice';
    dialog.setAttribute('role', 'dialog');
    dialog.setAttribute('aria-modal', 'true');
    const heading = document.createElement('h2');
    heading.id = 'experimental-choice-title';
    heading.textContent = title;
    dialog.setAttribute('aria-labelledby', heading.id);
    dialog.appendChild(heading);
    const tip = document.createElement('p');
    tip.textContent = '选择期间双方暂停；取消不扣金币或法术次数。';
    dialog.appendChild(tip);
    function finish(value) {
      document.removeEventListener('keydown', onKey, true);
      overlay.remove();
      active = false;
      if (game.phase === 'paused') game.phase = previousPhase;
      previousFocus?.focus?.();
      resolve(value);
    }
    for (const option of options) {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = option.label;
      button.addEventListener('click', () => finish(option.value), { once: true });
      dialog.appendChild(button);
    }
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'experimental-choice-cancel';
    cancel.textContent = '取消';
    cancel.addEventListener('click', () => finish(null), { once: true });
    dialog.appendChild(cancel);
    overlay.appendChild(dialog);
    overlay.addEventListener('pointerdown', event => event.stopPropagation());
    overlay.addEventListener('click', event => event.stopPropagation());
    function onKey(event) {
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopImmediatePropagation();
        finish(null);
      } else if (event.key === 'Tab') {
        const buttons = [...dialog.querySelectorAll('button')];
        const index = buttons.indexOf(document.activeElement);
        const next = (index + (event.shiftKey ? -1 : 1) + buttons.length) % buttons.length;
        event.preventDefault();
        event.stopImmediatePropagation();
        buttons[next].focus();
      } else if (!dialog.contains(event.target)) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    }
    document.addEventListener('keydown', onKey, true);
    document.getElementById('app').appendChild(overlay);
    dialog.querySelector('button').focus();
  });
}
