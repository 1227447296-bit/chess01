/** 36计公共校验与效果。费用/库存仅由 actions.useSpell 成功后结算。 */
import { SPELL_BY_ID, RANK, MERGE, LEVEL } from './config.js';
import game, { addGold, isPlaceablePlot, isDiggable, pieceAt, withBoard } from './gameData.js';
import { makePieceFromCard } from './shop.js';
import { digPlot } from './shovel.js';
import { removeFromBoard } from './synthesis.js';
import { hasBoardCapacity, BOARD_CAPACITY_REASON } from './boardLimits.js';
import { canPieceAttack, pieceDamage } from './attackRule.js';
import { spellDamage, stunEnemy, grantExperience } from './wave.js';
import { effectiveLives, addTemporaryLives, buffPiece, slowEnemy, enemySlowRate,
  amplifyEnemy, retreatEnemies, forceSpecial, forceCannonBurst } from './tacticalEffects.js';

const fail = reason => ({ ok: false, reason });
const now = () => game.cur.gameTime || 0;
const liveEnemies = () => game.enemies.filter(e => e.hp > 0 && !e.done && !e.dead && !e.dying);
const normalPiece = p => !!p && game.pieces.includes(p) && p.type !== 'king';
const busy = p => !!(p?.charge || p?.stomp);
const adjacent = (a, b) => Math.abs(a.c - b.c) + Math.abs(a.r - b.r) === 1;
const nearest = enemies => [...enemies].sort((a, b) => (b.progress || 0) - (a.progress || 0));
const highestHp = enemies => [...enemies].sort((a, b) => b.hp - a.hp)[0];
export function isSpellControlled(enemy, board = game.cur) {
  return !!enemy && (enemy.stunLeft > 0 || enemy.slowLeft > 0 || enemySlowRate(enemy, board) > 0 ||
    ((enemy.huanbingSlowUntil || 0) > (board.gameTime || 0) && (enemy.huanbingSlowMultiplier ?? 0.7) < 1));
}

/** 双目标传ID，预览不绑定真实对象。 */
export function spellSecondaryTargets(card, target) {
  const e = SPELL_BY_ID[card?.id]?.effect;
  if (!normalPiece(target)) return [];
  if (e?.type === 'pairBuff') return game.pieces.filter(p => normalPiece(p) && p !== target && p.id !== target.id && p.color !== target.color && adjacent(target, p));
  return [];
}

/** 随机法术有限机会节点，不抽随机、不修改棋子。 */
export function spellRandomOutcomes(card, target) {
  const type = SPELL_BY_ID[card?.id]?.effect.type;
  if (type === 'replaceBing' && target?.type === 'bing') return ['red', 'black'].map(color => ({ probability: 0.5, type: 'bing', color }));
  if (type === 'randomEvolve' && target?.type === 'bing') return MERGE.fromBing.flatMap(t => ['red', 'black'].map(color => ({ probability: 1 / (MERGE.fromBing.length * 2), type: t, color })));
  if (type === 'randomTransform' && RANK.rankTypes.includes(target?.type)) {
    const types = RANK.rankTypes.filter(t => t !== target.type);
    return types.map(t => ({ probability: 1 / types.length, type: t, color: target.color }));
  }
  return [];
}

function checkSpell(card, target, cell, options, shopping = false) {
  const spec = SPELL_BY_ID[card?.id];
  if (!spec) return fail('未知法术');
  if (spellStockLeft(spec.id) <= 0) return fail('该法术本局已用完');
  if (game.cur.dead) return fail('本盘已结束');
  if (options.cancelled || options.canceled) return fail('已取消选择');
  const e = spec.effect;
  if (spec.kind === 'target' && !normalPiece(target)) return fail('该法术需要指定场上普通棋子');
  if (spec.kind === 'cell') {
    if (target || !cell || !Number.isInteger(cell.c) || !Number.isInteger(cell.r)) return fail('请指定合法格子');
    if (e.type === 'dig') {
      if (!isDiggable(cell.c, cell.r) || pieceAt(cell.c, cell.r)) return fail('请选择可挖且未被占据的草地');
    } else if (!isPlaceablePlot(cell.c, cell.r)) return fail('该法术只能放在可放置的空地上');
  }
  if (spec.kind === 'target') {
    switch (e.restrict) {
      case 'bing': if (target.type !== 'bing') return fail('该法术只能对兵使用'); break;
      case 'rankType': if (!RANK.rankTypes.includes(target.type)) return fail('该法术只能对车、马、炮使用'); break;
      case 'pao': if (target.type !== 'pao') return fail('该法术只能对炮使用'); break;
      case 'shiXiang': if (!['shi', 'xiang'].includes(target.type)) return fail('该法术只能对士、象使用'); break;
    }
    if (e.minLevel && (target.level || 0) < e.minLevel) return fail(`该法术需要至少${e.minLevel}级`);
    if (busy(target) && e.type === 'cannonBurst') return fail('棋子正在执行攻击动作');
  }
  if (e.cooldown && now() < (game.cur.displacementCooldownUntil || 0)) return fail('位移法术正在公共冷却中');
  const enemies = liveEnemies();
  const needsEnemies = ['retreat', 'damageAll', 'damageSlowAll', 'retreatNearest', 'vulnerable', 'execute', 'slowEnemies', 'stunSlowAll', 'stunNearest', 'lastStand', 'damageNearestCell'];
  if (needsEnemies.includes(e.type) && !enemies.length && !(shopping && spec.role === 'rescue')) return fail('当前没有存活敌人');
  if (['retreat', 'retreatNearest', 'lastStand'].includes(e.type) && !game.map.path.length) return fail('当前没有有效道路');
  switch (e.type) {
    case 'spawnBing':
      if (!hasBoardCapacity(game.cur)) return fail(BOARD_CAPACITY_REASON);
      if (!['red', 'black'].includes(options.color)) return { ...fail('请选择兵的颜色'), requiresSelection: 'color', choices: ['red', 'black'] };
      break;
    case 'stageUp': if ((target.stage || 0) + e.value > MERGE.maxStage) return fail('该棋子阶数已满'); break;
    case 'experience': {
      const cap = Math.min(LEVEL.hardCap, LEVEL.naturalCap[target.type] ?? LEVEL.hardCap);
      if ((target.level || 0) >= cap) return fail('该棋子已达到等级上限');
      break;
    }
    case 'special': if (target.specialEnhancements?.[e.marker]) return fail('该棋子已使用过此特殊强化'); break;
    case 'flipOwnedColors': if (!game.pieces.length && !game.shopSlots.some(c => c?.source === 'fromBoard' && c.piece)) return fail('没有已拥有的棋子'); break;
    case 'replaceBing':
      if ((target.stage || 0) !== 0) return fail('只能消耗0阶兵');
      break;
    case 'pairBuff': {
      const choices = spellSecondaryTargets(card, target).map(p => p.id);
      if (!choices.length) return fail('没有合法的第二目标');
      if (options.secondaryTargetId == null) return { ...fail('请选择第二枚棋子'), requiresSelection: 'secondaryTargetId', choices };
      if (!choices.includes(options.secondaryTargetId)) return fail('第二目标不合法');
      break;
    }
    case 'neighborBuff': if (!game.pieces.some(p => p !== target && p.color === target.color && adjacent(target, p))) return fail('没有同色相邻友军'); break;
    case 'damageControlled': if (!enemies.some(e => isSpellControlled(e))) return fail('当前没有减速或眩晕的敌人'); break;
    case 'cannonBurst': if (!enemies.some(e => canPieceAttack(target, e))) return fail('当前没有符合炮架规则的可攻击目标'); break;
    case 'lastStand': if (effectiveLives(game.cur) !== 1) return fail('只有有效剩余生命为1时可用'); break;
    case 'temporaryLives': if ((game.lives || 0) < e.cost) return fail('永久生命不足'); break;
    case 'buffAll': if (!game.pieces.length) return fail('场上没有棋子'); break;
  }
  if (options.simulationOutcome != null) {
    if (!game.cur._simulationContext) return fail('正式施放不能指定随机结果');
    if (!spellRandomOutcomes(card, target).some(o => o.type === options.simulationOutcome.type && o.color === options.simulationOutcome.color)) return fail('无效的模拟随机结果');
  }
  return { ok: true };
}
export function validateSpell(card, target = null, cell = null, options = {}) { return checkSpell(card, target, cell, options); }

/** 救场牌无怪时可备战，棋种/等级等结构性条件仍严格检查。 */
export function hasLegalSpellTarget(spec, board = game.cur) {
  return withBoard(board, () => {
    const card = { type: 'spell', id: spec.id };
    const acceptable = result => result.ok || (!!result.requiresSelection && result.choices?.length > 0);
    if (spec.kind === 'target') return game.pieces.some(p => acceptable(checkSpell(card, p, null, {}, true)));
    if (spec.kind === 'cell') {
      for (let r = 0; r < game.map.rows; r++) for (let c = 0; c < game.map.cols; c++) if (acceptable(checkSpell(card, null, { c, r }, {}, true))) return true;
      return false;
    }
    return acceptable(checkSpell(card, null, null, {}, true));
  });
}
function changeType(target, outcome, resetStage) {
  target.type = outcome.type; target.color = outcome.color;
  if (resetStage) { target.stage = 0; target.mergeCount = 0; }
  target.cdLeft = 0; target.specialCount = 0; target.bonds = []; target.activeBonds = [];
  for (const key of ['charge', 'stomp', 'attackRoll', 'evolutionChoices', 'evolutionChoicesType', 'lastTargetId', 'sameTargetHits', 'bingTargetId', 'bingFocus', 'bingSpeedStacks', 'bingSpeedLeft']) delete target[key];
}

export function castSpell(card, target = null, cell = null, options = {}) {
  const check = validateSpell(card, target, cell, options);
  if (!check.ok) return check;
  const e = SPELL_BY_ID[card.id].effect, enemies = liveEnemies();
  const second = game.pieces.find(p => p.id === options.secondaryTargetId);
  const applyBuff = p => buffPiece(p, { rate: e.rate, duration: e.seconds, noCrit: e.noCrit, attackGold: e.attackGold }, game.cur);
  switch (e.type) {
    case 'flipColor': target.color = target.color === 'red' ? 'black' : 'red'; break;
    case 'retreat': retreatEnemies(game.cur, enemies, e.cells); break;
    case 'damageAll': spellDamage(target, enemies, { multiplier: e.multiplier }); break;
    case 'buff': applyBuff(target); break;
    case 'flipOwnedColors': {
      const seen = new Set(), ids = new Set();
      for (const p of [...game.pieces, ...game.shopSlots.filter(c => c?.source === 'fromBoard').map(c => c.piece)]) {
        if (!p || seen.has(p) || (p.id != null && ids.has(p.id))) continue;
        seen.add(p); if (p.id != null) ids.add(p.id);
        p.color = p.color === 'red' ? 'black' : 'red';
      }
      break;
    }
    case 'gainGold': addGold(e.value); break;
    case 'dig': return digPlot(cell.c, cell.r);
    case 'experience': {
      const bonus = e.condition === 'unbonded' ? !target.activeBonds?.length : enemies.some(enemy => isSpellControlled(enemy));
      grantExperience(target, bonus ? e.bonus : e.value); break;
    }
    case 'special':
      target.specialEnhancements = { ...(target.specialEnhancements || {}), [e.marker]: 1 };
      target[e.stat] = Math.max(target[e.stat] || 0, target.flags?.[e.stat] || 0) + e.value;
      target.flags = { ...(target.flags || {}), [e.stat]: target[e.stat] }; break;
    case 'randomEvolve':
    case 'randomTransform': {
      const outcomes = spellRandomOutcomes(card, target);
      if (game.cur._simulationContext && !options.simulationOutcome) return fail('模拟随机法术必须枚举结果');
      const outcome = options.simulationOutcome || outcomes[Math.min(outcomes.length - 1, Math.floor(Math.random() * outcomes.length))];
      changeType(target, outcome, e.type === 'randomEvolve'); break;
    }
    case 'refreshDiscount': addGold(e.value); game.cur.nextRefreshDiscount = Math.max(game.cur.nextRefreshDiscount || 0, e.discount); break;
    case 'damageSlowAll': enemies.forEach(enemy => slowEnemy(enemy, e.rate, e.seconds)); spellDamage(null, enemies, { fixed: e.fixed }); break;
    case 'spawnBing': {
      const piece = makePieceFromCard({ kind: 'bing', color: options.color, level: e.value });
      piece.c = cell.c; piece.r = cell.r; game.pieces.push(piece); break;
    }
    case 'retreatNearest': {
      const victim = nearest(enemies)[0]; retreatEnemies(game.cur, [victim], e.cells); slowEnemy(victim, e.rate, e.seconds); break;
    }
    case 'vulnerable': amplifyEnemy(highestHp(enemies), e.rate, e.seconds); break;
    case 'replaceBing': {
      const outcomes = spellRandomOutcomes(card, target);
      if (game.cur._simulationContext && !options.simulationOutcome) return fail('模拟随机法术必须枚举结果');
      const outcome = options.simulationOutcome || outcomes[Math.min(outcomes.length - 1, Math.floor(Math.random() * outcomes.length))];
      const piece = makePieceFromCard({ kind: 'bing', color: outcome.color, level: 0 });
      piece.c = target.c; piece.r = target.r;
      piece.stage = e.stage; piece.mergeCount = e.stage;
      removeFromBoard(target);
      game.pieces.push(piece);
      break;
    }
    case 'execute': {
      const victim = highestHp(enemies);
      spellDamage(target, [victim], { fixed: Math.min(victim.maxHp * e.hpRate, pieceDamage(target) * e.cap) }); break;
    }
    case 'slowEnemies': enemies.forEach(enemy => slowEnemy(enemy, e.rate, e.seconds)); break;
    case 'sell': removeFromBoard(target); addGold(e.value); break;
    case 'stunSlowAll': enemies.forEach(enemy => { stunEnemy(enemy, e.stun); slowEnemy(enemy, e.rate, e.seconds, e.delay); }); break;
    case 'pairBuff': applyBuff(target); applyBuff(second); break;
    case 'cannonBurst': if (!forceCannonBurst(target, game.cur)) return fail('当前无法发射双连炮'); break;
    case 'neighborBuff': game.pieces.filter(p => p !== target && p.color === target.color && adjacent(target, p)).forEach(applyBuff); break;
    case 'damageControlled': spellDamage(target, [nearest(enemies.filter(enemy => isSpellControlled(enemy)))[0]], { multiplier: e.multiplier }); break;
    case 'stageUp': target.stage = (target.stage || 0) + e.value; target.mergeCount = target.stage; break;
    case 'forceSpecial': if (!forceSpecial(target)) return fail('该棋子尚未解锁特殊技'); break;
    case 'stunNearest': nearest(enemies).slice(0, e.count).forEach(enemy => stunEnemy(enemy, e.seconds)); break;
    case 'lastStand': retreatEnemies(game.cur, nearest(enemies).slice(0, e.count), e.cells); break;
    case 'damageNearestCell': {
      const victim = nearest(enemies)[0]; spellDamage(target, enemies.filter(enemy => enemy.c === victim.c && enemy.r === victim.r), { multiplier: e.multiplier }); break;
    }
    case 'temporaryLives':
      // Atomic 1 permanent -> 0 permanent + 2 temporary, never transiently dead.
      if (!addTemporaryLives(game.cur, e.value, e.seconds)) return fail('无法获得临时生命');
      game.lives -= e.cost; break;
    case 'buffAll': game.pieces.forEach(applyBuff); break;
    case 'freeRefresh': return { ok: true, refreshShop: true };
    default: return fail(`未实现的效果：${e.type}`);
  }
  if (e.cooldown) game.cur.displacementCooldownUntil = now() + e.cooldown;
  return { ok: true };
}
export function spellStockLeft(id) {
  const spec = SPELL_BY_ID[id];
  if (!spec) return 0;
  return Math.max(0, (spec.stock ?? 1) - (game.spellUsed[id] || 0));
}
export function consumeSpellStock(id) { game.spellUsed[id] = (game.spellUsed[id] || 0) + 1; }
export const isSpellCard = card => card?.type === 'spell';
export default { castSpell, validateSpell, isSpellCard, spellStockLeft, consumeSpellStock,
  spellSecondaryTargets, spellRandomOutcomes, hasLegalSpellTarget, isSpellControlled };
