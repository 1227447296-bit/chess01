/** 显式、无DOM回归入口；不导航、不操作真实棋盘或正式调度。
 * 空闲时 import('./js/aiSpawnPlan.test.js').then(m => m.runSpawnPlanFixtures())。
 */
import game, { createBoard } from './gameData.js';
import { WAVES, ENEMY, spawnIntervalForWave } from './config.js';
import { sharedWaves } from './wave.js';
import { buildSpawnPlan } from './aiSpawnPlan.js';
import { simulateCombat, createCombatSimulation, runSimulationFixtures } from './aiSimulation.js';

const snapshot = value => JSON.stringify(value, (key, v) =>
  v instanceof Set ? [...v] : v instanceof Map ? [...v] : v);
const near = (a, b) => Math.abs(a - b) < 1e-8;
const makeState = overrides => ({
  wave: 1, waveToSpawn: 2, timer: WAVES.startDelay, spawnedInWave: 0,
  countInWave: WAVES.firstWaveCount, betweenWaves: false, countdown: false, ...overrides,
});
const makeBoard = () => {
  const board = createBoard('opp');
  board.lives = 100;
  board.map = {
    cols: 300, rows: 2, ground: [Array(300).fill(1), Array(300).fill(1)],
    grass: [Array(300).fill(0), Array(300).fill(0)],
    road: [Array(300).fill(1), Array(300).fill(0)], cleared: new Set(),
    path: Array.from({ length: 300 }, (_, c) => ({ c, r: 0 })),
    enemySpawn: { c: 0, r: 0 }, kingPoint: { c: 299, r: 0 }, raw: null,
  };
  return board;
};

// 独立有限参考时钟：不调用正式 updateSharedWaves，且从不假设一方会清空。
function referenceEvents(state, horizon, step, waves = WAVES) {
  const w = { ...state }, out = [];
  let at = 0;
  while (at < horizon - 1e-9) {
    const dt = Math.min(step, horizon - at);
    at += dt;
    if (w.spawnedInWave < w.countInWave) {
      w.timer -= dt;
      if (w.timer <= 0) {
        out.push({ at, wave: w.wave });
        w.spawnedInWave++;
        w.timer = spawnIntervalForWave(w.wave);
      }
    } else if (!w.betweenWaves) {
      w.betweenWaves = true;
      w.timer = waves.waveInterval;
    } else if (w.countdown) {
      w.timer -= dt;
      if (w.timer <= 0) {
        w.wave = w.waveToSpawn++;
        w.countInWave = waves.firstWaveCount + (w.wave - 1) * waves.countGrowPerWave;
        w.spawnedInWave = 0;
        w.timer = 0;
        w.betweenWaves = false;
        w.countdown = false;
      }
    }
  }
  return out;
}

export function runSpawnPlanFixtures() {
  const checks = [];
  const check = (name, ok) => {
    checks.push({ name, ok: !!ok });
    if (!ok) throw new Error(`spawn fixture: ${name}`);
  };
  const originalCur = game.cur, originalPhase = game.phase, originalRandom = Math.random;
  const sharedBefore = snapshot(sharedWaves);
  const configsBefore = snapshot({ WAVES, ENEMY });
  const plan = (state, options = {}) => buildSpawnPlan(state, { WAVES, ENEMY, ...options });
  const dt = 1 / 30;
  const initial = makeState();
  const initialBefore = snapshot(initial);
  const opening = plan(initial, { horizon: 10 });
  const reference = referenceEvents(initial, 10, dt);
  check('startDelay与正式tick参考一致', snapshot(opening.events.map(({ at, wave }) => ({ at, wave }))) === snapshot(reference));
  check('startDelay不是t0出生', opening.events.length > 0 && opening.events[0].at >= WAVES.startDelay);
  check('startDelay内无怪', plan(initial, { horizon: 1 }).events.length === 0);
  check('计划深层只读', Object.isFrozen(opening) && Object.isFrozen(opening.events) && opening.events.every(Object.isFrozen));

  const within = makeState({ wave: 4, waveToSpawn: 5, timer: 0.01, spawnedInWave: 5, countInWave: 8 });
  const wavePlan = plan(within, { horizon: 10 });
  check('只计划本波剩余数量', wavePlan.events.length === 3 && wavePlan.events.every(e => e.wave === 4));
  check('波内间隔重置不保留余量', snapshot(wavePlan.events.map(({ at, wave }) => ({ at, wave }))) ===
    snapshot(referenceEvents(within, 10, dt)));
  check('出完即标记未知清空边界', wavePlan.uncertainBoundary?.reason === 'awaiting-any-board-clear' &&
    wavePlan.uncertainBoundary.at === wavePlan.events[2].at);
  check('边界本身不可变', Object.isFrozen(wavePlan.uncertainBoundary));
  const over = makeState({ spawnedInWave: 5, countInWave: 5, timer: 0 });
  check('刚出完未启动倒计时不可捏造下一波', plan(over).events.length === 0 && plan(over).uncertainBoundary.at === 0);
  check('波间未锁存即使timer为0也不可开波', plan({ ...over, betweenWaves: true }).events.length === 0);
  const latched = { ...over, betweenWaves: true, countdown: true, timer: dt / 2 };
  const next = plan(latched, { horizon: 10 });
  check('锁存countdown允许下一波', next.events.length === 6 && next.events.every(e => e.wave === 2));
  check('开新波下一tick才出怪', near(next.events[0].at, 2 * dt));
  check('新波完整时钟与参考一致', snapshot(next.events.map(({ at, wave }) => ({ at, wave }))) ===
    snapshot(referenceEvents(latched, 10, dt)));
  check('新波之后再次止于未知边界', next.uncertainBoundary?.nextWave === 3);
  check('帅未到位不推断开始时刻', plan(initial, { schedulerReady: false }).uncertainBoundary?.reason === 'scheduler-not-ready');

  const threshold = wave => plan(makeState({ wave, waveToSpawn: wave + 1, timer: 0, spawnedInWave: 1, countInWave: 2 }), { horizon: dt }).events[0];
  for (const wave of [10, 11, 24, 25]) {
    const expectedHp = (30 + 9 * (wave - 1)) * 1.10 ** Math.max(0, wave - 10) * 1.12 ** Math.max(0, wave - 24);
    check(`${wave}波使用分段复利成长`, near(threshold(wave).hp, expectedHp));
  }
  const noGrowth = buildSpawnPlan(makeState({ wave: 16, waveToSpawn: 17, timer: 0, countInWave: 1 }),
    { WAVES, ENEMY: { ...ENEMY, growthEnabled: false }, horizon: dt });
  check('关闭成长使用基础数值且不应用遗留倍率', noGrowth.events[0].hp === ENEMY.baseHp && noGrowth.events[0].speed === ENEMY.baseSpeed);
  const rapidWaves = { ...WAVES, spawnInterval: dt / 10 };
  const rapid = buildSpawnPlan(makeState({ timer: -5, countInWave: 100 }), { WAVES: rapidWaves, ENEMY, horizon: 3 * dt });
  check('负timer每tick最多一只且遵循共享出怪间隔', rapid.events.length === 1 && near(rapid.events[0].at, dt));
  check('步长和horizon上限与模拟一致', plan(initial, { step: 10, horizon: 100 }).step === dt &&
    plan(initial, { step: 0.0001, horizon: 100 }).horizon === 30 && plan(initial, { horizon: 100 }).truncated);

  const board = makeBoard();
  const before = snapshot(board);
  const future = [{ at: 0.5, wave: 2, hp: 80, speed: 0.6 }, { at: 0.8, wave: 2, hp: 80, speed: 0.6 }];
  const futureBefore = snapshot(future);
  const sync = simulateCombat(board, { horizon: 1, spawnPlan: future });
  check('空场未来有出生不会早停', sync.generatedCount === 2 && near(sync.elapsed, 1));
  check('生成HP与旧HP分开统计', sync.generatedHp === 160 && sync.startRemainingHp === 0 && sync.remainingHp === 160);
  check('事件不是t0一股脑注入', sync.board.enemies[0].progress < 0.4 && sync.board.enemies[1].progress < sync.board.enemies[0].progress);
  check('有限计划不改变源出怪计数', board.spawned === 0 && sync.board.spawned === 2 && sync.board.wave === 2);
  const sliced = createCombatSimulation(board, { horizon: 1, spawnPlan: future });
  check('分帧初始无结果', sliced.result === null && sliced.advance(0) === null);
  sliced.advance(2);
  check('首片不预塞未来事件', !sliced.done && game.cur === originalCur);
  while (!sliced.done) sliced.advance({ maxSteps: 3, timeBudgetMs: Infinity });
  check('同步分帧完全一致', snapshot(sync) === snapshot(sliced.result));
  check('无计划保留空盘0步语义', simulateCombat(board).steps === 0);
  const defended = makeBoard();
  defended.pieces = [{ id: 'guard', kind: 'piece', type: 'bing', color: 'red', c: 0, r: 1,
    level: 0, exp: 0, stage: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [] }];
  const gaps = simulateCombat(defended, { horizon: 2, spawnPlan: [
    { at: 0.1, wave: 1, hp: 1, speed: 0.1 }, { at: 1.5, wave: 1, hp: 1, speed: 0.1 },
  ] });
  check('杀完第一只仍等待后续出生', gaps.generatedCount === 2 && gaps.kills === 2 && gaps.elapsed >= 1.5);
  const zero = simulateCombat(board, { horizon: 0.1, spawnPlan: [
    { at: 0, wave: 1, hp: 1, speed: 1 }, { at: 0.01, wave: 1, hp: 1, speed: 1 },
  ] });
  check('显式t0事件不会推迟紧邻事件', zero.generatedCount === 2 &&
    near(zero.board.enemies[0].progress, 0.1) && near(zero.board.enemies[1].progress, 0.1));
  check('horizon外事件不阻止早停', simulateCombat(board, { horizon: 0.1, spawnPlan: future }).steps === 0);
  const atEnd = simulateCombat(board, { horizon: dt, spawnPlan: [{ at: dt, wave: 1, hp: 1, speed: 1 }] });
  check('边界事件在该tick战斗前出生并移动', atEnd.generatedCount === 1 && near(atEnd.board.enemies[0].progress, dt));
  const occupied = makeBoard();
  occupied.enemies = [{ id: 'sim-spawn-1', kind: 'enemy', c: 4, r: 0, fx: 4, fy: 0,
    hp: 13, maxHp: 21, speed: 0.2, progress: 4, done: false, dying: false, deathT: 0,
    stunLeft: 2, stunImmuneLeft: 3, slowLeft: 4, extra: 'keep-me' }];
  const occupiedBefore = snapshot(occupied);
  const mixed = simulateCombat(occupied, { horizon: 0.1, spawnPlan: [{ at: dt, wave: 16, hp: 200, speed: 1 }] });
  const old = mixed.board.enemies[0];
  check('新波与旧怪并存且旧HP速度属性不重算', mixed.remainingEnemies === 2 && old.hp === 13 && old.maxHp === 21 && old.speed === 0.2 && old.extra === 'keep-me');
  check('旧怪眩晕与减速窗口随时间更新、眩晕中免疫不倒计时', near(old.stunLeft, 1.9) && old.stunImmuneLeft === 3 && near(old.slowLeft, 3.9) && old.progress === 4);
  check('局部ID避开旧怪ID', mixed.board.enemies[1].id !== old.id);
  const delayedOptions = { horizon: 1, spawnPlan: future, actionDelay: 0.2,
    mutateAfterDelay: clone => { clone.gold += 3; } };
  const delayedSync = simulateCombat(board, delayedOptions);
  const delayedSlices = createCombatSimulation(board, delayedOptions);
  while (!delayedSlices.done) delayedSlices.advance(1);
  check('延迟动作与出生分帧一致', delayedSync.mutationApplied && snapshot(delayedSync) === snapshot(delayedSlices.result));
  const mutable = future.map(e => ({ ...e }));
  const copied = createCombatSimulation(board, { horizon: 1, spawnPlan: mutable });
  mutable[0].hp = 999;
  mutable.length = 0;
  check('创建时复制事件而不借用可变输入', copied.advance().generatedHp === 160);
  let rejected = false;
  try { createCombatSimulation(board, { spawnPlan: [future[0], future[0]] }); } catch { rejected = true; }
  check('同tick批量事件被拒绝', rejected);
  check('原有模拟fixture仍通过', runSimulationFixtures().ok);
  check('源棋盘与计划输入不变', snapshot(board) === before && snapshot(occupied) === occupiedBefore && snapshot(future) === futureBefore);
  check('调度快照和配置不变', snapshot(initial) === initialBefore && snapshot({ WAVES, ENEMY }) === configsBefore);
  check('正式共享调度不变', snapshot(sharedWaves) === sharedBefore);
  check('当前棋盘phase随机函数引用不变', game.cur === originalCur && game.phase === originalPhase && Math.random === originalRandom);
  // 随机不变的状态保证来自生产路径中无 Math.random 调用；不替换全局随机做探针。
  return { ok: true, count: checks.length, checks };
}

export default runSpawnPlanFixtures;
