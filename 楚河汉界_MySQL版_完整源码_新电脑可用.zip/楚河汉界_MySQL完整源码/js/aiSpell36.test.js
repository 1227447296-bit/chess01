/** 浏览器显式入口；由主线程统一CDP运行，不创建服务、不访问对手商店。 */
import game, { createBoard, withBoard, uid } from './gameData.js';
import { SPELLS, SPELL_BY_ID, AI_PLAY } from './config.js';
import { spellActions, actionBranches, evaluateAction, scorePosition, clonePosition, riskAdjusted } from './aiEvaluation.js';
import { aiTick, aiInfo, setupAI } from './ai.js';
import { useSpell } from './actions.js';
import { effectiveLives, updateTacticalEffects, pieceTacticalStats } from './tacticalEffects.js';
import { createCombatSimulation } from './aiSimulation.js';
import { MAX_BOARD_PIECES } from './boardLimits.js';

const snapshot = value => JSON.stringify(value, (key, v) => v instanceof Set ? [...v] : v instanceof Map ? [...v] : v);
const piece = (id, type, c, r, color = 'red', level = 80) => ({ id, kind: 'piece', type, c, r, color, level,
  stage: 0, mergeCount: 0, exp: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [], activeBonds: [] });
const card = id => ({ source: 'native', type: 'spell', id, price: SPELL_BY_ID[id].price });
function fixture(id) {
  const b = createBoard('opp');
  const layer = value => Array.from({ length: 4 }, () => Array(12).fill(value));
  const road = layer(false), grass = layer(false);
  road[1].fill(true); grass[3][2] = true; grass[3][7] = true;
  b.map = { cols: 12, rows: 4, ground: layer(true), grass, road, cleared: new Set(),
    path: Array.from({ length: 12 }, (_, c) => ({ c, r: 1 })), enemySpawn: { c: 0, r: 1 }, kingPoint: { c: 11, r: 1 } };
  b.gold = 100; b.wave = 12; b.lives = id === 'kongchengji' ? 1 : 3; b.totalRefreshCount = 1;
  b.shopRefreshCost = 8;
  b.pieces = [piece('cannon', 'pao', 0, 1), piece('mount', 'bing', 1, 1, 'red', 0),
    piece('advisor', 'shi', 2, 0, 'red', 10), piece('rook', 'ju', 3, 0, 'red'),
    piece('horse', 'ma', 4, 0, 'black'), piece('pawn', 'bing', 5, 0, 'black', 0)];
  b.enemies = [3, 9].map((progress, i) => ({ id: `enemy-${i}`, kind: 'enemy', c: progress, r: 1,
    fx: progress, fy: 1, progress, hp: 200, maxHp: 200, speed: 0.65,
    stunLeft: ['guanmenzhuozei', 'meirenji'].includes(id) ? 0 : 0.4,
    stunImmuneLeft: 0, slowLeft: 0, done: false, dead: false, dying: false }));
  if (id) b.shopSlots[0] = card(id);
  return b;
}

export function runAISpell36Fixtures() {
  if (game.phase === 'playing') throw Error('请回开始页后由主线程统一运行AI36计夹具');
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  const original = game.cur, phase = game.phase;
  try {
    check('36种唯一且双方同库存1', SPELLS.length === 36 && new Set(SPELLS.map(s => s.id)).size === 36 && SPELLS.every(s => s.stock === 1));
    for (const spec of SPELLS) {
      const b = fixture(spec.id), before = snapshot(b);
      const uidBefore = Number(uid('ai36probe').slice(9));
      const originalRandom = Math.random;
      let actions, branches;
      try {
        Math.random = () => { throw Error(`${spec.id}预览触碰正式随机`); };
        actions = spellActions(b, 0);
        check(`${spec.id}生成公共校验合法动作`, actions.length > 0);
        branches = actionBranches(b, actions[0]);
        check(`${spec.id}用真实actions施法推演`, branches.length > 0 && branches.every(x => x.board.spellUsed[spec.id] === 1 && x.board.shopSlots[0] === null));
        check(`${spec.id}实际扣费而不把支出当收入`, branches.every(x => {
          const income = ['gainGold', 'refreshDiscount', 'sell'].includes(spec.effect.type) ? spec.effect.value : 0;
          return x.board.kills > b.kills || x.board.gold === b.gold - spec.price + income;
        }));
      } finally { Math.random = originalRandom; }
      const uidAfter = Number(uid('ai36probe').slice(9));
      check(`${spec.id}不污染源盘正式UID与当前盘`, snapshot(b) === before && uidAfter === uidBefore + 1 && game.cur === original);
      const after = branches[0].board;
      if (spec.effect.type === 'forceSpecial') {
        const target = after.pieces.find(p => p.id === actions[0].targetId);
        check('反客蓄势实际补满而非立即攻击', target.specialCount > 0 && after.enemies.every((e, i) => e.hp === b.enemies[i].hp));
      }
      if (spec.effect.type === 'sell') check('金蝉出售净金币0不当赚钱', after.gold === b.gold && after.pieces.length === b.pieces.length - 1);
      if (spec.effect.type === 'stunSlowAll') check('强控固定3~6秒慢速窗口', after.enemies.every(e => e.stunLeft >= 3 && e.tacticalSlows.some(s => s.start === 3 && s.until === 6)));
      if (spec.effect.type === 'cannonBurst') check('炮实际主炮和待追加炮', after.enemies.some((e, i) => e.hp < b.enemies[i].hp) && after.tacticalCannonShots.length > 0);
      if (spec.effect.type === 'dig') {
        const free = clonePosition(b); free.gold = 0;
        check('零资源仍可合法0费开垦', spellActions(free, 0).length > 0 && actionBranches(free, spellActions(free, 0)[0])[0].board.gold === 0);
      }
      if (spec.price > 0) {
        const empty = clonePosition(b); empty.gold = 0;
        check(`${spec.id}零资源无权生成`, spellActions(empty, 0).length === 0);
        check(`${spec.id}零资源不能把未合法动作当成功`, actionBranches(empty, actions[0]).length === 0);
      }
      const spent = clonePosition(b); spent.spellUsed[spec.id] = 1;
      check(`${spec.id}stock1不能二次生成`, spellActions(spent, 0).length === 0);
    }
    for (const [id, count] of [['lidaitaojiang', 4], ['toulianghuanzhu', 2], ['paozhuanyinyu', 2]]) {
      const b = fixture(id), action = spellActions(b, 0)[0], result = evaluateAction(b, action);
      check(`${id}全概率而非挑最好结果`, result.branches.length === count && Math.abs(result.branches.reduce((n, x) => n + x.probability, 0) - 1) < 1e-9 &&
        Math.abs(result.score - riskAdjusted(result.branches)) < 1e-9);
      const target = b.pieces.find(p => p.id === action.targetId);
      const colors = new Set(result.branches.map(x => x.board.pieces.find(p => id === 'paozhuanyinyu'
        ? p.c === target.c && p.r === target.r : p.id === action.targetId).color));
      check(`${id}颜色概率正确`, id === 'toulianghuanzhu' ? colors.size === 1 : colors.size === 2);
      check(`${id}正式动作不携带选定随机结果`, !('simulationOutcome' in action) && !('evolutionType' in action));
      if (id === 'paozhuanyinyu') {
        check('抛砖两种颜色各一半而非最好分支', result.branches.every(x => x.probability === 0.5) &&
          result.score <= Math.max(...result.branches.map(x => x.value)));
        check('抛砖仅消耗0阶兵且无第二目标或指定颜色', spellActions(b, 0).every(a => {
          const p = b.pieces.find(p => p.id === a.targetId);
          return p?.type === 'bing' && p.stage === 0 && !('secondaryTargetId' in a) && !('color' in a);
        }));
        check('抛砖实际消耗并在原位生成2阶0级新兵', result.branches.every(x => {
          const replacement = x.board.pieces.find(p => p.c === target.c && p.r === target.r);
          return !x.board.pieces.some(p => p.id === target.id) && x.board.pieces.length === b.pieces.length &&
            replacement?.type === 'bing' && replacement.stage === 2 && replacement.mergeCount === 2 &&
            replacement.level === 0 && replacement.exp === 0 && x.board.gold === b.gold - 6;
        }));
      }
    }
    for (const id of ['yuanjiaojingong']) {
      const b = fixture(id), actions = spellActions(b, 0);
      check(`${id}枚举显式第二目标`, actions.length > 0 && actions.every(a => a.secondaryTargetId && a.secondaryTargetId !== a.targetId));
      check(`${id}缺第二目标不算成功`, actionBranches(b, { ...actions[0], secondaryTargetId: undefined }).length === 0);
      check(`${id}自己不能作为第二目标`, actionBranches(b, { ...actions[0], secondaryTargetId: actions[0].targetId }).length === 0);
    }
    const replacementBoard = fixture('paozhuanyinyu');
    replacementBoard.pieces = [piece('sacrifice', 'bing', 2, 0, 'red', 40)];
    replacementBoard.pieces[0].exp = 12;
    replacementBoard.gold = 6;
    const replaceAction = spellActions(replacementBoard, 0)[0];
    const replaced = actionBranches(replacementBoard, replaceAction);
    check('抛砖单枚高等级0阶兵即可施法且新兵等级经验归零', replaced.length === 2 && replaced.every(x =>
      x.board.gold === 0 && x.board.pieces.length === 1 && x.board.pieces[0].level === 0 && x.board.pieces[0].exp === 0));
    for (const [type, stage] of [['bing', 1], ['bing', 2], ['shi', 0]]) {
      const invalid = clonePosition(replacementBoard);
      Object.assign(invalid.pieces[0], { type, stage, mergeCount: stage });
      check(`抛砖拒绝${stage}阶${type}`, spellActions(invalid, 0).length === 0 && actionBranches(invalid, replaceAction).length === 0);
    }
    const full = clonePosition(replacementBoard);
    while (full.pieces.length < MAX_BOARD_PIECES) {
      const index = full.pieces.length;
      full.pieces.push(piece(`full-${index}`, 'shi', index, 2));
    }
    const fullBranches = actionBranches(full, spellActions(full, 0)[0]);
    check('抛砖满盘仍原位置换而非额外召唤', fullBranches.length === 2 &&
      fullBranches.every(x => x.board.pieces.length === MAX_BOARD_PIECES));
    const bitter = fixture('kuruoji'); bitter.lives = 1;
    const bitterAction = spellActions(bitter, 0)[0], assessed = evaluateAction(bitter, bitterAction);
    check('苦肉1永久心合法但估值拒绝30秒必败', assessed.branches.length === 1 && assessed.unsafe && assessed.score < scorePosition(clonePosition(bitter)).score);
    const last = assessed.branches[0].board;
    check('苦肉实际施法0永久+2临时', last.lives === 0 && effectiveLives(last) === 2 && !last.dead);
    game.phase = 'paused';
    const time = last.gameTime; updateTacticalEffects(last, 31);
    check('暂停不让苦肉到期', last.gameTime === time && !last.dead);
    game.phase = 'playing'; updateTacticalEffects(last, 30.01);
    check('30秒后0永久必死', last.dead && effectiveLives(last) === 0);
    const buff = fixture('yiyidailao'), buffAction = spellActions(buff, 0)[0];
    const buffed = actionBranches(buff, buffAction)[0].board;
    check('限时增伤不伪装永久静态火力', Math.abs(scorePosition(clonePosition(buffed)).output - scorePosition(clonePosition(buff)).output) < 1e-9);
    const bp = buffed.pieces.find(p => p.id === buffAction.targetId);
    check('限时buff实际写入并到期', pieceTacticalStats(bp, buffed).rate === 0.25);
    updateTacticalEffects(buffed, 10.01);
    check('到期后AI读取增伤为0', pieceTacticalStats(bp, buffed).rate === 0);
    const refresh = fixture('zouweishangji'), refreshBefore = snapshot(refresh);
    const refreshed = actionBranches(refresh, spellActions(refresh, 0)[0])[0].board;
    check('刷新是未知机会而非预读好牌', refreshed.pendingShopRefresh && refreshed.shopSlots.every(x => x === null) && snapshot(refresh) === refreshBefore);
    const control = fixture('guanmenzhuozei');
    const controlled = actionBranches(control, spellActions(control, 0)[0])[0].board;
    const simulation = createCombatSimulation(controlled, { horizon: 6.1, seed: 17 });
    while (!simulation.done) simulation.advance(32);
    check('强控真实战斗推演不污染输入和源盘', simulation.result.elapsed > 0 && !controlled.dead && game.cur === original);
    // 此处动作直接调用与AI完全同一公共入口，确认双目标不是仅能评分的假动作。
    const pair = fixture('yuanjiaojingong'), pairAction = spellActions(pair, 0)[0];
    withBoard(pair, () => check('双目标真实施法产生两枚buff', useSpell(0, pair.pieces.find(p => p.id === pairAction.targetId), null,
      { secondaryTargetId: pairAction.secondaryTargetId }).ok && pair.pieces.filter(p => pieceTacticalStats(p, pair).rate === 0.2).length === 2));
    return { ok: true, checks };
  } finally { game.phase = phase; game.cur = original; }
}

/** 真正走aiTick→候选→估值→perform→actions；不缩短或更改正式AI间隔。 */
export function runAISpell36DecisionFixtures() {
  if (game.phase === 'playing') throw Error('请先回开始页');
  const checks = [], original = game.cur, phase = game.phase;
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  try {
    game.phase = 'playing';
    for (const id of ['wuzhongshengyou', 'dacaojingshe', 'yuanjiaojingong']) {
      const b = fixture(id); b.aiTimer = 0; b.gold = SPELL_BY_ID[id].price;
      if (id === 'dacaojingshe') { b.pieces = []; b.enemies.forEach(e => { e.hp = 20; e.maxHp = 20; e.progress = 10.5; }); }
      if (id === 'yuanjiaojingong') {
        // 两枚士均已覆盖8~9列的敌人，避免车的第二枚未对线、移动比20%增伤更优。
        b.pieces = [piece('pair-a', 'shi', 8, 0, 'red', 15), piece('pair-b', 'shi', 9, 0, 'black', 15)];
        b.pieces.forEach(p => { p.atkBonus = 1000; });
        b.enemies.forEach(e => { e.hp = 100000; e.maxHp = 100000; e.speed = 0.1; e.progress = 8; e.c = 8; e.fx = 8; e.r = 1; e.fy = 1; });
      }
      setupAI({ tier: 7 }, { seed: 173, variety: false, lowRankMode: 'normal', evaluationSlices: 64 });
      let frames = 0;
      withBoard(b, () => {
        while (!aiInfo(b).decisions && frames++ < 20000) aiTick(1 / 60, 3, 7);
        const used = b.spellUsed[id] === 1 && aiInfo(b).lastAction?.kind === 'spell';
        check(`${id}正常AI实际选择施法${used ? '' : ` ${JSON.stringify({ info: aiInfo(b), gold: b.gold, frames })}`}`, used);
        check(`${id}保持正常操作间隔`, b.aiTimer >= AI_PLAY.actionMin && b.aiTimer <= AI_PLAY.actionMax);
        const before = snapshot(b), decisions = aiInfo(b).decisions;
        aiTick(0.001, 3, 7);
        check(`${id}间隔未到不会连施法`, aiInfo(b).decisions === decisions && b.spellUsed[id] === 1 && b.gold >= 0);
        game.phase = 'paused'; const timer = b.aiTimer; aiTick(30, 3, 7);
        check(`${id}暂停不推进操作计时`, b.aiTimer === timer);
        game.phase = 'playing';
      });
    }
    return { ok: true, checks };
  } finally { game.phase = phase; game.cur = original; }
}
