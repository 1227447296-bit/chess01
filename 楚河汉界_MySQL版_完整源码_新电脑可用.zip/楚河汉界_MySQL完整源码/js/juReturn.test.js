import game, { createBoard, withBoard } from './gameData.js';
import { rescanBonds } from './bond.js';
import { updateCombat } from './wave.js';
import { pieceDamage } from './attackRule.js';

export function runJuReturnFixtures() {
  const checks = [];
  const check = (name, ok) => {
    checks.push({ name, ok: !!ok });
    if (!ok) throw new Error(name);
  };
  const previous = game.cur, phase = game.phase;
  try {
    game.phase = 'playing';
    // 双车错已删除：搭档同线也不再拐弯；返程70级半伤、80级全伤。
    for (const level of [69, 70, 80]) for (const bend of [false, true]) for (const stage of [0]) {
      for (const [dc, dr] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const c = 3, r = 3, cols = 7, rows = 7;
        const road = Array.from({ length: rows }, () => Array(cols).fill(1));
        const board = createBoard('me', { cols, rows, road, ground: road, grass: [], path: [] });
        board._simulationContext = { random: () => 1 }; // 排除秒杀，精确验证两段普通伤害。
        const p = { id: 'car', kind: 'piece', type: 'ju', color: 'red', c, r, level,
          exp: 0, stage, atkBonus: 0, flags: {}, cdLeft: 0, activeBonds: [], bonds: [] };
        board.pieces = [p];
        if (bend) board.pieces.push({ ...p, id: 'partner', color: 'black',
          c: c - dc, r: r - dr, cdLeft: 999 });
        const e = { id: 'target', c: c + dc, r: r + dr, hp: 100000, maxHp: 100000, done: false, dying: false };
        board.enemies = [e];
        const bendEnemy = bend ? { ...e, id: 'bend-target',
          c: dc ? (dc > 0 ? cols - 1 : 0) : c + 1,
          r: dr ? (dr > 0 ? rows - 1 : 0) : r + 1 } : null;
        if (bendEnemy) board.enemies.push(bendEnemy);
        withBoard(board, () => { rescanBonds(); updateCombat(0); });
        const damage = withBoard(board, () => pieceDamage(p));
        const label = `${level}/${bend}/${stage}阶/${dc},${dr}`;
        const returnRate = level >= 80 ? 1 : level >= 70 ? 0.5 : 0;
        check(`${label}同线搭档不再拐弯`, !p.charge.useBend);
        check(`${label}正确解锁返程伤害`, p.charge.returnDmg === (level >= 70));
        check(`${label}返程倍率`, p.charge.returnRate === returnRate);
        let noRepeatedHits = true;
        let outboundHp;
        for (let i = 0; i < 1000 && p.charge; i++) {
          if (p.charge.phase === 'back' && outboundHp == null) outboundHp = e.hp;
          withBoard(board, () => updateCombat(1 / 120));
          // 同一位置反复更新，不得因去重表分开而连续扣血。
          withBoard(board, () => updateCombat(0));
          const before = e.hp;
          for (let j = 0; j < 3; j++) withBoard(board, () => updateCombat(0));
          noRepeatedHits = noRepeatedHits && e.hp === before;
        }
        check(`${label}停留不重复伤害`, noRepeatedHits);
        check(`${label}去程只伤害一次`, Math.abs(outboundHp - (100000 - damage)) < 1e-6);
        check(`${label}往返伤害次数`, Math.abs(e.hp - (100000 - damage * (1 + returnRate))) < 1e-6);
        if (bendEnemy) check(`${label}拐弯段敌人不受伤`, bendEnemy.hp === 100000);
        check(`${label}正常结束返程`, !p.charge && p.c === c && p.r === r);
      }
    }
    return { passed: checks.length, checks };
  } finally { game.cur = previous; game.phase = phase; }
}
