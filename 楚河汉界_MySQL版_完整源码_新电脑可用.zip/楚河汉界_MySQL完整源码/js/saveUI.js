import * as rank from './rank.js';

/** 本地自动存档 + 手动迁移。无需账号，也不会上传到服务器。 */
export function setupSaveUI(onChange) {
  for (const where of ['start', 'pause']) {
    const host = document.getElementById(`save-${where}`);
    host.innerHTML = `
      <summary>段位存档 · 导出 / 导入</summary>
      <div class="save-content">
        <p>自动保存在当前浏览器。换手机、换网站或清理浏览器前，请导出备份；不会自动跨设备同步。</p>
        <textarea class="save-code" aria-label="段位存档码" placeholder="导出后复制保存，或在此粘贴存档码" spellcheck="false" autocapitalize="off" autocomplete="off"></textarea>
        <div class="save-buttons"><button type="button" data-save="export">导出</button><button type="button" data-save="copy">复制</button><button type="button" data-save="import">导入</button></div>
        <p class="save-message" role="status"></p>
      </div>`;
    const code = host.querySelector('textarea'), message = host.querySelector('.save-message');
    host.addEventListener('click', async e => {
      const action = e.target.dataset.save;
      if (action === 'export') {
        code.value = rank.exportRank();
        message.textContent = '已生成存档码，请复制到备忘录等安全位置';
      } else if (action === 'copy') {
        if (!code.value.trim()) code.value = rank.exportRank();
        try {
          await navigator.clipboard.writeText(code.value);
          message.textContent = '已复制到剪贴板';
        } catch {
          code.focus(); code.select(); code.setSelectionRange(0, code.value.length);
          message.textContent = '浏览器不允许自动复制，请长按选中的存档码手动复制';
        }
      } else if (action === 'import') {
        if (!code.value.trim()) { message.textContent = '请先粘贴存档码'; return; }
        if (!window.confirm('导入将覆盖当前段位进度，确定继续？')) return;
        const result = rank.importRank(code.value);
        message.textContent = !result.ok ? result.message : result.saved ? '导入成功，段位已更新' : '已导入到本次会话，但浏览器禁止保存，请保留备份';
        if (result.ok) onChange();
      }
    });
  }
  window.addEventListener('pagehide', () => { rank.save(); refreshSaveStatus(); });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') { rank.save(); refreshSaveStatus(); }
  });
  rank.save();                    // 启动即验证可写性，避免手机无痕模式误报已保存
  refreshSaveStatus();
}

export function refreshSaveStatus() {
  for (const el of document.querySelectorAll('.save-status')) {
    el.textContent = rank.storageStatus.ok
      ? rank.storageStatus.recovered ? '已从本地备份恢复段位' : '段位自动保存于此浏览器'
      : '浏览器存储不可用，请导出段位备份，关闭后可能丢失';
    el.classList.toggle('warning', !rank.storageStatus.ok);
  }
}
