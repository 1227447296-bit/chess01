/**
 * main.js —— 游戏入口，串联各模块
 * 职责：资源加载 → 地图解析 → 开始页 / 匹配 → 主循环（双棋盘）→ 输入交互（拖拽/点击）→ UI 同步 → 结算
 *
 * 同屏对决：4×10 左我右敌，5×8 上敌下我；对手棋盘上下翻转，只能点击查看。
 * 规则逻辑全部委托给：actions.js / shop.js / spell.js / synthesis.js / wave.js / bond.js / ai.js / rank.js
 */
import {
  GRID, SHOP, PIECE_STATS, pieceDisplayName, SPELL_BY_ID, LEVEL, experienceRequired, MISC, GLOBAL_ATK_SPEED_SCALE,
  GOLD_ON_KILL, LEVEL_EFFECT_TEXT, bondDetailText, BOND_CONFIG,
  MERGE, RANK, BONUS_SELECT_ENABLED, KING, MATCH, RANKS, displayNumber,
} from './config.js';
import game, {
  isPlaceablePlot, isDiggable, pieceAt, setGoldChangeHook, currentRefreshCost,
  resetBoards, withBoard, createBoard,
} from './gameData.js';
import { loadAll } from './assets.js';
import { loadMap, scanMaps } from './mapLoader.js';
import { showBonusSelect, setStartHook, applyChosenBonuses } from './bonusSelect.js';
import * as shop from './shop.js';
import { spellStockLeft, spellSecondaryTargets } from './spell.js';
import * as act from './actions.js';
import * as combatRules from './attackRule.js';
import { effectiveLives, specialThreshold } from './tacticalEffects.js';
import { chooseExperimentalOption } from './experimentalChoices.js';
import { experimentalResult } from './experimentalResult.js';
import { startGame, update as waveUpdate, updateSharedWaves, resetSharedWaves, jumpToWave, sharedWaves } from './wave.js';
import { rescanBonds } from './bond.js';
import { renderState, render, renderDragGhost, finalAtk, pixelToCell } from './render.js';
import { resetBondPopups } from './bondEffect.js';
import { levelCdMult, hasUnlock, bingAttackOffsets } from './attackRule.js';
import { draggedPieceInfo } from './rangePreview.js';
import { formationBonuses, XIANG_EYE_OFFSETS, MA_LEG_OFFSETS } from './formation.js';
import * as rank from './rank.js';
import { randomName } from './names.js';
import { setupAI, aiTick } from './ai.js';
import { runCheat, setCheatHooks } from './cheats.js';
import { isSidewaysMap, viewSize, boardToView, vectorToView } from './boardView.js';
import { showLoading, updateLoading, hideLoading, loadingError } from './loading.js';
import { setupSaveUI, refreshSaveStatus } from './saveUI.js';
import { setupTouchSafeguards, setupDetailDismissal } from './mobileTouch.js';
import { codexSpellGroups, isCodexUnlocked } from './codex.js';
import { BOSS, enemySpecForSpawn } from './boss.js';
import { uploadMatch } from './api.js';
import { ENEMY, WAVES, enemyStatsForWave } from './config.js';
import { shouldOfferTutorial, rememberTutorial, tutorialActive, createTutorialBoards,
  tutorialInstruction, advanceTutorial, startTutorialDefense, nextTutorialEnemy,
  tutorialActionAllowed, TUTORIAL_ACTION_REASON, TUTORIAL_DEFENSE_STEP, TUTORIAL_PANEL_RECT } from './tutorial.js';

// 尽早启用，包括资源加载界面；不取消输入控件的复制/粘贴菜单。
setupTouchSafeguards(document.getElementById('app'), document);

/** 解析后的地图（两边棋盘共用瓦片 / 路径） */
let mapData = null;
/** board 目录里扫描到的地图编号（每局从中随机） */
let mapList = [];
/** 两张画布 { me:{canvas,ctx}, opp:{canvas,ctx} } */
const canvases = {};
/** 本局对手信息 */
const match = { name: '', rankText: '' };
/** 作弊：游戏速度倍数 / 我方自动下棋（null = 关，数字 = AI 档位）/ 显示对手商店 */
const debug = { speed: 1, auto: null, seeShop: false };

/* ============================================================
 * 初始化
 * ============================================================ */
async function boot() {
  setGoldChangeHook(onGoldChange);

  showLoading();
  try {
    await loadAll(p => updateLoading(p.loaded / p.total * 75, p.label, `图片与字体 ${p.loaded} / ${p.total}`));
    updateLoading(75, '读取地图清单');
    mapList = await scanMaps();
    if (!mapList.length) throw new Error('地图清单中没有可用的 board 地图');
    mapData = await loadMap(mapList[0], progress =>
      updateLoading(80 + progress * 20, `地图 board${mapList[0]}`));
  } catch (e) {
    console.error('[main] 资源加载失败：', e);
    loadingError(e, boot);
    return;
  }
  console.log('[main] 可用地图：', mapList.map(n => `board${n}`).join(', '));
  resetBoards(sharedMapOf(mapData));

  setupCanvases();
  setupShop();
  setupInput();
  setupDetailPanel();
  setupPause();
  setupCheats();
  setupSaveUI(updateRankCard);

  setStartHook(beginBattle);
  setupStartScreen();
  showStartScreen();
  hideLoading();
  setupTutorial();
  setupCodex();

  requestAnimationFrame(loop);
}

/** 地图数据 → 棋盘用的共享地图（cleared 由 createBoard 每边单独新建） */
function sharedMapOf(m) {
  return {
    cols: m.cols, rows: m.rows,
    ground: m.ground, grass: m.grass, road: m.road,
    enemySpawn: m.enemySpawn, kingPoint: m.kingPoint,
    path: m.path, raw: m.raw,
  };
}

/**
 * 两张画布按地图设置（每局地图可能不同，开局时重新调用）。
 * 逻辑尺寸 = 格数 × GRID.tile；真实像素按显示大小 × 设备像素比（见 fitCanvasResolution）。
 * 先按逻辑尺寸设一次，保证 CSS 能按正确宽高比排版。
 */
function setupCanvases() {
  renderState.sideways = isSidewaysMap(mapData);
  document.getElementById('board-zoom').classList.toggle('stacked', renderState.sideways);
  const size = viewSize(mapData);
  for (const side of ['me', 'opp']) {
    const canvas = document.getElementById(`canvas-${side}`);
    const logicalW = size.cols * GRID.tile, logicalH = size.rows * GRID.tile;
    canvas.width = logicalW;
    canvas.height = logicalH;
    canvas.style.width = canvas.style.height = '';     // 换地图后重新按容器计算显示尺寸
    canvases[side] = { canvas, ctx: canvas.getContext('2d'), logicalW, logicalH, scale: 1 };
  }
  renderState.tile = GRID.tile;
}

/**
 * 本局随机选一张地图并加载（匹配期间调用，加载与匹配动画同时进行）。
 * 重新扫描一次 board 目录：游戏开着时新放进去的地图也能被选到。
 */
async function pickRandomMap(sequence) {
  const list = await scanMaps();
  if (sequence !== matchSequence) return null;
  if (!list.length) throw new Error('地图清单为空');
  mapList = list;
  const n = mapList[Math.floor(Math.random() * mapList.length)];
  updateLoading(20, `准备地图 board${n}`);
  const map = await loadMap(n, progress => {
    if (sequence === matchSequence) updateLoading(20 + progress * 80, `加载地图 board${n}`);
  });
  if (sequence === matchSequence) updateLoading(100, '地图已就绪');
  console.log(`[main] 本局地图：board${n}`);
  return map;
}

/* ============================================================
 * 页面流程：开始页 → 匹配 → 对局 → 结算 → 开始页
 * ============================================================ */
function showView(id) {
  for (const v of ['start-screen', 'match-screen', 'game-view']) {
    document.getElementById(v).classList.toggle('hidden', v !== id);
  }
}

function setupStartScreen() {
  document.getElementById('btn-start').addEventListener('click', startMatching);
  document.getElementById('btn-cancel-match').addEventListener('click', cancelMatching);
  document.getElementById('btn-restart').addEventListener('click', () => {
    document.getElementById('game-over').classList.add('hidden');
    showStartScreen();
  });
  // 段位卡 → 段位明细
  const detail = document.getElementById('rank-detail');
  document.getElementById('rank-card').addEventListener('click', () => {
    renderRankDetail();
    detail.classList.remove('hidden');
  });
  // 点叉或点遮罩空白处关闭
  detail.addEventListener('click', (e) => {
    if (e.target === detail || e.target.id === 'rank-detail-close') detail.classList.add('hidden');
  });
}

/**
 * 段位明细：列出全部大段，每个大段展开其小段。
 *   已达到 = 当前段位之前的（含当前大段里已过的小段），当前所在小段高亮并显示星数，未达到置灰。
 *   至高小段太多（999），只显示前几段 + 当前段附近 + 「…」。
 */
function renderRankDetail() {
  const s = rank.getRank();
  const list = document.getElementById('rank-detail-list');
  const rows = RANKS.map((r, ti) => {
    const tierState = ti < s.tier ? 'done' : ti === s.tier ? 'cur' : 'todo';
    let subs = [];
    if (r.subs <= 8) {
      subs = Array.from({ length: r.subs }, (_, i) => i + 1);
    } else {
      // 至高：显示 1~3 段、当前段前后各 1 段、以及「…」
      const pick = new Set([1, 2, 3]);
      if (ti === s.tier) [s.sub - 1, s.sub, s.sub + 1].forEach(n => n >= 1 && n <= r.subs && pick.add(n));
      subs = [...pick].sort((a, b) => a - b);
    }
    const subHtml = [];
    subs.forEach((n, idx) => {
      if (idx > 0 && n - subs[idx - 1] > 1) subHtml.push('<span class="rd-sub gap">…</span>');
      const st = ti < s.tier || (ti === s.tier && n < s.sub) ? 'done'
               : ti === s.tier && n === s.sub ? 'cur' : 'todo';
      const stars = st === 'cur' ? `<i>${'★'.repeat(Math.min(3, s.stars))}${'☆'.repeat(Math.max(0, 3 - s.stars))}${s.stars > 3 ? ` +${s.stars - 3}` : ''}</i>`
                  : st === 'done' ? '<i>★★★</i>' : '<i>☆☆☆</i>';
      subHtml.push(`<span class="rd-sub ${st}">${n} 段${stars}</span>`);
    });
    if (r.subs > 8 && subs[subs.length - 1] < r.subs) subHtml.push(`<span class="rd-sub gap">… 至 ${r.subs} 段</span>`);
    const tag = tierState === 'done' ? '已达到' : tierState === 'cur' ? '当前' : '未达到';
    const prot = ti === 0 ? '最低段位'
      : r.protect > 0 ? `掉段保护 ${tierState === 'cur' ? `${s.protectLeft}/` : ''}${r.protect} 次` : '无掉段保护';
    return `
      <div class="rd-tier ${tierState}">
        <div class="rd-tier-head">
          <span class="rd-tier-name" style="--tc:${r.color}">${r.name}</span>
          <span class="rd-tier-meta">${r.subs} 个小段 · ${prot}</span>
          <span class="rd-tag ${tierState}">${tag}</span>
        </div>
        <div class="rd-subs">${subHtml.join('')}</div>
      </div>`;
  });
  list.innerHTML = rows.join('');
  // 打开时滚到当前大段
  requestAnimationFrame(() => list.querySelector('.rd-tier.cur')?.scrollIntoView({ block: 'center' }));
}

function showStartScreen() {
  game.phase = 'start';
  updateRankCard();
  showView('start-screen');
}

function setupCodex() {
  const overlay = document.getElementById('codex');
  const list = document.getElementById('codex-list');
  const panel = document.getElementById('codex-detail');
  let category = 'pieces';
  const entry = (kind, id, label, image, note = '') => {
    const unlocked = kind === 'enemies' || isCodexUnlocked(kind, id);
    return `<button type="button" class="codex-entry${unlocked ? '' : ' locked'}" data-kind="${kind}" data-id="${id}">
      ${image ? `<img src="${image}" alt="" />` : ''}<span>${label}</span><small>${note || (unlocked ? '已解锁' : '未解锁 · 可查看')}</small></button>`;
  };
  const refresh = () => {
    panel.classList.add('hidden');
    document.querySelectorAll('#codex-tabs button').forEach(btn => btn.classList.toggle('active', btn.dataset.category === category));
    if (category === 'pieces') {
      list.innerHTML = '<div class="codex-grid">' + Object.entries(PIECE_STATS).map(([type, spec]) =>
        entry('pieces', type, spec.name, pieceSrc('red'))).join('') + '</div>';
    } else if (category === 'spells') {
      list.innerHTML = codexSpellGroups().map(group => `<h3 class="codex-group-title">${group.name}</h3><div class="codex-grid">` +
        group.spells.map((s, i) => entry('spells', s.id, `${group.start + i}. ${s.name}`, '', `${s.tier}阶 · ${s.price}金币 · ${isCodexUnlocked('spells', s.id) ? '已解锁' : '未解锁'}`)).join('') + '</div>').join('');
    } else {
      list.innerHTML = '<div class="codex-grid">' + entry('enemies', 'normal', '寇', 'piece/green_character.png', '普通敌人') +
        Object.keys(BOSS.waves).map(wave => entry('enemies', wave, '王', 'piece/green_character.png', `第${wave}波Boss`)).join('') + '</div>';
    }
  };
  const close = () => { overlay.classList.add('hidden'); panel.classList.add('hidden'); document.getElementById('btn-codex').focus(); };
  document.getElementById('btn-codex').addEventListener('click', () => { refresh(); overlay.classList.remove('hidden'); document.getElementById('codex-close').focus(); });
  document.getElementById('codex-close').addEventListener('click', close);
  overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
  overlay.addEventListener('keydown', e => {
    if (e.key === 'Escape') { close(); return; }
    if (e.key !== 'Tab') return;
    const buttons = [...overlay.querySelectorAll('button')].filter(b => b.getClientRects().length);
    const first = buttons[0], last = buttons[buttons.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
  document.getElementById('codex-tabs').addEventListener('click', e => {
    const tab = e.target.closest('[data-category]'); if (!tab) return;
    category = tab.dataset.category; refresh();
  });
  panel.addEventListener('click', e => { if (e.target.closest('.detail-close')) panel.classList.add('hidden'); });
  list.addEventListener('click', e => {
    const button = e.target.closest('.codex-entry'); if (!button) return;
    const { kind, id } = button.dataset;
    if (kind === 'enemies') {
      const normal = id === 'normal';
      const wave = normal ? 1 : +id;
      const spec = normal ? enemyStatsForWave(1) : enemySpecForSpawn(wave, 0);
      const multipliers = BOSS.waves[wave];
      panel.innerHTML = `<div class="detail-head"><span class="detail-title">${normal ? '寇 · 普通敌人' : `王 · 第${wave}波Boss`}</span><button class="detail-close" type="button" aria-label="关闭详情">✕</button></div>
        <div class="detail-grid"><div>生命 <b>${displayNumber(spec.hp)}</b></div><div>移速 <b>${spec.speed.toFixed(4)}格/秒</b></div><div>击杀金币 <b>${GOLD_ON_KILL.default}</b></div><div>漏怪扣心 <b>1</b></div></div>
        <p>沿道路向帅移动。${normal ? '普通敌人每波成长。' : '本波首名敌人替换为王，不增加数量；尺寸为普通敌人的1.55倍，出生提示“王从天降”。受到伤害后减速10%，持续0.5秒；结束后恢复速度，并有0.5秒受击减速免疫。减速期间不续时，免疫期间仍正常受伤；与其他减速取较强效果，不叠乘。'}</p>
        <p>普通敌人基础生命${displayNumber(ENEMY.baseHp)}，每波线性增加${displayNumber(ENEMY.hpGrowPerWave)}；第11波起另逐波×1.10，第25波起再逐波×1.12。</p>
        <p>HP(N) = [${displayNumber(ENEMY.baseHp)} + ${displayNumber(ENEMY.hpGrowPerWave)}×(N−1)] × 1.10^max(0,N−10) × 1.12^max(0,N−24)</p>
        <p>移速每波+${ENEMY.speedGrowPerWave}格/秒：min(${ENEMY.maxSpeed}, ${ENEMY.baseSpeed}+${ENEMY.speedGrowPerWave}×(N−1))。</p>
        <p>每波数量${WAVES.firstWaveCount}+(N−1)×${WAVES.countGrowPerWave}。${normal ? '' : `本王在同波普通属性上：生命×${multipliers.hpMultiplier}，移速×${multipliers.speedMultiplier}。`}</p>`;
      panel.classList.remove('hidden');
    } else {
      const preview = createBoard('me', sharedMapOf(mapData));
      withBoard(preview, () => {
        if (kind === 'pieces') renderDetail({ id: 'codex-piece', kind: 'piece', type: id, color: 'red', c: 1, r: 2,
          level: 0, stage: 0, exp: 0, atkBonus: 0, flags: {}, bonds: [], activeBonds: [], cdLeft: 0 }, panel);
        else renderDetailCard({ source: 'native', type: 'spell', id, ...SPELL_BY_ID[id] }, panel);
      });
    }
    panel.scrollTop = 0;
    panel.scrollIntoView({ block: 'nearest' });
  });
}

let tutorialOriginalMap = null;
function setupTutorial() {
  const prompt = document.getElementById('tutorial-prompt');
  document.getElementById('tutorial-skip').addEventListener('click', () => {
    rememberTutorial('skipped');
    prompt.classList.add('hidden');
    showStartScreen();
    document.getElementById('btn-start').focus();
  });
  let entering = false;
  const enterTutorial = async () => {
    if (entering || tutorialActive()) return;
    entering = true;
    const buttons = ['tutorial-enter', 'btn-tutorial'].map(id => document.getElementById(id));
    buttons.forEach(button => { button.disabled = true; });
    try {
      const boards = await createTutorialBoards();
      prompt.classList.add('hidden');
      tutorialOriginalMap = mapData;
      clearDrag(); resetPointer(); pointer.down = false; closeDetail();
      resetBondPopups(); resetCinematic();
      game.boards = boards;
      game.cur = game.boards.me;
      game.floaters = [];
      mapData = game.cur.map;
      setupCanvases();
      document.getElementById('app').classList.add('tutorial-mode');
      document.getElementById('btn-surrender').textContent = '退出教程';
      document.getElementById('tutorial-panel').classList.remove('hidden');
      showView('game-view');
      game.phase = 'playing'; lastTime = 0;
      renderShop(); syncUI(); updateTutorialPanel();
    } catch (error) {
      console.error('[tutorial] board1 加载失败', error);
      document.getElementById('tutorial-load-error').textContent = '教学地图加载失败，请重试。';
      prompt.classList.remove('hidden');
    } finally {
      entering = false;
      buttons.forEach(button => { button.disabled = false; });
    }
  };
  document.getElementById('tutorial-enter').addEventListener('click', enterTutorial);
  document.getElementById('btn-tutorial').addEventListener('click', enterTutorial);
  document.getElementById('tutorial-next').addEventListener('click', () => {
    const t = game.boards.me.tutorial;
    if (!t || game.phase !== 'playing') return;
    if (t.finished) { exitTutorial('completed'); return; }
    if (t.failed) { exitTutorial('skipped'); return; }
    if (startTutorialDefense()) updateTutorialPanel();
  });
  if (shouldOfferTutorial()) {
    prompt.classList.remove('hidden');
    document.getElementById('tutorial-enter').focus();
    prompt.addEventListener('keydown', e => {
      if (e.key !== 'Tab') return;
      e.preventDefault();
      const skip = document.getElementById('tutorial-skip');
      const enter = document.getElementById('tutorial-enter');
      (document.activeElement === enter ? skip : enter).focus();
    });
  }
}
function updateTutorialPanel() {
  const t = game.boards.me.tutorial;
  if (!t) return;
  const info = tutorialInstruction();
  document.getElementById('tutorial-title').textContent = t.finished ? '教程完成！' : t.failed ? '教学防守结束' : info.title;
  document.getElementById('tutorial-text').textContent = t.finished
    ? '你已学会刷新、放置、融合、开垦、羁绊和法术！守住自己的帅，与对手比拼防守。教学不计段位，资源不会带入正式对局。'
    : t.failed ? '生命归零时防守失败。教学不扣段位，返回主页即可开始正式游戏。' : info.text + (t.defending ? ` 已击杀${game.boards.me.kills}名，当前${game.boards.me.gold}金币。` : '');
  document.getElementById('btn-refresh').classList.toggle('tutorial-refresh-target', t.step === -1);
  const next = document.getElementById('tutorial-next');
  next.classList.toggle('hidden', t.step !== TUTORIAL_DEFENSE_STEP || (t.defending && !t.finished && !t.failed));
  next.textContent = t.finished || t.failed ? '返回主页' : '开始防守';
}
function exitTutorial(choice) {
  rememberTutorial(choice);
  clearDrag(); resetPointer(); pointer.down = false; closeDetail();
  resetBondPopups(); resetCinematic();
  document.getElementById('pause-overlay').classList.add('hidden');
  document.getElementById('tutorial-panel').classList.add('hidden');
  document.getElementById('app').classList.remove('tutorial-mode');
  document.getElementById('btn-surrender').textContent = '认输';
  document.getElementById('btn-refresh').classList.remove('tutorial-refresh-target');
  mapData = tutorialOriginalMap; tutorialOriginalMap = null;
  resetBoards(sharedMapOf(mapData)); setupCanvases();
  lastTime = detailAccum = bondAccum = 0;
  renderShop(); showStartScreen();
}
function tickTutorial(dt) {
  const me = game.boards.me, t = me.tutorial;
  if (advanceTutorial(me)) { renderShop(); closeDetail(); updateTutorialPanel(); }
  if (t.defending && !t.finished && !t.failed) {
    const enemy = nextTutorialEnemy(me, dt);
    if (enemy) { me.enemies.push(enemy); me.spawned++; }
    withBoard(me, () => waveUpdate(dt));
    withBoard(me, rescanBonds);
    if (me.dead) t.failed = true;
    else if (t.spawned === 3 && me.enemies.length === 0) t.finished = true;
    updateTutorialPanel();
  }
  for (const f of game.floaters) f.age += dt;
  game.floaters = game.floaters.filter(f => f.age < f.life);
  syncUI(); refreshDetailLive();
}

/** 开始页段位卡 */
function updateRankCard() {
  refreshSaveStatus();
  const s = rank.getRank();
  const nameEl = document.getElementById('rank-name');
  nameEl.textContent = rank.label(s);
  nameEl.style.color = '';            // 统一用样式表的墨色
  document.getElementById('rank-stars').textContent = rank.starText(s);
  const prot = s.tier > 0 && RANKS[s.tier].protect > 0 ? ` · 掉段保护 ${s.protectLeft}/${RANKS[s.tier].protect}` : '';
  document.getElementById('rank-extra').textContent = `胜 ${s.wins} · 负 ${s.losses}${prot}`;
}

/* ---------- 假匹配：随机 0~2 秒（同时加载本局随机地图） ---------- */
let matchTimer = null;
let mapReady = null;
let mapLoadDone = false;
let matchSequence = 0;
function startMatching() {
  const sequence = ++matchSequence;
  game.phase = 'matching';
  showView('match-screen');
  mapLoadDone = false;
  mapReady = pickRandomMap(sequence).then(map => {
    if (sequence === matchSequence) mapLoadDone = true;
    return { map };
  }, error => ({ error }));
  const s = rank.getRank();
  document.getElementById('match-my-rank').textContent = rank.label(s);
  document.getElementById('match-opp-name').textContent = '？？？';
  document.getElementById('match-opp-rank').textContent = '';
  document.getElementById('match-status').textContent = '正在匹配对手…';
  const avatar = document.getElementById('match-opp-avatar');
  avatar.classList.add('searching');
  avatar.textContent = '';
  document.getElementById('btn-cancel-match').classList.remove('hidden');

  const total = MATCH.minSec + Math.random() * (MATCH.maxSec - MATCH.minSec);
  const t0 = performance.now();
  const timerEl = document.getElementById('match-timer');
  clearInterval(matchTimer);
  matchTimer = setInterval(() => {
    const el = (performance.now() - t0) / 1000;
    timerEl.textContent = `${el.toFixed(1)}s`;
    if (el >= total) {
      clearInterval(matchTimer);
      matchFound(sequence, mapReady);
    }
  }, 50);
}

function cancelMatching() {
  matchSequence++;
  clearInterval(matchTimer);
  showStartScreen();
}

function matchFound(sequence, ready) {
  match.name = randomName();
  // 对手段位：与玩家同段（同大段内小段随机浮动）
  const s = rank.getRank();
  const sub = Math.max(1, Math.min(RANKS[s.tier].subs, s.sub + Math.floor(Math.random() * 3) - 1));
  match.rankText = `${RANKS[s.tier].name} ${sub} 段`;

  document.getElementById('match-status').textContent = '匹配成功！';
  document.getElementById('match-opp-name').textContent = match.name;
  document.getElementById('match-opp-rank').textContent = match.rankText;
  const avatar = document.getElementById('match-opp-avatar');
  avatar.classList.remove('searching');
  avatar.textContent = '?';                    // 头像素材暂空
  document.getElementById('btn-cancel-match').classList.add('hidden');

  setTimeout(async () => {
    if (game.phase !== 'matching' || sequence !== matchSequence) return;
    if (!mapLoadDone) showLoading('正在加载本局地图');
    const { map, error } = await ready;
    if (game.phase !== 'matching' || sequence !== matchSequence) return;
    if (error) {
      loadingError(error, () => { hideLoading(); showStartScreen(); }, '返回主页重试');
      return;
    }
    mapData = map;
    hideLoading();
    if (BONUS_SELECT_ENABLED) showBonusSelect();
    else beginBattle();
  }, MATCH.revealSec * 1000);
}

/** 进入对局：按本局地图重建两边棋盘，双方同时开局 */
function beginBattle() {
  setupCanvases();
  resetBoards(sharedMapOf(mapData));
  applyChosenBonuses();          // 开局增益（当前已关闭；开启时我方选择、对方随机）
  resetBondPopups();
  clearDrag();
  closeDetail();
  overShown = false;
  resetCinematic();
  game._matchStarted = Date.now();

  for (const b of [game.boards.me, game.boards.opp]) {
    withBoard(b, () => { startGame(); rescanBonds(); });
  }
  resetSharedWaves();
  setupAI(rank.getRank());

  document.getElementById('opp-name').textContent = match.name || '对手';
  showView('game-view');
  game.phase = 'playing';
  lastTime = 0;
  renderShop();
  syncUI();
}

/* ============================================================
 * 主循环（两边棋盘同步推进）
 * ============================================================ */
let lastTime = 0;
let detailAccum = 0;          // 详情面板刷新节流累加器
let bondAccum = 0;            // 羁绊重扫节流累加器
function loop(ts) {
  const t = ts / 1000;
  const rawDt = lastTime ? Math.min(t - lastTime, 0.1) : 0;   // 限制单帧步长，防止切页跳帧
  lastTime = t;

  if (game.phase === 'playing' && tutorialActive()) {
    tickTutorial(rawDt);
  } else if (game.phase === 'playing') {
    const dt = rawDt * debug.speed;
    const { me, opp } = game.boards;

    updateSharedWaves(dt, [me, opp]);          // 双方同时出怪、同样数量
    withBoard(me, () => waveUpdate(dt));
    withBoard(opp, () => waveUpdate(dt));
    withBoard(opp, () => aiTick(dt, effectiveLives(me)));
    if (debug.auto != null) withBoard(me, () => aiTick(dt, effectiveLives(opp), debug.auto));
    for (const floater of game.floaters) floater.age += dt;
    game.floaters = game.floaters.filter(f => f.age < f.life);

    // 定期重扫羁绊：棋子升级达到羁绊条件时也能立刻激活
    bondAccum += rawDt;
    if (bondAccum >= 0.4) {
      bondAccum = 0;
      withBoard(me, rescanBonds);
      withBoard(opp, rescanBonds);
    }

    syncUI();
    detailAccum += rawDt;
    if (detailAccum >= 0.2) { detailAccum = 0; refreshDetailLive(); }

    checkGameEnd();
  } else if (game.phase === 'dying') {
    updateDeathCinematic(rawDt);
  }

  if (game.phase !== 'start' && game.phase !== 'matching') renderBoards(t);
  requestAnimationFrame(loop);
}

/** 渲染两张棋盘（对方上下翻转、只读） */
function renderBoards(t) {
  for (const side of ['me', 'opp']) {
    if (side === 'opp' && tutorialActive()) continue;
    const cv = canvases[side];
    fitCanvasResolution(cv);
    renderState.canvas = cv.canvas;
    renderState.ctx = cv.ctx;
    renderState.flip = side === 'opp';
    renderState.readonly = side === 'opp';
    // 逻辑坐标仍是「1 格 = GRID.tile」，用 setTransform 放大到真实像素 → 文字 / 贴图清晰不糊
    cv.ctx.setTransform(cv.scale, 0, 0, cv.scale, 0, 0);
    withBoard(game.boards[side], () => render(t));
    cv.ctx.setTransform(1, 0, 0, 1, 0, 0);
  }
  renderState.flip = false;
  renderState.readonly = false;
  if (tutorialActive()) positionTutorialPanel();
  renderDragLayer();
}

/** 提示面板按画布的真实显示比例定位，始终留在 board1 的安全草地区。 */
function positionTutorialPanel() {
  const canvas = canvases.me.canvas;
  const rect = canvas.getBoundingClientRect();
  const wrap = canvas.parentElement.getBoundingClientRect();
  const region = TUTORIAL_PANEL_RECT;
  const scale = rect.width / canvases.me.logicalW;
  const panel = document.getElementById('tutorial-panel');
  panel.style.left = `${rect.left - wrap.left + region.c * GRID.tile * scale}px`;
  panel.style.top = `${rect.top - wrap.top + region.r * GRID.tile * scale}px`;
  panel.style.width = `${region.cols * GRID.tile}px`;
  panel.style.height = `${region.rows * GRID.tile}px`;
  panel.style.transform = `scale(${scale})`;
}

/**
 * 让画布清晰：按外层格子大小算出显示尺寸（保持地图宽高比），
 * 真实像素 = 显示尺寸 × 设备像素比（高清屏 / 手机也清晰）。
 * 显示尺寸只取决于外层容器，不随画布像素变化 → 不会来回抖动。
 * cv.scale 为「逻辑像素 → 真实像素」的倍率，供 setTransform 使用。
 */
function fitCanvasResolution(cv) {
  const wrap = cv.canvas.parentElement;
  if (!wrap.clientWidth || !wrap.clientHeight) return;
  const aspect = cv.logicalW / cv.logicalH;
  const dispW = Math.floor(Math.min(wrap.clientWidth, wrap.clientHeight * aspect));
  const dispH = Math.floor(dispW / aspect);
  if (cv.dispW !== dispW || cv.dispH !== dispH) {
    cv.canvas.style.width = `${dispW}px`;
    cv.canvas.style.height = `${dispH}px`;
    cv.dispW = dispW; cv.dispH = dispH;
  }
  const dpr = window.devicePixelRatio || 1;
  const scale = (dispW * dpr) / cv.logicalW;
  const w = Math.round(cv.logicalW * scale), h = Math.round(cv.logicalH * scale);
  if (cv.canvas.width !== w || cv.canvas.height !== h) {
    cv.canvas.width = w;
    cv.canvas.height = h;
  }
  cv.scale = scale;
}

/**
 * 拖拽层：全舞台覆盖画布，画跟随指针的棋子 / 卡牌幽灵。
 * 坐标按「我方棋盘的显示缩放」换算，幽灵大小与棋盘上的棋子一致。
 */
const dragPos = { clientX: 0, clientY: 0 };
function renderDragLayer() {
  const layer = document.getElementById('drag-layer');
  const ctx = layer.getContext('2d');
  const rect = layer.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  const w = Math.round(rect.width * dpr), h = Math.round(rect.height * dpr);
  if (layer.width !== w || layer.height !== h) { layer.width = w; layer.height = h; }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, w, h);
  if (!game.drag.active) return;

  // 棋盘逻辑像素 → 屏幕像素的缩放（与我方棋盘显示大小一致）
  const me = canvases.me;
  const k = me.canvas.getBoundingClientRect().width / me.logicalW;
  ctx.setTransform(dpr * k, 0, 0, dpr * k, 0, 0);
  const x = (dragPos.clientX - rect.left) / k;
  const y = (dragPos.clientY - rect.top) / k;
  renderDragGhost(ctx, x, y);
}

/** 胜负判定：一方红心归零即结束；同时归零为平局（先播阵亡特写，再弹结算） */
function checkGameEnd() {
  const { me, opp } = game.boards;
  const result = experimentalResult(me, opp);
  if (result) startDeathCinematic(result);
}

/* ============================================================
 * 阵亡特写：全景 → 缓慢推近到阵亡的帅（帅颤抖）→ 头顶出现「我投降」→ 弹出结算
 * 只是镜头动画：画面整体（#board-zoom）做 CSS 缩放平移，游戏逻辑此时已停止。
 * ============================================================ */
const CINEMA = {
  zoomSec: 2.2,          // 推镜时长
  holdSec: 1.6,          // 推到位、「我投降」出现后停留多久再弹结算
  kingFrac: 0.34,        // 特写时帅占画面宽度的比例
};
const cinema = { t: 0, result: null, side: null, shown: false };

/**
 * @param {'win'|'lose'|'draw'} result
 * 输：特写我方的帅；赢：特写对方的帅；平局：特写我方的帅。
 */
function startDeathCinematic(result) {
  if (game.phase === 'dying' || overShown) return;
  cinema.result = result;
  cinema.side = result === 'win' ? 'opp' : 'me';
  game.boards[cinema.side].dead = true;          // 作弊 / 认输直接结算时也让帅颤抖
  cinema.t = 0;
  cinema.shown = false;
  game.phase = 'dying';
  clearDrag();
  resetPointer();
  pointer.down = false;
  closeDetail();
  document.getElementById('pause-overlay').classList.add('hidden');
}

/** 阵亡的帅在缩放层里的坐标（未缩放的布局像素）与一格的显示大小 */
function deadKingPoint() {
  const cv = canvases[cinema.side];
  const board = game.boards[cinema.side];
  const k = board.king;
  const wrap = cv.canvas.parentElement;
  const tileDisp = cv.dispW / viewSize(board.map).cols;
  const point = boardToView(k?.fx ?? k?.c ?? 0, k?.fy ?? k?.r ?? 0, board.map, isSidewaysMap(board.map), cinema.side === 'opp');
  // 帅的位置始终按未缩放的容器坐标计算，包含横置与对手翻转。
  return {
    x: wrap.offsetLeft + (wrap.clientWidth - cv.dispW) / 2 + (point.c + 0.5) * tileDisp,
    y: wrap.offsetTop + (wrap.clientHeight - cv.dispH) / 2 + (point.r + 0.5) * tileDisp,
    tile: tileDisp,
  };
}

function updateDeathCinematic(dt) {
  cinema.t += dt;
  const zoomEl = document.getElementById('board-zoom');
  const p = deadKingPoint();
  const W = zoomEl.clientWidth, H = zoomEl.clientHeight;

  // 缓入缓出的推镜：从全景（1 倍）推到「帅占画面 kingFrac 宽」
  const q = Math.min(1, cinema.t / CINEMA.zoomSec);
  const ease = q < 0.5 ? 2 * q * q : 1 - Math.pow(-2 * q + 2, 2) / 2;
  const targetScale = Math.max(1.5, Math.min(7, (W * CINEMA.kingFrac) / p.tile));
  const s = 1 + (targetScale - 1) * ease;
  // 帅（以及头顶的字）对准画面中心略偏下，给「我投降」留出上方空间
  const tx = (W / 2 - p.x * targetScale) * ease;
  const ty = (H * 0.56 - p.y * targetScale) * ease;
  zoomEl.style.transform = `translate(${tx}px, ${ty}px) scale(${s})`;

  // 推到位 → 帅头顶出现「我投降」
  const txt = document.getElementById('surrender-text');
  if (q >= 1 && !cinema.shown) {
    cinema.shown = true;
    txt.style.left = `${p.x}px`;
    txt.style.top = `${p.y - p.tile * 0.55}px`;
    txt.style.fontSize = `${Math.max(6, p.tile * 0.34)}px`;
    txt.classList.remove('hidden');
    requestAnimationFrame(() => txt.classList.add('show'));
  }

  if (q >= 1 && cinema.t >= CINEMA.zoomSec + CINEMA.holdSec) finishGame(cinema.result);
}

/** 新开一局：镜头复位 */
function resetCinematic() {
  const zoomEl = document.getElementById('board-zoom');
  zoomEl.style.transform = '';
  const txt = document.getElementById('surrender-text');
  txt.classList.remove('show');
  txt.classList.add('hidden');
}

/** 若详情面板正开着，重新渲染当前选中棋子的最新数据（我方或对方） */
function refreshDetailLive() {
  const id = game.selectedPieceId;
  if (!id) return;
  for (const side of ['me', 'opp']) {
    const b = game.boards[side];
    const p = b.pieces.find(x => x.id === id);
    if (p) { withBoard(b, () => renderDetail(p)); return; }
  }
  // 我方商店里的棋子卡
  const card = game.detailCardSlot >= 0 ? game.boards.me.shopSlots[game.detailCardSlot] : null;
  const sp = card && shop.pieceDataOfCard(card);
  if (sp && sp.id === id) { renderDetail(sp); return; }
  closeDetail();             // 选中的棋子已不存在（被融合 / 进化）
}

/* ============================================================
 * UI 同步（金币 / 刷新 / 波次 / 红心 / 按钮态 / 卡牌价格色）—— 默认作用于我方
 * ============================================================ */
function syncUI() {
  const me = game.boards.me, opp = game.boards.opp;
  document.getElementById('gold-num').textContent = me.gold;
  const cost = currentRefreshCost();
  document.getElementById('refresh-cost').textContent = cost === 0 ? '免费' : cost;
  document.getElementById('refresh-count').textContent = `刷新 ${me.totalShopRefreshCount}`;
  const n = Math.max(me.wave, opp.wave);
  document.getElementById('wave-label').textContent = tutorialActive() ? '新手教程' : n >= 25 ? `决胜 · 第 ${n} 波` : `实验 · 第 ${n} 波`;
  document.getElementById('wave-timer').textContent = tutorialActive() ? (me.tutorial.defending ? `教学敌人 ${me.tutorial.spawned}/3` : '按提示操作') : waveCountdownText();

  renderHearts('lives', me);
  renderHearts('opp-lives', opp);

  const oppGold = document.getElementById('opp-gold');
  oppGold.classList.toggle('hidden', !debug.seeShop);
  oppGold.querySelector('b').textContent = opp.gold;

  const btn = document.getElementById('btn-refresh');
  btn.disabled = game.phase !== 'playing' || (!tutorialActive() && me.gold < cost);
  btn.setAttribute('aria-disabled', String(tutorialActive() && me.tutorial.step !== -1));

  const pauseBtn = document.getElementById('btn-pause');
  pauseBtn.disabled = game.phase !== 'playing' && game.phase !== 'paused';

  refreshPriceColors();
  if (debug.seeShop) renderOppShop();
}

/**
 * 顶栏出怪倒计时（读共享波次状态）：
 *   开局准备 / 波间倒计时 → 「第 N 波 X 秒后」；出怪中 → 「出怪中 已出/总数」；
 *   一波出完、双方都还在清怪 → 「清怪中」（任一方清完才开始倒计时）。
 */
function waveCountdownText() {
  const w = sharedWaves;
  const { me, opp } = game.boards;
  if ([me, opp].some(b => b.king && !b.king.arrived)) return '帅入场中';
  if (w.spawnedInWave < w.countInWave) {
    if (w.spawnedInWave === 0 && w.timer > 0) return `第 ${w.wave} 波 ${Math.ceil(w.timer)} 秒后`;
    return `出怪中 ${w.spawnedInWave}/${w.countInWave}`;
  }
  if (!w.countdown) return '清怪中';
  return `第 ${w.waveToSpawn} 波 ${Math.ceil(Math.max(0, w.timer))} 秒后`;
}

/** 永久红心与临时蓝心分开显示，计时跟随棋盘游戏时间。 */
function renderHearts(id, board) {
  const el = document.getElementById(id);
  const current = Math.max(0, Math.min(KING.hp, Number(board.lives) || 0));
  const shields = (board.temporaryLives || []).filter(e => e.amount > 0 && e.until > (board.gameTime || 0));
  const temporary = shields.reduce((n, e) => n + e.amount, 0);
  const seconds = temporary ? Math.ceil(Math.min(...shields.map(e => e.until)) - (board.gameTime || 0)) : 0;
  const key = `${current}:${temporary}:${seconds}`;
  if (el.dataset.lives !== key) {
    el.replaceChildren();
    for (let i = 0; i < KING.hp + temporary; i++) {
      const h = document.createElement('span');
      h.className = i >= KING.hp ? 'heart temporary' : `heart${i >= current ? ' off' : ''}`;
      h.textContent = '♥';
      el.appendChild(h);
    }
    if (temporary) {
      const timer = document.createElement('span');
      timer.className = 'temporary-life-timer';
      timer.textContent = `${seconds}秒`;
      el.appendChild(timer);
    }
    el.dataset.lives = key;
    el.setAttribute('aria-label', `剩余${current}颗红心${temporary ? `，${temporary}颗临时心，${seconds}秒后到期` : ''}`);
  }
}

/** 调试：显示对手商店（作弊码 seeshop） */
function renderOppShop() {
  const el = document.getElementById('opp-shop');
  const lines = game.boards.opp.shopSlots.map((c, i) => {
    if (!c) return `${i + 1}. （空）`;
    if (c.type === 'spell') return `${i + 1}. 法术·${c.name}（${c.price}）`;
    if (c.type === 'shovel') return `${i + 1}. 铲子`;
    const p = withBoard(game.boards.opp, () => shop.pieceDataOfCard(c));
    return `${i + 1}. ${p.color === 'red' ? '红' : '黑'}${pieceDisplayName(p)} Lv${p.level} ${p.stage || 0}阶`;
  });
  el.textContent = `对手商店\n${lines.join('\n')}`;
  el.style.whiteSpace = 'pre';
}

/* ============================================================
 * 暂停 / 认输
 * ============================================================ */
function setupPause() {
  const pauseBtn = document.getElementById('btn-pause');
  const resumeBtn = document.getElementById('btn-resume');

  const setPaused = (paused) => {
    if (paused) {
      if (game.phase !== 'playing') return;
      game.phase = 'paused';
      clearDrag();
      resetPointer();
      pointer.down = false;
      renderShop();
      document.getElementById('pause-overlay').classList.remove('hidden');
    } else {
      if (game.phase !== 'paused') return;
      game.phase = 'playing';
      document.getElementById('pause-overlay').classList.add('hidden');
      lastTime = 0;     // 重置帧时间，避免暂停期间累计 dt 造成跳帧
    }
    syncUI();
  };

  pauseBtn.addEventListener('click', () => setPaused(game.phase !== 'paused'));
  resumeBtn.addEventListener('click', () => setPaused(false));
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') setPaused(true);
  });
  document.getElementById('btn-surrender').addEventListener('click', () => {
    document.getElementById('pause-overlay').classList.add('hidden');
    if (tutorialActive()) exitTutorial('skipped');
    else startDeathCinematic('lose');
  });
}

/** 金币浮动提示（只为我方显示） */
function onGoldChange(delta) {
  if (game.phase !== 'playing' && game.phase !== 'paused') return;
  const label = document.getElementById('gold-label');
  const rect = label.getBoundingClientRect();
  const el = document.createElement('span');
  el.className = 'gold-float' + (delta >= 0 ? ' plus' : ' minus');
  el.textContent = (delta >= 0 ? '+' : '') + delta;
  el.style.left = `${rect.right + 4}px`;
  el.style.top = `${rect.top}px`;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), MISC.goldFloatMs);
}

/* ============================================================
 * 作弊码
 * ============================================================ */
function setupCheats() {
  setCheatHooks({
    inGame: () => game.phase === 'playing' || game.phase === 'paused' || game.phase === 'dying',
    finish: (r) => {
      document.getElementById('pause-overlay').classList.add('hidden');
      startDeathCinematic(r);
    },
    refreshUI: () => {
      updateRankCard();
      if (game.phase === 'playing' || game.phase === 'paused') { renderShop(); syncUI(); }
    },
    setSpeed: (s) => { debug.speed = s; },
    toggleAuto: (tier) => {
      debug.auto = tier != null ? tier : (debug.auto == null ? 4 : null);
      return debug.auto;
    },
    toggleSeeShop: () => {
      debug.seeShop = !debug.seeShop;
      document.getElementById('opp-shop').classList.toggle('hidden', !debug.seeShop);
      return debug.seeShop;
    },
    jumpWave: (n) => jumpToWave(n, [game.boards.me, game.boards.opp]),
  });

  for (const where of ['start', 'pause']) {
    const input = document.getElementById(`cheat-input-${where}`);
    const out = document.getElementById(`cheat-out-${where}`);
    input.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key !== 'Enter' || tutorialActive()) return;
      const res = withBoard(game.boards.me, () => runCheat(input.value));
      out.textContent = res.msg;
      out.classList.toggle('err', !res.ok);
      if (res.ok) input.value = '';
    });
    // 输入框里的指针事件不要触发「点空白关详情」等逻辑
    input.addEventListener('pointerdown', (e) => e.stopPropagation());
  }
}

/* ============================================================
 * 商店渲染
 * ============================================================ */
function setupShop() {
  const grid = document.getElementById('shop-grid');
  grid.innerHTML = '';
  for (let i = 0; i < SHOP.slotCount; i++) {
    const slot = document.createElement('div');
    slot.className = 'shop-slot';
    slot.dataset.index = i;
    grid.appendChild(slot);
  }

  document.getElementById('btn-refresh').addEventListener('click', () => {
    if (game.phase !== 'playing' || pointer.down) return;
    const res = act.refresh();
    if (!res.ok) flashHint(res.reason);
    renderShop();
    syncUI();
  });

  renderShop();
}

/** 重绘商店卡位 */
function renderShop() {
  const grid = document.getElementById('shop-grid');
  const d = game.drag;
  // 正在从商店拖拽中的源卡位：显示为空（棋子被「拿在手上」）
  const draggingSlot = (d.active && d.from === 'shop') ? d.slotIndex : -1;

  for (let i = 0; i < SHOP.slotCount; i++) {
    const slotEl = grid.children[i];
    const card = game.shopSlots[i];
    const isEmpty = !card || i === draggingSlot;
    slotEl.classList.toggle('empty', isEmpty);
    if (isEmpty) {
      if (slotEl.firstChild) slotEl.replaceChildren();
      continue;
    }

    let cardEl = slotEl.firstElementChild;
    if (!cardEl) {
      cardEl = document.createElement('div');
      cardEl.dataset.slot = i;
      slotEl.appendChild(cardEl);
    }
    const classes = ['shop-card'];
    // 详情高亮单独更新，不重建未变化的图片或重启法术动画。
    if (game.detailCardSlot === i) classes.push('selected');
    let html = '';

    if (card.source === 'fromBoard') {
      // 场上棋子放回：显示棋子完整信息（等级/融合计数/经验条），不显示价格
      classes.push('from-board');
      html = pieceCardInner(card.piece);
    } else if (card.type === 'piece') {
      html = `
        ${pieceCardInner(shop.pieceDataOfCard(card))}
        <span class="card-price" data-price="1">${priceOf(card)}</span>`;
    } else if (card.type === 'shovel') {
      html = `
        <img class="card-img" src="${shovelSrc()}" alt="铲子" />
        <span class="card-name">铲子</span>
        <span class="card-price" data-price="1">${priceOf(card)}</span>`;
    } else if (card.type === 'spell') {
      const spec = SPELL_BY_ID[card.id];
      classes.push('spell-card', `spell-t${card.tier}`);
      html = `
        <span class="card-tier tier-${card.tier}">${card.tier}阶</span>
        <span class="card-name spell-name">${spec?.name || card.name}</span>
        <span class="card-desc">${spec?.desc || ''}</span>
        <span class="card-price" data-price="1">${priceOf(card)}</span>`;
    }
    const className = classes.join(' ');
    if (cardEl.className !== className) cardEl.className = className;
    if (cardEl._content !== html) {
      cardEl.innerHTML = html;
      cardEl._content = html;
    }
  }
  refreshPriceColors();
}

/**
 * 商店棋子卡内容：与场上棋子一致的固定布局 ——
 * 顶部 Lv、中间名称（叠在棋子图上）、底部融合计数、最底细经验条。
 */
function pieceCardInner(p) {
  if (!p) return '';
  const name = pieceDisplayName(p);
  const cap = LEVEL.naturalCap[p.type] ?? LEVEL.hardCap;
  const atCap = (p.level || 0) >= cap;
  const expNeed = experienceRequired(p.level || 0);
  const ratio = atCap ? 1 : Math.min(1, (p.exp || 0) / (expNeed || 1));

  return `
    <div class="piece-card-fig">
      <img class="card-img piece-img" src="${pieceSrc(p.color)}" alt="棋子" />
      <span class="piece-lv">Lv.${p.level ?? 0}</span>
      <span class="piece-name-center">${name}</span>
      <span class="piece-merge">${p.stage || 0}阶</span>
      <span class="piece-expbar"><i style="width:${(ratio * 100).toFixed(0)}%"></i></span>
      ${atCap ? '<span class="piece-cap">上限</span>' : ''}
    </div>`;
}

const priceOf = (card) => shop.cardPrice(card) ?? '';
const pieceSrc = (color) => `piece/${color === 'red' ? 'red_character' : 'black_character'}.png`;
const shovelSrc = () => 'piece/genericItem_color_022.png';

/** 价格文字颜色：金币足够白色，不足红色；fromBoard 无价格 */
function refreshPriceColors() {
  document.querySelectorAll('#shop-grid .card-price').forEach(el => {
    const slotIdx = Number(el.closest('.shop-card')?.dataset.slot);
    const card = game.shopSlots[slotIdx];
    if (!card || card.source !== 'native') { el.textContent = ''; return; }
    const price = shop.cardPrice(card);
    el.classList.toggle('poor', game.gold < price);
  });
}

/* ============================================================
 * 输入交互：拖拽 + 点击
 * ============================================================ */

/** 拖拽会话（用于区分「点击」与「拖动」） */
const pointer = {
  down: false,
  moved: false,
  startX: 0, startY: 0,
  downSide: null,        // 'me' | 'opp'：按下时在哪张棋盘上
  downCell: null,        // 点击地图时的落点 {c,r}
  fromPiece: null,
  fromSlot: -1,
  downTime: 0,
  pointerId: null,
  captureEl: null,
};

function setupInput() {
  // 我方画布：可点击、可拖拽
  canvases.me.canvas.addEventListener('pointerdown', (ev) => {
    if (game.phase !== 'playing' || pointer.down) return;
    const cell = eventToCell(ev, 'me');
    beginPointer(ev, 'me', cell);
    const occ = cell ? pieceAt(cell.c, cell.r) : null;   // 当前棋盘默认就是我方
    // 帅（king）不可点击、不可拖动：只允许「普通棋子 piece」
    pointer.fromPiece = (occ && occ.kind === 'piece') ? occ : null;
  });

  // 对方画布：只能点击查看，不能拖拽
  canvases.opp.canvas.addEventListener('pointerdown', (ev) => {
    if (game.phase !== 'playing' || pointer.down) return;
    beginPointer(ev, 'opp', eventToCell(ev, 'opp'));
  });

  // 商店卡牌 pointerdown：仅为点击/拖拽会话记录起点
  document.getElementById('shop-grid').addEventListener('pointerdown', (ev) => {
    if (game.phase !== 'playing' || pointer.down) return;
    const cardEl = ev.target.closest('.shop-card');
    if (!cardEl) return;
    const idx = Number(cardEl.dataset.slot);
    if (!game.shopSlots[idx]) return;
    beginPointer(ev, null, null);
    pointer.fromSlot = idx;
  });

  window.addEventListener('pointermove', onPointerMove);
  window.addEventListener('pointerup', onPointerUp);
  window.addEventListener('pointercancel', ev => {
    if (ev.pointerId !== pointer.pointerId) return;
    clearDrag(); renderShop(); resetPointer(); pointer.down = false;
  });

}

function beginPointer(ev, side, cell) {
  pointer.down = true;
  pointer.moved = false;
  pointer.startX = ev.clientX; pointer.startY = ev.clientY;
  pointer.downSide = side;
  pointer.downCell = cell;
  pointer.fromPiece = null;
  pointer.fromSlot = -1;
  pointer.downTime = performance.now();
  pointer.pointerId = ev.pointerId;
  pointer.captureEl = side ? canvases[side].canvas : document.getElementById('shop-grid');
  try { pointer.captureEl.setPointerCapture(ev.pointerId); } catch { /* 合成测试事件不持有真实指针 */ }
}

function onPointerMove(ev) {
  if (!pointer.down || ev.pointerId !== pointer.pointerId || game.phase !== 'playing') return;
  // 对方棋盘上按下：不允许拖拽
  if (pointer.downSide === 'opp') return;

  const dist = Math.hypot(ev.clientX - pointer.startX, ev.clientY - pointer.startY);
  if (!pointer.moved && dist > 6) {
    if (!pointer.fromPiece && pointer.fromSlot < 0) return;   // 空地上拖动：什么也不做
    pointer.moved = true;
    beginDrag(ev);
  }
  if (!pointer.moved) return;

  updateDrag(ev);
}

function onPointerUp(ev) {
  if (!pointer.down || ev.pointerId !== pointer.pointerId) return;
  pointer.down = false;

  // ---------- 未移动 → 视为「点击」 ----------
  if (!pointer.moved) {
    if (pointer.fromSlot >= 0) {
      handleCardClick(pointer.fromSlot);
    } else if (pointer.downCell) {
      handleMapClick(pointer.downSide, pointer.downCell.c, pointer.downCell.r);
    } else {
      closeDetail();
    }
    resetPointer();
    return;
  }

  // ---------- 移动了 → 拖拽结算 ----------
  updateDrag(ev);             // 手机抬手时再取一次最终落点，避免最后一帧移动漏报
  endDrag(ev);
  resetPointer();
}

function resetPointer() {
  try {
    if (pointer.captureEl?.hasPointerCapture(pointer.pointerId)) pointer.captureEl.releasePointerCapture(pointer.pointerId);
  } catch { /* 指针可能已被浏览器取消 */ }
  pointer.pointerId = null;
  pointer.captureEl = null;
  pointer.fromPiece = null;
  pointer.fromSlot = -1;
  pointer.downCell = null;
  pointer.downSide = null;
  pointer.moved = false;
}

/* ============================================================
 * 点击交互（只负责查看信息；放置 / 融合 / 换位全部走拖拽）
 * ============================================================ */

/** 点击商店卡牌：弹出该卡信息（卡位高亮）；再点同一张关闭 */
function handleCardClick(slotIndex) {
  const card = game.shopSlots[slotIndex];
  if (!card) { closeDetail(); return; }
  if (game.detailCardSlot === slotIndex) { closeDetail(); return; }
  closeDetail();
  const p = shop.pieceDataOfCard(card);
  if (p) handlePieceClick(p);
  else renderDetailCard(card);
  game.detailCardSlot = slotIndex;
  renderShop();
}

/** 点击棋盘：点棋子 → 弹出 / 关闭详情（我方或对方）；点其它任何地方 → 关闭详情 */
function handleMapClick(side, c, r) {
  const board = game.boards[side];
  const occ = withBoard(board, () => pieceAt(c, r));
  if (occ && occ.kind === 'piece') {
    if (game.detailCardSlot >= 0) closeDetail();   // 从商店卡信息切换到场上棋子
    withBoard(board, () => handlePieceClick(occ));
    return;
  }
  closeDetail();
}

/** 开始拖拽（只可能是我方棋子 / 我方商店卡） */
function beginDrag(ev) {
  closeDetail();             // 开始拖拽即关闭详情，避免卡位变化后高亮错位
  const d = game.drag;
  d.active = true;

  if (pointer.fromPiece) {
    d.from = 'board';
    d.piece = pointer.fromPiece;
    d.card = null;
    d.slotIndex = -1;
  } else if (pointer.fromSlot >= 0) {
    d.from = 'shop';
    d.slotIndex = pointer.fromSlot;
    d.card = game.shopSlots[pointer.fromSlot];
    // 统一用 pieceDataOfCard 取棋子数据，让原生兵卡拖拽时也能显示棋子跟随鼠标
    d.piece = shop.pieceDataOfCard(d.card);
  }
  renderShop();
  updateDrag(ev);
}

/** 拖拽中：更新幽灵位置与悬停目标（只在我方棋盘 / 我方商店上判定） */
function updateDrag(ev) {
  const d = game.drag;
  if (!d.active) return;
  dragPos.clientX = ev.clientX;
  dragPos.clientY = ev.clientY;

  // 我方棋盘逻辑坐标（按显示大小换算）
  const me = canvases.me;
  const rect = me.canvas.getBoundingClientRect();
  d.x = (ev.clientX - rect.left) * (me.logicalW / rect.width);
  d.y = (ev.clientY - rect.top) * (me.logicalH / rect.height);

  d.hoverCell = null;
  d.hoverPiece = null;
  d.hoverKind = null;
  d.hoverSlot = -1;
  game.highlightPieceId = null;

  // 悬停商店空位？（也用于商店内互相融合：拖到另一个棋子卡上）
  const slotIdx = shopSlotAt(ev.clientX, ev.clientY);
  if (slotIdx >= 0) {
    d.hoverSlot = slotIdx;
    const targetCard = game.shopSlots[slotIdx];
    const draggingInfo = draggedPieceInfo(d);
    if (slotIdx !== d.slotIndex && targetCard && shop.isPieceCard(targetCard)
        && draggingInfo && shop.isPieceCard(d.card)) {
      d.hoverKind = 'shopMerge';
    } else {
      d.hoverKind = targetCard ? 'invalid' : 'shopSlot';
    }
    return;
  }

  // 悬停我方棋盘？
  const cell = eventToCell(ev, 'me');
  if (!cell) return;
  d.hoverCell = { c: cell.c, r: cell.r };

  const occupant = pieceAt(cell.c, cell.r);
  const draggingPiece = getDragPiece();

  if (isDragSpell()) {
    if (SPELL_BY_ID[d.card.id]?.kind === 'cell') {
      const dig = SPELL_BY_ID[d.card.id]?.effect.type === 'dig';
      d.hoverKind = (dig ? isDiggable(cell.c, cell.r) && !occupant : isPlaceablePlot(cell.c, cell.r)) ? 'plot' : 'invalid';
    } else if (occupant && occupant.kind === 'piece') {
      d.hoverPiece = occupant;
      d.hoverKind = 'piece';
      game.highlightPieceId = occupant.id;
    } else {
      d.hoverKind = 'invalid';
    }
  } else if (occupant && occupant.kind === 'piece' && draggingPiece && occupant.id !== draggingPiece.id) {
    d.hoverPiece = occupant;
    d.hoverKind = 'piece';
  } else if (d.from === 'board' && occupant && occupant.id === d.piece?.id) {
    // 悬停在被拖棋子自己的原位：视为可放置（放下 = 不动），同样显示攻击范围预览
    d.hoverKind = 'plot';
  } else if (isPlaceablePlot(cell.c, cell.r)) {
    d.hoverKind = 'plot';
  } else if (isDragShovel() && isDiggable(cell.c, cell.r)) {
    d.hoverKind = 'plot';
  } else {
    d.hoverKind = 'invalid';
  }
}

/** Explicit choices never retain withBoard context across an asynchronous dialog. */
async function requestPlayerSpell(slotIndex, target = null, cell = null) {
  const board = game.boards.me;
  const card = board.shopSlots[slotIndex];
  if (!card || card.type !== 'spell') return;
  const options = {};
  const spec = SPELL_BY_ID[card.id];
  if (spec?.effect.type === 'spawnBing') {
    options.color = await chooseExperimentalOption(`${spec.name}：选择颜色`, [
      { label: '红兵', value: 'red' }, { label: '黑卒', value: 'black' },
    ]);
    if (options.color == null) return;
  } else if (spec?.effect.type === 'pairBuff' && target) {
    const choices = withBoard(board, () => spellSecondaryTargets(card, target));
    if (!choices.length) { flashHint('没有合法的第二目标'); return; }
    options.secondaryTargetId = await chooseExperimentalOption(`${spec.name}：选择第二枚棋子`, choices.map(p => ({
      label: `${p.color === 'red' ? '红' : '黑'}${pieceDisplayName(p)} Lv.${p.level} · ${p.stage || 0}阶 · 第${p.c + 1}列第${p.r + 1}行`, value: p.id,
    })));
    if (options.secondaryTargetId == null) return;
  }
  if (board.shopSlots[slotIndex] !== card || game.phase !== 'playing') return;
  const result = withBoard(board, () => act.useSpell(slotIndex, target, cell, options));
  renderShop();
  syncUI();
  if (!result.ok && result.reason) flashHint(result.reason);
  else if (result.hint) flashHint(result.hint);
  refreshDetailLive();
}

/** 结束拖拽 → 交给 actions.js 结算 */
function endDrag(ev) {
  const d = game.drag;
  if (!d.active) return;

  const dropCell = d.hoverCell;
  const hoverSlot = d.hoverSlot;
  const hoverPiece = d.hoverPiece;
  let res = null;

  // 包含道路、地图外、回原位、空卡位等不会调用 actions 的无效落点。
  // 在任何异步法术选择或正式动作之前统一检查，保证错操作既不生效也不静默。
  if (tutorialActive()) {
    let kind = 'invalid', args = [];
    if (d.from === 'shop') {
      if (d.card?.type === 'spell') { kind = 'useSpell'; args = [d.slotIndex, hoverPiece, dropCell]; }
      else if (d.card?.type === 'shovel') { kind = 'useShovel'; args = [d.slotIndex, dropCell?.c, dropCell?.r]; }
      else if (hoverPiece) { kind = 'shopToPiece'; args = [d.slotIndex, hoverPiece]; }
      else if (dropCell) { kind = 'buyAndPlace'; args = [d.slotIndex, dropCell.c, dropCell.r]; }
    }
    if (!tutorialActionAllowed(kind, args)) {
      clearDrag(); renderShop(); syncUI();
      flashHint(TUTORIAL_ACTION_REASON);
      return;
    }
  }

  if (d.from === 'shop' && d.card?.type === 'spell') {
    /* 1) 法术牌：空地型指定格子，目标型指定棋子，无目标型拖出商店即生效 */
    const spec = SPELL_BY_ID[d.card.id];
    if (spec?.kind === 'cell') {
      if (dropCell) res = requestPlayerSpell(d.slotIndex, null, dropCell);
      else if (!insideShop(ev.clientX, ev.clientY)) res = { ok: false, reason: '该法术需要拖到可放置的空地上' };
    } else if (spec?.kind === 'none') {
      if (!insideShop(ev.clientX, ev.clientY)) res = requestPlayerSpell(d.slotIndex, null);
    } else if (hoverPiece) {
      res = requestPlayerSpell(d.slotIndex, hoverPiece);
    } else if (!insideShop(ev.clientX, ev.clientY)) {
      res = { ok: false, reason: '该法术需要拖到一枚我方棋子上' };
    }
  } else if (d.from === 'shop' && d.card?.type === 'shovel') {
    /* 2) 铲子 */
    if (dropCell) res = act.useShovel(d.slotIndex, dropCell.c, dropCell.r);
  } else if (d.from === 'shop' && d.card && shop.isPieceCard(d.card)) {
    /* 3) 商店棋子：商店内融合 / 拖到棋子上融合或换位 / 放空地 */
    if (d.hoverKind === 'shopMerge' && hoverSlot >= 0 && hoverSlot !== d.slotIndex) {
      res = act.shopMerge(d.slotIndex, hoverSlot);
    } else if (hoverPiece && d.hoverKind === 'piece') {
      res = act.shopToPiece(d.slotIndex, hoverPiece);
    } else if (dropCell && d.hoverKind === 'plot') {
      res = act.buyAndPlace(d.slotIndex, dropCell.c, dropCell.r);
    }
  } else if (d.from === 'board' && d.piece) {
    /* 4) 场上棋子：拖到棋子上融合或换位 / 拖回商店空位 / 移到空地 */
    if (hoverPiece && hoverPiece.id !== d.piece.id) {
      res = act.boardToPiece(d.piece, hoverPiece);
    } else if (hoverSlot >= 0 && !game.shopSlots[hoverSlot]) {
      res = act.sellToShop(d.piece, hoverSlot);
    } else if (dropCell && d.hoverKind === 'plot'
               && !(dropCell.c === d.piece.c && dropCell.r === d.piece.r)) {   // 放回原位 = 不动
      res = act.moveTo(d.piece, dropCell.c, dropCell.r);
    }
  }

  clearDrag();
  renderShop();
  syncUI();
  if (res && !res.ok && res.reason) flashHint(res.reason);
  else if (res?.hint) flashHint(res.hint);
}

function clearDrag() {
  const d = game.drag;
  d.active = false;
  d.from = null;
  d.piece = null;
  d.card = null;
  d.slotIndex = -1;
  d.hoverCell = null;
  d.hoverPiece = null;
  d.hoverKind = null;
  d.hoverSlot = -1;
  game.highlightPieceId = null;
}

/** 屏幕中央短暂提示（用于融合失败 / 金币不足等反馈） */
function flashHint(text) {
  const layer = document.getElementById('float-layer');
  const el = document.createElement('div');
  el.className = 'flash-hint';
  el.textContent = text;
  layer.appendChild(el);
  setTimeout(() => el.remove(), 1200);
}

/* ---------- 拖拽辅助 ---------- */
// 取当前拖拽中的棋子数据：board 直接是棋子；shop 用 pieceDataOfCard（统一到 card.piece）
const getDragPiece = () =>
  game.drag.piece || (game.drag.card ? shop.pieceDataOfCard(game.drag.card) : null);
const isDragSpell = () => game.drag.card?.type === 'spell';
const isDragShovel = () => game.drag.card?.type === 'shovel';

/** 屏幕坐标 → 某张棋盘的网格坐标（对方棋盘按翻转反算） */
function eventToCell(ev, side) {
  const cv = canvases[side];
  const rect = cv.canvas.getBoundingClientRect();
  if (ev.clientX < rect.left || ev.clientX > rect.right || ev.clientY < rect.top || ev.clientY > rect.bottom) return null;
  const px = (ev.clientX - rect.left) * (cv.logicalW / rect.width);
  const py = (ev.clientY - rect.top) * (cv.logicalH / rect.height);
  const { c, r } = pixelToCell(px, py, side === 'opp');
  if (c < 0 || r < 0 || c >= mapData.cols || r >= mapData.rows) return null;
  return { c, r };
}

/** 命中的商店卡位索引（无则 -1） */
function shopSlotAt(clientX, clientY) {
  const els = document.querySelectorAll('#shop-grid .shop-slot');
  for (const el of els) {
    const r = el.getBoundingClientRect();
    if (clientX >= r.left && clientX <= r.right && clientY >= r.top && clientY <= r.bottom) {
      return Number(el.dataset.index);
    }
  }
  return -1;
}

/** 是否位于商店区域内 */
function insideShop(clientX, clientY) {
  const r = document.getElementById('shop').getBoundingClientRect();
  return clientX >= r.left && clientX <= r.right && clientY >= r.top && clientY <= r.bottom;
}

/* ============================================================
 * 点击棋子 → 详情面板 + 攻击范围高亮
 * ============================================================ */

/** 等级机制中文说明（键对应 config.LEVEL_UNLOCK 的值） */
const MECH_TEXT = {
  'bingFocus': '15级：每次攻击攻速+5%，最多4层',
  'bingBackSpeed': '20级：身后一格的己方棋子攻速+10%',
  'shiMultiTarget': '20级：一次可同时攻击两名敌人',
  'shiGroundAura': '30级：攻击范围内空地上的己方棋子攻击力+10%',
  'xiangNoEye': '20级：无视兵／卒塞象眼',
  'xiangEyeControl': '30级：象眼上的己方棋子控制时间+10%',
  'juColumn': '50级：去程穿透并逐格命中',
  'juReturnDmg': '70级：返程造成50%伤害',
  'maStun3': '50级：眩晕提升至1秒',
  'maNoHorseLeg': '80级：无视绊马腿',
  'paoBlast2': '50级：爆炸范围3×3，主目标100%其余60%',
  'paoSlow': '70级：命中减速30%，持续1秒',
  'paoCarriage3': '80级：允许1~3枚炮架',
};

/** 某羁绊要求「本种类棋子」自身达到的等级（两枚都须达标）。 */
function bondLevelFor(conf, type) {
  const rl = conf.requireLevel;
  if (typeof rl === 'number') return rl;
  if (rl?.either != null) return rl.either;
  if (rl?.anyOf?.[type] != null) return rl.anyOf[type];
  if (rl?.all?.[type] != null) return rl.all[type];
  return 0;
}

/**
 * 详情面板「等级」部分：按等级从低到高列出等级技能 + 该等级可触发的羁绊。
 * 技能：达到等级 = 金色；羁绊：当前激活 = 金色；其余浅灰。
 */
function levelSectionRows(piece) {
  const rows = [];
  for (const [lv, text] of Object.entries(LEVEL_EFFECT_TEXT[piece.type] || {})) {
    rows.push({ lv: Number(lv), on: piece.level >= Number(lv), tag: '技能', text: text +
      (piece.type === 'ma' && +lv === 70 && piece.level >= 70 ? `（当前+${Math.round(formationBonuses(piece).atkRate * 100)}%）` : '') });
  }
  const special = {
    ju: { 60: '逆行战车：每6次攻击召出战车，沿道路从帅冲向出生点，造成30%攻击伤害',
      100: '逆行战车：每4次攻击触发，战车伤害提高至50%' },
    pao: { 60: '追加炮击：每4次攻击追加一发70%伤害炮弹',
      100: '追加炮击：每3次攻击触发，追加炮弹伤害提高至90%' },
    ma: { 60: '道路残影：每5次攻击，沿道路向出生点方向召出2格马棋子虚影攻击，各造成60%伤害后消失',
      100: '道路残影：每4次攻击触发，追加3格马棋子虚影，各造成80%伤害后消失' },
  };
  for (const [lv, text] of Object.entries(special[piece.type] || {})) {
    rows.push({ lv: Number(lv), on: piece.level >= Number(lv), tag: '特殊技', text });
  }
  const activeBonds = piece.activeBonds || [];
  for (const conf of Object.values(BOND_CONFIG)) {
    if (!conf.requireType.includes(piece.type)) continue;
    rows.push({
      lv: bondLevelFor(conf, piece.type),
      on: activeBonds.includes(conf.name),
      tag: '羁绊',
      text: bondDetailText(piece, conf),
    });
  }
  rows.sort((a, b) => a.lv - b.lv);
  return rows.map(r =>
    `<div class="fx-row ${r.on ? 'on' : 'off'}"><span class="fx-lv">${r.lv}级</span>` +
    `<span class="fx-tag">${r.tag}</span>${r.text}</div>`
  ).join('');
}

/**
 * 详情面板「等阶」部分：各阶暴击加成与自动进化说明。
 * 等级与阶数独立；兵/士/象融合达到3阶时自动随机进化并随机颜色。
 * 已达到的阶 = 金色，当前阶标注「当前」。
 */
function stageSectionRows(piece) {
  const cur = piece.stage || 0;
  const evolves = ['bing', 'shi', 'xiang'].includes(piece.type);
  const evolveText = {
    bing: '随机进化为仕、士、相、象（红黑随机）',
    shi: '随机进化为马、馬、车、車、炮、砲（红黑随机）',
    xiang: '随机进化为马、馬、车、車、炮、砲（红黑随机）',
  };
  const rows = [];
  for (let s = 0; s <= 3; s++) {
    const crit = RANK.critByStage[s];
    const text = s === 0 ? '无效果'
      : s === 3 && evolves ? evolveText[piece.type]
      : `暴击率+${Math.round(crit.rate * 100)}%，暴击伤害+${Math.round(crit.damage * 100)}%`;
    rows.push(`<div class="fx-row ${cur >= s ? 'on' : 'off'}"><span class="fx-lv">${s}阶</span>${text}` +
      `${cur === s ? '<span class="fx-cur">当前</span>' : ''}</div>`);
  }
  rows.push(evolves
    ? '<div class="detail-cap">融合达到3阶时自动进化，产物回到0阶，保留等级。</div>'
    : '<div class="detail-cap">车/马/炮最高3阶，融合只提升阶数与等级。</div>');
  return rows.join('');
}

/**
 * 详情面板「攻击范围」：示意图 + 文字说明。
 * 示意图以棋子为中心（实心 = 直接可打，浅色 = 需满足条件：象眼 / 马腿 / 炮架 / 无阻挡），
 * 按棋子当前等级解锁、标记、羁绊、开局增益实时计算，与 attackRule.js 的判定规则一致。
 */
function rangeSectionHtml(piece) {
  const t = piece.type;
  const hit = [], cond = [];          // 相对坐标 [dc, dr]（dr 负 = 上方）
  let text = '';

  if (t === 'bing') {
    hit.push(...bingAttackOffsets(piece));
    text = game.cur.side === 'opp' ? '屏幕下、左、右各 1 格（不能打上方）'
      : '屏幕上、左、右各 1 格（不能打下方）';
  } else if (t === 'shi') {
    for (const dc of [-1, 1]) for (const dr of [-1, 1]) hit.push([dc, dr]);
    text = '斜向 1 格，共 4 格';
  } else if (t === 'xiang') {
    const noEye = game.flags.xiangNoEye || piece.flags?.noXiangEye;
    for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
      (noEye ? hit : cond).push([sx * 2, sy * 2]);
    }
    text = noEye ? '斜向2格，无象眼限制'
      : hasUnlock(piece, 'xiangNoEye') ? '斜向2格，仅无视兵／卒塞象眼'
      : '斜向2格，象眼有棋子则受阻';
  } else if (t === 'ma') {
    const noLeg = piece.flags?.noHorseLeg || hasUnlock(piece, 'maNoHorseLeg');
    for (const [a, b] of [[1, 2], [2, 1]]) for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
      (noLeg ? hit : cond).push([a * sx, b * sy]);
    }
    text = noLeg
      ? '日字8格，无马腿限制'
      : '日字8格，马腿有棋子则受阻';
  } else if (t === 'ju' || t === 'pao') {
    for (let d = 1; d <= 3; d++) {
      for (const [dc, dr] of [[d, 0], [-d, 0], [0, d], [0, -d]]) {
        // 车：第 1 格必然无阻挡；炮：至少隔一枚炮架，示意图全部画成「有条件」
        (t === 'ju' && d === 1 ? hit : cond).push([dc, dr]);
      }
    }
    if (t === 'ju') {
      text = '横竖直线，射程到棋盘边；中间有棋子会挡住';
    } else {
      const max = hasUnlock(piece, 'paoCarriage3') ? 3 : 1;      // 与 attackRule.canPaoAttack 一致
      text = `横竖直线，必须${max === 1 ? 1 : `1~${max}`}枚炮架；无架不能攻击`;
    }
  }
  // 羁绊 / 其它额外范围可在此追加

  const R = (t === 'ju' || t === 'pao') ? 3 : 2;      // 示意图半径：车炮 7×7，其余 5×5
  const sideways = isSidewaysMap(game.map), flip = game.cur.side === 'opp';
  const key = (dc, dr) => {
    const p = vectorToView(dc, dr, sideways, flip);
    return `${p.x},${p.y}`;
  };
  const hitSet = new Set(hit.map(([a, b]) => key(a, b)));
  const condSet = new Set(cond.map(([a, b]) => key(a, b)));
  const support = t === 'xiang' ? XIANG_EYE_OFFSETS : t === 'ma' ? MA_LEG_OFFSETS : [];
  const supportSet = new Set(support.map(([a, b]) => key(a, b)));
  let cells = '';
  for (let dr = -R; dr <= R; dr++) {
    for (let dc = -R; dc <= R; dc++) {
      const k = `${dc},${dr}`;
      const cls = (dc === 0 && dr === 0) ? 'self' : hitSet.has(k) ? 'hit' : condSet.has(k) ? 'cond' : supportSet.has(k) ? 'support' : '';
      const label = cls === 'self' ? pieceDisplayName(piece) : '';
      cells += `<i class="${cls}">${label}</i>`;
    }
  }
  const legendCond = cond.length ? '<span class="lg cond"></span>需满足条件' : '';
  const flipNote = t === 'bing'
    ? '<div class="range-note">以屏幕为准，双方上下镜像</div>'
    : sideways
      ? '<div class="range-note">示意图已跟随横向棋盘旋转；技能中的方向以原地图为准</div>'
      : flip ? '<div class="range-note">对方棋盘上下翻转显示，「上」指对方的前方</div>' : '';
  return `
    <div class="range-box">
      <div class="range-grid" style="--n:${R * 2 + 1}">${cells}</div>
      <div class="range-text">
        <div>${text}</div>
        <div class="range-legend"><span class="lg hit"></span>可攻击 ${legendCond}${support.length ? `<span class="lg support"></span>${t === 'ma' ? '马腿位置' : '象眼位置'}` : ''}</div>
        ${support.length ? '<div class="range-note">绿色只标空地/草地上的象眼或马腿位置（含已有友军）；草地需先铲开才能落子。</div>' : ''}
        ${flipNote}
      </div>
    </div>`;
}

function setupDetailPanel() {
  const panel = document.getElementById('detail-panel');
  setupDetailDismissal(document.getElementById('app'), panel, closeDetail);
}

function handlePieceClick(piece) {
  if (game.selectedPieceId === piece.id) { closeDetail(); return; }
  game.selectedPieceId = piece.id;
  renderDetail(piece);
}

function renderDetail(piece, panel = document.getElementById('detail-panel')) {
  const cap = LEVEL.naturalCap[piece.type] ?? LEVEL.hardCap;
  const atCap = piece.level >= cap;
  const need = experienceRequired(piece.level);
  const expRatio = atCap ? 1 : Math.min(1, (piece.exp || 0) / (need || 1));

  // 最终冷却（基础 × 全局攻速 × 等级攻速 × 增益 × 羁绊，与 wave.pieceCooldown 一致）
  const baseCd = PIECE_STATS[piece.type]?.cd ?? 0;
  const cdRate = GLOBAL_ATK_SPEED_SCALE
    * levelCdMult(piece)
    * (game.flags.cdRateByType?.[piece.type] ?? 1)
    * (piece.bondMods?.cdRate ?? 1);
  const finalCd = baseCd * cdRate / combatRules.pieceSkillSpeedMult(piece);

  const crit = combatRules.criticalStats(piece);
  const gold = GOLD_ON_KILL.default;

  const levelHtml = levelSectionRows(piece);
  const stageHtml = stageSectionRows(piece);
  const rangeHtml = rangeSectionHtml(piece);
  const isOpp = game.cur.side === 'opp';
  panel.classList.toggle('opp-side', isOpp);

  panel.innerHTML = `
    <div class="detail-head">
      <span class="detail-title">${pieceDisplayName(piece)} · Lv.${piece.level}</span>
      <span class="detail-owner ${isOpp ? 'opp' : 'me'}">${isOpp ? '对方' : '我方'}</span>
      <span class="detail-color ${piece.color}">${piece.color === 'red' ? '红' : '黑'}</span>
      <button type="button" class="detail-close" aria-label="关闭详情">✕</button>
    </div>
    <div class="detail-grid">
      <div><span class="k">攻击力</span><b>${displayNumber(finalAtk(piece))}</b></div>
      <div><span class="k">攻击冷却</span><b>${finalCd.toFixed(2)}s</b></div>
      <div><span class="k">阶数</span><b>${piece.stage || 0} 阶</b></div>
      <div><span class="k">暴击率／暴伤</span><b>${(crit.rate * 100).toFixed(0)}%／${(crit.damage * 100).toFixed(0)}%</b></div>
      <div><span class="k">击杀经验</span><b>全场8，补刀+2</b></div>
      <div><span class="k">单次击杀金币</span><b>+${gold}</b></div>
      <div><span class="k">升级上限</span><b>${atCap ? '已达上限' : cap}</b></div>
      ${specialThreshold(piece) ? `<div><span class="k">特殊技蓄势</span><b>${Math.min(specialThreshold(piece), piece.specialCount || 0)} / ${specialThreshold(piece)}</b></div>` : ''}
    </div>
    <div class="detail-exp">
      <div class="exp-label">经验 ${atCap ? '—' : `${piece.exp || 0} / ${need}`}</div>
      <div class="exp-track"><i style="width:${(expRatio * 100).toFixed(1)}%"></i></div>
    </div>
    <div class="detail-sec">攻击范围</div>${rangeHtml}
    ${levelHtml ? `<div class="detail-sec">等级</div>${levelHtml}` : ''}
    ${stageHtml ? `<div class="detail-sec">等阶</div>${stageHtml}` : ''}
    ${atCap ? '<div class="detail-cap">已达升级上限</div>' : ''}
    <div class="detail-cap">每方最多10枚棋子；羁绊按各自规则生效。</div>
  `;
  panel.classList.remove('hidden');
}

/**
 * 给商店卡牌（铲子 / 法术牌）弹一个简易信息面板。
 * 棋子卡走 renderDetail（显示完整棋子信息）。
 */
function renderDetailCard(card, panel = document.getElementById('detail-panel')) {
  if (!card) return;

  let title = '', color = '', rows = '', tip = '';
  if (card.type === 'shovel') {
    title = '铲子';
    tip = '拖拽到地图上的草地格，铲出空地';
    rows = `<div><span class="k">售价</span><b>${SHOP.price.shovel} 金币</b></div>`;
  } else if (card.type === 'spell') {
    const spec = SPELL_BY_ID[card.id];
    title = spec?.name || card.name || '法术';
    color = `${card.tier}阶`;
    rows = `
      <div><span class="k">售价</span><b>${card.price ?? spec?.price ?? 0} 金币</b></div>
      <div><span class="k">类型</span><b>${spec?.kind === 'target' ? '指定棋子' : spec?.kind === 'cell' ? (spec.effect.type === 'dig' ? '指定草地' : '指定空地') : '无目标'}</b></div>
      ${spec?.stock != null ? `<div><span class="k">本局剩余</span><b>${spellStockLeft(card.id)} / ${spec.stock}</b></div>` : ''}`;
    tip = spec?.detail || spec?.desc || '';
  } else {
    return;
  }

  panel.innerHTML = `
    <div class="detail-head">
      <span class="detail-title">${title}</span>
      ${color ? `<span class="detail-color">${color}</span>` : ''}
      <button type="button" class="detail-close" aria-label="关闭详情">✕</button>
    </div>
    <div class="detail-grid">${rows}</div>
    ${tip ? `<div class="detail-cap spell-detail-text">${tip}</div>` : ''}
  `;
  panel.classList.remove('opp-side');
  panel.classList.remove('hidden');
}

function closeDetail() {
  const hadCard = game.detailCardSlot >= 0;
  game.selectedPieceId = null;
  game.detailCardSlot = -1;
  document.getElementById('detail-panel').classList.add('hidden');
  if (hadCard) renderShop();   // 去掉商店卡位高亮
}

/* ============================================================
 * 结算：段位升降 + 统计，返回主页
 * ============================================================ */
let overShown = false;

/** @param {'win'|'lose'|'draw'} result */
function finishGame(result) {
  if (overShown) return;
  overShown = true;
  game.phase = 'over';
  clearDrag();
  closeDetail();

  const { before, after, events } = rank.settle(result);
  const me = game.boards.me, opp = game.boards.opp;

  // 仅上传结束摘要：HTTPS 使用 D1；本地显式 MySQL 模式使用 Node API，默认本地跳过。
  uploadMatch({
    map: String(mapData?.file || 'unknown').split('/').pop(),
    rank: rank.label(before),
    result,
    waves: Math.max(me.wave, opp.wave),
    duration: Math.round((Date.now() - (game._matchStarted || Date.now())) / 1000),
    my_pieces: (me.pieces || []).map(p => ({ type: p.type, color: p.color, level: p.level, stage: p.stage, c: p.c, r: p.r })),
    opp_pieces: (opp.pieces || []).map(p => ({ type: p.type, color: p.color, level: p.level, stage: p.stage, c: p.c, r: p.r })),
    spells: Object.entries(me.spellUsed || {}).map(([id, uses]) => ({ id, uses })),
  });

  const box = document.querySelector('.game-over-box');
  box.classList.toggle('lose', result === 'lose');
  document.getElementById('game-over-title').textContent =
    { win: '胜利', lose: '失败', draw: '平局' }[result];

  const unchanged = before.tier === after.tier && before.sub === after.sub && before.stars === after.stars;
  const delta = result === 'win' ? '+1 ★'
    : result === 'draw' ? '星数不变'
    : unchanged ? '不掉星' : '-1 ★';
  document.getElementById('game-over-rank').innerHTML = `
    <div>${rank.label(before)} ${rank.starText(before)} → <b>${rank.label(after)} ${rank.starText(after)}</b></div>
    <div>${delta}</div>
    ${events.map(e => `<div class="ev">${e}</div>`).join('')}
  `;
  document.getElementById('game-over-stats').innerHTML = `
    <div><span class="k">对手</span><b>${match.name || '—'}</b></div>
    <div><span class="k">坚持波次</span><b>${Math.max(me.wave, opp.wave)}</b></div>
    <div><span class="k">双方各出怪</span><b>${me.spawned}</b></div>
    <div><span class="k">我方漏怪</span><b>${KING.hp - me.lives}</b></div>
    <div><span class="k">我方击杀</span><b>${me.kills}</b></div>
    <div><span class="k">对方击杀</span><b>${opp.kills}</b></div>
  `;
  document.getElementById('game-over').classList.remove('hidden');
}

/* ============================================================
 * 启动
 * ============================================================ */
window.addEventListener('DOMContentLoaded', boot);