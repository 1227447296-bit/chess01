import game, { createBoard, withBoard, isPlaceablePlot } from './gameData.js';
import * as actions from './actions.js';
import { boardToView, viewSize } from './boardView.js';

/** Exercises the real main.js event handlers without changing the player's board/save. */
export async function runExperimentalSmokeFixtures() {
  const saved = { boards: game.boards, cur: game.cur, phase: game.phase,
    selected: game.selectedPieceId, detail: game.detailCardSlot };
  const gameView = document.getElementById('game-view');
  const startView = document.getElementById('start-screen');
  const endView = document.getElementById('game-over');
  const classes = [gameView.className, startView.className, endView.className];
  let passed = 0;
  const check = (value, message) => { if (!value) throw new Error(message); passed++; };
  try {
    const me = createBoard('me', saved.boards.me.map);
    const opp = createBoard('opp', saved.boards.me.map);
    game.boards = { me, opp };
    game.cur = me;
    game.phase = 'paused';
    game.selectedPieceId = null;
    game.detailCardSlot = -1;
    gameView.classList.remove('hidden');
    startView.classList.add('hidden');
    endView.classList.add('hidden');
    let plot;
    withBoard(me, () => {
      for (let r = 0; r < me.map.rows && !plot; r++) for (let c = 0; c < me.map.cols; c++) {
        if (isPlaceablePlot(c, r)) { plot = { c, r }; break; }
      }
    });
    check(!!plot, 'A real map has an available plot');
    me.shopSlots[0] = { source: 'native', type: 'piece', kind: 'bing', color: 'red', level: 0, mergeCount: 0 };
    check(withBoard(me, () => actions.buyAndPlace(0, plot.c, plot.r)).ok, 'Real purchase succeeds');
    const piece = me.pieces[0];
    piece.stage = 2;
    piece.level = 20;
    const id = piece.id;
    const gold = me.gold;
    await new Promise(requestAnimationFrame);
    const canvas = document.getElementById('canvas-me');
    const rect = canvas.getBoundingClientRect();
    const view = boardToView(piece.c, piece.r, me.map);
    const size = viewSize(me.map);
    const x = rect.left + (view.c + .5) * rect.width / size.cols;
    const y = rect.top + (view.r + .5) * rect.height / size.rows;
    const pointer = type => new PointerEvent(type, { bubbles: true, pointerId: 91, clientX: x, clientY: y });
    game.phase = 'playing';
    canvas.dispatchEvent(pointer('pointerdown'));
    window.dispatchEvent(pointer('pointerup'));
    const panel = document.getElementById('detail-panel');
    check(!panel.classList.contains('hidden'), 'Actual canvas click opens detail');
    check(panel.textContent.includes('暴击率'), 'Detail includes actual critical stats');
    check(panel.textContent.includes('120'), 'Level20 experience requirement is displayed');
    check(!panel.querySelector('.experimental-evolve'), '3阶自动进化不显示主动进化按钮');
    const material = { id: 'smoke-material', kind: 'piece', type: 'bing', color: piece.color,
      c: 1, r: 1, level: 1, exp: 0, stage: 0, atkBonus: 0, flags: {}, bonds: [] };
    me.pieces.push(material);
    check(withBoard(me, () => actions.boardToPiece(material, piece)).ok, '真实融合达到3阶成功');
    check(piece.id === id && piece.stage === 0 && ['shi', 'xiang'].includes(piece.type) &&
      ['red', 'black'].includes(piece.color), '真实融合自动随机进化并随机颜色');
    check(me.gold === gold, '真实融合不额外扣金币');
    me.wave = 5;
    me.gold = 100;
    const card = { source: 'native', type: 'spell', id: 'jieshihuanhun', tier: 2, price: 10 };
    me.shopSlots[0] = card;
    // Injecting a test card bypasses normal shop rendering; a card click invokes the real renderer.
    const placeholder = document.createElement('div');
    placeholder.className = 'shop-card';
    placeholder.dataset.slot = '0';
    document.getElementById('shop-grid').children[0].replaceChildren(placeholder);
    placeholder.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerId: 93, clientX: 1, clientY: 1 }));
    window.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 93, clientX: 1, clientY: 1 }));
    let destination;
    withBoard(me, () => {
      for (let r = 0; r < me.map.rows && !destination; r++) for (let c = 0; c < me.map.cols; c++) {
        if (isPlaceablePlot(c, r)) { destination = { c, r }; break; }
      }
    });
    check(!!destination, 'There is a second valid summon plot');
    const targetView = boardToView(destination.c, destination.r, me.map);
    const targetX = rect.left + (targetView.c + .5) * rect.width / size.cols;
    const targetY = rect.top + (targetView.r + .5) * rect.height / size.rows;
    const eventAt = (type, x, y) => new PointerEvent(type, { bubbles: true, pointerId: 92, clientX: x, clientY: y });
    function dragSummon() {
      const slot = document.querySelector('.shop-card[data-slot="0"]');
      const box = slot.getBoundingClientRect();
      const sx = box.left + box.width / 2, sy = box.top + box.height / 2;
      slot.dispatchEvent(eventAt('pointerdown', sx, sy));
      window.dispatchEvent(eventAt('pointermove', targetX, targetY));
      window.dispatchEvent(eventAt('pointerup', targetX, targetY));
    }
    dragSummon();
    check(!!document.querySelector('.experimental-choice'), 'Dragging summon opens color choice');
    document.querySelector('.experimental-choice-cancel').click();
    await Promise.resolve();
    check(me.gold === 100 && me.shopSlots[0] === card && !me.spellUsed.jieshihuanhun, 'Cancel summon consumes nothing');
    dragSummon();
    const choices = [...document.querySelectorAll('.experimental-choice button')];
    choices.find(button => button.textContent === '黑卒').click();
    await Promise.resolve();
    check(me.pieces.some(p => p.type === 'bing' && p.color === 'black' && p.level === 5), 'Chosen black summon is placed');
    check(me.gold === 90 && me.shopSlots[0] == null && me.spellUsed.jieshihuanhun === 1, 'Summon charges once after choice');
    me.wave = 12;
    me.shopSlots[0] = { source: 'native', type: 'spell', id: 'lidaitaojiang', tier: 3, price: 14 };
    const evolutionCard = document.createElement('div');
    evolutionCard.className = 'shop-card';
    evolutionCard.dataset.slot = '0';
    document.getElementById('shop-grid').children[0].replaceChildren(evolutionCard);
    evolutionCard.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerId: 93, clientX: 1, clientY: 1 }));
    window.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 93, clientX: 1, clientY: 1 }));
    dragSummon();
    check(!document.querySelector('.experimental-choice'), '随机进化不让玩家指定种类或颜色');
    await Promise.resolve();
    const evolvedRecruit = me.pieces.find(p => p.c === destination.c && p.r === destination.r);
    check(['shi', 'xiang'].includes(evolvedRecruit.type) && ['red', 'black'].includes(evolvedRecruit.color), '李代桃僵将0阶兵随机进化并随机颜色');
    check(me.gold === 76 && me.spellUsed.lidaitaojiang === 1, '李代桃僵只扣14金及一张库存');
    return passed;
  } finally {
    document.querySelector('.experimental-choice-cancel')?.click();
    game.boards = saved.boards;
    game.cur = saved.cur;
    game.phase = saved.phase;
    game.selectedPieceId = saved.selected;
    game.detailCardSlot = saved.detail;
    [gameView.className, startView.className, endView.className] = classes;
    document.getElementById('detail-panel').classList.add('hidden');
  }
}
