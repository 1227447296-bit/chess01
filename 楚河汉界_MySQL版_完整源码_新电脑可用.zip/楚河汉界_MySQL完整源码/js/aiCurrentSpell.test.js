/** 低/高段实际施法小样本，不修改正式棋盘与存档。 */
import game, { createBoard, withBoard } from './gameData.js';
import { setupAI, aiTick, aiInfo } from './ai.js';
import { loadMap } from './mapLoader.js';
import { AI_PLAY } from './config.js';

export async function runAICurrentSpellFixtures() {
  const saved = { cur: game.cur, phase: game.phase };
  const map = await loadMap(1), results = [];
  try {
    game.phase = 'playing';
    for (const [tier, mode] of [[0, 'novice'], [0, 'normal'], [7, 'normal']]) {
      setupAI({ tier }, { seed: 173, lowRankMode: mode, variety: false, evaluationSlices: 32 });
      const b = createBoard('opp', map);
      b.totalRefreshCount = 1; b.gold = 6; b.aiTimer = 0;
      b.shopSlots[0] = { source: 'native', type: 'spell', id: 'wuzhongshengyou', price: 6 };
      withBoard(b, () => {
        for (let n = 0; n < 20000 && !b.spellUsed.wuzhongshengyou; n++) aiTick(1 / 60, 3);
      });
      const used = b.spellUsed.wuzhongshengyou === 1;
      const legal = used && b.gold === 9 && !b.shopSlots[0];
      const normalPace = b.aiTimer >= AI_PLAY.actionMin && b.aiTimer <= AI_PLAY.actionMax;
      if (!legal || !normalPace) throw Error(`tier=${tier}/${mode}: ${JSON.stringify(aiInfo(b))}`);
      results.push({ tier, mode, used, gold: b.gold, normalPace });
    }
    return { passed: results.length * 2, results };
  } finally {
    game.cur = saved.cur; game.phase = saved.phase;
    setupAI({ tier: 7 });
  }
}
