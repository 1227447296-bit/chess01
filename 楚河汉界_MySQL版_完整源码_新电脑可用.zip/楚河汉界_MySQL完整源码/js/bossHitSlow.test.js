/** 王受击减速：真实伤害入口、分段移动、免疫及暂停回归。 */
import game, { createBoard, withBoard } from './gameData.js';
import { enemySpecForSpawn, applyBossHitSlow } from './boss.js';
import { update, updateCombat, spellDamage } from './wave.js';
import { slowEnemy, enemySlowRate } from './tacticalEffects.js';
import { cloneBoard } from './aiSimulation.js';

export function runBossHitSlowFixtures() {
  const checks = [];
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(`Boss受击减速: ${name}`); };
  const near = (a, b) => Math.abs(a - b) < 1e-7;
  const saved = { cur: game.cur, phase: game.phase };
  const make = (boss = true) => {
    const b = createBoard('me', {
      cols: 300, rows: 2, ground: [], grass: [], road: [],
      path: Array.from({ length: 300 }, (_, c) => ({ c, r: 0 })),
      enemySpawn: { c: 0, r: 0 }, kingPoint: { c: 299, r: 0 },
    });
    b.enemies = [{ ...enemySpecForSpawn(8, boss ? 0 : 1), id: 'target', kind: 'enemy',
      hp: 10000, maxHp: 10000, speed: 1, progress: 0, c: 0, r: 0, fx: 0, fy: 0,
      done: false, dying: false, deathT: 0, stunLeft: 0, stunImmuneLeft: 0 }];
    return b;
  };
  const hit = b => spellDamage(null, b.enemies, { fixed: 1, board: b });
  const tick = (b, dt) => withBoard(b, () => update(dt));
  try {
    game.phase = 'playing';
    const b = make(), e = b.enemies[0];
    check('首次实际伤害扣血', hit(b) === 1 && e.hp === 9999);
    check('首次命中减速10%', near(enemySlowRate(e, b), 0.1));
    const first = e.tacticalSlows[0];
    check('减速窗口0.5秒，免疫结束在1秒', first.start === 0 && first.until === 0.5 && e.bossHitSlowImmuneUntil === 1);
    hit(b); hit(b);
    check('同帧多次伤害不刷新或叠加', e.hp === 9997 && e.tacticalSlows.length === 1 && e.tacticalSlows[0] === first);
    tick(b, 0.25);
    check('减速期间以90%移速前进', near(e.progress, 0.225));
    hit(b);
    check('减速中再命中不续时', e.bossHitSlowImmuneUntil === 1 && first.until === 0.5);
    tick(b, 0.25);
    check('满0.5秒走过0.45格并恢复速度', near(e.progress, 0.45) && enemySlowRate(e, b) === 0);
    hit(b);
    check('减速结束进入免疫仍正常扣血', e.hp === 9995 && e.bossHitSlowImmuneUntil === 1 && enemySlowRate(e, b) === 0);
    tick(b, 0.25);
    check('免疫期间正常速度', near(e.progress, 0.7));
    hit(b);
    check('免疫期间不能再次减速', e.hp === 9994 && enemySlowRate(e, b) === 0);
    tick(b, 0.25); hit(b);
    check('免疫满0.5秒后再次命中可减速', near(e.progress, 0.95) && near(enemySlowRate(e, b), 0.1) && e.bossHitSlowImmuneUntil === 2);

    const pauseTime = b.gameTime, pauseProgress = e.progress;
    game.phase = 'paused'; tick(b, 10);
    check('暂停冻结减速和移动', b.gameTime === pauseTime && e.progress === pauseProgress && near(enemySlowRate(e, b), 0.1));
    game.phase = 'playing'; tick(b, 0.5);
    game.phase = 'paused'; tick(b, 10);
    check('暂停也冻结免疫时间', b.gameTime === 1.5 && !applyBossHitSlow(e, b.gameTime));
    game.phase = 'playing'; tick(b, 0.5); hit(b);
    check('恢复游戏后免疫按游戏时间结束', near(enemySlowRate(e, b), 0.1));

    const cross = make(); hit(cross); tick(cross, 0.75);
    check('跨减速边界帧分段积分不提前或延长', near(cross.enemies[0].progress, 0.7));
    const long = make(); hit(long); tick(long, 1.2); hit(long);
    check('大帧跨过减速和免疫后可重新触发', near(long.enemies[0].progress, 1.15) && near(enemySlowRate(long.enemies[0], long), 0.1));

    const strong = make(); hit(strong); slowEnemy(strong.enemies[0], 0.3, 1, 0, strong); tick(strong, 0.5);
    check('其他30%减速与受击减速不叠乘', near(strong.enemies[0].progress, 0.35));
    const delayed = make(); hit(delayed); slowEnemy(delayed.enemies[0], 0.3, 0.25, 0.25, delayed); tick(delayed, 0.75);
    check('延迟减速交叠时逐段取最强效果', near(delayed.enemies[0].progress, 0.65));
    const stun = make(); hit(stun); stun.enemies[0].stunLeft = 0.25; tick(stun, 0.25); tick(stun, 0.25);
    check('眩晕期间受击减速仍按游戏时间到期', near(stun.enemies[0].progress, 0.225) && enemySlowRate(stun.enemies[0], stun) === 0);

    const ordinary = make(false); hit(ordinary); tick(ordinary, 0.5);
    check('普通敌人不触发受击减速', ordinary.enemies[0].bossHitSlowImmuneUntil === undefined && near(ordinary.enemies[0].progress, 0.5));
    const zero = make(); spellDamage(null, zero.enemies, { fixed: 0, board: zero });
    check('无实际伤害不触发', zero.enemies[0].bossHitSlowImmuneUntil === undefined);
    zero.enemies[0].hp = 1; hit(zero);
    check('致死伤害不创建减速状态', zero.enemies[0].dying && zero.enemies[0].bossHitSlowImmuneUntil === undefined);
    const normalAttack = make();
    normalAttack.pieces = [{ id: 'bing', kind: 'piece', type: 'bing', color: 'red', c: 0, r: 1,
      level: 0, exp: 0, stage: 0, atkBonus: 0, flags: {}, cdLeft: 0, bonds: [] }];
    withBoard(normalAttack, () => updateCombat(0));
    check('真实普通攻击也触发', normalAttack.enemies[0].hp < 10000 && near(enemySlowRate(normalAttack.enemies[0], normalAttack), 0.1));
    const source = make(); hit(source);
    const sim = cloneBoard(source); sim._simulationContext = true;
    game.phase = 'paused'; tick(sim, 0.75);
    check('私有AI推演保留减速规则', near(sim.enemies[0].progress, 0.7));
    check('推演状态不污染真实棋盘', source.gameTime === 0 && source.enemies[0].progress === 0 && near(enemySlowRate(source.enemies[0], source), 0.1));
    check('恢复棋盘上下文', game.cur === saved.cur);
    return { ok: true, count: checks.length, checks };
  } finally { game.cur = saved.cur; game.phase = saved.phase; }
}
export default runBossHitSlowFixtures;
