/** 图鉴进度独立于段位；仅记录玩家真实使用，不记录AI与推演。 */
import game from './gameData.js';
import { SPELLS, PIECE_STATS } from './config.js';
export const CODEX_KEY = 'cnchess.experimental.codex.v1';
export const STRATAGEM_GROUPS = ['胜战计', '敌战计', '攻战计', '混战计', '并战计', '败战计'];
export const codexSpellGroups = () => STRATAGEM_GROUPS.map((name, index) => ({
  name, spells: SPELLS.slice(index * 6, index * 6 + 6), start: index * 6 + 1,
}));
let progress = null;
function load() {
  if (progress) return progress;
  progress = { pieces: [], spells: [] };
  try {
    const value = JSON.parse(globalThis.localStorage.getItem(CODEX_KEY));
    if (value) {
      progress.pieces = [...new Set((Array.isArray(value.pieces) ? value.pieces : []).filter(x => x in PIECE_STATS))];
      progress.spells = [...new Set((Array.isArray(value.spells) ? value.spells : []).filter(x => SPELLS.some(s => s.id === x)))];
    }
  } catch { /* 无存档或存储不可用时使用会话进度 */ }
  return progress;
}
export function isCodexUnlocked(kind, id) { return load()[kind]?.includes(id) || false; }
export function recordCodex(kind, id, board = game.cur) {
  if (!board || board.side !== 'me' || board._simulationContext || board.tutorial) return false;
  const valid = kind === 'pieces' ? Object.hasOwn(PIECE_STATS, id) : kind === 'spells' && SPELLS.some(s => s.id === id);
  if (!valid || isCodexUnlocked(kind, id)) return false;
  load()[kind].push(id);
  try { globalThis.localStorage.setItem(CODEX_KEY, JSON.stringify(progress)); } catch { /* 会话中仍然解锁 */ }
  return true;
}
export function recordOwnedPieces(board = game.cur) {
  for (const p of board.pieces) recordCodex('pieces', p.type, board);
  for (const card of board.shopSlots) if (card?.source === 'fromBoard' && card.piece) recordCodex('pieces', card.piece.type, board);
}
