/**
 * names.js —— 对手随机昵称：「状态的食物 + 5 位数字」，如「飞翔的冰淇淋48213」
 * 仅作显示用，没有任何玩法含义。
 */
import { NAME_MOODS, NAME_FOODS } from './config.js';

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

export function randomName() {
  const num = 10000 + Math.floor(Math.random() * 90000);   // 10000~99999
  return `${pick(NAME_MOODS)}的${pick(NAME_FOODS)}${num}`;
}

export default randomName;
