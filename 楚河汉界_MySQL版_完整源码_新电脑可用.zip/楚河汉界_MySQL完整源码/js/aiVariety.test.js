/** 强度优先的多样性回归：纯选择门禁 + 实际两手扩建；仅在开始页显式运行。 */
import game, { createBoard, withBoard, uid } from './gameData.js';
import { loadMap } from './mapLoader.js';
import { actionKey, variationKey, placementShortlist, registerPieceKeys, equivalentAction, symmetricPlacement, chooseEquivalent } from './aiVariety.js';
import { setupAI, aiTick, aiInfo } from './ai.js';
import { simulateCombat } from './aiSimulation.js';
import * as act from './actions.js';
import { waitForBenchmarkReady } from './aiBenchmark.test.js';

const snapshot = value => JSON.stringify(value, (key, v) => v instanceof Set ? [...v] : v instanceof Map ? [...v] : v);
const candidate = (c, extra = {}) => ({ kind: 'buy', slot: 1, c, r: 2, cost: 6,
  gain: 10, score: 100, branches: [{ value: 100, probability: 1 }], tested: true,
  combat: { value: 8, worstValue: 8, leaks: 0 }, ...extra });

export async function runAIVarietyFixtures() {
  await waitForBenchmarkReady();
  if (game.phase !== 'start') throw Error('请先回到开始页');
  const checks = [], original = { cur: game.cur, phase: game.phase, random: Math.random };
  const check = (name, ok) => { checks.push({ name, ok: !!ok }); if (!ok) throw Error(name); };
  try {
    const reference = candidate(1), other = candidate(3);
    const geometry = { map: { cols: 5, rows: 5, path: [{ c: 2, r: 2 }],
      ground: [], grass: [], road: [], cleared: new Set() }, pieces: [], enemies: [] };
    const options = { seed: 11, needsCombat: true, board: geometry };
    check('缺少几何证明时不凭评分随机', chooseEquivalent(reference, [reference, other],
      { seed: 11, needsCombat: true }).eligible === 1);
    check('弯曲道路的短期同分落点不视作长期等价', !symmetricPlacement({ ...geometry,
      map: { ...geometry.map, path: [{ c: 1, r: 1 }, { c: 2, r: 1 }] } }, other, reference));
    check('不把上下镜像当作兵的左右对称', !symmetricPlacement(geometry,
      candidate(1, { r: 4 }), reference));
    check('不对称原有棋子阻止落点替换', !symmetricPlacement({ ...geometry,
      pieces: [{ c: 1, r: 0 }] }, other, reference));
    check('不对称已铲土地阻止落点替换', !symmetricPlacement({ ...geometry,
      map: { ...geometry.map, cleared: new Set(['1,2']) } }, other, reference));
    check('不对称地形阻止落点替换', !symmetricPlacement({ ...geometry,
      map: { ...geometry.map, grass: [[false, true]] } }, other, reference));
    const rookBoard = { ...geometry, pieces: [{ type: 'ju', c: 2, r: 1 },
      { type: 'ju', c: 2, r: 4 }], bondMods: { juBend: true } };
    check('轴上双车也不能忽略固定向右拐弯', !symmetricPlacement(rookBoard, other, reference));
    check('双车方向性例外在最终随机入口保持原动作', chooseEquivalent(reference,
      [reference, other], { ...options, board: rookBoard }).action === reference);
    check('商店待上场的车也阻止镜像替换', !symmetricPlacement({ ...geometry,
      shopSlots: [{ type: 'piece', piece: { type: 'ju' } }] }, other, reference));
    check('旧字段中的待上场车同样排除', !symmetricPlacement({ ...geometry,
      shopSlots: [{ type: 'piece', _piece: { type: 'ju' } }] }, other, reference));
    const picked = chooseEquivalent(reference, [reference, other], options);
    check('安全同分候选进入随机池', picked.eligible === 2 && equivalentAction(other, reference, true));
    check('相同风格种子结果相同', chooseEquivalent(reference, [reference, other], options).action === picked.action);
    check('候选数组顺序不控制结果', chooseEquivalent(reference, [other, reference], options).action === picked.action);
    check('不同种子能选择不同等价方案', new Set(Array.from({ length: 16 }, (_, seed) =>
      actionKey(chooseEquivalent(reference, [reference, other], { ...options, seed }).action))).size === 2);
    check('明显较差方案不能进入随机池', !equivalentAction(candidate(3, { gain: 9 }), reference, true));
    check('静态价值下降不能靠近期分掩盖', !equivalentAction(candidate(3, { score: 99 }), reference, true));
    check('更高花费不能伪装等价', !equivalentAction(candidate(3, { cost: 7 }), reference, true));
    check('即时同分也不随机换另一张卡和颜色路线', !equivalentAction(candidate(3, { slot: 2 }), reference, true));
    check('即时同分也不随机撤走另一枚棋子', !equivalentAction(candidate(3, { kind: 'move', pieceId: 'b' }),
      candidate(1, { kind: 'move', pieceId: 'a' }), true));
    const merge = candidate(1, { kind: 'merge' });
    check('融合材料和非落子动作不随机改选', chooseEquivalent(merge,
      [merge, candidate(3, { kind: 'merge' })], options).action === merge);
    check('缺少完整分支不能入选', !equivalentAction(candidate(3, { branches: [] }), reference, true));
    check('随机融合最差分支下降不能入选', !equivalentAction(candidate(3, {
      branches: [{ value: 80, probability: 0.5 }, { value: 120, probability: 0.5 }],
    }), reference, true));
    check('未完成战斗推演不能入选', !equivalentAction(candidate(3, { tested: false }), reference, true));
    check('缺少战斗摘要不能入选', !equivalentAction(candidate(3, { combat: null }), reference, true));
    check('最坏漏怪增加不能入选', !equivalentAction(candidate(3, { combat: { value: 8, worstValue: 8, leaks: 1 } }), reference, true));
    check('近期战斗价值下降不能入选', !equivalentAction(candidate(3, { combat: { value: 7, worstValue: 7, leaks: 0 } }), reference, true));
    check('最差暴击样本退步不能入选', !equivalentAction(candidate(3, { combat: { value: 8, worstValue: 7, leaks: 0 } }), reference, true));
    check('动作类别不能随机切换', !equivalentAction(candidate(3, { kind: 'move' }), reference, true));
    for (const [name, extra] of [['紧急防守', { urgent: true }], ['关闭多样性', { enabled: false }]]) {
      check(name + '保持原动作', chooseEquivalent(reference, [other, reference], { ...options, ...extra }).action === reference);
    }
    for (const flag of ['committed', 'saved']) {
      const priority = candidate(1, { [flag]: true });
      check(flag + '优先级不被随机打断', chooseEquivalent(priority, [other, priority], options).action === priority);
    }
    const dig = candidate(1, { kind: 'dig', cost: 1, followup: { kind: 'buy', slot: 1, c: 1, r: 2, cost: 6 },
      followupCombat: { value: 8, worstValue: 8, leaks: 0, followupApplied: true } });
    const altDig = { ...dig, c: 3, followup: { ...dig.followup, c: 3 } };
    check('安全后续落子扩建可比较', equivalentAction(altDig, dig, true));
    check('扩建替代不偷偷更换后续购买材料', !equivalentAction({ ...altDig,
      followup: { ...altDig.followup, slot: 2 } }, dig, true));
    check('没有后续战斗检查的扩建不能入选', !equivalentAction({ ...altDig, followupCombat: null }, dig, true));
    check('延迟后不能真实落子的扩建不能入选', !equivalentAction({ ...altDig,
      followupCombat: { ...dig.followupCombat, followupApplied: false } }, dig, true));
    check('后续撤防新增漏怪的扩建不能入选', !equivalentAction({ ...altDig,
      followupCombat: { ...dig.followupCombat, leaks: 1 } }, dig, true));
    const cells = [1, 2, 3, 4].map(c => ({ c, r: 2, weight: c === 4 ? 9 : 10 }));
    const shortlist = placementShortlist(cells, 2);
    check('粗选保留完整原集合而不只是第一名', snapshot(shortlist) === snapshot(cells.slice(0, 2)));
    const hiddenBest = [{ c: 1, weight: 10, finalScore: 5 }, { c: 2, weight: 10, finalScore: 100 },
      { c: 3, weight: 10, finalScore: 1 }];
    check('粗分同分但完整价值更强的原第二名不会被挤掉', placementShortlist(hiddenBest, 2).some(cell => cell.finalScore === 100));
    const cellsBefore = snapshot(cells);
    placementShortlist(cells, 2);
    check('粗选不改输入或混入低分格', snapshot(cells) === cellsBefore && shortlist.every(cell => cell.weight === 10));
    const beforeID = Number(uid('variety').slice(7));
    Math.random = () => { throw Error('多样性不应消费正式随机'); };
    chooseEquivalent(reference, [other, reference], options);
    placementShortlist(cells, 2);
    variationKey(17, actionKey(other));
    check('纯多样性不消耗正式随机或UID', Number(uid('variety').slice(7)) === beforeID + 1);
    Math.random = original.random;
    const firstID = candidate(1, { kind: 'move', pieceId: 'p100' });
    const secondID = candidate(1, { kind: 'move', pieceId: 'p999' });
    check('盘内动作签名不依赖前局全局UID', actionKey(firstID, new Map([['p100', 0]])) ===
      actionKey(secondID, new Map([['p999', 0]])));
    const pieces = [{ id: 'p100', type: 'bing', color: 'red', c: 1, r: 2 },
      { id: 'p999', type: 'bing', color: 'red', c: 3, r: 2 }];
    const forwardKeys = registerPieceKeys(pieces), reversedKeys = registerPieceKeys([...pieces].reverse());
    const moves = [firstID, secondID];
    check('真实登记不依赖棋子数组顺序', pieces.every(p => forwardKeys.get(p.id) === reversedKeys.get(p.id)) &&
      Array.from({ length: 16 }, (_, seed) => actionKey(chooseEquivalent(firstID, moves,
        { ...options, seed, pieceKeys: forwardKeys }).action) === actionKey(chooseEquivalent(firstID, moves,
        { ...options, seed, pieceKeys: reversedKeys }).action)).every(Boolean));
    pieces[0].c = 4;
    registerPieceKeys([...pieces].reverse(), forwardKeys);
    check('棋子移动后保留已登记身份', forwardKeys.get('p100') === reversedKeys.get('p100'));

    const map = await loadMap(1);
    const fixture = () => {
      const board = createBoard('opp', map);
      const layer = fn => Array.from({ length: 5 }, (_, r) => Array.from({ length: 5 }, (_, c) => fn(c, r)));
      board.map = { ...board.map, cols: 5, rows: 5,
        ground: layer((c, r) => r === 2 && c >= 1 && c <= 3),
        road: layer((c, r) => r === 2 && c === 2),
        grass: layer((c, r) => r === 2 && (c === 1 || c === 3)), path: [{ c: 2, r: 2 }],
        kingPoint: { c: 2, r: 2 }, enemySpawn: { c: 2, r: 2 } };
      board.totalRefreshCount = 1;
      board.shopSlots[0] = { source: 'native', type: 'shovel' };
      board.shopSlots[1] = { source: 'native', type: 'piece', color: 'red' };
      board.shopSlots[2] = { source: 'native', type: 'piece', color: 'black' };
      return board;
    };
    game.phase = 'playing';
    const run = (variationSeed, variety = true) => {
      setupAI({ tier: 7 }, { seed: 17, variationSeed, variety, evaluationSlices: 32 });
      const board = fixture();
      const finish = () => {
        const count = aiInfo(board).decisions;
        withBoard(board, () => aiTick(2, 3, 7));
        for (let i = 0; i < 1000 && aiInfo(board).decisions === count; i++) withBoard(board, () => aiTick(0, 3, 7));
        if (aiInfo(board).decisions !== count + 1) throw Error('多样性决策未完成');
      };
      finish();
      const plan = aiInfo(board).plan, timer = board.aiTimer, goldAfterDig = board.gold;
      if (!plan || aiInfo(board).lastAction.kind !== 'dig' || board.pieces.length) throw Error('铲地提前落子或未保存预约');
      finish();
      const p = board.pieces[0];
      if (board.pieces.length !== 1 || p.c !== plan.c || p.r !== plan.r || board.gold !== 18 ||
          aiInfo(board).plansCompleted !== 1) throw Error('没有按随机扩建方案真实落实下一手');
      return { c: p.c, r: p.r, color: p.color, timer, goldAfterDig, gold: board.gold,
        decisions: aiInfo(board).decisions, choices: aiInfo(board).varietyChoices };
    };
    const varied = Array.from({ length: 16 }, (_, seed) => run(seed));
    check('实际铲地和落子位置随风格种子变化', new Set(varied.map(result => result.c)).size === 2);
    check('实际扩建不随机改变已选颜色和材料路线', varied.every(result => result.color === 'red'));
    check('变化不靠多花钱或多执行操作实现', varied.every(result => result.goldAfterDig === 24 && result.gold === 18 && result.decisions === 2));
    check('变化不消费操作等待随机流', new Set(varied.map(result => result.timer)).size === 1);
    check('实际布局相同风格种子可重复', snapshot(run(11)) === snapshot(run(11)));
    check('关闭多样性保留固定基线', snapshot(run(1, false)) === snapshot(run(2, false)));
    check('实际对局确有等价替代选择记录', varied.some(result => result.choices > 0));

    const delayed = fixture();
    delayed.map.cleared.add('1,2');
    const raw = snapshot(delayed), uidBefore = Number(uid('variety').slice(7));
    Math.random = () => { throw Error('私有延迟落子不应抽正式随机'); };
    const simulation = simulateCombat(delayed, { horizon: 1, actionDelay: 0.5,
      mutateAfterDelay: copy => withBoard(copy, () => act.buyAndPlace(1, 1, 2)) });
    Math.random = original.random;
    check('私有延迟落子不提前免费上场', simulation.mutationApplied && simulation.elapsed >= 0.5 - 1e-9 &&
      simulation.board.pieces.length === 1 && simulation.board.gold === delayed.gold - 6);
    check('延迟落子推演不消耗正式UID或改变源', Number(uid('variety').slice(7)) === uidBefore + 1 && snapshot(delayed) === raw);
    check('多样性与延迟推演恢复棋盘上下文', game.cur === original.cur);
    return { passed: checks.length, checks, layouts: [...new Set(varied.map(result => `${result.c},${result.r}:${result.color}`))] };
  } finally {
    Math.random = original.random;
    game.cur = original.cur;
    game.phase = original.phase;
    setupAI({ tier: 7 });
  }
}
