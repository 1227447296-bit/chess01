import { readFile } from 'node:fs/promises';
import { createPool } from './server.js';

// 只执行建表和非破坏性的新增列/索引；不建账号、不清库、不读取/输出凭据。
let pool;
try {
  pool = createPool();
  const source = await readFile(new URL('./schema.sql', import.meta.url), 'utf8');
  for (const statement of source.replace(/^--.*$/gm, '').split(';').map(s => s.trim()).filter(Boolean)) {
    await pool.query(statement);
  }
  const [columns] = await pool.execute('SHOW COLUMNS FROM matches');
  if (!columns.some(c => c.Field === 'match_uuid')) await pool.query('ALTER TABLE matches ADD COLUMN match_uuid CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL');
  if (!columns.some(c => c.Field === 'payload_hash')) await pool.query('ALTER TABLE matches ADD COLUMN payload_hash CHAR(64) CHARACTER SET ascii NULL');
  const [indexes] = await pool.execute('SHOW INDEX FROM matches');
  if (!indexes.some(i => i.Key_name === 'uq_matches_uuid')) await pool.query('ALTER TABLE matches ADD UNIQUE KEY uq_matches_uuid (match_uuid)');
  console.log('MySQL schema 已就绪；保留现有对局记录。');
} catch {
  console.error('MySQL schema 初始化失败，请检查专用账号权限、连接与表结构。未执行清库。');
  process.exitCode = 1;
} finally { if (pool) await pool.end(); }
