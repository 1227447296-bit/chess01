import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { saveMatch, validateMatch, createApiServer, createPool } from './server.js';
import { SPELLS } from './js/config.js';
const sample = () => ({
  match_uuid: '12345678-1234-4234-8234-123456789012',
  map: 'board1.tmx', rank: '青铜', result: 'win', waves: 3, duration: 12,
  my_pieces: [{ type: 'bing', color: 'red', level: 1, stage: 0, c: 4, r: 9 }],
  opp_pieces: [], spells: [{ id: SPELLS[0].id, uses: 2 }],
});
function fakePool({ failChild = false, duplicate = false, conflict = false, unavailable = false } = {}) {
  const calls = [];
  let hash;
  const connection = {
    async beginTransaction() { calls.push('begin'); },
    async execute(sql, params) {
      calls.push({ sql, params });
      if (sql.startsWith('INSERT INTO matches')) {
        hash = params[1];
        if (duplicate) throw Object.assign(new Error('duplicate'), { code: 'ER_DUP_ENTRY' });
        return [{ insertId: 41 }];
      }
      if (sql.startsWith('SELECT id, payload_hash')) return [[{ id: 41, payload_hash: conflict ? 'other' : hash }]];
      if (failChild) throw Error('child failed');
      return [{}];
    },
    async commit() { calls.push('commit'); },
    async rollback() { calls.push('rollback'); },
    release() { calls.push('release'); },
  };
  return {
    calls,
    async getConnection() { if (unavailable) throw Error('secret connection detail'); return connection; },
    async execute(sql, params) {
      calls.push({ sql, params });
      if (unavailable) throw Error('secret connection detail');
      if (sql.startsWith('SELECT 1')) return [[{ connected: 1 }]];
      if (sql.includes('WHERE id =')) return [[{ id: 41, map: 'board1.tmx' }]];
      if (sql.includes('COUNT(*) AS total')) return [[{ total: 1, wins: 1 }]];
      return [[]];
    },
  };
}
async function withServer(pool, callback) {
  const server = createApiServer(pool);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await callback(base); }
  finally { await new Promise(resolve => server.close(resolve)); }
}

test('requires explicit dedicated user; never defaults to root', () => {
  for (const env of [{}, { MYSQL_USER: 'root' }, { MYSQL_USER: 'ROOT' }]) assert.throws(() => createPool(env), /非 root/);
});
test('strict validation rejects malformed values, illegal pieces/spells and oversized collections', () => {
  validateMatch(sample());
  for (const change of [
    { result: 'unknown' }, { match_uuid: 'bad' }, { waves: '3' }, { duration: -1 },
    { map: 'x'.repeat(33) }, { my_pieces: 'bad' }, { my_pieces: Array(21).fill({}) },
    { spells: [{ id: 'not-a-spell', uses: 1 }] },
  ]) assert.throws(() => validateMatch({ ...sample(), ...change }));
  for (const change of [{ type: 'king' }, { color: 'green' }, { level: 1000 }, { stage: 4 }, { c: 8 }, { r: 16 }, { c: 0.5 }]) {
    const body = sample(); Object.assign(body.my_pieces[0], change);
    assert.throws(() => validateMatch(body));
  }
});
test('parameterized parent and children commit in one transaction', async () => {
  const pool = fakePool();
  assert.deepEqual(await saveMatch(sample(), pool), { ok: true, match_id: 41, duplicate: false });
  assert.equal(pool.calls[0], 'begin');
  assert.equal(pool.calls.at(-2), 'commit'); assert.equal(pool.calls.at(-1), 'release');
  assert.equal(pool.calls.filter(c => typeof c === 'object').length, 3);
  assert.ok(pool.calls[1].sql.includes('`rank`'));
  assert.ok(pool.calls[1].sql.includes('VALUES (?, ?, ?, ?, ?, ?, ?, ?)'));
  assert.equal(pool.calls[1].params[2], 'board1.tmx');
});
test('child failure rolls back and releases without success', async () => {
  const pool = fakePool({ failChild: true });
  await assert.rejects(saveMatch(sample(), pool), /child failed/);
  assert.ok(pool.calls.includes('rollback')); assert.ok(!pool.calls.includes('commit'));
  assert.equal(pool.calls.at(-1), 'release');
});
test('matching UUID retry returns same id; conflicting retry is 409', async () => {
  const pool = fakePool({ duplicate: true });
  assert.deepEqual(await saveMatch(sample(), pool), { ok: true, match_id: 41, duplicate: true });
  assert.ok(pool.calls.includes('rollback'));
  await assert.rejects(saveMatch(sample(), fakePool({ duplicate: true, conflict: true })), e => e.status === 409);
});
test('HTTP health, post, stats, leaderboard, recent/detail, report and static routes', async () => {
  const pool = fakePool();
  await withServer(pool, async base => {
    const health = await fetch(base + '/api/health');
    assert.deepEqual(await health.json(), { ok: true, source: 'mysql', connected: true });
    assert.equal(health.headers.get('access-control-allow-origin'), null);
    const saved = await fetch(base + '/api/match', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(sample()) });
    assert.equal(saved.status, 200); assert.equal((await saved.json()).match_id, 41);
    for (const route of ['/api/stats', '/api/leaderboard', '/api/matches', '/api/matches/41', '/report', '/', '/js/api.js']) {
      const res = await fetch(base + route);
      assert.equal(res.status, 200, route);
      if (route === '/report') {
        const html = await res.text();
        assert.ok(html.includes('累计对局'));
        assert.ok(html.includes('最近对局'));
        assert.ok(html.includes('textContent'));
        assert.ok(!html.includes('<pre'));
        const script = html.split('<script type="module">')[1].split('</script>')[0];
        const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
        assert.doesNotThrow(() => new AsyncFunction(script));
      } else await res.arrayBuffer();
    }
  });
});
test('HTTP private files, traversal, foreign Host/Origin/Fetch Metadata are denied', async () => {
  await withServer(fakePool(), async base => {
    for (const route of ['/.env', '/server.js', '/package.json', '/node_modules/mysql2/package.json', '/js/%2e%2e%5c.env', '/cloudflare/schema.sql']) {
      const response = await fetch(base + route); assert.equal(response.status, 404, route); await response.text();
    }
    for (const headers of [{ Host: 'evil.example' }, { Origin: 'https://evil.example' }, { 'Sec-Fetch-Site': 'cross-site' }]) {
      const code = await new Promise((resolve, reject) => {
        const request = http.get(base + '/api/health', { headers }, response => {
          response.resume(); response.on('end', () => resolve(response.statusCode));
        });
        request.on('error', reject);
      });
      assert.equal(code, 403, JSON.stringify(headers));
    }
  });
});
test('HTTP invalid JSON/type/size and database outage never produce ok=true', async () => {
  await withServer(fakePool({ unavailable: true }), async base => {
    for (const route of ['/api/health', '/api/stats']) {
      const response = await fetch(base + route); assert.equal(response.status, 503);
      const result = await response.json(); assert.equal(result.ok, false); assert.ok(!result.error.includes('secret'));
    }
    for (const [body, type, status] of [['{', 'application/json', 400], ['{}', 'text/plain', 415], ['x'.repeat(129 * 1024), 'application/json', 413], [JSON.stringify(sample()), 'application/json', 503]]) {
      const response = await fetch(base + '/api/match', { method: 'POST', headers: { 'Content-Type': type }, body });
      assert.equal(response.status, status); assert.equal((await response.json()).ok, false);
    }
  });
});
test('frontend MySQL rejects unconfirmed success, retains retry UUID, HTTPS stays D1', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.window = {};
  globalThis.location = { protocol: 'http:', hostname: '127.0.0.1', search: '' };
  const { uploadMatch } = await import('./js/api.js');
  try {
    assert.equal((await uploadMatch(sample())).skipped, true);
    window.__CHESS_DATA_SOURCE__ = 'mysql';
    const sent = [];
    globalThis.fetch = async (url, options) => {
      sent.push({ url, body: JSON.parse(options.body) });
      return { ok: true, status: 200, async json() { return {}; } };
    };
    const payload = sample();
    assert.equal((await uploadMatch(payload)).ok, false);
    assert.equal((await uploadMatch(payload)).ok, false);
    assert.equal(sent[0].body.match_uuid, sent[1].body.match_uuid);
    assert.equal(sent[0].url, '/api/match');
    location.protocol = 'https:'; location.hostname = 'example.workers.dev';
    globalThis.fetch = async (url, options) => {
      assert.equal(url, '/api/match'); assert.equal(JSON.parse(options.body).match_uuid, payload.match_uuid);
      return { ok: true, async json() { return { ok: true, match_id: 1 }; } };
    };
    assert.equal((await uploadMatch(payload)).ok, true);
  } finally { globalThis.fetch = originalFetch; delete globalThis.window; delete globalThis.location; }
});
