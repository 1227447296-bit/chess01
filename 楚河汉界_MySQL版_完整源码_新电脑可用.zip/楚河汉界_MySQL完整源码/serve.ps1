# ============================================================
# serve.ps1 -- Zero-dependency local static server (PowerShell)
# Serves this folder over HTTP so the browser can load .tmx and
# ES modules (file:// is blocked by CORS).
#
# This file is intentionally ASCII-only so it works regardless of
# the machine's ANSI codepage.
#
# Usage:  powershell -ExecutionPolicy Bypass -File serve.ps1
#         (optionally) -Port 8090   to force a specific port
# ============================================================

param(
  [int]$Port = 8092,       # independent experimental server
  [string]$Root = $PSScriptRoot,
  [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'

$mime = @{
  '.html' = 'text/html; charset=utf-8'
  '.htm'  = 'text/html; charset=utf-8'
  '.js'   = 'text/javascript; charset=utf-8'
  '.mjs'  = 'text/javascript; charset=utf-8'
  '.css'  = 'text/css; charset=utf-8'
  '.json' = 'application/json; charset=utf-8'
  '.xml'  = 'application/xml; charset=utf-8'
  '.tmx'  = 'application/xml; charset=utf-8'
  '.tsx'  = 'application/xml; charset=utf-8'
  '.png'  = 'image/png'
  '.jpg'  = 'image/jpeg'
  '.jpeg' = 'image/jpeg'
  '.gif'  = 'image/gif'
  '.svg'  = 'image/svg+xml'
  '.ttf'  = 'font/ttf'
  '.otf'  = 'font/otf'
  '.woff' = 'font/woff'
  '.woff2'= 'font/woff2'
  '.txt'  = 'text/plain; charset=utf-8'
}

# Candidate ports when auto-picking (the first free one wins)
$candidates = @(8080, 8081, 8088, 8090, 3000, 5173, 5500, 8000)

function Start-Listener([int[]]$ports) {
  foreach ($p in $ports) {
    $l = New-Object System.Net.HttpListener
    $l.Prefixes.Add("http://localhost:$p/")
    try {
      $l.Start()
      return @{ Listener = $l; Port = $p }
    } catch {
      try { $l.Close() } catch {}
      Write-Host "  port $p busy, trying next..." -ForegroundColor DarkYellow
    }
  }
  return $null
}

if ($Port -gt 0) { $candidates = @($Port) }

$started = Start-Listener $candidates
if (-not $started) {
  Write-Host "ERROR: no free port among: $($candidates -join ', ')" -ForegroundColor Red
  Write-Host "Close other servers or pass a specific free port, e.g.:"
  Write-Host "  powershell -ExecutionPolicy Bypass -File serve.ps1 -Port 8123"
  Read-Host "Press Enter to exit"
  exit 1
}

$listener = $started.Listener
$port = $started.Port
$url = "http://localhost:$port/"

Write-Host ""
Write-Host "==============================================" -ForegroundColor Green
Write-Host "  Chess Tower Defense - local server running" -ForegroundColor Green
Write-Host "  Root : $Root"
Write-Host "  Open : $url" -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Green
Write-Host "  Opening your browser..."
Write-Host "  Keep this window open. Close it to stop."
Write-Host ""

if (-not $NoBrowser) { Start-Process $url }

while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext()
  } catch { break }

  $req = $ctx.Request
  $res = $ctx.Response

  try {
    $rel = [System.Uri]::UnescapeDataString($req.Url.AbsolutePath).TrimStart('/')
    if ([string]::IsNullOrWhiteSpace($rel)) { $rel = 'index.html' }
    $rel = $rel -replace '/', '\'

    # List only existing maps; no speculative 404 requests from the browser.
    if ($rel -eq 'board\maps.json') {
      $maps = @(Get-ChildItem -LiteralPath (Join-Path $Root 'board') -File | Where-Object { $_.Name -match '^board\d+\.tmx$' } | Sort-Object Name | ForEach-Object { $_.Name })
      $json = ConvertTo-Json -InputObject $maps -Compress
      $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
      $res.ContentType = 'application/json; charset=utf-8'
      $res.ContentLength64 = $bytes.Length
      $res.Headers.Add('Cache-Control', 'no-cache')
      $res.OutputStream.Write($bytes, 0, $bytes.Length)
      continue
    }

    $full = Join-Path $Root $rel

    $fullResolved = [System.IO.Path]::GetFullPath($full)
    $rootResolved = [System.IO.Path]::GetFullPath($Root)
    if (-not $fullResolved.StartsWith($rootResolved, [System.StringComparison]::OrdinalIgnoreCase)) {
      $res.StatusCode = 403
      $res.Close()
      continue
    }

    if (Test-Path -LiteralPath $fullResolved -PathType Leaf) {
      $ext = [System.IO.Path]::GetExtension($fullResolved).ToLower()
      $type = $mime[$ext]
      if (-not $type) { $type = 'application/octet-stream' }
      $bytes = [System.IO.File]::ReadAllBytes($fullResolved)
      $res.ContentType = $type
      $res.ContentLength64 = $bytes.Length
      $res.Headers.Add('Cache-Control', 'no-store, no-cache, must-revalidate')
      $res.OutputStream.Write($bytes, 0, $bytes.Length)
      Write-Host ("  200  " + $rel) -ForegroundColor DarkGray
    } else {
      $res.StatusCode = 404
      $msg = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found: $rel")
      $res.ContentType = 'text/plain; charset=utf-8'
      $res.ContentLength64 = $msg.Length
      $res.OutputStream.Write($msg, 0, $msg.Length)
      Write-Host ("  404  " + $rel) -ForegroundColor DarkYellow
    }
  } catch {
    try { $res.StatusCode = 500 } catch {}
    Write-Host "  500  $($_.Exception.Message)" -ForegroundColor Red
  } finally {
    try { $res.OutputStream.Close() } catch {}
    try { $res.Close() } catch {}
  }
}

$listener.Stop()
Write-Host "Server stopped." -ForegroundColor Yellow
