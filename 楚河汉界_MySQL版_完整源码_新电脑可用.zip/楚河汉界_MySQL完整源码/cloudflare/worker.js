/**
 * cloudflare/worker.js —— 楚河汉界 Cloudflare Worker
 *
 * 游戏页面、脚本、图片、地图等静态文件由 Workers Static Assets 直接提供，不经过本脚本；
 * 只有没有对应静态文件的请求（即 /api/*）才会进入这里，读写 D1 数据库。
 *
 * 绑定（见根目录 wrangler.jsonc）：
 *   env.DB     – D1 数据库
 *   env.ASSETS – 静态文件
 *
 * 接口：
 *   POST /api/match        上传一局对局记录
 *   GET  /api/stats        汇总统计
 *   GET  /api/leaderboard  胜局排行（按坚持波数）
 */

const RESULTS = new Set(['win', 'lose', 'draw']);

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors() });

    try {
      const route = `${request.method} ${url.pathname}`;
      if (route === 'POST /api/match') return await saveMatch(request, env);
      if (route === 'GET /api/stats') return await stats(env);
      if (route === 'GET /api/leaderboard') return await leaderboard(env);
      return json({ error: '接口不存在' }, 404);
    } catch (err) {
      return json({ error: String(err?.message || err) }, 500);
    }
  },
};

/** 上传一局：对局、双方结束时的棋子、我方用过的计策，在一个批处理里原子写入。 */
async function saveMatch(request, env) {
  let body;
  try { body = await request.json(); } catch { return json({ error: '请求不是合法的 JSON' }, 400); }
  if (!RESULTS.has(body?.result)) return json({ error: 'result 必须是 win/lose/draw' }, 400);

  const text = (v, max) => String(v ?? '').slice(0, max);
  const int = v => Math.max(0, Math.min(1e6, Math.round(Number(v) || 0)));

  const inserted = await env.DB.prepare(
    `INSERT INTO matches (map, rank, result, waves, duration_sec, created_at)
     VALUES (?, ?, ?, ?, ?, ?) RETURNING id`,
  ).bind(text(body.map, 32), text(body.rank, 32), body.result,
    int(body.waves), int(body.duration), new Date().toISOString()).first();
  const matchId = inserted.id;

  const rows = [];
  for (const [side, list] of [['me', body.my_pieces], ['opp', body.opp_pieces]]) {
    for (const p of (Array.isArray(list) ? list : []).slice(0, 20)) {
      rows.push(env.DB.prepare(
        `INSERT INTO match_pieces (match_id, side, type, color, level, stage, c, r)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      ).bind(matchId, side, text(p.type, 8), text(p.color, 8), int(p.level), int(p.stage), int(p.c), int(p.r)));
    }
  }
  for (const s of (Array.isArray(body.spells) ? body.spells : []).slice(0, 36)) {
    rows.push(env.DB.prepare(
      'INSERT INTO match_spells (match_id, spell_id, uses) VALUES (?, ?, ?)',
    ).bind(matchId, text(s.id, 32), int(s.uses)));
  }
  if (rows.length) await env.DB.batch(rows);

  return json({ ok: true, match_id: matchId });
}

/** 汇总统计：总体胜负与平均波数、各地图胜率、我方常用棋子。 */
async function stats(env) {
  const [totals, byMap, pieces] = await env.DB.batch([
    env.DB.prepare(`
      SELECT COUNT(*) AS total,
             SUM(result = 'win')  AS wins,
             SUM(result = 'lose') AS losses,
             SUM(result = 'draw') AS draws,
             ROUND(AVG(waves), 1)        AS avg_waves,
             ROUND(AVG(duration_sec), 0) AS avg_duration_sec
      FROM matches`),
    env.DB.prepare(`
      SELECT map, COUNT(*) AS games,
             ROUND(100.0 * SUM(result = 'win') / COUNT(*), 1) AS win_pct
      FROM matches GROUP BY map ORDER BY games DESC LIMIT 10`),
    env.DB.prepare(`
      SELECT type, color, COUNT(*) AS appearances, ROUND(AVG(level), 1) AS avg_level
      FROM match_pieces WHERE side = 'me'
      GROUP BY type, color ORDER BY appearances DESC LIMIT 20`),
  ]);
  return json({ totals: totals.results[0], by_map: byMap.results, piece_usage: pieces.results });
}

/** 胜局排行：坚持波数多者在前，同波数用时短者在前。 */
async function leaderboard(env) {
  const { results } = await env.DB.prepare(`
    SELECT rank, waves, duration_sec, map, created_at
    FROM matches WHERE result = 'win'
    ORDER BY waves DESC, duration_sec ASC LIMIT 20`).all();
  return json({ leaderboard: results });
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status, headers: { 'Content-Type': 'application/json; charset=utf-8', ...cors() },
  });
}

function cors() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };
}
