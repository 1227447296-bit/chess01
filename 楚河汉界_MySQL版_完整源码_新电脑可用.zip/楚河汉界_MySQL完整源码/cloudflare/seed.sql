-- 楚河汉界：演示用测试数据（毕业设计截图用）
-- 执行：wrangler.cmd d1 execute cn-chess-db --remote --file=cloudflare/seed.sql
-- 这些是人工构造的测试数据，编号 1001～1012；重复执行会先删除再重新写入，不影响真实对局记录。

DELETE FROM match_spells WHERE match_id BETWEEN 1001 AND 1012;
DELETE FROM match_pieces WHERE match_id BETWEEN 1001 AND 1012;
DELETE FROM matches      WHERE id       BETWEEN 1001 AND 1012;

INSERT INTO matches (id, map, rank, result, waves, duration_sec, created_at) VALUES
  (1001, 'board1.tmx',  '塑料 1 段',   'win',  9,  412, '2026-10-20T10:12:00Z'),
  (1002, 'board3.tmx',  '塑料 2 段',   'win',  11, 498, '2026-10-20T10:31:00Z'),
  (1003, 'board2.tmx',  '陶瓷 1 段',   'lose', 8,  371, '2026-10-21T14:05:00Z'),
  (1004, 'board5.tmx',  '陶瓷 1 段',   'win',  13, 602, '2026-10-21T14:22:00Z'),
  (1005, 'board1.tmx',  '陶瓷 2 段',   'win',  15, 688, '2026-10-22T19:40:00Z'),
  (1006, 'board7.tmx',  '不锈钢 1 段', 'lose', 12, 560, '2026-10-22T20:03:00Z'),
  (1007, 'board4.tmx',  '不锈钢 1 段', 'win',  17, 781, '2026-10-23T09:15:00Z'),
  (1008, 'board9.tmx',  '不锈钢 2 段', 'draw', 16, 735, '2026-10-23T09:48:00Z'),
  (1009, 'board3.tmx',  '钛合金 1 段', 'win',  20, 934, '2026-10-24T16:20:00Z'),
  (1010, 'board6.tmx',  '钛合金 1 段', 'lose', 15, 702, '2026-10-24T16:51:00Z'),
  (1011, 'board10.tmx', '钛合金 2 段', 'win',  22, 1043, '2026-10-25T21:07:00Z'),
  (1012, 'board8.tmx',  '黄金 1 段',   'lose', 19, 896, '2026-10-25T21:40:00Z');

INSERT INTO match_pieces (match_id, side, type, color, level, stage, c, r) VALUES
  (1001, 'me',  'bing',  'red',   12, 1, 1, 1), (1001, 'me',  'bing',  'black', 10, 0, 1, 2), (1001, 'opp', 'bing', 'red', 9, 1, 2, 1),
  (1002, 'me',  'shi',   'red',   16, 0, 1, 2), (1002, 'me',  'bing',  'red',   11, 2, 2, 4), (1002, 'opp', 'bing', 'black', 12, 1, 1, 1),
  (1003, 'me',  'bing',  'red',   8,  1, 1, 1), (1003, 'opp', 'xiang', 'black', 15, 0, 2, 3),
  (1004, 'me',  'xiang', 'black', 21, 0, 1, 4), (1004, 'me',  'shi',   'black', 18, 1, 2, 5), (1004, 'opp', 'shi', 'red', 14, 0, 1, 2),
  (1005, 'me',  'ma',    'red',   33, 0, 1, 2), (1005, 'me',  'bing',  'red',   20, 1, 2, 4), (1005, 'opp', 'xiang', 'red', 19, 1, 2, 2),
  (1006, 'me',  'pao',   'black', 29, 1, 0, 3), (1006, 'me',  'bing',  'red',   22, 2, 0, 4), (1006, 'opp', 'ju', 'red', 35, 0, 1, 1),
  (1007, 'me',  'ju',    'red',   46, 1, 0, 1), (1007, 'me',  'shi',   'red',   30, 2, 1, 2), (1007, 'opp', 'ma', 'black', 31, 1, 2, 3),
  (1008, 'me',  'ma',    'black', 44, 1, 1, 3), (1008, 'me',  'xiang', 'black', 30, 0, 2, 2), (1008, 'opp', 'pao', 'red', 42, 1, 0, 2),
  (1009, 'me',  'pao',   'red',   58, 2, 0, 2), (1009, 'me',  'ju',    'black', 51, 1, 1, 0), (1009, 'opp', 'ma', 'red', 47, 1, 2, 3),
  (1010, 'me',  'ma',    'red',   40, 1, 1, 3), (1010, 'opp', 'ju',    'black', 55, 2, 0, 1), (1010, 'opp', 'pao', 'red', 49, 1, 1, 2),
  (1011, 'me',  'ju',    'red',   72, 3, 0, 1), (1011, 'me',  'pao',   'black', 66, 2, 1, 2), (1011, 'opp', 'ma', 'black', 60, 2, 2, 3),
  (1012, 'me',  'ma',    'black', 61, 2, 1, 3), (1012, 'opp', 'ju',    'red',   74, 3, 0, 1), (1012, 'opp', 'pao', 'black', 68, 2, 1, 2);

INSERT INTO match_spells (match_id, spell_id, uses) VALUES
  (1002, 'yiyidailao', 1), (1004, 'mantianguohai', 1), (1005, 'yiyidailao', 1),
  (1006, 'dacaojingshe', 1), (1007, 'xiaolicangdao', 1), (1007, 'yiyidailao', 1),
  (1009, 'jiedaosharen', 1), (1009, 'shushangkaihua', 1), (1010, 'dacaojingshe', 1),
  (1011, 'lidaitaojiang', 1), (1011, 'xiaolicangdao', 1), (1012, 'fanjianji', 1);
