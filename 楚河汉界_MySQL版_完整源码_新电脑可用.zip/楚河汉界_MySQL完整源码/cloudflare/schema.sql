-- 楚河汉界对局记录：Cloudflare D1 建表 SQL
-- 执行：wrangler d1 execute cn-chess-db --remote --file=cloudflare/schema.sql
-- 也可以在 Cloudflare 控制台 D1 数据库的 Console 中粘贴执行。

CREATE TABLE IF NOT EXISTS matches (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  map          TEXT    NOT NULL,
  rank         TEXT    NOT NULL DEFAULT '',
  result       TEXT    NOT NULL CHECK(result IN ('win','lose','draw')),
  waves        INTEGER NOT NULL DEFAULT 0,
  duration_sec INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS match_pieces (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  match_id INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  side     TEXT    NOT NULL CHECK(side IN ('me','opp')),
  type     TEXT    NOT NULL,
  color    TEXT    NOT NULL,
  level    INTEGER NOT NULL DEFAULT 0,
  stage    INTEGER NOT NULL DEFAULT 0,
  c        INTEGER NOT NULL DEFAULT 0,
  r        INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS match_spells (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  match_id INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  spell_id TEXT    NOT NULL,
  uses     INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_matches_result ON matches(result);
CREATE INDEX IF NOT EXISTS idx_matches_map    ON matches(map);
CREATE INDEX IF NOT EXISTS idx_pieces_match   ON match_pieces(match_id);
