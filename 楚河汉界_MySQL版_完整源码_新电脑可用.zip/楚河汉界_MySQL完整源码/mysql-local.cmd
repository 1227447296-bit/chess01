@echo off
setlocal EnableExtensions DisableDelayedExpansion
rem Always load the project-local .env, regardless of the caller's directory.
pushd "%~dp0" || exit /b 1
set "NODE_EXE="
for /f "delims=" %%I in ('where node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%I"
if defined NODE_EXE goto node_found
if exist "%USERPROFILE%\nodejs-v24\node.exe" set "NODE_EXE=%USERPROFILE%\nodejs-v24\node.exe"
if defined NODE_EXE goto node_found
if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if defined NODE_EXE goto node_found
echo ERROR: Node.js 24+ not found. Install it and add it to PATH.
goto fail

:node_found
"%NODE_EXE%" -e "process.exit(Number(process.versions.node.split('.')[0]) >= 24 ? 0 : 1)"
if errorlevel 1 (
  echo ERROR: Node.js 24+ is required. Update the Node executable selected from PATH.
  goto fail
)
for %%I in ("%NODE_EXE%") do set "NODE_DIR=%%~dpI"
set "PATH=%NODE_DIR%;%PATH%"
set "NPM_CMD=%NODE_DIR%npm.cmd"
if exist "%NPM_CMD%" goto npm_found
set "NPM_CMD="
for /f "delims=" %%I in ('where npm.cmd 2^>nul') do if not defined NPM_CMD set "NPM_CMD=%%I"
if defined NPM_CMD goto npm_found
echo ERROR: npm.cmd not found. Install a complete Node.js distribution.
goto fail

:npm_found
if "%~1"=="" goto start
if /i "%~1"=="start" goto start
if /i "%~1"=="install" goto install
if /i "%~1"=="setup" goto setup
if /i "%~1"=="test" goto test
echo Usage: mysql-local.cmd [install ^| setup ^| test ^| start]
echo install = npm ci; setup = npm run db:setup; test = npm run test:mysql-api
echo start = npm run start:mysql, using project-local .env
goto fail

:install
call "%NPM_CMD%" ci
goto done
:setup
call "%NPM_CMD%" run db:setup
goto done
:test
call "%NPM_CMD%" run test:mysql-api
goto done
:start
if not exist ".env" (
  echo ERROR: Missing project-local .env. Create it from .env.example and configure a dedicated MySQL user.
  goto fail
)
call "%NPM_CMD%" run start:mysql
goto done

:fail
popd
exit /b 1
:done
set "RESULT=%ERRORLEVEL%"
popd
exit /b %RESULT%
