﻿# 论文对照实验批量运行脚本：逐个 (实验组, 变体, 地图) 调用浏览器内 benchmarkAI，结果逐行追加到 results.jsonl。
# 已完成的组合会跳过，中断后重新运行即可续跑。
param([string]$Out = 'E:\cn chess experimental\experiments\results.jsonl')
$ErrorActionPreference = 'Stop'
$cdp = 'E:\cn chess experimental\test-ai-cdp.ps1'
$maps = 1..10
$seeds = '[11,23,37]'
$runs = @()
# 实验一：基线对比
foreach ($v in @(@('baseline','random','{"strategy":"random"}'), @('baseline','greedy','{"noSimulation":true}'), @('baseline','full','null'))) { $runs += ,$v }
# 实验二：风险系数 λ 消融（full 的默认 λ=0.5 已在实验一中）
foreach ($l in '0','0.25','0.75','1') { $runs += ,@('risk', "lambda$l", "{`"risk`":$l}") }
# 实验三：推演时长（full 的默认 8 秒已在实验一中）
foreach ($h in '4','12') { $runs += ,@('horizon', "h$h", "{`"horizon`":$h}") }
# 实验四：难度分级（单种子，关闭新手模式以单独观察档位参数）
foreach ($t in 0..7) { $runs += ,@('tier', "tier$t", "TIER:$t") }

$done = @{}
if (Test-Path $Out) { Get-Content $Out | ForEach-Object { $o = $_ | ConvertFrom-Json; $done["$($o.group)|$($o.variant)|$($o.map)"] = $true } }
$frame = ((& $cdp -Method Page.getFrameTree | ConvertFrom-Json).result.frameTree.frame.id)
foreach ($r in $runs) {
  foreach ($m in $maps) {
    $key = "$($r[0])|$($r[1])|$m"
    if ($done[$key]) { continue }
    $ctx = ((& $cdp -Method Page.createIsolatedWorld -ParamsJson (@{ frameId = $frame; worldName = "exp-$($r[1])-$m" } | ConvertTo-Json -Compress) | ConvertFrom-Json).result.executionContextId)
    if ($r[2] -like 'TIER:*') { $tier = $r[2].Substring(5); $opts = "{rankTier:$tier,lowRankMode:'normal'}"; $sd = '[11]' }
    else { $opts = "{rankTier:7,experiment:$($r[2])}"; $sd = $seeds }
    $expr = @"
(async()=>{const b=await import('/js/aiBenchmark.test.js?run=$($r[1])-$m');
const rs=await b.benchmarkAI(['$m'],$sd,1800,$opts);
return rs.map(r=>({group:'$($r[0])',variant:'$($r[1])',map:$m,seed:r.seed,wave:r.wave,gameSec:r.time,lives:r.lives,leaks:r.leaks,
firstLeakAt:r.firstLeakAt,kills:r.kills,decisions:r.decisions,avgMs:r.avgMsPerTick,peakMs:r.peakMs,actions:r.actions,
pieces:r.pieces}));})()
"@
    $params = @{ expression = $expr; contextId = $ctx; awaitPromise = $true; returnByValue = $true } | ConvertTo-Json -Compress
    $raw = & $cdp -Method Runtime.evaluate -ParamsJson $params -TimeoutSeconds 600
    $rows = ($raw | ConvertFrom-Json).result.result.value
    foreach ($row in $rows) { Add-Content -LiteralPath $Out -Value ($row | ConvertTo-Json -Compress -Depth 6) -Encoding UTF8 }
    Write-Host ("{0} map{1}: waves {2}" -f $r[1], $m, (($rows | ForEach-Object { $_.wave }) -join ','))
  }
}
Write-Host 'ALL DONE'
