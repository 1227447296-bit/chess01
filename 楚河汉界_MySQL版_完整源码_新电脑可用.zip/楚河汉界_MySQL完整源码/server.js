import http from 'node:http';
import { readFile, realpath } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import mysql from 'mysql2/promise';
import { PIECE_STATS, COLORS, SPELL_BY_ID } from './js/config.js';

export const ROOT = path.dirname(fileURLToPath(import.meta.url));
const MAX_BODY_BYTES = 128 * 1024;
const RESULTS = new Set(['win', 'lose', 'draw']);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export function createPool(env = process.env) {
  if (!env.MYSQL_USER || env.MYSQL_USER.toLowerCase() === 'root') {
    throw new Error('MYSQL_USER 必须配置为专用非 root 账号');
  }
  if (!env.MYSQL_DATABASE) throw new Error('MYSQL_DATABASE 必须配置');
  return mysql.createPool({
    host: env.MYSQL_HOST || '127.0.0.1', port: Number(env.MYSQL_PORT || 3306),
    user: env.MYSQL_USER, password: env.MYSQL_PASSWORD || '', database: env.MYSQL_DATABASE,
    connectionLimit: 5, waitForConnections: true, queueLimit: 20, connectTimeout: 5000,
    charset: 'utf8mb4', timezone: 'Z', supportBigNumbers: true, bigNumberStrings: true,
  });
}

function invalid(message, status = 400) {
  return Object.assign(new Error(message), { status });
}
function object(value, name) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw invalid(`${name} 必须是对象`);
}
function text(value, name, max, empty = false) {
  if (typeof value !== 'string' || value.length > max || (!empty && !value.length) || /[\u0000-\u001f]/.test(value)) {
    throw invalid(`${name} 必须是${empty ? '0' : '1'}..${max}字符字符串`);
  }
  return value;
}
function int(value, name, min, max) {
  if (!Number.isSafeInteger(value) || value < min || value > max) throw invalid(`${name} 必须是 ${min}..${max} 整数`);
  return value;
}
function list(value, name, max) {
  if (!Array.isArray(value) || value.length > max) throw invalid(`${name} 必须是最多 ${max} 项的数组`);
  return value;
}
export function validateMatch(body) {
  object(body, '请求');
  if (typeof body.match_uuid !== 'string' || !UUID.test(body.match_uuid)) throw invalid('match_uuid 必须是 UUID v4');
  if (!RESULTS.has(body.result)) throw invalid('result 必须是 win/lose/draw');
  text(body.map, 'map', 32); text(body.rank, 'rank', 32, true);
  int(body.waves, 'waves', 0, 1000000); int(body.duration, 'duration', 0, 1000000);
  for (const name of ['my_pieces', 'opp_pieces']) {
    for (const piece of list(body[name], name, 20)) {
      object(piece, 'piece');
      if (typeof piece.type !== 'string' || !Object.hasOwn(PIECE_STATS, piece.type)) throw invalid('非法棋种');
      if (typeof piece.color !== 'string' || !Object.hasOwn(COLORS, piece.color)) throw invalid('非法颜色');
      int(piece.level, 'level', 0, 999); int(piece.stage, 'stage', 0, 3);
      // 当前资源地图至多 8x16；棋子只记录结束时格坐标，不记录行为回放。
      int(piece.c, 'c', 0, 7); int(piece.r, 'r', 0, 15);
    }
  }
  const seen = new Set();
  for (const spell of list(body.spells, 'spells', 36)) {
    object(spell, 'spell');
    if (typeof spell.id !== 'string' || !Object.hasOwn(SPELL_BY_ID, spell.id)) throw invalid('非法计策');
    if (seen.has(spell.id)) throw invalid('重复计策');
    seen.add(spell.id);
    int(spell.uses, 'uses', 1, 1000000);
  }
  return body;
}
function canonical(body) {
  const pieces = items => items.map(p => [p.type, p.color, p.level, p.stage, p.c, p.r]);
  return JSON.stringify([body.map, body.rank, body.result, body.waves, body.duration,
    pieces(body.my_pieces), pieces(body.opp_pieces), body.spells.map(s => [s.id, s.uses])]);
}
export async function saveMatch(body, pool) {
  validateMatch(body);
  const hash = createHash('sha256').update(canonical(body)).digest('hex');
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [result] = await connection.execute(
      'INSERT INTO matches (match_uuid, payload_hash, map, `rank`, result, waves, duration_sec, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [body.match_uuid, hash, body.map, body.rank, body.result, body.waves, body.duration, new Date().toISOString().slice(0, 19).replace('T', ' ')],
    );
    const matchId = result.insertId;
    for (const [side, pieces] of [['me', body.my_pieces], ['opp', body.opp_pieces]]) {
      for (const p of pieces) {
        await connection.execute(
          'INSERT INTO match_pieces (match_id, side, type, color, level, stage, c, r) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
          [matchId, side, p.type, p.color, p.level, p.stage, p.c, p.r],
        );
      }
    }
    for (const spell of body.spells) {
      await connection.execute('INSERT INTO match_spells (match_id, spell_id, uses) VALUES (?, ?, ?)', [matchId, spell.id, spell.uses]);
    }
    await connection.commit();
    return { ok: true, match_id: matchId, duplicate: false };
  } catch (error) {
    await connection.rollback();
    if (error.code === 'ER_DUP_ENTRY') {
      const [rows] = await connection.execute('SELECT id, payload_hash FROM matches WHERE match_uuid = ?', [body.match_uuid]);
      if (rows.length && rows[0].payload_hash === hash) return { ok: true, match_id: rows[0].id, duplicate: true };
      throw invalid('match_uuid 已存在但摘要不一致', 409);
    }
    throw error;
  } finally { connection.release(); }
}

function send(response, status, value, type = 'application/json; charset=utf-8') {
  response.writeHead(status, {
    'Content-Type': type, 'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'no-store', 'Referrer-Policy': 'same-origin',
    'Cross-Origin-Resource-Policy': 'same-origin',
  });
  response.end(type.startsWith('application/json') ? JSON.stringify(value) : value);
}
async function readBody(request) {
  if (!/^application\/json(?:\s*;|$)/i.test(request.headers['content-type'] || '')) throw invalid('仅接受 application/json', 415);
  if (Number(request.headers['content-length']) > MAX_BODY_BYTES) throw invalid('请求体过大', 413);
  let size = 0;
  const chunks = [];
  for await (const chunk of request) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw invalid('请求体过大', 413);
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw invalid('请求不是合法 JSON'); }
}
function secureRequest(request) {
  const localPort = request.socket.localPort;
  const hosts = new Set([`127.0.0.1:${localPort}`, `localhost:${localPort}`]);
  if (!hosts.has(request.headers.host)) throw invalid('Host 不允许', 403);
  if (request.headers.origin && request.headers.origin !== `http://${request.headers.host}`) throw invalid('仅允许同源请求', 403);
  const site = request.headers['sec-fetch-site'];
  if (site && !['same-origin', 'none'].includes(site)) throw invalid('跨站请求被拒绝', 403);
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.tmx': 'application/xml', '.tsx': 'application/xml', '.png': 'image/png', '.webp': 'image/webp', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.ttf': 'font/ttf', '.woff': 'font/woff', '.woff2': 'font/woff2' };
async function staticFile(url, response) {
  let name;
  try { name = decodeURIComponent(url.pathname); } catch { throw invalid('无效路径'); }
  if (name === '/') name = '/index.html';
  if (name.includes('\\') || name.split('/').some(part => part === '..' || part.startsWith('.'))) throw invalid('不允许的路径', 404);
  if (!(name === '/index.html' || name === '/front-home.webp' || /^\/(js|css|board|assets|piece|font)\//.test(name))) throw invalid('文件不存在', 404);
  const type = MIME[path.extname(name).toLowerCase()];
  if (!type) throw invalid('文件类型不允许', 404);
  try {
    const expected = path.join(ROOT, name);
    const target = await realpath(expected);
    const root = await realpath(ROOT);
    if (!target.startsWith(root + path.sep) || target.toLowerCase() !== expected.toLowerCase()) throw invalid('文件不存在', 404);
    const content = await readFile(target);
    // JSON 静态资源不可再次 JSON.stringify。
    response.writeHead(200, { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', 'Cross-Origin-Resource-Policy': 'same-origin' });
    response.end(content);
  } catch (error) {
    if (error.status) throw error;
    throw invalid('文件不存在', 404);
  }
}
async function stats(pool) {
  const [totals] = await pool.execute("SELECT COUNT(*) AS total, COALESCE(SUM(result = 'win'),0) AS wins, COALESCE(SUM(result = 'lose'),0) AS losses, COALESCE(SUM(result = 'draw'),0) AS draws, ROUND(AVG(waves),1) AS avg_waves, ROUND(AVG(duration_sec),0) AS avg_duration_sec FROM matches");
  const [by_map] = await pool.execute("SELECT map, COUNT(*) AS games, ROUND(100.0 * SUM(result = 'win') / COUNT(*),1) AS win_pct FROM matches GROUP BY map ORDER BY games DESC LIMIT 10");
  const [piece_usage] = await pool.execute("SELECT type, color, COUNT(*) AS appearances, ROUND(AVG(level),1) AS avg_level FROM match_pieces WHERE side = 'me' GROUP BY type,color ORDER BY appearances DESC LIMIT 20");
  return { totals: totals[0], by_map, piece_usage };
}
const reportHtml = `<!doctype html>
<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MySQL 对局摘要报告</title>
<style>
*{box-sizing:border-box}body{font:16px/1.5 "Microsoft YaHei",sans-serif;background:#f4efE5;color:#342619;margin:0;padding:28px}main{max-width:1160px;margin:auto}header{display:flex;justify-content:space-between;align-items:center;gap:16px}h1{font-size:28px;margin:0}h2{font-size:20px;margin:0 0 14px}p{margin:8px 0}a{color:#77501e}header a{white-space:nowrap}.subtitle,.muted{color:#796e60;font-size:14px}.status{background:#e9f2e4;border:1px solid #b2c8a6;border-radius:10px;padding:12px 18px;margin:18px 0}.status.failed{background:#fce6e2;border-color:#c9867c}.cards{display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin-bottom:20px}.card,section{background:#fffcf5;border:1px solid #d9c8ad;border-radius:12px}.card{padding:16px;text-align:center}.card span{display:block;font-size:14px;color:#796e60}.card b{font-size:28px;font-weight:700;color:#64411c}section{padding:20px;margin:16px 0}table{width:100%;border-collapse:collapse;font-size:15px}th{text-align:left;background:#efe5d3;color:#75532d;font-weight:600}td,th{padding:10px 12px;border-bottom:1px solid #e8dfd1}tr:last-child td{border-bottom:0}.win{color:#357139;font-weight:bold}.lose{color:#a64435;font-weight:bold}.draw{color:#776346;font-weight:bold}.table-wrap{overflow:auto}.section-head{display:flex;justify-content:space-between;align-items:center;gap:12px}.section-head a{font-size:14px}.columns{display:grid;grid-template-columns:1fr 1fr;gap:16px}.columns section{margin:0}.empty{color:#887763}footer{font-size:13px;color:#887763;margin-top:18px}@media(max-width:760px){body{padding:14px}.cards{grid-template-columns:repeat(3,1fr)}.columns{grid-template-columns:1fr}header{align-items:flex-start}h1{font-size:23px}.card b{font-size:23px}td,th{padding:8px}}
</style>
<main>
<header><div><h1>实验版 · 对局数据报告</h1><p class="subtitle">本地 MySQL / Node API · 结束对局摘要 · 只读查询</p></div><a href="/?dataSource=mysql">返回游戏（MySQL 模式）</a></header>
<div id="status" class="status" role="status">正在检查 MySQL 连接并读取真实记录…</div>
<div class="cards" id="cards"></div>
<section><div class="section-head"><h2>最近对局</h2><a href="/api/matches" target="_blank" rel="noopener">查看最近 20 局 API</a></div><div class="table-wrap"><table><thead><tr><th>对局 ID</th><th>地图</th><th>结果</th><th>波数</th><th>时长</th><th>记录详情</th></tr></thead><tbody id="recent"></tbody></table></div><p class="muted">展示最近 8 局；详情包含双方棋子快照与已使用计策。</p></section>
<div class="columns">
<section><h2>胜局排行 · 前 5 名</h2><div class="table-wrap"><table><thead><tr><th>对局</th><th>段位</th><th>波数</th><th>时长</th></tr></thead><tbody id="leaders"></tbody></table></div></section>
<section><h2>地图统计 · 前 5 项</h2><div class="table-wrap"><table><thead><tr><th>地图</th><th>对局数</th><th>胜率</th></tr></thead><tbody id="maps"></tbody></table></div></section>
</div>
<footer>本报告通过同源 API 实时读取 MySQL；连接或查询失败会明确显示，不生成模拟数据。仅保存结束对局摘要，不收集实时操作。</footer>
</main>
<script type="module">
const element = id => document.getElementById(id);
const results = {win:'胜利',lose:'失败',draw:'平局'};
const shown = value => value === null || value === undefined ? '—' : String(value);
function row(target, values, resultIndex = -1, result = '') {
  const tr = document.createElement('tr');
  values.forEach((value,index) => {
    const td = document.createElement('td');
    if (value instanceof Node) td.appendChild(value); else td.textContent = shown(value);
    if(index === resultIndex && ['win','lose','draw'].includes(result)) td.className = result;
    tr.appendChild(td);
  });
  element(target).appendChild(tr);
}
function empty(target, count) {
  const tr = document.createElement('tr'); const td = document.createElement('td');
  td.colSpan = count; td.className = 'empty'; td.textContent = '暂无已保存记录';
  tr.appendChild(td); element(target).appendChild(tr);
}
function detail(id) {
  const link = document.createElement('a');
  if (!/^[1-9][0-9]*$/.test(String(id))) { link.textContent = '—'; return link; }
  link.href = '/api/matches/' + encodeURIComponent(String(id));
  link.textContent = '查看摘要'; link.target = '_blank'; link.rel = 'noopener'; return link;
}
function seconds(value) { return value === null || value === undefined ? '—' : String(value) + ' 秒'; }
async function get(route) {
  const response = await fetch('/api/' + route, {signal:AbortSignal.timeout(10000)});
  const data = await response.json();
  if (!response.ok || data.ok === false) throw Error(data.error || '查询失败');
  return data;
}
try {
  const health = await get('health');
  if(health.ok !== true || health.connected !== true || health.source !== 'mysql') throw Error('未确认 MySQL 连接');
  const [stats, recent, leaders] = await Promise.all([get('stats'), get('matches'), get('leaderboard')]);
  const total = stats.totals;
  for (const [label,value] of [['累计对局',total.total],['胜利',total.wins],['失败',total.losses],['平局',total.draws],['平均波数',total.avg_waves],['平均时长',seconds(total.avg_duration_sec)]]) {
    const card = document.createElement('div'); card.className = 'card';
    const title = document.createElement('span'); title.textContent = label;
    const number = document.createElement('b'); number.textContent = shown(value);
    card.append(title,number); element('cards').appendChild(card);
  }
  for (const match of recent.matches.slice(0,8)) row('recent',[match.id,match.map,results[match.result] || '未知',match.waves,seconds(match.duration_sec),detail(match.id)],2,match.result);
  if(!recent.matches.length) empty('recent',6);
  for (const match of leaders.leaderboard.slice(0,5)) row('leaders',[match.id,match.rank,match.waves,seconds(match.duration_sec)]);
  if(!leaders.leaderboard.length) empty('leaders',4);
  for (const map of stats.by_map.slice(0,5)) row('maps',[map.map,map.games,shown(map.win_pct)+'%']);
  if(!stats.by_map.length) empty('maps',3);
  element('status').textContent = 'MySQL 已连接 · 数据查询成功 · 更新时间：' + new Date().toLocaleString('zh-CN');
} catch(error) {
  element('status').classList.add('failed');
  element('status').textContent = 'MySQL 报告读取失败：' + error.message + '（未生成替代记录）';
}
</script></html>`;

export function createApiServer(pool) {
  const server = http.createServer(async (request, response) => {
    try {
      secureRequest(request);
      const url = new URL(request.url, `http://${request.headers.host}`);
      if (request.method === 'GET' && url.pathname === '/api/health') {
        await pool.execute('SELECT 1 AS connected');
        return send(response, 200, { ok: true, source: 'mysql', connected: true });
      }
      if (request.method === 'POST' && url.pathname === '/api/match') return send(response, 200, await saveMatch(await readBody(request), pool));
      if (request.method === 'GET' && url.pathname === '/api/stats') return send(response, 200, await stats(pool));
      if (request.method === 'GET' && url.pathname === '/api/leaderboard') {
        const [leaderboard] = await pool.execute("SELECT id, `rank`, waves, duration_sec, map, created_at FROM matches WHERE result = 'win' ORDER BY waves DESC, duration_sec ASC LIMIT 20");
        return send(response, 200, { leaderboard });
      }
      if (request.method === 'GET' && url.pathname === '/api/matches') {
        const [matches] = await pool.execute('SELECT id, match_uuid, map, `rank`, result, waves, duration_sec, created_at FROM matches ORDER BY id DESC LIMIT 20');
        return send(response, 200, { matches });
      }
      if (request.method === 'GET' && /^\/api\/matches\/[1-9]\d{0,14}$/.test(url.pathname)) {
        const id = url.pathname.split('/').pop();
        const [matches] = await pool.execute('SELECT id, match_uuid, map, `rank`, result, waves, duration_sec, created_at FROM matches WHERE id = ?', [id]);
        if (!matches.length) throw invalid('对局不存在', 404);
        const [pieces] = await pool.execute('SELECT side, type, color, level, stage, c, r FROM match_pieces WHERE match_id = ? ORDER BY id', [id]);
        const [spells] = await pool.execute('SELECT spell_id, uses FROM match_spells WHERE match_id = ? ORDER BY id', [id]);
        return send(response, 200, { match: matches[0], pieces, spells });
      }
      if (request.method === 'GET' && url.pathname === '/report') return send(response, 200, reportHtml, 'text/html; charset=utf-8');
      if (url.pathname.startsWith('/api/')) throw invalid('接口不存在或方法不允许', 404);
      if (request.method !== 'GET') throw invalid('方法不允许', 405);
      return await staticFile(url, response);
    } catch (error) {
      // 不向网页泄漏 DB 主机、用户、连接参数或 SQL。
      send(response, error.status || 503, { ok: false, error: error.status ? error.message : 'MySQL 数据库操作失败，请检查本地服务与数据库配置' });
    }
  });
  server.requestTimeout = 15000;
  server.headersTimeout = 10000;
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const pool = createPool();
    const port = int(Number(process.env.PORT || 8787), 'PORT', 1024, 65535);
    const server = createApiServer(pool);
    server.listen(port, '127.0.0.1', () => {
      console.log(`MySQL 模式：http://127.0.0.1:${port}/?dataSource=mysql`);
      console.log(`只读报告：http://127.0.0.1:${port}/report`);
    });
    server.on('error', () => { console.error('本地服务监听失败，请检查端口'); process.exitCode = 1; pool.end(); });
    for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => server.close(async () => { await pool.end(); }));
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
