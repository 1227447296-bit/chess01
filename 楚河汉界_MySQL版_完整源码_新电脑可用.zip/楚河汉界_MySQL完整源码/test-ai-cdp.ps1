param([string]$Expression = '', [switch]$Reload, [ValidateRange(1, 600)][int]$TimeoutSeconds = 120, [string]$Method = '', [string]$ParamsJson = '{}')
$ErrorActionPreference = 'Stop'
$targets = (Invoke-WebRequest -UseBasicParsing http://localhost:9222/json -TimeoutSec 5).Content | ConvertFrom-Json
$target = $targets | Where-Object { $_.type -eq 'page' -and $_.url -eq 'http://localhost:8092/' } | Select-Object -First 1
if (-not $target) { throw 'Game root test target not found' }
$ws = New-Object System.Net.WebSockets.ClientWebSocket
$cancel = New-Object System.Threading.CancellationTokenSource
$cancel.CancelAfter($TimeoutSeconds * 1000)
$ct = $cancel.Token
try {
  $ws.ConnectAsync([Uri]$target.webSocketDebuggerUrl, $ct).GetAwaiter().GetResult() | Out-Null
  function Invoke-CDP($id, $method, $params) {
    $msg = @{ id=$id; method=$method; params=$params } | ConvertTo-Json -Depth 20 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($msg)
    $ws.SendAsync([ArraySegment[byte]]::new($bytes), [Net.WebSockets.WebSocketMessageType]::Text, $true, $ct).GetAwaiter().GetResult() | Out-Null
    $buf = New-Object byte[] 1048576
    do {
      $text = New-Object Text.StringBuilder
      do {
        $r = $ws.ReceiveAsync([ArraySegment[byte]]::new($buf), $ct).GetAwaiter().GetResult()
        [void]$text.Append([Text.Encoding]::UTF8.GetString($buf, 0, $r.Count))
      } while (-not $r.EndOfMessage)
      $reply = $text.ToString() | ConvertFrom-Json
    } while ($reply.id -ne $id)
    $reply | ConvertTo-Json -Depth 40 -Compress
    if ($reply.error) { throw ($reply.error | ConvertTo-Json -Compress) }
    if ($reply.result.exceptionDetails) { throw ($reply.result.exceptionDetails | ConvertTo-Json -Depth 10 -Compress) }
  }
  if ($Reload) { Invoke-CDP 1 'Page.reload' @{ignoreCache=$true} }
  if ($Method) { Invoke-CDP 3 $Method ($ParamsJson | ConvertFrom-Json) }
  if ($Expression) { Invoke-CDP 2 'Runtime.evaluate' @{expression=$Expression; awaitPromise=$true; returnByValue=$true} }
} finally { $ws.Dispose(); $cancel.Dispose() }
