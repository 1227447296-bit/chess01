# 可选本地 MySQL 数据源

默认不变：Cloudflare HTTPS 页面继续使用 Worker/D1 `/api/match`；本地默认不上传。MySQL 只保存结束对局摘要，不改变玩法、AI 和段位结算。

## 启动（Node.js 24+ / MySQL 8）

在实验项目目录运行（解压到其它电脑任意目录也可）：

Windows 可使用 `mysql-local.cmd`，它先采用 PATH 中的 Node，再尝试 `%USERPROFILE%\nodejs-v24` 和 `%ProgramFiles%\nodejs`，检查 Node 版本至少 24，并始终切换到脚本所在项目目录以加载该目录 `.env`。它不会自动覆盖配置或替你创建账号：

```bat
mysql-local.cmd install
mysql-local.cmd setup
mysql-local.cmd test
mysql-local.cmd start
```

分别等价于 `npm ci`、`npm run db:setup`、`npm run test:mysql-api`、`npm run start:mysql`。首次应先 install，准备数据库和 `.env` 后再 setup，最后 start；双击 `.cmd` 默认只启动，不自动迁移。跨电脑时安装完整 Node.js 24+（含 npm）和 MySQL 8 即可，不依赖任何本机专用 MySQL 路径或额外构建脚本。

1. `npm ci` 安装锁定依赖。若已装 Node 但未添加 PATH，请先将安装目录加到当前终端 PATH。
2. 在专用数据库为专用非 root 账号授权；服务拒绝缺省账号和 root。不要使用原版或其它项目的库。
3. **仅当 `.env` 不存在时**复制 `.env.example` 为 `.env`，填写专用连接信息。已有 `.env` 请勿覆盖。npm 启动和迁移脚本通过 Node `--env-file-if-exists=.env` 自动加载，环境变量优先；凭据不写入前端。
4. `npm run db:setup`：显式创建表、为早期 MySQL 版本补 UUID/hash 列和唯一索引；不清库、不删除既有记录。初始化账号需要建表/ALTER 权限；运行时仅需 SELECT/INSERT。
5. `npm run start:mysql`：固定绑定 `127.0.0.1`，不接受 HOST 覆盖。端口取 `.env` 的 PORT（示例为 8797；未配置时 8787）。
6. 打开终端显示的网址，例如 `http://127.0.0.1:8797/?dataSource=mysql`。同一个 Node 端口提供游戏与 API，不再额外启动静态服务器。

显式模式也支持页面加载前设置 `window.__CHESS_DATA_SOURCE__='mysql'`。`window.__CHESS_API_URL__` 仅适合保持同源的代理地址，不建议跨端口；服务拒绝跨源请求，无 CORS 通配符。HTTPS 即便配置 mysql 也仍走原 D1 路径。

MySQL 模式左下角常驻状态显示数据源、真实数据库连接检查和保存结果；成功显示 `match_id`，失败显示“未确认写入”并返回 `{ok:false,error}`，不会自动降级或伪造成功。每个 payload 分配 UUID，同一对象重试复用；服务唯一约束和内容 hash 保证重复内容不重复插入，不一致返回 409。

## 通用数据库与专用账号示例

用 MySQL 自带客户端连接你自己的本机 MySQL 服务（端口按实际安装设置，例如 3306；不要依赖项目之外的安装路径）。以下 SQL **由管理员在 MySQL 客户端内手动执行一次**，不属于自动启动动作；占位密码务必替换。只对新建的独立实验库授权，不接触其它数据库：

```sql
CREATE DATABASE IF NOT EXISTS chess_experimental
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'chess_app'@'127.0.0.1'
  IDENTIFIED BY 'REPLACE_WITH_A_NEW_LOCAL_PASSWORD';
GRANT SELECT, INSERT, CREATE, ALTER, INDEX, REFERENCES
  ON chess_experimental.* TO 'chess_app'@'127.0.0.1';
```

若本机 MySQL 的名称解析/账号匹配要求 `localhost`，由管理员将账号 host 配为本机实际匹配的 `localhost`；不要简单扩大为 `%`。账号已存在时不要盲目重建或重置密码。MySQL 必须正在监听 `.env` 指定的 host/port。

在**尚不存在 `.env` 时**复制 `.env.example`，将 MYSQL_HOST/PORT 配为该 MySQL 服务、MYSQL_USER 配为 chess_app、MYSQL_PASSWORD 配为刚设置的新密码、MYSQL_DATABASE 配为 chess_experimental；PORT 是 Node 游戏/API 端口，不是 MYSQL_PORT。示例文件只含占位配置，不含真实凭据。已有 `.env` 不得用示例覆盖。

`npm run db:setup` 成功后可由管理员收回运行不需要的 DDL 权限（未来再次升级前需临时恢复）：

```sql
REVOKE CREATE, ALTER, INDEX, REFERENCES
  ON chess_experimental.* FROM 'chess_app'@'127.0.0.1';
```

此后运行仅需 SELECT/INSERT。不要把 root 账号写入 `.env`。跨电脑导出源码时不要包含 `.env`、node_modules、数据库数据目录或本机专用账号初始化脚本。

## 只读验证 / 截图

- `/report`：中文只读 MySQL 报告，显示真实连接检查、汇总、最近 20 局和胜局排行。
- `GET /api/health`：真实执行 SELECT，不仅检查 HTTP 服务。
- `GET /api/stats`、`GET /api/leaderboard`、`GET /api/matches`、`GET /api/matches/{id}`：只读统计与结束摘要详情；列表限制 20 条。
- `POST /api/match`：严格类型、合法棋种/颜色/计策，等级 0..999、阶段 0..3、格坐标列 0..7/行 0..15，请求体最多 128KiB、每方最多 20 棋子、36 计策。参数化 SQL，父子行在单一事务中提交。

同端口静态白名单只提供 index、js、css、board、assets、piece、font 和 front-home.webp，不提供目录列表或 `.env`/server/schema。Host、Origin、Fetch Metadata 限制阻止跨站访问；这不是公网认证服务，不要将本机端口暴露至互联网。`.assetsignore` 排除服务端、凭据和依赖，不改变原 Cloudflare D1 绑定和表结构。

## 无密钥测试

`npm run test:mysql-api` 使用 fake pool 和真实本地 HTTP 测试：严格输入、参数化语句、commit/rollback、UUID 重试/冲突、健康/统计/详情/报告路由、静态白名单、Host/Origin 限制、数据库失败以及前端失败不假成功与 HTTPS 保持 D1。不加载 `.env`、不需要真实数据库账号。

真实数据库验收需另行 `npm run db:setup`、`npm run start:mysql` 后结束一局并检查状态和报告。自动化测试并不等同于真实 MySQL 验收。
