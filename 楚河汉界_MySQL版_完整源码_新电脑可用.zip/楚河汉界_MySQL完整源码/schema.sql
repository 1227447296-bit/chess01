-- MySQL 8 schema for the optional local API. Existing Cloudflare D1 schema remains unchanged.
CREATE TABLE IF NOT EXISTS matches (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  match_uuid CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL,
  payload_hash CHAR(64) CHARACTER SET ascii NULL,
  map VARCHAR(32) NOT NULL,
  `rank` VARCHAR(32) NOT NULL DEFAULT '',
  result ENUM('win', 'lose', 'draw') NOT NULL,
  waves INT UNSIGNED NOT NULL DEFAULT 0,
  duration_sec INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_matches_uuid (match_uuid),
  INDEX idx_matches_result (result),
  INDEX idx_matches_map (map)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS match_pieces (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  match_id BIGINT UNSIGNED NOT NULL,
  side ENUM('me', 'opp') NOT NULL,
  type VARCHAR(8) NOT NULL,
  color VARCHAR(8) NOT NULL,
  level INT NOT NULL DEFAULT 0,
  stage INT NOT NULL DEFAULT 0,
  c INT NOT NULL DEFAULT 0,
  r INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  INDEX idx_pieces_match (match_id),
  CONSTRAINT fk_pieces_match FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS match_spells (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  match_id BIGINT UNSIGNED NOT NULL,
  spell_id VARCHAR(32) NOT NULL,
  uses INT UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  CONSTRAINT fk_spells_match FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE
) ENGINE=InnoDB;
